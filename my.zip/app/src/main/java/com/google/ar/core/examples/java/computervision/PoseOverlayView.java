package com.google.ar.core.examples.java.computervision;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.google.mlkit.vision.pose.PoseLandmark;

import java.util.ArrayList;
import java.util.List;

public class PoseOverlayView extends View {
  private final Paint jointPaint;
  private final Paint linePaint;
  private final Paint shieldPaint;
  private final Paint thermalPaint;
  private final Paint bodyGatePaint;
  private final Paint eyeGatePaint;
  private final Paint brainGatePaint;
  private final Paint wallPaint;
  private final Paint ripplePaint;
  private final Paint textPaint;
  private final List<PoseLandmark> landmarks = new ArrayList<>();
  private int imageWidth = 1;
  private int imageHeight = 1;
  private boolean showShield = true;
  private boolean showThermal = false;
  private boolean showBodyGate = true;
  private boolean showEyesGate = true;
  private boolean showBrainGate = false;
  private boolean showWall = true;
  private boolean showRipple = true;
  private boolean mirror = false;
  private float thermalIntensity = 0.0f;
  private float eyeColorThreshold = 0.5f;
  private float ambientThreshold = 0.4f;

  public PoseOverlayView(Context context) {
    this(context, null);
  }

  public PoseOverlayView(Context context, @Nullable AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public PoseOverlayView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    jointPaint = new Paint();
    jointPaint.setColor(Color.CYAN);
    jointPaint.setStyle(Paint.Style.FILL);
    jointPaint.setStrokeWidth(8f);
    jointPaint.setAntiAlias(true);

    linePaint = new Paint();
    linePaint.setColor(Color.GREEN);
    linePaint.setStyle(Paint.Style.STROKE);
    linePaint.setStrokeWidth(6f);
    linePaint.setAntiAlias(true);

    shieldPaint = new Paint();
    shieldPaint.setColor(Color.argb(128, 0, 192, 255));
    shieldPaint.setStyle(Paint.Style.STROKE);
    shieldPaint.setStrokeWidth(8f);
    shieldPaint.setAntiAlias(true);

    thermalPaint = new Paint();
    thermalPaint.setStyle(Paint.Style.FILL);
    thermalPaint.setAntiAlias(true);

    bodyGatePaint = new Paint();
    bodyGatePaint.setColor(Color.argb(180, 80, 220, 180));
    bodyGatePaint.setStyle(Paint.Style.STROKE);
    bodyGatePaint.setStrokeWidth(8f);
    bodyGatePaint.setPathEffect(new DashPathEffect(new float[]{20f, 20f}, 0f));
    bodyGatePaint.setAntiAlias(true);

    eyeGatePaint = new Paint();
    eyeGatePaint.setStyle(Paint.Style.STROKE);
    eyeGatePaint.setStrokeWidth(10f);
    eyeGatePaint.setAntiAlias(true);

    brainGatePaint = new Paint();
    brainGatePaint.setColor(Color.argb(150, 180, 80, 220));
    brainGatePaint.setStyle(Paint.Style.STROKE);
    brainGatePaint.setStrokeWidth(14f);
    brainGatePaint.setAntiAlias(true);

    wallPaint = new Paint();
    wallPaint.setColor(Color.argb(90, 60, 140, 220));
    wallPaint.setStyle(Paint.Style.STROKE);
    wallPaint.setStrokeWidth(4f);
    wallPaint.setPathEffect(new DashPathEffect(new float[]{12f, 10f}, 0f));
    wallPaint.setAntiAlias(true);

    ripplePaint = new Paint();
    ripplePaint.setColor(Color.argb(90, 0, 255, 240));
    ripplePaint.setStyle(Paint.Style.STROKE);
    ripplePaint.setStrokeWidth(4f);
    ripplePaint.setAntiAlias(true);

    textPaint = new Paint();
    textPaint.setColor(Color.WHITE);
    textPaint.setTextSize(36f);
    textPaint.setAntiAlias(true);
  }

  public void updatePose(List<PoseLandmark> newLandmarks, int imageWidth, int imageHeight) {
    synchronized (landmarks) {
      landmarks.clear();
      if (newLandmarks != null) {
        landmarks.addAll(newLandmarks);
      }
    }
    this.imageWidth = Math.max(1, imageWidth);
    this.imageHeight = Math.max(1, imageHeight);
    postInvalidate();
  }

  public void setShowShield(boolean showShield) {
    this.showShield = showShield;
    postInvalidate();
  }

  public void setShowThermal(boolean showThermal) {
    this.showThermal = showThermal;
    postInvalidate();
  }

  public void setMirror(boolean mirror) {
    this.mirror = mirror;
    postInvalidate();
  }

  public void setEyesGate(boolean showEyesGate) {
    this.showEyesGate = showEyesGate;
    postInvalidate();
  }

  public void setBodyGate(boolean showBodyGate) {
    this.showBodyGate = showBodyGate;
    postInvalidate();
  }

  public void setBrainGate(boolean showBrainGate) {
    this.showBrainGate = showBrainGate;
    postInvalidate();
  }

  public void setWallEffect(boolean showWall) {
    this.showWall = showWall;
    postInvalidate();
  }

  public void setRippleEffect(boolean showRipple) {
    this.showRipple = showRipple;
    postInvalidate();
  }

  public void setEyeColorThreshold(float eyeColorThreshold) {
    this.eyeColorThreshold = Math.min(1.0f, Math.max(0.0f, eyeColorThreshold));
    postInvalidate();
  }

  public void setAmbientThreshold(float ambientThreshold) {
    this.ambientThreshold = Math.min(1.0f, Math.max(0.0f, ambientThreshold));
    postInvalidate();
  }

  public void setThermalIntensity(float thermalIntensity) {
    this.thermalIntensity = Math.min(1.0f, Math.max(0.0f, thermalIntensity));
    postInvalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    int width = getWidth();
    int height = getHeight();

    if (mirror) {
      canvas.save();
      canvas.scale(-1f, 1f, width / 2f, height / 2f);
    }

    if (showThermal) {
      int alpha = (int) (thermalIntensity * 180);
      int red = Math.min(255, 128 + (int) (thermalIntensity * 127));
      thermalPaint.setColor(Color.argb(alpha, red, 24, 24));
      canvas.drawRect(0, 0, width, height, thermalPaint);
    }

    synchronized (landmarks) {
      if (landmarks.isEmpty()) {
        canvas.drawText("No body tracked yet", 20f, 40f, textPaint);
      } else {
        drawSkeleton(canvas, width, height);
        if (showBodyGate) {
          drawBodyGate(canvas, width, height);
        }
        if (showShield) {
          drawShield(canvas, width, height);
        }
        if (showEyesGate) {
          drawEyeGate(canvas, width, height);
        }
        if (showBrainGate) {
          drawBrainGate(canvas, width, height);
        }
      }
    }

    if (mirror) {
      canvas.restore();
    }
  }

  private void drawSkeleton(Canvas canvas, int width, int height) {
    drawConnection(canvas, PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER);
    drawConnection(canvas, PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_ELBOW);
    drawConnection(canvas, PoseLandmark.LEFT_ELBOW, PoseLandmark.LEFT_WRIST);
    drawConnection(canvas, PoseLandmark.LEFT_WRIST, PoseLandmark.LEFT_INDEX);
    drawConnection(canvas, PoseLandmark.LEFT_WRIST, PoseLandmark.LEFT_THUMB);
    drawConnection(canvas, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_ELBOW);
    drawConnection(canvas, PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_WRIST);
    drawConnection(canvas, PoseLandmark.RIGHT_WRIST, PoseLandmark.RIGHT_INDEX);
    drawConnection(canvas, PoseLandmark.RIGHT_WRIST, PoseLandmark.RIGHT_THUMB);
    drawConnection(canvas, PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_HIP);
    drawConnection(canvas, PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_HIP);
    drawConnection(canvas, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_HIP);
    drawConnection(canvas, PoseLandmark.LEFT_HIP, PoseLandmark.LEFT_KNEE);
    drawConnection(canvas, PoseLandmark.LEFT_KNEE, PoseLandmark.LEFT_ANKLE);
    drawConnection(canvas, PoseLandmark.LEFT_ANKLE, PoseLandmark.LEFT_HEEL);
    drawConnection(canvas, PoseLandmark.LEFT_ANKLE, PoseLandmark.LEFT_FOOT_INDEX);
    drawConnection(canvas, PoseLandmark.RIGHT_HIP, PoseLandmark.RIGHT_KNEE);
    drawConnection(canvas, PoseLandmark.RIGHT_KNEE, PoseLandmark.RIGHT_ANKLE);
    drawConnection(canvas, PoseLandmark.RIGHT_ANKLE, PoseLandmark.RIGHT_HEEL);
    drawConnection(canvas, PoseLandmark.RIGHT_ANKLE, PoseLandmark.RIGHT_FOOT_INDEX);
    drawConnection(canvas, PoseLandmark.LEFT_EYE, PoseLandmark.RIGHT_EYE);
    drawConnection(canvas, PoseLandmark.NOSE, PoseLandmark.LEFT_EYE);
    drawConnection(canvas, PoseLandmark.NOSE, PoseLandmark.RIGHT_EYE);
    drawConnection(canvas, PoseLandmark.LEFT_MOUTH, PoseLandmark.RIGHT_MOUTH);
    drawConnection(canvas, PoseLandmark.LEFT_EAR, PoseLandmark.LEFT_EYE_OUTER);
    drawConnection(canvas, PoseLandmark.RIGHT_EAR, PoseLandmark.RIGHT_EYE_OUTER);

    for (PoseLandmark landmark : landmarks) {
      PointF scaled = toViewPoint(landmark.getPosition());
      canvas.drawCircle(scaled.x, scaled.y, 12f, jointPaint);
    }
  }

  private void drawConnection(Canvas canvas, int startLandmarkType, int endLandmarkType) {
    PoseLandmark start = findLandmark(startLandmarkType);
    PoseLandmark end = findLandmark(endLandmarkType);
    if (start == null || end == null) {
      return;
    }
    PointF startPoint = toViewPoint(start.getPosition());
    PointF endPoint = toViewPoint(end.getPosition());
    canvas.drawLine(startPoint.x, startPoint.y, endPoint.x, endPoint.y, linePaint);
  }

  private PoseLandmark findLandmark(int type) {
    for (PoseLandmark landmark : landmarks) {
      if (landmark.getLandmarkType() == type) {
        return landmark;
      }
    }
    return null;
  }

  private PointF toViewPoint(PointF imagePoint) {
    float scaleX = (float) getWidth() / imageWidth;
    float scaleY = (float) getHeight() / imageHeight;
    return new PointF(imagePoint.x * scaleX, imagePoint.y * scaleY);
  }

  private void drawShield(Canvas canvas, int width, int height) {
    RectF bounds = computeBodyBounds();
    int alpha = 100 + (int) (thermalIntensity * 155);
    int blue = 192 + (int) (thermalIntensity * 60);
    shieldPaint.setColor(Color.argb(alpha, 0, blue, 255));
    shieldPaint.setStrokeWidth(8f + thermalIntensity * 6f);

    if (bounds != null) {
      bounds.inset(-20f, -20f);
      canvas.drawRoundRect(bounds, 60f, 60f, shieldPaint);
      canvas.drawLine(bounds.left, bounds.top, bounds.right, bounds.bottom, shieldPaint);
      canvas.drawLine(bounds.left, bounds.bottom, bounds.right, bounds.top, shieldPaint);
      canvas.drawCircle(bounds.centerX(), bounds.centerY(), Math.max(bounds.width(), bounds.height()) * 0.45f, shieldPaint);
      canvas.drawText("ATOM SPARE SHIELD", bounds.left + 16f, bounds.top + 40f, textPaint);
    } else {
      canvas.drawCircle(width / 2f, height / 2f, Math.min(width, height) * 0.35f, shieldPaint);
      canvas.drawText("ATOM SPARE SHIELD", width * 0.1f, height * 0.12f, textPaint);
    }
  }

  private RectF computeBodyBounds() {
    RectF bounds = null;
    synchronized (landmarks) {
      for (PoseLandmark landmark : landmarks) {
        PointF point = toViewPoint(landmark.getPosition());
        if (bounds == null) {
          bounds = new RectF(point.x, point.y, point.x, point.y);
        } else {
          bounds.left = Math.min(bounds.left, point.x);
          bounds.top = Math.min(bounds.top, point.y);
          bounds.right = Math.max(bounds.right, point.x);
          bounds.bottom = Math.max(bounds.bottom, point.y);
        }
      }
    }
    return bounds;
  }

  private float distance(PointF a, PointF b) {
    return (float) Math.hypot(a.x - b.x, a.y - b.y);
  }
}
