precision mediump float;
varying vec2 v_TexCoord;
uniform sampler2D u_DepthTexture;

void main() {
  float depth = texture2D(u_DepthTexture, v_TexCoord).r;
  gl_FragColor = vec4(vec3(depth), 1.0);
}
