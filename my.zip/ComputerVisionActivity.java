package com.google.ar.core.examples.java.computervision;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.Image;
import android.media.MediaRecorder;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.Config;
import com.google.ar.core.Frame;
import com.google.ar.core.Session;
import com.google.ar.core.TrackingState;
import com.google.ar.core.exceptions.CameraNotAvailableException;
import com.google.ar.core.exceptions.NotYetAvailableException;
import com.google.ar.core.exceptions.UnavailableApkTooOldException;
import com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException;
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException;
import com.google.ar.core.exceptions.UnavailableSdkTooOldException;
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException;
import com.google.ar.core.examples.java.common.helpers.DisplayRotationHelper;
import com.google.ar.core.examples.java.common.helpers.TrackingStateHelper;
import com.google.ar.core.examples.java.common.rendering.BackgroundRenderer;
import android.graphics.Color;
import android.graphics.PointF;
import android.view.View;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.graphics.RectF;
import android.os.SystemClock;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class ComputerVisionActivity extends AppCompatActivity implements GLSurfaceView.Renderer, SensorEventListener {
    private static final String TAG = ComputerVisionActivity.class.getSimpleName();
    private static final int PERMISSION_REQUEST_CODE = 1;
    private static final String[] REQUIRED_PERMISSIONS = new String[] {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
    };

    private GLSurfaceView surfaceView;
    private Session session;
    private BackgroundRenderer backgroundRenderer;
    private DisplayRotationHelper displayRotationHelper;
    private final TrackingStateHelper trackingStateHelper = new TrackingStateHelper(this);

    private TextView statusText;
    private TextView killCountText;
    private TextView noiseMeterText;
    private TextView sensorStatus;
    private ListView bodyPartsListView;
    private PlayerView playerView;
    private Button playPauseButton;
    private Button stopPlaybackButton;
    private SeekBar speedSeekBar;
    private TextView speedLabel;
    private PoseOverlayView overlayView;
    private Switch shieldSwitch;
    private Switch thermalSwitch;
    private Switch mirrorSwitch;
    private Switch audioGateSwitch;
    private Switch eyesGateSwitch;
    private Switch bodyGateSwitch;
    private Switch brainGateSwitch;
    private Switch wallEffectSwitch;
    private Switch rippleEffectSwitch;
    private Switch publicSafeModeSwitch;
    private SeekBar thresholdSeekBar;
    private SeekBar eyeThresholdSeekBar;
    private SeekBar ambientThresholdSeekBar;
    private TextView thresholdValueText;
    private TextView eyeThresholdText;
    private TextView ambientThresholdText;

    private ArrayAdapter<String> bodyPartsAdapter;
    private final List<String> bodyPartStates = new ArrayList<>();
    private static final List<Integer> BODY_LANDMARK_TYPES = Arrays.asList(
            PoseLandmark.NOSE,
            PoseLandmark.LEFT_EYE_INNER,
            PoseLandmark.LEFT_EYE,
            PoseLandmark.LEFT_EYE_OUTER,
            PoseLandmark.RIGHT_EYE_INNER,
            PoseLandmark.RIGHT_EYE,
            PoseLandmark.RIGHT_EYE_OUTER,
            PoseLandmark.LEFT_EAR,
            PoseLandmark.RIGHT_EAR,
            PoseLandmark.LEFT_MOUTH,
            PoseLandmark.RIGHT_MOUTH,
            PoseLandmark.LEFT_SHOULDER,
            PoseLandmark.RIGHT_SHOULDER,
            PoseLandmark.LEFT_ELBOW,
            PoseLandmark.RIGHT_ELBOW,
            PoseLandmark.LEFT_WRIST,
            PoseLandmark.RIGHT_WRIST,
            PoseLandmark.LEFT_PINKY,
            PoseLandmark.RIGHT_PINKY,
            PoseLandmark.LEFT_INDEX,
            PoseLandmark.RIGHT_INDEX,
            PoseLandmark.LEFT_THUMB,
            PoseLandmark.RIGHT_THUMB,
            PoseLandmark.LEFT_HIP,
            PoseLandmark.RIGHT_HIP,
            PoseLandmark.LEFT_KNEE,
            PoseLandmark.RIGHT_KNEE,
            PoseLandmark.LEFT_ANKLE,
            PoseLandmark.RIGHT_ANKLE,
            PoseLandmark.LEFT_HEEL,
            PoseLandmark.RIGHT_HEEL,
            PoseLandmark.LEFT_FOOT_INDEX,
            PoseLandmark.RIGHT_FOOT_INDEX
    );

    private static final List<String> BODY_PART_LABELS = Arrays.asList(
            "Nose",
            "Left Eye Inner",
            "Left Eye",
            "Left Eye Outer",
            "Right Eye Inner",
            "Right Eye",
            "Right Eye Outer",
            "Left Ear",
            "Right Ear",
            "Left Mouth",
            "Right Mouth",
            "Left Shoulder",
            "Right Shoulder",
            "Left Elbow",
            "Right Elbow",
            "Left Wrist",
            "Right Wrist",
            "Left Pinky",
            "Right Pinky",
            "Left Index",
            "Right Index",
            "Left Thumb",
            "Right Thumb",
            "Left Hip",
            "Right Hip",
            "Left Knee",
            "Right Knee",
            "Left Ankle",
            "Right Ankle",
            "Left Heel",
            "Right Heel",
            "Left Foot Index",
            "Right Foot Index"
    );

    private PoseDetector poseDetector;
    private ExecutorService backgroundExecutor;
    private boolean installRequested = false;

    private ExoPlayer exoPlayer;
    private boolean isPlayerPrepared = false;

    private AudioRecord audioRecord;
    private AudioTrack audioTrack;
    private Thread audioThread;
    private boolean isPassthroughActive = false;
    private static final int SAMPLE_RATE = 44100;
    private int audioBufferSize;

    private int killCount = 0;
    private static final int THRESHOLD = 5;
    private float audioGain = 1.0f;
    private float currentPitch = 1.0f;
    private boolean showShieldOverlay = true;
    private boolean showThermalOverlay = false;
    private boolean mirrorMode = false;
    private boolean audioGateEnabled = true;
    private boolean eyesGateEnabled = true;
    private boolean bodyGateEnabled = true;
    private boolean brainGateEnabled = false;
    private boolean wallEffectEnabled = true;
    private boolean rippleEffectEnabled = true;
    private boolean publicSafeModeEnabled = false;
    private float noiseThresholdDb = -25f;
    private float eyeColorThreshold = 0.5f;
    private float ambientThreshold = 0.4f;
    private int latestImageWidth = 1;
    private int latestImageHeight = 1;
    private float latestNoiseDb = -160f;
    private PointF lastNosePosition;
    private final Map<Integer, PointF> lastLandmarkPositions = new HashMap<>();
    private long lastKillNotificationTime = 0;
    private SensorManager sensorManager;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surfaceView = findViewById(R.id.surfaceview);
        overlayView = findViewById(R.id.overlayView);
        statusText = findViewById(R.id.statusText);
        killCountText = findViewById(R.id.killCountText);
        noiseMeterText = findViewById(R.id.noiseMeterText);
        sensorStatus = findViewById(R.id.sensorStatus);
        bodyPartsListView = findViewById(R.id.bodyPartsListView);
        playerView = findViewById(R.id.playerView);
        playPauseButton = findViewById(R.id.btnPlayPause);
        stopPlaybackButton = findViewById(R.id.btnStopPlayback);
        speedSeekBar = findViewById(R.id.seekSpeed);
        speedLabel = findViewById(R.id.speedLabel);
        shieldSwitch = findViewById(R.id.switchShieldOverlay);
        thermalSwitch = findViewById(R.id.switchThermalOverlay);
        mirrorSwitch = findViewById(R.id.switchMirrorMode);
        audioGateSwitch = findViewById(R.id.switchAudioGate);
        eyesGateSwitch = findViewById(R.id.switchEyesGate);
        bodyGateSwitch = findViewById(R.id.switchBodyGate);
        brainGateSwitch = findViewById(R.id.switchBrainGate);
        wallEffectSwitch = findViewById(R.id.switchWallEffect);
        rippleEffectSwitch = findViewById(R.id.switchRippleEffect);
        publicSafeModeSwitch = findViewById(R.id.switchPublicSafe);
        thresholdSeekBar = findViewById(R.id.seekThreshold);
        eyeThresholdSeekBar = findViewById(R.id.seekEyeThreshold);
        ambientThresholdSeekBar = findViewById(R.id.seekAmbientThreshold);
        thresholdValueText = findViewById(R.id.thresholdValueText);
        eyeThresholdText = findViewById(R.id.eyeThresholdText);
        ambientThresholdText = findViewById(R.id.ambientThresholdText);

        displayRotationHelper = new DisplayRotationHelper(this);
        backgroundRenderer = new BackgroundRenderer();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        initializeBodyParts();
        setupButtons();
        initPoseDetector();
        initProtectionControls();
        initExoPlayer();
        checkPermissions();

        surfaceView.setPreserveEGLContextOnPause(true);
        surfaceView.setEGLContextClientVersion(2);
        surfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        surfaceView.setRenderer(this);
        surfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    private void initializeBodyParts() {
        for (String label : BODY_PART_LABELS) {
            bodyPartStates.add(label + ": waiting for pose...");
        }
        bodyPartsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bodyPartStates);
        bodyPartsListView.setAdapter(bodyPartsAdapter);
    }

    private void initPoseDetector() {
        PoseDetectorOptions options = new PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
                .build();
        poseDetector = PoseDetection.getClient(options);
        backgroundExecutor = Executors.newSingleThreadExecutor();
    }

    private void initExoPlayer() {
        try {
            exoPlayer = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(exoPlayer);
            MediaItem mediaItem = MediaItem.fromUri("https://storage.googleapis.com/exoplayer-test-media-0/play.mp3");
            exoPlayer.setMediaItem(mediaItem);
            exoPlayer.prepare();
            exoPlayer.addListener(new Player.Listener() {
                @Override
                public void onPlaybackStateChanged(int playbackState) {
                    if (playbackState == Player.STATE_READY) {
                        isPlayerPrepared = true;
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Failed initializing ExoPlayer", e);
            statusText.setText("Player unavailable on device");
        }
    }

    private void setupButtons() {
        findViewById(R.id.btnFocusKill).setOnClickListener(v -> highFocusKill());
        findViewById(R.id.btnAmbientKill).setOnClickListener(v -> ambientKill());
        findViewById(R.id.btnThreshold).setOnClickListener(v -> thresholdBankKill());
        findViewById(R.id.btnPassthrough).setOnClickListener(v -> toggleLiveMic());
        findViewById(R.id.btnGainUp).setOnClickListener(v -> increaseGain());
        playPauseButton.setOnClickListener(v -> togglePlayback());
        stopPlaybackButton.setOnClickListener(v -> stopPlayback());
        speedSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float speed = 0.5f + progress * 0.05f;
                speedLabel.setText(String.format("Speed: %.1fx", speed));
                if (exoPlayer != null) {
                    exoPlayer.setPlaybackParameters(new PlaybackParameters(speed));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void initProtectionControls() {
        shieldSwitch.setChecked(showShieldOverlay);
        thermalSwitch.setChecked(showThermalOverlay);
        mirrorSwitch.setChecked(mirrorMode);
        audioGateSwitch.setChecked(audioGateEnabled);
        eyesGateSwitch.setChecked(eyesGateEnabled);
        bodyGateSwitch.setChecked(bodyGateEnabled);
        brainGateSwitch.setChecked(brainGateEnabled);
        wallEffectSwitch.setChecked(wallEffectEnabled);
        rippleEffectSwitch.setChecked(rippleEffectEnabled);
        publicSafeModeSwitch.setChecked(publicSafeModeEnabled);
        thresholdSeekBar.setMax(60);
        thresholdSeekBar.setProgress((int) (noiseThresholdDb + 60));
        eyeThresholdSeekBar.setMax(100);
        eyeThresholdSeekBar.setProgress((int) (eyeColorThreshold * 100));
        ambientThresholdSeekBar.setMax(100);
        ambientThresholdSeekBar.setProgress((int) (ambientThreshold * 100));
        updateThresholdLabel();
        updateEyeThresholdLabel();
        updateAmbientThresholdLabel();

        shieldSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            showShieldOverlay = isChecked;
            overlayView.setShowShield(isChecked);
        });
        thermalSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            showThermalOverlay = isChecked;
            overlayView.setShowThermal(isChecked);
        });
        mirrorSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mirrorMode = isChecked;
            surfaceView.setScaleX(isChecked ? -1f : 1f);
            overlayView.setMirror(isChecked);
        });
        audioGateSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            audioGateEnabled = isChecked;
            overlayView.setAmbientThreshold(ambientThreshold);
            statusText.setText(isChecked ? "Audio protection gate enabled" : "Audio protection gate disabled");
        });
        eyesGateSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            eyesGateEnabled = isChecked;
            overlayView.setEyesGate(isChecked);
            statusText.setText(isChecked ? "Eyes gate enabled" : "Eyes gate disabled");
        });
        bodyGateSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            bodyGateEnabled = isChecked;
            overlayView.setBodyGate(isChecked);
            statusText.setText(isChecked ? "Body gate enabled" : "Body gate disabled");
        });
        brainGateSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            brainGateEnabled = isChecked;
            overlayView.setBrainGate(isChecked);
            statusText.setText(isChecked ? "Brain gate enabled" : "Brain gate disabled");
        });
        wallEffectSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            wallEffectEnabled = isChecked;
            overlayView.setWallEffect(isChecked);
            statusText.setText(isChecked ? "AR wall enabled" : "AR wall disabled");
        });
        rippleEffectSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            rippleEffectEnabled = isChecked;
            overlayView.setRippleEffect(isChecked);
            statusText.setText(isChecked ? "Ripples enabled" : "Ripples disabled");
        });
        publicSafeModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            publicSafeModeEnabled = isChecked;
            if (isChecked) {
                eyesGateSwitch.setChecked(true);
                bodyGateSwitch.setChecked(true);
                brainGateSwitch.setChecked(true);
                wallEffectSwitch.setChecked(true);
                rippleEffectSwitch.setChecked(true);
                statusText.setText("Public safety mode: full protection active");
            } else {
                statusText.setText("Public safety mode disabled");
            }
        });
        eyeThresholdSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                eyeColorThreshold = progress / 100f;
                updateEyeThresholdLabel();
                overlayView.setEyeColorThreshold(eyeColorThreshold);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        ambientThresholdSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ambientThreshold = progress / 100f;
                updateAmbientThresholdLabel();
                overlayView.setAmbientThreshold(ambientThreshold);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        thresholdSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                noiseThresholdDb = progress - 60;
                updateThresholdLabel();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void updateThresholdLabel() {
        thresholdValueText.setText("Noise threshold: " + (int) noiseThresholdDb + " dB");
    }

    private void updateEyeThresholdLabel() {
        eyeThresholdText.setText(String.format("Eye color threshold: %.2f", eyeColorThreshold));
    }

    private void updateAmbientThresholdLabel() {
        ambientThresholdText.setText(String.format("Ambient threshold: %.2f", ambientThreshold));
    }

    private void togglePlayback() {
        if (exoPlayer == null || !isPlayerPrepared) {
            statusText.setText("Player not ready");
            return;
        }
        if (exoPlayer.isPlaying()) {
            exoPlayer.pause();
            playPauseButton.setText("Play");
            statusText.setText("Playback paused");
        } else {
            exoPlayer.play();
            playPauseButton.setText("Pause");
            statusText.setText("Playback started");
        }
    }

    private void stopPlayback() {
        if (exoPlayer == null) {
            return;
        }
        exoPlayer.pause();
        exoPlayer.seekTo(0);
        playPauseButton.setText("Play");
        statusText.setText("Playback stopped");
    }

    private void updateHeadMotionStatus(PoseLandmark nose, PoseLandmark leftEye, PoseLandmark rightEye) {
        if (nose == null) {
            return;
        }
        PointF nosePoint = nose.getPosition();
        if (lastNosePosition != null) {
            float motion = distance(nosePoint, lastNosePosition);
            if (motion > 20f) {
                if (SystemClock.elapsedRealtime() - lastKillNotificationTime > 1400) {
                    notifyKillEvent("Head surge detected");
                } else {
                    statusText.setText("Shield active: head movement detected");
                }
            }
        }
        lastNosePosition = new PointF(nosePoint.x, nosePoint.y);
        if (leftEye != null && rightEye != null) {
            float eyeGap = distance(leftEye.getPosition(), rightEye.getPosition());
            if (eyeGap > 50f) {
                statusText.setText("Eyes moving: protection edge engaged");
            }
        }
    }

    private float distance(PointF a, PointF b) {
        return (float) Math.hypot(a.x - b.x, a.y - b.y);
    }

    private boolean hasPermissions() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void checkPermissions() {
        if (!hasPermissions()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSION_REQUEST_CODE);
        } else {
            initializeSession();
        }
    }

    private void initializeSession() {
        if (session != null) {
            return;
        }

        try {
            switch (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                case INSTALL_REQUESTED:
                    installRequested = true;
                    return;
                case INSTALLED:
                    break;
            }

            session = new Session(this);
            Config config = new Config(session);
            config.setFocusMode(Config.FocusMode.AUTO);
            config.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE);
            if (session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) {
                config.setDepthMode(Config.DepthMode.AUTOMATIC);
            }
            session.configure(config);
            setSessionCameraTexture();
        } catch (UnavailableArcoreNotInstalledException
                | UnavailableUserDeclinedInstallationException
                | UnavailableApkTooOldException
                | UnavailableSdkTooOldException
                | UnavailableDeviceNotCompatibleException e) {
            Log.e(TAG, "ARCore not available", e);
            statusText.setText("ARCore unavailable: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize AR session", e);
            statusText.setText("Unable to start AR session.");
        }
    }

    private void setSessionCameraTexture() {
        if (session != null && backgroundRenderer != null && backgroundRenderer.getTextureId() != -1) {
            session.setCameraTextureName(backgroundRenderer.getTextureId());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayRotationHelper.onResume();
        if (!hasPermissions()) {
            checkPermissions();
            return;
        }
        initializeSession();
        if (session != null) {
            try {
                session.resume();
                surfaceView.onResume();
                registerSensors();
                statusText.setText("AR body tracking ready");
            } catch (CameraNotAvailableException e) {
                Log.e(TAG, "Camera not available during onResume", e);
                statusText.setText("Camera unavailable. Restart app.");
                session = null;
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopAudioCapture();
        displayRotationHelper.onPause();
        if (session != null) {
            session.pause();
        }
        surfaceView.onPause();
        unregisterSensors();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != PERMISSION_REQUEST_CODE) {
            return;
        }
        if (hasPermissions()) {
            initializeSession();
            statusText.setText("Permissions granted. AR ready.");
        } else {
            statusText.setText("Camera and microphone permissions are required for AR protection.");
        }
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        try {
            backgroundRenderer.createOnGlThread(this);
            setSessionCameraTexture();
        } catch (IOException e) {
            throw new RuntimeException("Failed to create background renderer", e);
        }
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        displayRotationHelper.onSurfaceChanged(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        if (session == null) {
            return;
        }

        try {
            displayRotationHelper.updateSessionIfNeeded(session);
            Frame frame = session.update();
            backgroundRenderer.draw(frame);

            Camera camera = frame.getCamera();
            trackingStateHelper.updateKeepScreenOnFlag(camera.getTrackingState());
            updateTrackingStatus(camera);
            if (camera.getTrackingState() == TrackingState.TRACKING) {
                detectPose(frame);
            }
        } catch (CameraNotAvailableException e) {
            statusText.setText("Camera not available.");
            Log.e(TAG, "Camera not available", e);
        }
    }

    private void updateTrackingStatus(Camera camera) {
        String text = "Tracking: " + camera.getTrackingState();
        if (camera.getTrackingState() != TrackingState.TRACKING) {
            text += " - " + TrackingStateHelper.getTrackingFailureReasonString(camera);
        }
        final String status = text;
        runOnUiThread(() -> statusText.setText(status));
    }

    private void detectPose(Frame frame) {
        final Image[] mediaImage = new Image[1];
        try {
            mediaImage[0] = frame.acquireCameraImage();
            latestImageWidth = mediaImage[0].getWidth();
            latestImageHeight = mediaImage[0].getHeight();
            int rotation = displayRotationHelper.getCameraSensorToDisplayRotation(session.getCameraConfig().getCameraId());
            InputImage inputImage = InputImage.fromMediaImage(mediaImage[0], rotation);
            poseDetector.process(inputImage)
                    .addOnSuccessListener(this::onPoseDetected)
                    .addOnFailureListener(e -> Log.e(TAG, "Pose detection failed", e))
                    .addOnCompleteListener(backgroundExecutor, task -> {
                        if (mediaImage[0] != null) {
                            mediaImage[0].close();
                        }
                    });
        } catch (NotYetAvailableException e) {
            if (mediaImage[0] != null) {
                mediaImage[0].close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed acquiring camera image", e);
            if (mediaImage[0] != null) {
                mediaImage[0].close();
            }
        }
    }

    private void onPoseDetected(Pose pose) {
        if (pose == null) {
            return;
        }
        runOnUiThread(() -> {
            updateBodyPartStates(pose);
            overlayView.setThermalIntensity(Math.min(1f, Math.max(0f, (latestNoiseDb + 60f) / 60f)));
            overlayView.setAmbientThreshold(ambientThreshold);
            overlayView.setEyeColorThreshold(eyeColorThreshold);
            overlayView.setEyesGate(eyesGateEnabled);
            overlayView.setBodyGate(bodyGateEnabled);
            overlayView.setBrainGate(brainGateEnabled);
            overlayView.setWallEffect(wallEffectEnabled);
            overlayView.setRippleEffect(rippleEffectEnabled);
            overlayView.updatePose(pose.getAllPoseLandmarks(), latestImageWidth, latestImageHeight);
            detectBodyMotion(pose);
            updateHeadMotionStatus(pose.getPoseLandmark(PoseLandmark.NOSE), pose.getPoseLandmark(PoseLandmark.LEFT_EYE), pose.getPoseLandmark(PoseLandmark.RIGHT_EYE));
            bodyPartsAdapter.notifyDataSetChanged();
            sensorStatus.setText("Pose landmarks: " + pose.getAllPoseLandmarks().size());
        });
    }

    private String computeVectorText(PoseLandmark start, PoseLandmark end, String label) {
        if (start == null || end == null) {
            return label + " not tracked";
        }
        PointF startPoint = start.getPosition();
        PointF endPoint = end.getPosition();
        return String.format("%.2f, %.2f", endPoint.x - startPoint.x, endPoint.y - startPoint.y);
    }

    private String computeMidpointText(PoseLandmark a, PoseLandmark b, String label) {
        if (a == null || b == null) {
            return label + " not tracked";
        }
        PointF aPoint = a.getPosition();
        PointF bPoint = b.getPosition();
        return String.format("%.2f, %.2f", (aPoint.x + bPoint.x) / 2f, (aPoint.y + bPoint.y) / 2f);
    }

    private String computeAngleText(PoseLandmark a, PoseLandmark b, PoseLandmark c, String label) {
        if (a == null || b == null || c == null) {
            return label + " not tracked";
        }
        PointF aPoint = a.getPosition();
        PointF bPoint = b.getPosition();
        PointF cPoint = c.getPosition();
        float abx = aPoint.x - bPoint.x;
        float aby = aPoint.y - bPoint.y;
        float cbx = cPoint.x - bPoint.x;
        float cby = cPoint.y - bPoint.y;
        float dot = abx * cbx + aby * cby;
        float magAB = (float) Math.sqrt(abx * abx + aby * aby);
        float magCB = (float) Math.sqrt(cbx * cbx + cby * cby);
        if (magAB == 0f || magCB == 0f) {
            return label + " not tracked";
        }
        float angle = (float) Math.toDegrees(Math.acos(Math.max(-1f, Math.min(1f, dot / (magAB * magCB)))));
        return String.format("%.1f°", angle);
    }

    private String computeDistanceText(PoseLandmark a, PoseLandmark b, String label) {
        if (a == null || b == null) {
            return label + " not tracked";
        }
        PointF aPoint = a.getPosition();
        PointF bPoint = b.getPosition();
        float dx = aPoint.x - bPoint.x;
        float dy = aPoint.y - bPoint.y;
        return String.format("%.2f px", (float) Math.sqrt(dx * dx + dy * dy));
    }

    private String formatPoint(PoseLandmark landmark, String label) {
        if (landmark == null) {
            return label + " not tracked";
        }
        PointF point = landmark.getPosition();
        return String.format("%.2f, %.2f", point.x, point.y);
    }

    private void updateBodyPartStates(Pose pose) {
        for (int i = 0; i < BODY_LANDMARK_TYPES.size(); i++) {
            int landmarkType = BODY_LANDMARK_TYPES.get(i);
            PoseLandmark landmark = pose.getPoseLandmark(landmarkType);
            setBodyPartState(i, buildLandmarkState(landmark, BODY_PART_LABELS.get(i)));
        }
    }

    private String buildLandmarkState(PoseLandmark landmark, String label) {
        if (landmark == null) {
            return "signal lost";
        }
        PointF point = landmark.getPosition();
        return String.format("%.1f, %.1f @ %.2f", point.x, point.y, landmark.getInFrameLikelihood());
    }

    private void detectBodyMotion(Pose pose) {
        float motionSum = 0f;
        for (int landmarkType : BODY_LANDMARK_TYPES) {
            PoseLandmark landmark = pose.getPoseLandmark(landmarkType);
            if (landmark == null) {
                continue;
            }
            PointF current = landmark.getPosition();
            PointF previous = lastLandmarkPositions.get(landmarkType);
            if (previous != null) {
                motionSum += distance(current, previous);
            }
            lastLandmarkPositions.put(landmarkType, new PointF(current.x, current.y));
        }

        if (motionSum > 240f && SystemClock.elapsedRealtime() - lastKillNotificationTime > 1200) {
            notifyKillEvent("AtomShield burst activated");
        }
    }

    private void notifyKillEvent(String reason) {
        killCount++;
        lastKillNotificationTime = SystemClock.elapsedRealtime();
        updateKillUI();
        statusText.setText("⚡ " + reason + " — KILLS: " + killCount);
    }

    private void setBodyPartState(int index, String value) {
        if (index >= 0 && index < bodyPartStates.size()) {
            bodyPartStates.set(index, BODY_PART_LABELS.get(index) + ": " + value);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            sensorStatus.setText(String.format("Accel: %.2f %.2f %.2f", event.values[0], event.values[1], event.values[2]));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // no-op
    }

    private void registerSensors() {
        if (sensorManager != null) {
            sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_UI);
        }
    }

    private void unregisterSensors() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    private void highFocusKill() {
        killCount++;
        updateKillUI();
        statusText.setText("🎯 HIGH FOCUS KILL");
    }

    private void ambientKill() {
        statusText.setText("🌫️ AMBIENT KILL");
    }

    private void thresholdBankKill() {
        statusText.setText("💥 THRESHOLD BANK KILL");
    }

    private void toggleLiveMic() {
        if (isPassthroughActive) {
            stopAudioCapture();
        } else {
            startAudioCapture();
        }
        isPassthroughActive = !isPassthroughActive;
        statusText.setText(isPassthroughActive ? "🛡️ Microphone passthrough active" : "🔇 Microphone stopped");
    }

    private void increaseGain() {
        audioGain += 0.1f;
        statusText.setText("Gain: " + String.format("%.1f", audioGain));
    }

    private void startAudioCapture() {
        if (audioRecord != null) {
            return;
        }

        audioBufferSize = Math.max(AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), SAMPLE_RATE);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, audioBufferSize);
        audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, audioBufferSize, AudioTrack.MODE_STREAM);

        audioRecord.startRecording();
        audioTrack.play();

        audioThread = new Thread(() -> {
            short[] buffer = new short[audioBufferSize / 2];
            while (audioRecord != null && audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                int read = audioRecord.read(buffer, 0, buffer.length);
                if (read > 0) {
                    double max = 0;
                    for (int i = 0; i < read; i++) {
                        max = Math.max(max, Math.abs(buffer[i]));
                    }
                    final double db = 20 * Math.log10(Math.max(max / 32767.0, 0.000001));
                    latestNoiseDb = (float) db;
                    final float targetVolume = audioGateEnabled && latestNoiseDb > noiseThresholdDb ? 0.18f : 1.0f;
                    audioTrack.setVolume(targetVolume);
                    runOnUiThread(() -> {
                        noiseMeterText.setText(String.format("Noise: %.1f dB", db));
                        if (audioGateEnabled && latestNoiseDb > noiseThresholdDb) {
                            statusText.setText("Audio gate active: reducing external noise");
                        }
                    });
                    audioTrack.write(buffer, 0, read);
                }
            }
        }, "AudioCaptureThread");
        audioThread.start();
    }

    private void stopAudioCapture() {
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
        if (audioTrack != null) {
            audioTrack.stop();
            audioTrack.release();
            audioTrack = null;
        }
        if (audioThread != null) {
            audioThread.interrupt();
            audioThread = null;
        }
        runOnUiThread(() -> noiseMeterText.setText("Noise: -∞ dB"));
    }

    private void updateKillUI() {
        killCountText.setText("Kills: " + killCount + " / " + THRESHOLD);
    }
}
