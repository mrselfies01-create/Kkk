using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/TV/Vignetting")]
public class CameraFilterPack_TV_Vignetting : MonoBehaviour
{
	public Shader SCShader;

	private Material SCMaterial;

	private Texture2D Vignette;

	[Range(0f, 1f)]
	public float Vignetting = 1f;

	[Range(0f, 1f)]
	public float VignettingFull;

	[Range(0f, 1f)]
	public float VignettingDirt;

	public Color VignettingColor = new Color(0f, 0f, 0f, 1f);

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/TV_Vignetting");
		ref Texture2D vignette = ref Vignette;
		Object obj = Resources.Load("CameraFilterPack_TV_Vignetting1");
		vignette = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			material.SetTexture("Vignette", (Texture)(object)Vignette);
			material.SetFloat("_Vignetting", Vignetting);
			material.SetFloat("_Vignetting2", VignettingFull);
			material.SetColor("_VignettingColor", VignettingColor);
			material.SetFloat("_VignettingDirt", VignettingDirt);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
