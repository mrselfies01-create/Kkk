using UnityEngine;

public class AmbientSystem : MonoBehaviour
{
	public AudioClip[] Dark;

	public AudioClip[] Light;

	private int index;

	public bool ambientOn;

	private AudioSource audioComponent;

	private bool darkLastPlayed;

	private bool dark;

	public Button3D lightButton;

	public Button3D darkButton;

	private void Start()
	{
		audioComponent = ((Component)this).GetComponent<AudioSource>();
		((Behaviour)audioComponent).enabled = false;
	}

	public void DarkPressed()
	{
		if (ambientOn && dark)
		{
			ambientOn = false;
		}
		else
		{
			ambientOn = true;
			dark = true;
		}
		if (dark)
		{
			lightButton.pressed = false;
		}
	}

	public void LightPressed()
	{
		if (ambientOn && !dark)
		{
			ambientOn = false;
		}
		else
		{
			ambientOn = true;
			dark = false;
		}
		if (!dark)
		{
			darkButton.pressed = false;
		}
	}

	private void Update()
	{
		if (ambientOn)
		{
			((Behaviour)audioComponent).enabled = true;
		}
		else
		{
			((Behaviour)audioComponent).enabled = false;
		}
		if (!((Behaviour)audioComponent).enabled)
		{
			return;
		}
		bool flag = false;
		if (dark && !darkLastPlayed)
		{
			flag = true;
		}
		else if (!dark && darkLastPlayed)
		{
			flag = true;
		}
		if (audioComponent.isPlaying && !flag)
		{
			return;
		}
		if (dark)
		{
			index++;
			if (index >= Dark.Length)
			{
				index = 0;
			}
			audioComponent.clip = Dark[index];
			audioComponent.Play();
			darkLastPlayed = true;
		}
		else
		{
			index++;
			if (index >= Light.Length)
			{
				index = 0;
			}
			audioComponent.clip = Light[index];
			audioComponent.Play();
			darkLastPlayed = false;
		}
	}
}
