using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Drawing/EnhancedComics")]
public class CameraFilterPack_Drawing_EnhancedComics : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	private Material SCMaterial;

	[Range(0f, 1f)]
	public float DotSize = 0.15f;

	[Range(0f, 1f)]
	public float _ColorR = 0.9f;

	[Range(0f, 1f)]
	public float _ColorG = 0.4f;

	[Range(0f, 1f)]
	public float _ColorB = 0.4f;

	[Range(0f, 1f)]
	public float _Blood = 0.5f;

	[Range(0f, 1f)]
	public float _SmoothStart = 0.02f;

	[Range(0f, 1f)]
	public float _SmoothEnd = 0.1f;

	public Color ColorRGB = new Color(1f, 0f, 0f);

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/Drawing_EnhancedComics");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_DotSize", DotSize);
			material.SetFloat("_ColorR", _ColorR);
			material.SetFloat("_ColorG", _ColorG);
			material.SetFloat("_ColorB", _ColorB);
			material.SetFloat("_Blood", _Blood);
			material.SetColor("_ColorRGB", ColorRGB);
			material.SetFloat("_SmoothStart", _SmoothStart);
			material.SetFloat("_SmoothEnd", _SmoothEnd);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
