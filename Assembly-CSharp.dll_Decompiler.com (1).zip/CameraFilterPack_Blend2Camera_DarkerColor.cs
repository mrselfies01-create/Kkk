using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Blend 2 Camera/DarkerColor")]
public class CameraFilterPack_Blend2Camera_DarkerColor : MonoBehaviour
{
	private string ShaderName = "CameraFilterPack/Blend2Camera_DarkerColor";

	public Shader SCShader;

	public Camera Camera2;

	private float TimeX = 1f;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	[Range(0f, 1f)]
	public float SwitchCameraToCamera2;

	[Range(0f, 1f)]
	public float BlendFX = 0.5f;

	private RenderTexture Camera2tex;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
		SCShader = Shader.Find(ShaderName);
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			if ((Object)(object)Camera2 != (Object)null)
			{
				material.SetTexture("_MainTex2", (Texture)(object)Camera2tex);
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value", BlendFX);
			material.SetFloat("_Value2", SwitchCameraToCamera2);
			material.SetVector("_ScreenResolution", new Vector4((float)((Texture)sourceTexture).width, (float)((Texture)sourceTexture).height, 0f, 0f));
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void OnValidate()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
	}

	private void Update()
	{
	}

	private void OnEnable()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
	}

	private void OnDisable()
	{
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2.targetTexture = null;
		}
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
