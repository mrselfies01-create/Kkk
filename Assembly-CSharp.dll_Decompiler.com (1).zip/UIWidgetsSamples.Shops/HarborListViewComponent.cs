using UIWidgets;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class HarborListViewComponent : ListViewItem
{
	[SerializeField]
	public Text Name;

	[SerializeField]
	public Text SellPrice;

	[SerializeField]
	public Text BuyPrice;

	[SerializeField]
	public Text AvailableBuyCount;

	[SerializeField]
	public Text AvailableSellCount;

	[SerializeField]
	private CenteredSlider Count;

	private HarborOrderLine OrderLine;

	protected override void Start()
	{
		((UnityEvent<int>)Count.OnValuesChange).AddListener((UnityAction<int>)ChangeCount);
		((UIBehaviour)this).Start();
	}

	public override void OnMove(AxisEventData eventData)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		MoveDirection moveDir = eventData.moveDir;
		if ((int)moveDir != 0)
		{
			if ((int)moveDir == 2)
			{
				Count.Value++;
			}
			else
			{
				base.OnMove(eventData);
			}
		}
		else
		{
			Count.Value--;
		}
	}

	public void SetData(HarborOrderLine orderLine)
	{
		OrderLine = orderLine;
		Name.text = OrderLine.Item.Name;
		BuyPrice.text = OrderLine.BuyPrice.ToString();
		SellPrice.text = OrderLine.SellPrice.ToString();
		AvailableBuyCount.text = OrderLine.BuyCount.ToString();
		AvailableSellCount.text = OrderLine.SellCount.ToString();
		Count.Value = 0;
		Count.LimitMin = -OrderLine.SellCount;
		Count.LimitMax = OrderLine.BuyCount;
	}

	private void ChangeCount(int value)
	{
		OrderLine.Count = value;
	}

	protected override void OnDestroy()
	{
		if ((Object)(object)Count != (Object)null)
		{
			((UnityEvent<int>)Count.OnValuesChange).RemoveListener((UnityAction<int>)ChangeCount);
		}
	}
}
