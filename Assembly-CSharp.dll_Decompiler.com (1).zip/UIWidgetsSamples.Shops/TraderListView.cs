using UIWidgets;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class TraderListView : ListViewCustom<TraderListViewComponent, JRPGOrderLine>
{
	protected override void SetData(TraderListViewComponent component, JRPGOrderLine item)
	{
		component.SetData(item);
	}

	protected override void HighlightColoring(TraderListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		base.HighlightColoring(component);
		((Graphic)component.Name).color = HighlightedColor;
		((Graphic)component.Price).color = HighlightedColor;
		((Graphic)component.AvailableCount).color = HighlightedColor;
	}

	protected override void SelectColoring(TraderListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		base.SelectColoring(component);
		((Graphic)component.Name).color = base.SelectedColor;
		((Graphic)component.Price).color = base.SelectedColor;
		((Graphic)component.AvailableCount).color = base.SelectedColor;
	}

	protected override void DefaultColoring(TraderListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		base.DefaultColoring(component);
		((Graphic)component.Name).color = base.DefaultColor;
		((Graphic)component.Price).color = base.DefaultColor;
		((Graphic)component.AvailableCount).color = base.DefaultColor;
	}
}
