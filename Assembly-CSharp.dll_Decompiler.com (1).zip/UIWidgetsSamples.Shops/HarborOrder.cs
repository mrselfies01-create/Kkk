using System;
using System.Collections.Generic;
using System.Linq;
using UIWidgets;

namespace UIWidgetsSamples.Shops;

public class HarborOrder : IOrder
{
	private List<HarborOrderLine> OrderLines;

	public HarborOrder(ObservableList<HarborOrderLine> orderLines)
	{
		OrderLines = orderLines.Where((HarborOrderLine x) => x.Count != 0).ToList();
	}

	public List<IOrderLine> GetOrderLines()
	{
		return OrderLines.Convert((Converter<HarborOrderLine, IOrderLine>)((HarborOrderLine x) => x));
	}

	public int OrderLinesCount()
	{
		return OrderLines.Count;
	}

	public int Total()
	{
		return OrderLines.Sum((HarborOrderLine x) => x.Count * ((x.Count <= 0) ? x.SellPrice : x.BuyPrice));
	}
}
