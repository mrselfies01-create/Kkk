using System;
using UnityEngine;

namespace UIWidgetsSamples.Shops;

[Serializable]
public class HarborOrderLine : IOrderLine
{
	[SerializeField]
	private Item item;

	[SerializeField]
	public int BuyPrice;

	[SerializeField]
	public int SellPrice;

	[SerializeField]
	public int BuyCount;

	[SerializeField]
	public int SellCount;

	[SerializeField]
	private int count;

	public Item Item
	{
		get
		{
			return item;
		}
		set
		{
			item = value;
		}
	}

	public int Count
	{
		get
		{
			return count;
		}
		set
		{
			count = value;
		}
	}

	public HarborOrderLine(Item newItem, int buyPrice, int sellPrice, int buyCount, int sellCount)
	{
		item = newItem;
		BuyPrice = buyPrice;
		SellPrice = sellPrice;
		BuyCount = buyCount;
		SellCount = sellCount;
	}
}
