using System.Collections.Generic;
using UIWidgets;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class JRPGShop : MonoBehaviour
{
	private Trader Shop;

	[SerializeField]
	private TraderListView ShopItems;

	[SerializeField]
	private Button BuyButton;

	[SerializeField]
	private Text ShopTotal;

	private Trader Player;

	[SerializeField]
	private TraderListView PlayerItems;

	[SerializeField]
	private Button SellButton;

	[SerializeField]
	private Text PlayerMoney;

	[SerializeField]
	private Text PlayerTotal;

	private void Start()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected O, but got Unknown
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected O, but got Unknown
		Shop = new Trader();
		Player = new Trader();
		Init();
		((UnityEvent)BuyButton.onClick).AddListener(new UnityAction(Buy));
		((UnityEvent)SellButton.onClick).AddListener(new UnityAction(Sell));
		Shop.OnItemsChange += UpdateShopItems;
		Player.OnItemsChange += UpdatePlayerItems;
		Player.OnMoneyChange += UpdatePlayerMoneyInfo;
		UpdateShopItems();
		UpdatePlayerItems();
		UpdatePlayerMoneyInfo();
	}

	public void Init()
	{
		Shop.Money = -1;
		Shop.PriceFactor = 1f;
		Shop.Inventory.Clear();
		List<Item> list = new List<Item>();
		list.Add(new Item("Sword", 10));
		list.Add(new Item("Short Sword", 5));
		list.Add(new Item("Long Sword", 5));
		list.Add(new Item("Knife", -1));
		list.Add(new Item("Dagger", -1));
		list.Add(new Item("Hammer", -1));
		list.Add(new Item("Shield", -1));
		list.Add(new Item("Leather Armor", 3));
		list.Add(new Item("Ring", 2));
		list.Add(new Item("Bow", -1));
		list.Add(new Item("Crossbow", -1));
		list.Add(new Item("HP Potion", -1));
		list.Add(new Item("Mana Potion", -1));
		list.Add(new Item("HP UP", 10));
		list.Add(new Item("Mana UP", 10));
		List<Item> items = list;
		Shop.Inventory.AddRange(items);
		Player.Money = 2000;
		Player.PriceFactor = 0.5f;
		Player.Inventory.Clear();
		list = new List<Item>();
		list.Add(new Item("Stick", 1));
		list.Add(new Item("Sword", 1));
		list.Add(new Item("HP Potion", 5));
		list.Add(new Item("Mana Potion", 5));
		List<Item> items2 = list;
		Player.Inventory.AddRange(items2);
	}

	public void UpdateShopTotal()
	{
		JRPGOrder jRPGOrder = new JRPGOrder(ShopItems.DataSource);
		ShopTotal.text = jRPGOrder.Total().ToString();
	}

	public void UpdatePlayerTotal()
	{
		JRPGOrder jRPGOrder = new JRPGOrder(PlayerItems.DataSource);
		PlayerTotal.text = jRPGOrder.Total().ToString();
	}

	private ObservableList<JRPGOrderLine> CreateOrderLines(Trader trader)
	{
		return trader.Inventory.Convert((Item item) => new JRPGOrderLine(item, Prices.GetPrice(item, trader.PriceFactor)));
	}

	private void UpdateShopItems()
	{
		ShopItems.DataSource = CreateOrderLines(Shop);
	}

	private void UpdatePlayerItems()
	{
		PlayerItems.DataSource = CreateOrderLines(Player);
	}

	private void UpdatePlayerMoneyInfo()
	{
		PlayerMoney.text = Player.Money.ToString();
	}

	private void Buy()
	{
		JRPGOrder jRPGOrder = new JRPGOrder(ShopItems.DataSource);
		if (Player.CanBuy(jRPGOrder))
		{
			Shop.Sell(jRPGOrder);
			Player.Buy(jRPGOrder);
		}
		else
		{
			string message = $"Not enough money to buy items. Available: {Player.Money}; Required: {jRPGOrder.Total()}";
			Notify.Template("NotifyTemplateSimple").Show(message, 3f, null, null, null, null, NotifySequence.First, 0.3f, clearSequence: true);
		}
	}

	private void Sell()
	{
		JRPGOrder jRPGOrder = new JRPGOrder(PlayerItems.DataSource);
		if (Shop.CanBuy(jRPGOrder))
		{
			Shop.Buy(jRPGOrder);
			Player.Sell(jRPGOrder);
		}
		else
		{
			string message = $"Not enough money in shop to sell items. Available: {Shop.Money}; Required: {jRPGOrder.Total()}";
			Notify.Template("NotifyTemplateSimple").Show(message, 3f, null, null, null, null, NotifySequence.First, 0.3f, clearSequence: true);
		}
	}

	private void OnDestroy()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		if ((Object)(object)BuyButton != (Object)null)
		{
			((UnityEvent)BuyButton.onClick).RemoveListener(new UnityAction(Buy));
		}
		if ((Object)(object)SellButton != (Object)null)
		{
			((UnityEvent)SellButton.onClick).RemoveListener(new UnityAction(Sell));
		}
		if (Shop != null)
		{
			Shop.OnItemsChange -= UpdateShopItems;
		}
		if (Player != null)
		{
			Player.OnItemsChange -= UpdatePlayerItems;
			Player.OnMoneyChange -= UpdatePlayerMoneyInfo;
		}
	}
}
