using System;
using UnityEngine;

namespace UIWidgetsSamples.Shops;

[Serializable]
public class JRPGOrderLine : IOrderLine
{
	[SerializeField]
	private Item item;

	[SerializeField]
	public int Price;

	[SerializeField]
	private int count;

	public Item Item
	{
		get
		{
			return item;
		}
		set
		{
			item = value;
		}
	}

	public int Count
	{
		get
		{
			return count;
		}
		set
		{
			count = value;
		}
	}

	public JRPGOrderLine(Item newItem, int newPrice)
	{
		item = newItem;
		Price = newPrice;
	}
}
