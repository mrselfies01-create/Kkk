namespace UIWidgetsSamples.Shops;

public interface IOrderLine
{
	Item Item { get; set; }

	int Count { get; set; }
}
