using System;
using System.Collections.Generic;
using System.Linq;
using UIWidgets;

namespace UIWidgetsSamples.Shops;

public class JRPGOrder : IOrder
{
	private List<JRPGOrderLine> OrderLines;

	public JRPGOrder(ObservableList<JRPGOrderLine> orderLines)
	{
		OrderLines = orderLines.Where((JRPGOrderLine x) => x.Count != 0).ToList();
	}

	public List<IOrderLine> GetOrderLines()
	{
		return OrderLines.Convert((Converter<JRPGOrderLine, IOrderLine>)((JRPGOrderLine x) => x));
	}

	public int OrderLinesCount()
	{
		return OrderLines.Count;
	}

	public int Total()
	{
		return OrderLines.Sum((JRPGOrderLine x) => x.Count * x.Price);
	}
}
