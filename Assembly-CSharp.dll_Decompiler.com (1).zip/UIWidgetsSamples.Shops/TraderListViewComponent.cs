using UIWidgets;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class TraderListViewComponent : ListViewItem
{
	[SerializeField]
	public Text Name;

	[SerializeField]
	public Text Price;

	[SerializeField]
	public Text AvailableCount;

	[SerializeField]
	private Spinner Count;

	private JRPGOrderLine OrderLine;

	protected override void Start()
	{
		((UnityEvent<int>)Count.onValueChangeInt).AddListener((UnityAction<int>)ChangeCount);
		((UIBehaviour)this).Start();
	}

	public override void OnMove(AxisEventData eventData)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		MoveDirection moveDir = eventData.moveDir;
		if ((int)moveDir != 0)
		{
			if ((int)moveDir == 2)
			{
				Count.Value++;
			}
			else
			{
				base.OnMove(eventData);
			}
		}
		else
		{
			Count.Value--;
		}
	}

	public void SetData(JRPGOrderLine orderLine)
	{
		OrderLine = orderLine;
		Name.text = OrderLine.Item.Name;
		Price.text = OrderLine.Price.ToString();
		AvailableCount.text = ((OrderLine.Item.Count != -1) ? OrderLine.Item.Count.ToString() : "∞");
		Count.Value = 0;
		Count.Min = 0;
		Count.Max = ((OrderLine.Item.Count != -1) ? OrderLine.Item.Count : 9999);
	}

	private void ChangeCount(int count)
	{
		OrderLine.Count = count;
	}

	protected override void OnDestroy()
	{
		if ((Object)(object)Count != (Object)null)
		{
			((UnityEvent<int>)Count.onValueChangeInt).RemoveListener((UnityAction<int>)ChangeCount);
		}
	}
}
