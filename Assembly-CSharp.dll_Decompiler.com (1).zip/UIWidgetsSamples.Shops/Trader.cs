using UIWidgets;

namespace UIWidgetsSamples.Shops;

public class Trader
{
	private int money;

	private ObservableList<Item> inventory = new ObservableList<Item>();

	public float PriceFactor = 1f;

	public bool DeleteIfEmpty = true;

	public int Money
	{
		get
		{
			return money;
		}
		set
		{
			if (money == -1)
			{
				MoneyChanged();
				return;
			}
			money = value;
			MoneyChanged();
		}
	}

	public ObservableList<Item> Inventory
	{
		get
		{
			return inventory;
		}
		set
		{
			if (inventory != null)
			{
				inventory.OnChange -= ItemsChanged;
			}
			inventory = value;
			if (inventory != null)
			{
				inventory.OnChange += ItemsChanged;
			}
			ItemsChanged();
		}
	}

	public event OnItemsChange OnItemsChange;

	public event OnMoneyChange OnMoneyChange;

	public Trader(bool deleteIfEmpty = true)
	{
		DeleteIfEmpty = deleteIfEmpty;
		inventory.OnChange += ItemsChanged;
	}

	private void ItemsChanged()
	{
		if (this.OnItemsChange != null)
		{
			this.OnItemsChange();
		}
	}

	private void MoneyChanged()
	{
		if (this.OnMoneyChange != null)
		{
			this.OnMoneyChange();
		}
	}

	public void Sell(IOrder order)
	{
		if (order.OrderLinesCount() != 0)
		{
			Inventory.BeginUpdate();
			order.GetOrderLines().ForEach(SellItem);
			Inventory.EndUpdate();
			Money += order.Total();
		}
	}

	private void SellItem(IOrderLine orderLine)
	{
		int count = orderLine.Count;
		orderLine.Item.Count -= count;
		if (DeleteIfEmpty && orderLine.Item.Count == 0)
		{
			Inventory.Remove(orderLine.Item);
		}
	}

	public void Buy(IOrder order)
	{
		if (order.OrderLinesCount() != 0)
		{
			Inventory.BeginUpdate();
			order.GetOrderLines().ForEach(BuyItem);
			Inventory.EndUpdate();
			Money -= order.Total();
		}
	}

	private void BuyItem(IOrderLine orderLine)
	{
		Item item = Inventory.Find((Item x) => x.Name == orderLine.Item.Name);
		int count = orderLine.Count;
		if (item == null)
		{
			Inventory.Add(new Item(orderLine.Item.Name, count));
		}
		else
		{
			item.Count += count;
		}
	}

	public bool CanBuy(IOrder order)
	{
		return Money == -1 || Money >= order.Total();
	}
}
