using UIWidgets;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class HarborListView : ListViewCustom<HarborListViewComponent, HarborOrderLine>
{
	protected override void SetData(HarborListViewComponent component, HarborOrderLine item)
	{
		component.SetData(item);
	}

	protected override void HighlightColoring(HarborListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		base.HighlightColoring(component);
		((Graphic)component.Name).color = HighlightedColor;
		((Graphic)component.BuyPrice).color = HighlightedColor;
		((Graphic)component.SellPrice).color = HighlightedColor;
		((Graphic)component.AvailableBuyCount).color = HighlightedColor;
		((Graphic)component.AvailableSellCount).color = HighlightedColor;
	}

	protected override void SelectColoring(HarborListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		base.SelectColoring(component);
		((Graphic)component.Name).color = base.SelectedColor;
		((Graphic)component.BuyPrice).color = base.SelectedColor;
		((Graphic)component.SellPrice).color = base.SelectedColor;
		((Graphic)component.AvailableBuyCount).color = base.SelectedColor;
		((Graphic)component.AvailableSellCount).color = base.SelectedColor;
	}

	protected override void DefaultColoring(HarborListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		base.DefaultColoring(component);
		((Graphic)component.Name).color = base.DefaultColor;
		((Graphic)component.BuyPrice).color = base.DefaultColor;
		((Graphic)component.SellPrice).color = base.DefaultColor;
		((Graphic)component.AvailableBuyCount).color = base.DefaultColor;
		((Graphic)component.AvailableSellCount).color = base.DefaultColor;
	}
}
