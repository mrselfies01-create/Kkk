namespace UIWidgetsSamples.Shops;

public delegate void OnMoneyChange();
