using System.ComponentModel;
using UIWidgets;

namespace UIWidgetsSamples.Shops;

public class Item : IObservable, INotifyPropertyChanged
{
	public string Name;

	private int count;

	public int Count
	{
		get
		{
			return count;
		}
		set
		{
			if (count == -1)
			{
				Changed();
				return;
			}
			count = value;
			Changed();
		}
	}

	public event OnChange OnChange;

	public event PropertyChangedEventHandler PropertyChanged;

	public Item(string name, int count)
	{
		Name = name;
		Count = count;
	}

	private void Changed()
	{
		if (this.PropertyChanged != null)
		{
			this.PropertyChanged(this, null);
		}
		if (this.OnChange != null)
		{
			this.OnChange();
		}
	}
}
