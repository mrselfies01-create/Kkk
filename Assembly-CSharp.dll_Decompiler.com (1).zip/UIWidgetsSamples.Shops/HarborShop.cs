using System.Collections.Generic;
using UIWidgets;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgetsSamples.Shops;

public class HarborShop : MonoBehaviour
{
	private Trader Harbor;

	[SerializeField]
	private HarborListView TradeView;

	[SerializeField]
	private Text TradeTotal;

	[SerializeField]
	private Button BuyButton;

	private Trader Player;

	[SerializeField]
	private Text PlayerMoney;

	private void Start()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected O, but got Unknown
		Harbor = new Trader(deleteIfEmpty: false);
		Player = new Trader(deleteIfEmpty: false);
		Init();
		((UnityEvent)BuyButton.onClick).AddListener(new UnityAction(Trade));
		Harbor.OnItemsChange += UpdateTraderItems;
		Player.OnItemsChange += UpdateTraderItems;
		Player.OnMoneyChange += UpdatePlayerMoneyInfo;
		UpdateTraderItems();
		UpdatePlayerMoneyInfo();
	}

	public void Init()
	{
		Harbor.Money = -1;
		Harbor.PriceFactor = 1f;
		Harbor.Inventory.Clear();
		List<Item> list = new List<Item>();
		list.Add(new Item("Wood", 100));
		list.Add(new Item("Wheat", 30));
		list.Add(new Item("Fruits", 0));
		list.Add(new Item("Sugar", 20));
		list.Add(new Item("Metal", 40));
		list.Add(new Item("Cotton", 0));
		list.Add(new Item("Silver", 25));
		list.Add(new Item("Gold", 55));
		list.Add(new Item("Cocoa", 10));
		list.Add(new Item("Coffee", 7));
		list.Add(new Item("Tobacco", 20));
		List<Item> items = list;
		Harbor.Inventory.AddRange(items);
		Player.Money = 5000;
		Player.PriceFactor = 0.5f;
		Player.Inventory.Clear();
		list = new List<Item>();
		list.Add(new Item("Wood", 50));
		list.Add(new Item("Cocoa", 100));
		list.Add(new Item("Metal", 20));
		list.Add(new Item("Sugar", 10));
		List<Item> items2 = list;
		Player.Inventory.AddRange(items2);
	}

	public void UpdateTotal()
	{
		HarborOrder harborOrder = new HarborOrder(TradeView.DataSource);
		TradeTotal.text = harborOrder.Total().ToString();
	}

	private ObservableList<HarborOrderLine> CreateOrderLines(Trader harbor, Trader player)
	{
		return harbor.Inventory.Convert(delegate(Item item)
		{
			Item item2 = player.Inventory.Find((Item x) => x.Name == item.Name);
			return new HarborOrderLine(item, Prices.GetPrice(item, harbor.PriceFactor), Prices.GetPrice(item, player.PriceFactor), item.Count, item2?.Count ?? 0);
		});
	}

	private void UpdateTraderItems()
	{
		TradeView.DataSource = CreateOrderLines(Harbor, Player);
	}

	private void UpdatePlayerMoneyInfo()
	{
		PlayerMoney.text = Player.Money.ToString();
	}

	private void Trade()
	{
		HarborOrder harborOrder = new HarborOrder(TradeView.DataSource);
		if (Player.CanBuy(harborOrder))
		{
			Harbor.Sell(harborOrder);
			Player.Buy(harborOrder);
		}
		else
		{
			string message = $"Not enough money to buy items. Available: {Player.Money}; Required: {harborOrder.Total()}";
			Notify.Template("NotifyTemplateSimple").Show(message, 3f, null, null, null, null, NotifySequence.First, 0.3f, clearSequence: true);
		}
	}

	private void OnDestroy()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		if ((Object)(object)BuyButton != (Object)null)
		{
			((UnityEvent)BuyButton.onClick).RemoveListener(new UnityAction(Trade));
		}
		if (Harbor != null)
		{
			Harbor.OnItemsChange -= UpdateTraderItems;
		}
		if (Player != null)
		{
			Player.OnItemsChange -= UpdateTraderItems;
			Player.OnMoneyChange -= UpdatePlayerMoneyInfo;
		}
	}
}
