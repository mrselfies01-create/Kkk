namespace UIWidgetsSamples.Shops;

public delegate void OnItemsChange();
