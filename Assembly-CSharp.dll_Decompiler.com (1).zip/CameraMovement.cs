using UnityEngine;

public class CameraMovement : MonoBehaviour
{
	private Animator anim;

	private UltimateBloom bloom;

	public GameObject particleEffects;

	public bool VisualsOn;

	public CameraFilterPack_TV_Horror horrorEffect;

	public CameraFilterPack_Real_VHS vhsEffect;

	public CameraFilterPack_TV_80 tv80sEffect;

	public DoorController door;

	public UIScript ui;

	public float speed = 5f;

	public float rotationspeed = 1f;

	public int shot;

	private void Start()
	{
		anim = ((Component)this).GetComponent<Animator>();
		bloom = ((Component)this).GetComponentInChildren<UltimateBloom>();
		particleEffects.SetActive(false);
		((Behaviour)bloom).enabled = false;
	}

	public void ShowVisual(bool show)
	{
		anim.SetBool("AtDoor", show);
	}

	public void StartScanVisual()
	{
		if (ui.ScanVisuals)
		{
			((Behaviour)horrorEffect).enabled = true;
			((Behaviour)vhsEffect).enabled = true;
			((Behaviour)tv80sEffect).enabled = true;
		}
	}

	public void StopScanVisual()
	{
		((Behaviour)horrorEffect).enabled = false;
		((Behaviour)vhsEffect).enabled = false;
		((Behaviour)tv80sEffect).enabled = false;
	}

	public void TriggerDoor()
	{
		door.ToggleDoor();
		((Behaviour)bloom).enabled = true;
		particleEffects.SetActive(true);
	}

	public void DoorDoneOpening()
	{
		anim.SetTrigger("DoorDoneOpening");
	}

	public void DoorDoneClosing()
	{
		((Behaviour)bloom).enabled = false;
		particleEffects.SetActive(false);
	}
}
