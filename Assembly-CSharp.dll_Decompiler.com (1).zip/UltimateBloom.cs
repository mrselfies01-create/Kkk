using System;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class UltimateBloom : MonoBehaviour
{
	public enum BloomQualityPreset
	{
		Optimized,
		Standard,
		HighVisuals,
		Custom
	}

	public enum BloomSamplingQuality
	{
		VerySmallKernel,
		SmallKernel,
		MediumKernel,
		LargeKernel,
		LargerKernel,
		VeryLargeKernel
	}

	public enum BloomScreenBlendMode
	{
		Screen,
		Add
	}

	public enum HDRBloomMode
	{
		Auto,
		On,
		Off
	}

	public enum BlurSampleCount
	{
		Nine,
		Seventeen,
		Thirteen,
		TwentyThree,
		TwentySeven,
		ThrirtyOne,
		NineCurve,
		FourSimple
	}

	public enum FlareRendering
	{
		Sharp,
		Blurred,
		MoreBlurred
	}

	public enum SimpleSampleCount
	{
		Four,
		Nine,
		FourCurve,
		ThirteenTemporal,
		ThirteenTemporalCurve
	}

	public enum FlareType
	{
		Single,
		Double
	}

	public enum BloomIntensityManagement
	{
		FilmicCurve,
		Threshold
	}

	private enum FlareStripeType
	{
		Anamorphic,
		Star,
		DiagonalUpright,
		DiagonalUpleft
	}

	public enum AnamorphicDirection
	{
		Horizontal,
		Vertical
	}

	public enum BokehFlareQuality
	{
		Low,
		Medium,
		High,
		VeryHigh
	}

	public enum BlendMode
	{
		ADD,
		SCREEN
	}

	public enum SamplingMode
	{
		Fixed,
		HeightRelative
	}

	public enum FlareBlurQuality
	{
		Fast,
		Normal,
		High
	}

	public enum FlarePresets
	{
		ChoosePreset,
		GhostFast,
		Ghost1,
		Ghost2,
		Ghost3,
		Bokeh1,
		Bokeh2,
		Bokeh3
	}

	private delegate void BlurFunction(RenderTexture source, RenderTexture destination, float horizontalBlur, float verticalBlur, RenderTexture additiveTexture, BlurSampleCount sampleCount, Color tint, float intensity);

	public float m_SamplingMinHeight = 400f;

	public float[] m_ResSamplingPixelCount = new float[6];

	public SamplingMode m_SamplingMode;

	public BlendMode m_BlendMode;

	public float m_ScreenMaxIntensity;

	public BloomQualityPreset m_QualityPreset;

	public HDRBloomMode m_HDR;

	public BloomScreenBlendMode m_ScreenBlendMode = BloomScreenBlendMode.Add;

	public float m_BloomIntensity = 1f;

	public float m_BloomThreshhold = 0.5f;

	public Color m_BloomThreshholdColor = Color.white;

	public int m_DownscaleCount = 5;

	public BloomIntensityManagement m_IntensityManagement;

	public float[] m_BloomIntensities;

	public Color[] m_BloomColors;

	public bool[] m_BloomUsages;

	[SerializeField]
	public DeluxeFilmicCurve m_BloomCurve = new DeluxeFilmicCurve();

	private int m_LastDownscaleCount = 5;

	public bool m_UseLensFlare;

	public float m_FlareTreshold = 0.8f;

	public float m_FlareIntensity = 0.25f;

	public Color m_FlareTint0 = new Color(0.5372549f, 0.32156864f, 0f);

	public Color m_FlareTint1 = new Color(0f, 21f / 85f, 42f / 85f);

	public Color m_FlareTint2 = new Color(24f / 85f, 0.5921569f, 0f);

	public Color m_FlareTint3 = new Color(38f / 85f, 7f / 51f, 0f);

	public Color m_FlareTint4 = new Color(0.47843137f, 0.34509805f, 0f);

	public Color m_FlareTint5 = new Color(0.5372549f, 0.2784314f, 0f);

	public Color m_FlareTint6 = new Color(0.38039216f, 0.54509807f, 0f);

	public Color m_FlareTint7 = new Color(8f / 51f, 0.5568628f, 0f);

	public float m_FlareGlobalScale = 1f;

	public Vector4 m_FlareScales = new Vector4(1f, 0.6f, 0.5f, 0.4f);

	public Vector4 m_FlareScalesNear = new Vector4(1f, 0.8f, 0.6f, 0.5f);

	public Texture2D m_FlareMask;

	public FlareRendering m_FlareRendering = FlareRendering.Blurred;

	public FlareType m_FlareType = FlareType.Double;

	public Texture2D m_FlareShape;

	public FlareBlurQuality m_FlareBlurQuality = FlareBlurQuality.High;

	private BokehRenderer m_FlareSpriteRenderer;

	private Mesh[] m_BokehMeshes;

	public bool m_UseBokehFlare;

	public float m_BokehScale = 0.4f;

	public BokehFlareQuality m_BokehFlareQuality = BokehFlareQuality.Medium;

	public bool m_UseAnamorphicFlare;

	public float m_AnamorphicFlareTreshold = 0.8f;

	public float m_AnamorphicFlareIntensity = 1f;

	public int m_AnamorphicDownscaleCount = 3;

	public int m_AnamorphicBlurPass = 2;

	private int m_LastAnamorphicDownscaleCount;

	private RenderTexture[] m_AnamorphicUpscales;

	public float[] m_AnamorphicBloomIntensities;

	public Color[] m_AnamorphicBloomColors;

	public bool[] m_AnamorphicBloomUsages;

	public bool m_AnamorphicSmallVerticalBlur = true;

	public AnamorphicDirection m_AnamorphicDirection;

	public float m_AnamorphicScale = 3f;

	public bool m_UseStarFlare;

	public float m_StarFlareTreshol = 0.8f;

	public float m_StarFlareIntensity = 1f;

	public float m_StarScale = 2f;

	public int m_StarDownscaleCount = 3;

	public int m_StarBlurPass = 2;

	private int m_LastStarDownscaleCount;

	private RenderTexture[] m_StarUpscales;

	public float[] m_StarBloomIntensities;

	public Color[] m_StarBloomColors;

	public bool[] m_StarBloomUsages;

	public bool m_UseLensDust;

	public float m_DustIntensity = 1f;

	public Texture2D m_DustTexture;

	public float m_DirtLightIntensity = 5f;

	public BloomSamplingQuality m_DownsamplingQuality;

	public BloomSamplingQuality m_UpsamplingQuality;

	public bool m_TemporalStableDownsampling = true;

	public bool m_InvertImage;

	private Material m_FlareMaterial;

	private Shader m_FlareShader;

	private Material m_SamplingMaterial;

	private Shader m_SamplingShader;

	private Material m_CombineMaterial;

	private Shader m_CombineShader;

	private Material m_BrightpassMaterial;

	private Shader m_BrightpassShader;

	private Material m_FlareMaskMaterial;

	private Shader m_FlareMaskShader;

	private Material m_MixerMaterial;

	private Shader m_MixerShader;

	private Material m_FlareBokehMaterial;

	private Shader m_FlareBokehShader;

	public bool m_DirectDownSample;

	public bool m_DirectUpsample;

	public bool m_UiShowBloomScales;

	public bool m_UiShowAnamorphicBloomScales;

	public bool m_UiShowStarBloomScales;

	public bool m_UiShowHeightSampling;

	public bool m_UiShowBloomSettings;

	public bool m_UiShowSampling;

	public bool m_UiShowIntensity;

	public bool m_UiShowOptimizations;

	public bool m_UiShowLensDirt;

	public bool m_UiShowLensFlare;

	public bool m_UiShowAnamorphic;

	public bool m_UiShowStar;

	private RenderTexture[] m_DownSamples;

	private RenderTexture[] m_UpSamples;

	private RenderTextureFormat m_Format;

	private bool[] m_BufferUsage;

	private RenderTexture m_LastBloomUpsample;

	private void DestroyMaterial(Material mat)
	{
		if (Object.op_Implicit((Object)(object)mat))
		{
			Object.DestroyImmediate((Object)(object)mat);
			mat = null;
		}
	}

	private void LoadShader(ref Material material, ref Shader shader, string shaderPath)
	{
		if (!((Object)(object)shader != (Object)null))
		{
			shader = Shader.Find(shaderPath);
			if ((Object)(object)shader == (Object)null)
			{
				Debug.LogError((object)("Shader not found: " + shaderPath));
			}
			else if (!shader.isSupported)
			{
				Debug.LogError((object)("Shader contains error: " + shaderPath + "\n Maybe include path? Try rebuilding the shader."));
			}
			else
			{
				material = CreateMaterial(shader);
			}
		}
	}

	public void CreateMaterials()
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		int num = 8;
		if (m_BloomIntensities == null || m_BloomIntensities.Length < num)
		{
			m_BloomIntensities = new float[num];
			for (int i = 0; i < 8; i++)
			{
				m_BloomIntensities[i] = 1f;
			}
		}
		if (m_BloomColors == null || m_BloomColors.Length < num)
		{
			m_BloomColors = (Color[])(object)new Color[num];
			for (int j = 0; j < 8; j++)
			{
				ref Color reference = ref m_BloomColors[j];
				reference = Color.white;
			}
		}
		if (m_BloomUsages == null || m_BloomUsages.Length < num)
		{
			m_BloomUsages = new bool[num];
			for (int k = 0; k < 8; k++)
			{
				m_BloomUsages[k] = true;
			}
		}
		if (m_AnamorphicBloomIntensities == null || m_AnamorphicBloomIntensities.Length < num)
		{
			m_AnamorphicBloomIntensities = new float[num];
			for (int l = 0; l < 8; l++)
			{
				m_AnamorphicBloomIntensities[l] = 1f;
			}
		}
		if (m_AnamorphicBloomColors == null || m_AnamorphicBloomColors.Length < num)
		{
			m_AnamorphicBloomColors = (Color[])(object)new Color[num];
			for (int m = 0; m < 8; m++)
			{
				ref Color reference2 = ref m_AnamorphicBloomColors[m];
				reference2 = Color.white;
			}
		}
		if (m_AnamorphicBloomUsages == null || m_AnamorphicBloomUsages.Length < num)
		{
			m_AnamorphicBloomUsages = new bool[num];
			for (int n = 0; n < 8; n++)
			{
				m_AnamorphicBloomUsages[n] = true;
			}
		}
		if (m_StarBloomIntensities == null || m_StarBloomIntensities.Length < num)
		{
			m_StarBloomIntensities = new float[num];
			for (int num2 = 0; num2 < 8; num2++)
			{
				m_StarBloomIntensities[num2] = 1f;
			}
		}
		if (m_StarBloomColors == null || m_StarBloomColors.Length < num)
		{
			m_StarBloomColors = (Color[])(object)new Color[num];
			for (int num3 = 0; num3 < 8; num3++)
			{
				ref Color reference3 = ref m_StarBloomColors[num3];
				reference3 = Color.white;
			}
		}
		if (m_StarBloomUsages == null || m_StarBloomUsages.Length < num)
		{
			m_StarBloomUsages = new bool[num];
			for (int num4 = 0; num4 < 8; num4++)
			{
				m_StarBloomUsages[num4] = true;
			}
		}
		if (m_FlareSpriteRenderer == null && (Object)(object)m_FlareShape != (Object)null && m_UseBokehFlare)
		{
			if (m_FlareSpriteRenderer != null)
			{
				m_FlareSpriteRenderer.Clear(ref m_BokehMeshes);
			}
			m_FlareSpriteRenderer = new BokehRenderer();
		}
		if ((Object)(object)m_SamplingMaterial == (Object)null)
		{
			m_DownSamples = (RenderTexture[])(object)new RenderTexture[GetNeededDownsamples()];
			m_UpSamples = (RenderTexture[])(object)new RenderTexture[m_DownscaleCount];
			m_AnamorphicUpscales = (RenderTexture[])(object)new RenderTexture[m_AnamorphicDownscaleCount];
			m_StarUpscales = (RenderTexture[])(object)new RenderTexture[m_StarDownscaleCount];
		}
		string shaderPath = ((m_FlareType != 0) ? "Hidden/Ultimate/FlareDouble" : "Hidden/Ultimate/FlareSingle");
		LoadShader(ref m_FlareMaterial, ref m_FlareShader, shaderPath);
		LoadShader(ref m_SamplingMaterial, ref m_SamplingShader, "Hidden/Ultimate/Sampling");
		LoadShader(ref m_BrightpassMaterial, ref m_BrightpassShader, "Hidden/Ultimate/BrightpassMask");
		LoadShader(ref m_FlareMaskMaterial, ref m_FlareMaskShader, "Hidden/Ultimate/FlareMask");
		LoadShader(ref m_MixerMaterial, ref m_MixerShader, "Hidden/Ultimate/BloomMixer");
		LoadShader(ref m_FlareBokehMaterial, ref m_FlareBokehShader, "Hidden/Ultimate/FlareMesh");
		bool flag = m_UseLensDust || m_UseLensFlare || m_UseAnamorphicFlare || m_UseStarFlare;
		string shaderPath2 = "Hidden/Ultimate/BloomCombine";
		if (flag)
		{
			shaderPath2 = "Hidden/Ultimate/BloomCombineFlareDirt";
		}
		LoadShader(ref m_CombineMaterial, ref m_CombineShader, shaderPath2);
	}

	private Material CreateMaterial(Shader shader)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Expected O, but got Unknown
		if (!Object.op_Implicit((Object)(object)shader))
		{
			return null;
		}
		Material val = new Material(shader);
		((Object)val).hideFlags = (HideFlags)61;
		return val;
	}

	private void OnDisable()
	{
		ForceShadersReload();
		if (m_FlareSpriteRenderer != null)
		{
			m_FlareSpriteRenderer.Clear(ref m_BokehMeshes);
			m_FlareSpriteRenderer = null;
		}
	}

	public void ForceShadersReload()
	{
		DestroyMaterial(m_FlareMaterial);
		m_FlareMaterial = null;
		m_FlareShader = null;
		DestroyMaterial(m_SamplingMaterial);
		m_SamplingMaterial = null;
		m_SamplingShader = null;
		DestroyMaterial(m_CombineMaterial);
		m_CombineMaterial = null;
		m_CombineShader = null;
		DestroyMaterial(m_BrightpassMaterial);
		m_BrightpassMaterial = null;
		m_BrightpassShader = null;
		DestroyMaterial(m_FlareBokehMaterial);
		m_FlareBokehMaterial = null;
		m_FlareBokehShader = null;
		DestroyMaterial(m_FlareMaskMaterial);
		m_FlareMaskMaterial = null;
		m_FlareMaskShader = null;
		DestroyMaterial(m_MixerMaterial);
		m_MixerMaterial = null;
		m_MixerShader = null;
	}

	private int GetNeededDownsamples()
	{
		int num = Mathf.Max(m_DownscaleCount, m_UseAnamorphicFlare ? m_AnamorphicDownscaleCount : 0);
		num = Mathf.Max(num, m_UseLensFlare ? (GetGhostBokehLayer() + 1) : 0);
		return Mathf.Max(num, m_UseStarFlare ? m_StarDownscaleCount : 0);
	}

	private void ComputeBufferOptimization()
	{
		if (m_BufferUsage == null)
		{
			m_BufferUsage = new bool[m_DownSamples.Length];
		}
		if (m_BufferUsage.Length != m_DownSamples.Length)
		{
			m_BufferUsage = new bool[m_DownSamples.Length];
		}
		for (int i = 0; i < m_BufferUsage.Length; i++)
		{
			m_BufferUsage[i] = false;
		}
		for (int j = 0; j < m_BufferUsage.Length; j++)
		{
			m_BufferUsage[j] = m_BloomUsages[j] || m_BufferUsage[j];
		}
		if (m_UseAnamorphicFlare)
		{
			for (int k = 0; k < m_BufferUsage.Length; k++)
			{
				m_BufferUsage[k] = m_AnamorphicBloomUsages[k] || m_BufferUsage[k];
			}
		}
		if (m_UseStarFlare)
		{
			for (int l = 0; l < m_BufferUsage.Length; l++)
			{
				m_BufferUsage[l] = m_StarBloomUsages[l] || m_BufferUsage[l];
			}
		}
	}

	private int GetGhostBokehLayer()
	{
		if (m_UseBokehFlare && (Object)(object)m_FlareShape != (Object)null)
		{
			if (m_BokehFlareQuality == BokehFlareQuality.VeryHigh)
			{
				return 1;
			}
			if (m_BokehFlareQuality == BokehFlareQuality.High)
			{
				return 2;
			}
			if (m_BokehFlareQuality == BokehFlareQuality.Medium)
			{
				return 3;
			}
			if (m_BokehFlareQuality == BokehFlareQuality.Low)
			{
				return 4;
			}
		}
		return 0;
	}

	private BlurSampleCount GetUpsamplingSize()
	{
		if (m_SamplingMode == SamplingMode.Fixed)
		{
			BlurSampleCount result = BlurSampleCount.ThrirtyOne;
			if (m_UpsamplingQuality == BloomSamplingQuality.VerySmallKernel)
			{
				result = BlurSampleCount.Nine;
			}
			else if (m_UpsamplingQuality == BloomSamplingQuality.SmallKernel)
			{
				result = BlurSampleCount.Thirteen;
			}
			else if (m_UpsamplingQuality == BloomSamplingQuality.MediumKernel)
			{
				result = BlurSampleCount.Seventeen;
			}
			else if (m_UpsamplingQuality == BloomSamplingQuality.LargeKernel)
			{
				result = BlurSampleCount.TwentyThree;
			}
			else if (m_UpsamplingQuality == BloomSamplingQuality.LargerKernel)
			{
				result = BlurSampleCount.TwentySeven;
			}
			return result;
		}
		float num = Screen.height;
		int num2 = 0;
		float num3 = float.MaxValue;
		for (int i = 0; i < m_ResSamplingPixelCount.Length; i++)
		{
			float num4 = Math.Abs(num - m_ResSamplingPixelCount[i]);
			if (num4 < num3)
			{
				num3 = num4;
				num2 = i;
			}
		}
		return num2 switch
		{
			0 => BlurSampleCount.Nine, 
			1 => BlurSampleCount.Thirteen, 
			2 => BlurSampleCount.Seventeen, 
			3 => BlurSampleCount.TwentyThree, 
			4 => BlurSampleCount.TwentySeven, 
			_ => BlurSampleCount.ThrirtyOne, 
		};
	}

	public void ComputeResolutionRelativeData()
	{
		float num = m_SamplingMinHeight;
		float num2 = 9f;
		for (int i = 0; i < m_ResSamplingPixelCount.Length; i++)
		{
			m_ResSamplingPixelCount[i] = num;
			float num3 = num2 + 4f;
			float num4 = num3 / num2;
			num *= num4;
			num2 = num3;
		}
	}

	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Expected O, but got Unknown
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Expected O, but got Unknown
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Expected O, but got Unknown
		//IL_052f: Unknown result type (might be due to invalid IL or missing references)
		//IL_053f: Expected O, but got Unknown
		//IL_0552: Unknown result type (might be due to invalid IL or missing references)
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Expected O, but got Unknown
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cd: Expected O, but got Unknown
		bool flag = false;
		flag = ((m_HDR != 0) ? (m_HDR == HDRBloomMode.On) : ((int)source.format == 2 && ((Component)this).GetComponent<Camera>().hdr));
		m_Format = (RenderTextureFormat)((!flag) ? 7 : 2);
		if (m_DownSamples != null && m_DownSamples.Length != GetNeededDownsamples())
		{
			OnDisable();
		}
		if (m_LastDownscaleCount != m_DownscaleCount || m_LastAnamorphicDownscaleCount != m_AnamorphicDownscaleCount || m_LastStarDownscaleCount != m_StarDownscaleCount)
		{
			OnDisable();
		}
		m_LastDownscaleCount = m_DownscaleCount;
		m_LastAnamorphicDownscaleCount = m_AnamorphicDownscaleCount;
		m_LastStarDownscaleCount = m_StarDownscaleCount;
		CreateMaterials();
		if (m_DirectDownSample || m_DirectUpsample)
		{
			ComputeBufferOptimization();
		}
		bool flag2 = false;
		if (m_SamplingMode == SamplingMode.HeightRelative)
		{
			ComputeResolutionRelativeData();
		}
		RenderTexture temporary = RenderTexture.GetTemporary(((Texture)source).width, ((Texture)source).height, 0, m_Format);
		((Texture)temporary).filterMode = (FilterMode)1;
		if (m_IntensityManagement == BloomIntensityManagement.Threshold)
		{
			BrightPass(source, temporary, Color.op_Implicit(m_BloomThreshhold * m_BloomThreshholdColor));
		}
		else
		{
			m_BloomCurve.UpdateCoefficients();
			Graphics.Blit((Texture)(object)source, temporary);
		}
		if (m_IntensityManagement == BloomIntensityManagement.Threshold)
		{
			CachedDownsample(temporary, m_DownSamples, null, flag);
		}
		else
		{
			CachedDownsample(temporary, m_DownSamples, m_BloomCurve, flag);
		}
		BlurSampleCount upsamplingSize = GetUpsamplingSize();
		CachedUpsample(m_DownSamples, m_UpSamples, ((Texture)source).width, ((Texture)source).height, upsamplingSize);
		Texture flareRT = (Texture)(object)Texture2D.blackTexture;
		RenderTexture val = null;
		if (m_UseLensFlare)
		{
			int ghostBokehLayer = GetGhostBokehLayer();
			int num = ((Texture)source).width / (int)Mathf.Pow(2f, (float)ghostBokehLayer);
			int num2 = ((Texture)source).height / (int)Mathf.Pow(2f, (float)ghostBokehLayer);
			if ((Object)(object)m_FlareShape != (Object)null && m_UseBokehFlare)
			{
				float num3 = 15f;
				if (m_BokehFlareQuality == BokehFlareQuality.Medium)
				{
					num3 *= 2f;
				}
				if (m_BokehFlareQuality == BokehFlareQuality.High)
				{
					num3 *= 4f;
				}
				if (m_BokehFlareQuality == BokehFlareQuality.VeryHigh)
				{
					num3 *= 8f;
				}
				num3 *= m_BokehScale;
				m_FlareSpriteRenderer.SetMaterial(m_FlareBokehMaterial);
				m_FlareSpriteRenderer.RebuildMeshIfNeeded(num, num2, 1f / (float)num * num3, 1f / (float)num2 * num3, ref m_BokehMeshes);
				m_FlareSpriteRenderer.SetTexture(m_FlareShape);
				val = RenderTexture.GetTemporary(((Texture)source).width / 4, ((Texture)source).height / 4, 0, m_Format);
				int num4 = ghostBokehLayer;
				RenderTexture temporary2 = RenderTexture.GetTemporary(((Texture)source).width / (int)Mathf.Pow(2f, (float)(num4 + 1)), ((Texture)source).height / (int)Mathf.Pow(2f, (float)(num4 + 1)), 0, m_Format);
				BrightPass(m_DownSamples[ghostBokehLayer], temporary2, m_FlareTreshold * Vector4.one);
				m_FlareSpriteRenderer.RenderFlare(temporary2, val, (!m_UseBokehFlare) ? m_FlareIntensity : 1f, ref m_BokehMeshes);
				RenderTexture.ReleaseTemporary(temporary2);
				RenderTexture temporary3 = RenderTexture.GetTemporary(((Texture)val).width, ((Texture)val).height, 0, m_Format);
				m_FlareMaskMaterial.SetTexture("_MaskTex", (Texture)(object)m_FlareMask);
				Graphics.Blit((Texture)(object)val, temporary3, m_FlareMaskMaterial, 0);
				RenderTexture.ReleaseTemporary(val);
				val = null;
				RenderFlares(temporary3, source, ref flareRT);
				RenderTexture.ReleaseTemporary(temporary3);
			}
			else
			{
				int ghostBokehLayer2 = GetGhostBokehLayer();
				RenderTexture val2 = m_DownSamples[ghostBokehLayer2];
				RenderTexture temporary4 = RenderTexture.GetTemporary(((Texture)val2).width, ((Texture)val2).height, 0, m_Format);
				BrightPassWithMask(m_DownSamples[ghostBokehLayer2], temporary4, m_FlareTreshold * Vector4.one, (Texture)(object)m_FlareMask);
				RenderFlares(temporary4, source, ref flareRT);
				RenderTexture.ReleaseTemporary(temporary4);
			}
		}
		if (!m_UseLensFlare && m_FlareSpriteRenderer != null)
		{
			m_FlareSpriteRenderer.Clear(ref m_BokehMeshes);
		}
		if (m_UseAnamorphicFlare)
		{
			RenderTexture val3 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.Anamorphic);
			if ((Object)(object)val3 != (Object)null)
			{
				if (m_UseLensFlare)
				{
					RenderTextureAdditive(val3, (RenderTexture)flareRT, 1f);
					RenderTexture.ReleaseTemporary(val3);
				}
				else
				{
					flareRT = (Texture)(object)val3;
				}
			}
		}
		if (m_UseStarFlare)
		{
			RenderTexture val4 = null;
			if (m_StarBlurPass == 1)
			{
				val4 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.Star);
				if ((Object)(object)val4 != (Object)null)
				{
					if (m_UseLensFlare || m_UseAnamorphicFlare)
					{
						RenderTextureAdditive(val4, (RenderTexture)flareRT, m_StarFlareIntensity);
					}
					else
					{
						flareRT = (Texture)(object)RenderTexture.GetTemporary(((Texture)source).width, ((Texture)source).height, 0, m_Format);
						BlitIntensity(val4, (RenderTexture)flareRT, m_StarFlareIntensity);
					}
					RenderTexture.ReleaseTemporary(val4);
				}
			}
			else if (m_UseLensFlare || m_UseAnamorphicFlare)
			{
				val4 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.DiagonalUpright);
				if ((Object)(object)val4 != (Object)null)
				{
					RenderTextureAdditive(val4, (RenderTexture)flareRT, m_StarFlareIntensity);
					RenderTexture.ReleaseTemporary(val4);
					val4 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.DiagonalUpleft);
					RenderTextureAdditive(val4, (RenderTexture)flareRT, m_StarFlareIntensity);
					RenderTexture.ReleaseTemporary(val4);
				}
			}
			else
			{
				val4 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.DiagonalUpleft);
				if ((Object)(object)val4 != (Object)null)
				{
					RenderTexture val5 = RenderStripe(m_DownSamples, upsamplingSize, ((Texture)source).width, ((Texture)source).height, FlareStripeType.DiagonalUpright);
					CombineAdditive(val5, val4, m_StarFlareIntensity, m_StarFlareIntensity);
					RenderTexture.ReleaseTemporary(val5);
					flareRT = (Texture)(object)val4;
				}
			}
		}
		if (m_DirectDownSample)
		{
			for (int i = 0; i < m_DownSamples.Length; i++)
			{
				if (m_BufferUsage[i])
				{
					RenderTexture.ReleaseTemporary(m_DownSamples[i]);
				}
			}
		}
		else
		{
			for (int j = 0; j < m_DownSamples.Length; j++)
			{
				RenderTexture.ReleaseTemporary(m_DownSamples[j]);
			}
		}
		m_CombineMaterial.SetFloat("_Intensity", m_BloomIntensity);
		m_CombineMaterial.SetFloat("_FlareIntensity", m_FlareIntensity);
		m_CombineMaterial.SetTexture("_ColorBuffer", (Texture)(object)source);
		m_CombineMaterial.SetTexture("_FlareTexture", flareRT);
		m_CombineMaterial.SetTexture("_AdditiveTexture", (Texture)(object)((!m_UseLensDust) ? Texture2D.whiteTexture : m_DustTexture));
		m_CombineMaterial.SetTexture("_brightTexture", (Texture)(object)temporary);
		if (m_UseLensDust)
		{
			m_CombineMaterial.SetFloat("_DirtIntensity", m_DustIntensity);
			m_CombineMaterial.SetFloat("_DirtLightIntensity", m_DirtLightIntensity);
		}
		else
		{
			m_CombineMaterial.SetFloat("_DirtIntensity", 1f);
			m_CombineMaterial.SetFloat("_DirtLightIntensity", 0f);
		}
		if (m_BlendMode == BlendMode.SCREEN)
		{
			m_CombineMaterial.SetFloat("_ScreenMaxIntensity", m_ScreenMaxIntensity);
		}
		if (m_InvertImage)
		{
			Graphics.Blit((Texture)(object)m_LastBloomUpsample, destination, m_CombineMaterial, 1);
		}
		else
		{
			Graphics.Blit((Texture)(object)m_LastBloomUpsample, destination, m_CombineMaterial, 0);
		}
		for (int k = 0; k < m_UpSamples.Length; k++)
		{
			if ((Object)(object)m_UpSamples[k] != (Object)null)
			{
				RenderTexture.ReleaseTemporary(m_UpSamples[k]);
			}
		}
		if (flag2)
		{
			Graphics.Blit((Texture)(object)val, destination);
		}
		if ((m_UseLensFlare || m_UseAnamorphicFlare || m_UseStarFlare) && (Object)(object)flareRT != (Object)null && flareRT is RenderTexture)
		{
			RenderTexture.ReleaseTemporary((RenderTexture)flareRT);
		}
		RenderTexture.ReleaseTemporary(temporary);
		if ((Object)(object)m_FlareShape != (Object)null && m_UseBokehFlare && (Object)(object)val != (Object)null)
		{
			RenderTexture.ReleaseTemporary(val);
		}
	}

	private RenderTexture RenderStar(RenderTexture[] sources, BlurSampleCount upsamplingCount, int sourceWidth, int sourceHeight)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		for (int num = m_StarUpscales.Length - 1; num >= 0; num--)
		{
			m_StarUpscales[num] = RenderTexture.GetTemporary(sourceWidth / (int)Mathf.Pow(2f, (float)num), sourceHeight / (int)Mathf.Pow(2f, (float)num), 0, m_Format);
			((Texture)m_StarUpscales[num]).filterMode = (FilterMode)1;
			float num2 = 1f / (float)((Texture)sources[num]).width;
			float num3 = 1f / (float)((Texture)sources[num]).height;
			if (num < m_StarDownscaleCount - 1)
			{
				GaussianBlur2(sources[num], m_StarUpscales[num], num2 * m_StarScale, num3 * m_StarScale, m_StarUpscales[num + 1], upsamplingCount, Color.white, 1f);
			}
			else
			{
				GaussianBlur2(sources[num], m_StarUpscales[num], num2 * m_StarScale, num3 * m_StarScale, null, upsamplingCount, Color.white, 1f);
			}
		}
		for (int i = 1; i < m_StarUpscales.Length; i++)
		{
			if ((Object)(object)m_StarUpscales[i] != (Object)null)
			{
				RenderTexture.ReleaseTemporary(m_StarUpscales[i]);
			}
		}
		return m_StarUpscales[0];
	}

	private RenderTexture RenderStripe(RenderTexture[] sources, BlurSampleCount upsamplingCount, int sourceWidth, int sourceHeight, FlareStripeType type)
	{
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_046f: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture[] array = m_AnamorphicUpscales;
		bool[] array2 = m_AnamorphicBloomUsages;
		float[] array3 = m_AnamorphicBloomIntensities;
		Color[] array4 = m_AnamorphicBloomColors;
		bool flag = m_AnamorphicSmallVerticalBlur;
		float num = m_AnamorphicBlurPass;
		float num2 = m_AnamorphicScale;
		float num3 = m_AnamorphicFlareIntensity;
		float num4 = 1f;
		float num5 = 0f;
		if (m_AnamorphicDirection == AnamorphicDirection.Vertical)
		{
			num4 = 0f;
			num5 = 1f;
		}
		if (type != 0)
		{
			array = m_StarUpscales;
			array2 = m_StarBloomUsages;
			array3 = m_StarBloomIntensities;
			array4 = m_StarBloomColors;
			flag = false;
			num = m_StarBlurPass;
			num2 = m_StarScale;
			num3 = m_StarFlareIntensity;
			num5 = ((type != FlareStripeType.DiagonalUpleft) ? 1f : (-1f));
		}
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = null;
		}
		RenderTexture val = null;
		for (int num6 = array.Length - 1; num6 >= 0; num6--)
		{
			if ((!((Object)(object)sources[num6] == (Object)null) || !m_DirectUpsample) && (array2[num6] || !m_DirectUpsample))
			{
				array[num6] = RenderTexture.GetTemporary(sourceWidth / (int)Mathf.Pow(2f, (float)num6), sourceHeight / (int)Mathf.Pow(2f, (float)num6), 0, m_Format);
				((Texture)array[num6]).filterMode = (FilterMode)1;
				float num7 = 1f / (float)((Texture)array[num6]).width;
				float num8 = 1f / (float)((Texture)array[num6]).height;
				RenderTexture source = sources[num6];
				RenderTexture val2 = array[num6];
				if (!array2[num6])
				{
					if ((Object)(object)val != (Object)null)
					{
						if (flag)
						{
							GaussianBlur1(val, val2, (m_AnamorphicDirection != AnamorphicDirection.Vertical) ? 0f : num7, (m_AnamorphicDirection != 0) ? 0f : num8, null, BlurSampleCount.FourSimple, Color.white, 1f);
						}
						else
						{
							Graphics.Blit((Texture)(object)val, val2);
						}
					}
					else
					{
						Graphics.Blit((Texture)(object)Texture2D.blackTexture, val2);
					}
					val = array[num6];
				}
				else
				{
					RenderTexture val3 = null;
					if (flag && (Object)(object)val != (Object)null)
					{
						val3 = RenderTexture.GetTemporary(((Texture)val2).width, ((Texture)val2).height, 0, m_Format);
						GaussianBlur1(val, val3, (m_AnamorphicDirection != AnamorphicDirection.Vertical) ? 0f : num7, (m_AnamorphicDirection != 0) ? 0f : num8, null, BlurSampleCount.FourSimple, Color.white, 1f);
						val = val3;
					}
					if (num == 1f)
					{
						if (type != 0)
						{
							GaussianBlur2(source, val2, num7 * num2 * num4, num8 * num2 * num5, val, upsamplingCount, array4[num6], array3[num6] * num3);
						}
						else
						{
							GaussianBlur1(source, val2, num7 * num2 * num4, num8 * num2 * num5, val, upsamplingCount, array4[num6], array3[num6] * num3);
						}
					}
					else
					{
						RenderTexture temporary = RenderTexture.GetTemporary(((Texture)val2).width, ((Texture)val2).height, 0, m_Format);
						bool flag2 = false;
						for (int j = 0; (float)j < num; j++)
						{
							RenderTexture additiveTexture = (((float)j != num - 1f) ? null : val);
							if (j == 0)
							{
								if (type != 0)
								{
									GaussianBlur2(source, temporary, num7 * num2 * num4, num8 * num2 * num5, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								else
								{
									GaussianBlur1(source, temporary, num7 * num2 * num4, num8 * num2 * num5, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								continue;
							}
							num7 = 1f / (float)((Texture)val2).width;
							num8 = 1f / (float)((Texture)val2).height;
							if (j % 2 == 1)
							{
								if (type != 0)
								{
									GaussianBlur2(temporary, val2, num7 * num2 * num4 * 1.5f, num8 * num2 * num5 * 1.5f, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								else
								{
									GaussianBlur1(temporary, val2, num7 * num2 * num4 * 1.5f, num8 * num2 * num5 * 1.5f, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								flag2 = false;
							}
							else
							{
								if (type != 0)
								{
									GaussianBlur2(val2, temporary, num7 * num2 * num4 * 1.5f, num8 * num2 * num5 * 1.5f, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								else
								{
									GaussianBlur1(val2, temporary, num7 * num2 * num4 * 1.5f, num8 * num2 * num5 * 1.5f, additiveTexture, upsamplingCount, array4[num6], array3[num6] * num3);
								}
								flag2 = true;
							}
						}
						if (flag2)
						{
							Graphics.Blit((Texture)(object)temporary, val2);
						}
						if ((Object)(object)val3 != (Object)null)
						{
							RenderTexture.ReleaseTemporary(val3);
						}
						RenderTexture.ReleaseTemporary(temporary);
					}
					val = array[num6];
				}
			}
		}
		RenderTexture val4 = null;
		for (int k = 0; k < array.Length; k++)
		{
			if ((Object)(object)array[k] != (Object)null)
			{
				if ((Object)(object)val4 == (Object)null)
				{
					val4 = array[k];
				}
				else
				{
					RenderTexture.ReleaseTemporary(array[k]);
				}
			}
		}
		return val4;
	}

	private void RenderFlares(RenderTexture brightTexture, RenderTexture source, ref Texture flareRT)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Expected O, but got Unknown
		//IL_04db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0553: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_040e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Expected O, but got Unknown
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Expected O, but got Unknown
		//IL_0618: Unknown result type (might be due to invalid IL or missing references)
		//IL_062c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0653: Expected O, but got Unknown
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Expected O, but got Unknown
		//IL_0687: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c2: Expected O, but got Unknown
		flareRT = (Texture)(object)RenderTexture.GetTemporary(((Texture)source).width, ((Texture)source).height, 0, m_Format);
		flareRT.filterMode = (FilterMode)1;
		m_FlareMaterial.SetVector("_FlareScales", m_FlareScales * m_FlareGlobalScale);
		m_FlareMaterial.SetVector("_FlareScalesNear", m_FlareScalesNear * m_FlareGlobalScale);
		m_FlareMaterial.SetVector("_FlareTint0", Color.op_Implicit(m_FlareTint0));
		m_FlareMaterial.SetVector("_FlareTint1", Color.op_Implicit(m_FlareTint1));
		m_FlareMaterial.SetVector("_FlareTint2", Color.op_Implicit(m_FlareTint2));
		m_FlareMaterial.SetVector("_FlareTint3", Color.op_Implicit(m_FlareTint3));
		m_FlareMaterial.SetVector("_FlareTint4", Color.op_Implicit(m_FlareTint4));
		m_FlareMaterial.SetVector("_FlareTint5", Color.op_Implicit(m_FlareTint5));
		m_FlareMaterial.SetVector("_FlareTint6", Color.op_Implicit(m_FlareTint6));
		m_FlareMaterial.SetVector("_FlareTint7", Color.op_Implicit(m_FlareTint7));
		m_FlareMaterial.SetFloat("_Intensity", m_FlareIntensity);
		if (m_FlareRendering == FlareRendering.Sharp)
		{
			RenderTexture temporary = RenderTexture.GetTemporary(((Texture)source).width / 2, ((Texture)source).height / 2, 0, m_Format);
			((Texture)temporary).filterMode = (FilterMode)1;
			RenderSimple(brightTexture, temporary, 1f / (float)((Texture)brightTexture).width, 1f / (float)((Texture)brightTexture).height, SimpleSampleCount.Four);
			Graphics.Blit((Texture)(object)temporary, (RenderTexture)flareRT, m_FlareMaterial, 0);
			RenderTexture.ReleaseTemporary(temporary);
		}
		else if (m_FlareBlurQuality == FlareBlurQuality.Fast)
		{
			RenderTexture temporary2 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 2, ((Texture)brightTexture).height / 2, 0, m_Format);
			((Texture)temporary2).filterMode = (FilterMode)1;
			RenderTexture temporary3 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 4, ((Texture)brightTexture).height / 4, 0, m_Format);
			((Texture)temporary3).filterMode = (FilterMode)1;
			Graphics.Blit((Texture)(object)brightTexture, temporary2, m_FlareMaterial, 0);
			if (m_FlareRendering == FlareRendering.Blurred)
			{
				GaussianBlurSeparate(temporary2, temporary3, 1f / (float)((Texture)temporary2).width, 1f / (float)((Texture)temporary2).height, null, BlurSampleCount.Thirteen, Color.white, 1f);
				RenderSimple(temporary3, (RenderTexture)flareRT, 1f / (float)((Texture)temporary3).width, 1f / (float)((Texture)temporary3).height, SimpleSampleCount.Four);
			}
			else if (m_FlareRendering == FlareRendering.MoreBlurred)
			{
				GaussianBlurSeparate(temporary2, temporary3, 1f / (float)((Texture)temporary2).width, 1f / (float)((Texture)temporary2).height, null, BlurSampleCount.ThrirtyOne, Color.white, 1f);
				RenderSimple(temporary3, (RenderTexture)flareRT, 1f / (float)((Texture)temporary3).width, 1f / (float)((Texture)temporary3).height, SimpleSampleCount.Four);
			}
			RenderTexture.ReleaseTemporary(temporary2);
			RenderTexture.ReleaseTemporary(temporary3);
		}
		else if (m_FlareBlurQuality == FlareBlurQuality.Normal)
		{
			RenderTexture temporary4 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 2, ((Texture)brightTexture).height / 2, 0, m_Format);
			((Texture)temporary4).filterMode = (FilterMode)1;
			RenderTexture temporary5 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 4, ((Texture)brightTexture).height / 4, 0, m_Format);
			((Texture)temporary5).filterMode = (FilterMode)1;
			RenderTexture temporary6 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 4, ((Texture)brightTexture).height / 4, 0, m_Format);
			((Texture)temporary6).filterMode = (FilterMode)1;
			RenderSimple(brightTexture, temporary4, 1f / (float)((Texture)brightTexture).width, 1f / (float)((Texture)brightTexture).height, SimpleSampleCount.Four);
			RenderSimple(temporary4, temporary5, 1f / (float)((Texture)temporary4).width, 1f / (float)((Texture)temporary4).height, SimpleSampleCount.Four);
			Graphics.Blit((Texture)(object)temporary5, temporary6, m_FlareMaterial, 0);
			if (m_FlareRendering == FlareRendering.Blurred)
			{
				GaussianBlurSeparate(temporary6, temporary5, 1f / (float)((Texture)temporary5).width, 1f / (float)((Texture)temporary5).height, null, BlurSampleCount.Thirteen, Color.white, 1f);
				RenderSimple(temporary5, (RenderTexture)flareRT, 1f / (float)((Texture)temporary5).width, 1f / (float)((Texture)temporary5).height, SimpleSampleCount.Four);
			}
			else if (m_FlareRendering == FlareRendering.MoreBlurred)
			{
				GaussianBlurSeparate(temporary6, temporary5, 1f / (float)((Texture)temporary5).width, 1f / (float)((Texture)temporary5).height, null, BlurSampleCount.ThrirtyOne, Color.white, 1f);
				RenderSimple(temporary5, (RenderTexture)flareRT, 1f / (float)((Texture)temporary5).width, 1f / (float)((Texture)temporary5).height, SimpleSampleCount.Four);
			}
			RenderTexture.ReleaseTemporary(temporary4);
			RenderTexture.ReleaseTemporary(temporary5);
			RenderTexture.ReleaseTemporary(temporary6);
		}
		else if (m_FlareBlurQuality == FlareBlurQuality.High)
		{
			RenderTexture temporary7 = RenderTexture.GetTemporary(((Texture)brightTexture).width / 2, ((Texture)brightTexture).height / 2, 0, m_Format);
			((Texture)temporary7).filterMode = (FilterMode)1;
			RenderTexture temporary8 = RenderTexture.GetTemporary(((Texture)temporary7).width / 2, ((Texture)temporary7).height / 2, 0, m_Format);
			((Texture)temporary8).filterMode = (FilterMode)1;
			RenderTexture temporary9 = RenderTexture.GetTemporary(((Texture)temporary8).width / 2, ((Texture)temporary8).height / 2, 0, m_Format);
			((Texture)temporary9).filterMode = (FilterMode)1;
			RenderTexture temporary10 = RenderTexture.GetTemporary(((Texture)temporary8).width / 2, ((Texture)temporary8).height / 2, 0, m_Format);
			((Texture)temporary10).filterMode = (FilterMode)1;
			RenderSimple(brightTexture, temporary7, 1f / (float)((Texture)brightTexture).width, 1f / (float)((Texture)brightTexture).height, SimpleSampleCount.Four);
			RenderSimple(temporary7, temporary8, 1f / (float)((Texture)temporary7).width, 1f / (float)((Texture)temporary7).height, SimpleSampleCount.Four);
			RenderSimple(temporary8, temporary9, 1f / (float)((Texture)temporary8).width, 1f / (float)((Texture)temporary8).height, SimpleSampleCount.Four);
			Graphics.Blit((Texture)(object)temporary9, temporary10, m_FlareMaterial, 0);
			if (m_FlareRendering == FlareRendering.Blurred)
			{
				GaussianBlurSeparate(temporary10, temporary9, 1f / (float)((Texture)temporary9).width, 1f / (float)((Texture)temporary9).height, null, BlurSampleCount.Thirteen, Color.white, 1f);
				RenderSimple(temporary9, (RenderTexture)flareRT, 1f / (float)((Texture)temporary9).width, 1f / (float)((Texture)temporary9).height, SimpleSampleCount.Four);
			}
			else if (m_FlareRendering == FlareRendering.MoreBlurred)
			{
				GaussianBlurSeparate(temporary10, temporary9, 1f / (float)((Texture)temporary9).width, 1f / (float)((Texture)temporary9).height, null, BlurSampleCount.ThrirtyOne, Color.white, 1f);
				RenderSimple(temporary9, (RenderTexture)flareRT, 1f / (float)((Texture)temporary9).width, 1f / (float)((Texture)temporary9).height, SimpleSampleCount.Four);
			}
			RenderTexture.ReleaseTemporary(temporary7);
			RenderTexture.ReleaseTemporary(temporary8);
			RenderTexture.ReleaseTemporary(temporary9);
			RenderTexture.ReleaseTemporary(temporary10);
		}
	}

	private void CachedUpsample(RenderTexture[] sources, RenderTexture[] destinations, int originalWidth, int originalHeight, BlurSampleCount upsamplingCount)
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture val = null;
		for (int i = 0; i < m_UpSamples.Length; i++)
		{
			m_UpSamples[i] = null;
		}
		for (int num = destinations.Length - 1; num >= 0; num--)
		{
			if (m_BloomUsages[num] || !m_DirectUpsample)
			{
				m_UpSamples[num] = RenderTexture.GetTemporary(originalWidth / (int)Mathf.Pow(2f, (float)num), originalHeight / (int)Mathf.Pow(2f, (float)num), 0, m_Format);
				((Texture)m_UpSamples[num]).filterMode = (FilterMode)1;
			}
			float num2 = 1f;
			if (m_BloomUsages[num])
			{
				float num3 = 1f / (float)((Texture)sources[num]).width;
				float verticalBlur = 1f / (float)((Texture)sources[num]).height;
				GaussianBlurSeparate(m_DownSamples[num], m_UpSamples[num], num3 * num2, verticalBlur, val, upsamplingCount, m_BloomColors[num], m_BloomIntensities[num]);
			}
			else if (num < m_DownscaleCount - 1)
			{
				if (!m_DirectUpsample)
				{
					RenderSimple(val, m_UpSamples[num], 1f / (float)((Texture)m_UpSamples[num]).width, 1f / (float)((Texture)m_UpSamples[num]).height, SimpleSampleCount.Four);
				}
			}
			else
			{
				Graphics.Blit((Texture)(object)Texture2D.blackTexture, m_UpSamples[num]);
			}
			if (m_BloomUsages[num] || !m_DirectUpsample)
			{
				val = m_UpSamples[num];
			}
		}
		m_LastBloomUpsample = val;
	}

	private void CachedDownsample(RenderTexture source, RenderTexture[] destinations, DeluxeFilmicCurve intensityCurve, bool hdr)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		int num = destinations.Length;
		RenderTexture val = source;
		bool flag = false;
		for (int i = 0; i < num; i++)
		{
			if (m_DirectDownSample && !m_BufferUsage[i])
			{
				continue;
			}
			destinations[i] = RenderTexture.GetTemporary(((Texture)source).width / (int)Mathf.Pow(2f, (float)(i + 1)), ((Texture)source).height / (int)Mathf.Pow(2f, (float)(i + 1)), 0, m_Format);
			((Texture)destinations[i]).filterMode = (FilterMode)1;
			RenderTexture destination = destinations[i];
			float num2 = 1f;
			float num3 = 1f / (float)((Texture)val).width;
			float num4 = 1f / (float)((Texture)val).height;
			if (intensityCurve != null && !flag)
			{
				intensityCurve.StoreK();
				m_SamplingMaterial.SetFloat("_CurveExposure", intensityCurve.GetExposure());
				m_SamplingMaterial.SetFloat("_K", intensityCurve.m_k);
				m_SamplingMaterial.SetFloat("_Crossover", intensityCurve.m_CrossOverPoint);
				m_SamplingMaterial.SetVector("_Toe", intensityCurve.m_ToeCoef);
				m_SamplingMaterial.SetVector("_Shoulder", intensityCurve.m_ShoulderCoef);
				float num5 = ((!hdr) ? 1f : 2f);
				m_SamplingMaterial.SetFloat("_MaxValue", num5);
				num3 = 1f / (float)((Texture)val).width;
				num4 = 1f / (float)((Texture)val).height;
				if (m_TemporalStableDownsampling)
				{
					RenderSimple(val, destination, num3 * num2, num4 * num2, SimpleSampleCount.ThirteenTemporalCurve);
				}
				else
				{
					RenderSimple(val, destination, num3 * num2, num4 * num2, SimpleSampleCount.FourCurve);
				}
				flag = true;
			}
			else if (m_TemporalStableDownsampling)
			{
				RenderSimple(val, destination, num3 * num2, num4 * num2, SimpleSampleCount.ThirteenTemporal);
			}
			else
			{
				RenderSimple(val, destination, num3 * num2, num4 * num2, SimpleSampleCount.Four);
			}
			val = destinations[i];
		}
	}

	private void BrightPass(RenderTexture source, RenderTexture destination, Vector4 treshold)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		m_BrightpassMaterial.SetTexture("_MaskTex", (Texture)(object)Texture2D.whiteTexture);
		m_BrightpassMaterial.SetVector("_Threshhold", treshold);
		Graphics.Blit((Texture)(object)source, destination, m_BrightpassMaterial, 0);
	}

	private void BrightPassWithMask(RenderTexture source, RenderTexture destination, Vector4 treshold, Texture mask)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		m_BrightpassMaterial.SetTexture("_MaskTex", mask);
		m_BrightpassMaterial.SetVector("_Threshhold", treshold);
		Graphics.Blit((Texture)(object)source, destination, m_BrightpassMaterial, 0);
	}

	private void RenderSimple(RenderTexture source, RenderTexture destination, float horizontalBlur, float verticalBlur, SimpleSampleCount sampleCount)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(horizontalBlur, verticalBlur, 0f, 0f));
		switch (sampleCount)
		{
		case SimpleSampleCount.Four:
			Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, 0);
			break;
		case SimpleSampleCount.Nine:
			Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, 1);
			break;
		case SimpleSampleCount.FourCurve:
			Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, 5);
			break;
		case SimpleSampleCount.ThirteenTemporal:
			Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, 11);
			break;
		case SimpleSampleCount.ThirteenTemporalCurve:
			Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, 12);
			break;
		}
	}

	private void GaussianBlur1(RenderTexture source, RenderTexture destination, float horizontalBlur, float verticalBlur, RenderTexture additiveTexture, BlurSampleCount sampleCount, Color tint, float intensity)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		int num = 2;
		if (sampleCount == BlurSampleCount.Seventeen)
		{
			num = 3;
		}
		if (sampleCount == BlurSampleCount.Nine)
		{
			num = 4;
		}
		if (sampleCount == BlurSampleCount.NineCurve)
		{
			num = 6;
		}
		if (sampleCount == BlurSampleCount.FourSimple)
		{
			num = 7;
		}
		if (sampleCount == BlurSampleCount.Thirteen)
		{
			num = 8;
		}
		if (sampleCount == BlurSampleCount.TwentyThree)
		{
			num = 9;
		}
		if (sampleCount == BlurSampleCount.TwentySeven)
		{
			num = 10;
		}
		Texture val = null;
		val = (Texture)((!((Object)(object)additiveTexture == (Object)null)) ? ((object)additiveTexture) : ((object)Texture2D.blackTexture));
		m_SamplingMaterial.SetTexture("_AdditiveTexture", val);
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(horizontalBlur, verticalBlur, 0f, 0f));
		m_SamplingMaterial.SetVector("_Tint", Color.op_Implicit(tint));
		m_SamplingMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, num);
	}

	private void GaussianBlur2(RenderTexture source, RenderTexture destination, float horizontalBlur, float verticalBlur, RenderTexture additiveTexture, BlurSampleCount sampleCount, Color tint, float intensity)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture temporary = RenderTexture.GetTemporary(((Texture)destination).width, ((Texture)destination).height, destination.depth, destination.format);
		((Texture)temporary).filterMode = (FilterMode)1;
		int num = 2;
		if (sampleCount == BlurSampleCount.Seventeen)
		{
			num = 3;
		}
		if (sampleCount == BlurSampleCount.Nine)
		{
			num = 4;
		}
		if (sampleCount == BlurSampleCount.NineCurve)
		{
			num = 6;
		}
		if (sampleCount == BlurSampleCount.FourSimple)
		{
			num = 7;
		}
		if (sampleCount == BlurSampleCount.Thirteen)
		{
			num = 8;
		}
		if (sampleCount == BlurSampleCount.TwentyThree)
		{
			num = 9;
		}
		if (sampleCount == BlurSampleCount.TwentySeven)
		{
			num = 10;
		}
		Texture val = null;
		val = (Texture)((!((Object)(object)additiveTexture == (Object)null)) ? ((object)additiveTexture) : ((object)Texture2D.blackTexture));
		m_SamplingMaterial.SetTexture("_AdditiveTexture", val);
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(horizontalBlur, verticalBlur, 0f, 0f));
		m_SamplingMaterial.SetVector("_Tint", Color.op_Implicit(tint));
		m_SamplingMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, temporary, m_SamplingMaterial, num);
		val = (Texture)(object)temporary;
		m_SamplingMaterial.SetTexture("_AdditiveTexture", val);
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(0f - horizontalBlur, verticalBlur, 0f, 0f));
		m_SamplingMaterial.SetVector("_Tint", Color.op_Implicit(tint));
		m_SamplingMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, destination, m_SamplingMaterial, num);
		RenderTexture.ReleaseTemporary(temporary);
	}

	private void GaussianBlurSeparate(RenderTexture source, RenderTexture destination, float horizontalBlur, float verticalBlur, RenderTexture additiveTexture, BlurSampleCount sampleCount, Color tint, float intensity)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture temporary = RenderTexture.GetTemporary(((Texture)destination).width, ((Texture)destination).height, destination.depth, destination.format);
		((Texture)temporary).filterMode = (FilterMode)1;
		int num = 2;
		if (sampleCount == BlurSampleCount.Seventeen)
		{
			num = 3;
		}
		if (sampleCount == BlurSampleCount.Nine)
		{
			num = 4;
		}
		if (sampleCount == BlurSampleCount.NineCurve)
		{
			num = 6;
		}
		if (sampleCount == BlurSampleCount.FourSimple)
		{
			num = 7;
		}
		if (sampleCount == BlurSampleCount.Thirteen)
		{
			num = 8;
		}
		if (sampleCount == BlurSampleCount.TwentyThree)
		{
			num = 9;
		}
		if (sampleCount == BlurSampleCount.TwentySeven)
		{
			num = 10;
		}
		m_SamplingMaterial.SetTexture("_AdditiveTexture", (Texture)(object)Texture2D.blackTexture);
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(0f, verticalBlur, 0f, 0f));
		m_SamplingMaterial.SetVector("_Tint", Color.op_Implicit(tint));
		m_SamplingMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, temporary, m_SamplingMaterial, num);
		Texture val = null;
		val = (Texture)((!((Object)(object)additiveTexture == (Object)null)) ? ((object)additiveTexture) : ((object)Texture2D.blackTexture));
		m_SamplingMaterial.SetTexture("_AdditiveTexture", val);
		m_SamplingMaterial.SetVector("_OffsetInfos", new Vector4(horizontalBlur, 0f, 1f / (float)((Texture)destination).width, 1f / (float)((Texture)destination).height));
		m_SamplingMaterial.SetVector("_Tint", Color.op_Implicit(Color.white));
		m_SamplingMaterial.SetFloat("_Intensity", 1f);
		Graphics.Blit((Texture)(object)temporary, destination, m_SamplingMaterial, num);
		RenderTexture.ReleaseTemporary(temporary);
	}

	private void RenderTextureAdditive(RenderTexture source, RenderTexture destination, float intensity)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture temporary = RenderTexture.GetTemporary(((Texture)source).width, ((Texture)source).height, source.depth, source.format);
		Graphics.Blit((Texture)(object)destination, temporary);
		m_MixerMaterial.SetTexture("_ColorBuffer", (Texture)(object)temporary);
		m_MixerMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, destination, m_MixerMaterial, 0);
		RenderTexture.ReleaseTemporary(temporary);
	}

	private void BlitIntensity(RenderTexture source, RenderTexture destination, float intensity)
	{
		m_MixerMaterial.SetFloat("_Intensity", intensity);
		Graphics.Blit((Texture)(object)source, destination, m_MixerMaterial, 2);
	}

	private void CombineAdditive(RenderTexture source, RenderTexture destination, float intensitySource, float intensityDestination)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture temporary = RenderTexture.GetTemporary(((Texture)source).width, ((Texture)source).height, source.depth, source.format);
		Graphics.Blit((Texture)(object)destination, temporary);
		m_MixerMaterial.SetTexture("_ColorBuffer", (Texture)(object)temporary);
		m_MixerMaterial.SetFloat("_Intensity0", intensitySource);
		m_MixerMaterial.SetFloat("_Intensity1", intensityDestination);
		Graphics.Blit((Texture)(object)source, destination, m_MixerMaterial, 1);
		RenderTexture.ReleaseTemporary(temporary);
	}

	public void SetFilmicCurveParameters(float middle, float dark, float bright, float highlights)
	{
		m_BloomCurve.m_ToeStrength = -1f * dark;
		m_BloomCurve.m_ShoulderStrength = bright;
		m_BloomCurve.m_Highlights = highlights;
		m_BloomCurve.m_CrossOverPoint = middle;
		m_BloomCurve.UpdateCoefficients();
	}
}
