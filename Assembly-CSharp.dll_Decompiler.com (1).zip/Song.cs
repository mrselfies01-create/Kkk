using System;
using UnityEngine;

[Serializable]
public class Song
{
	public string title;

	public AudioSource file;

	public float length;
}
