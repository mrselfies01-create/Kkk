namespace Audial.Utils;

public class AllPassFilter : BufferedComponent
{
	public AllPassFilter(float delayLength, float gain)
		: base(delayLength, gain)
	{
	}

	public new float ProcessSample(int channel, float sample)
	{
		float num = base.ProcessSample(channel, sample);
		return num - gain * sample;
	}
}
