using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/VHS/Real VHS HQ")]
public class CameraFilterPack_Real_VHS : MonoBehaviour
{
	public Shader SCShader;

	private Material SCMaterial;

	private Texture2D VHS;

	private Texture2D VHS2;

	[Range(0f, 1f)]
	public float TRACKING = 0.212f;

	[Range(0f, 1f)]
	public float JITTER = 1f;

	[Range(0f, 1f)]
	public float GLITCH = 1f;

	[Range(0f, 1f)]
	public float NOISE = 1f;

	[Range(-1f, 1f)]
	public float Brightness;

	[Range(0f, 1.5f)]
	public float Constrast = 1f;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/Real_VHS");
		ref Texture2D vHS = ref VHS;
		Object obj = Resources.Load("CameraFilterPack_VHS1");
		vHS = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		ref Texture2D vHS2 = ref VHS2;
		Object obj2 = Resources.Load("CameraFilterPack_VHS2");
		vHS2 = (Texture2D)(object)((obj2 is Texture2D) ? obj2 : null);
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	public static Texture2D GetRTPixels(Texture2D t, RenderTexture rt, int sx, int sy)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture active = RenderTexture.active;
		RenderTexture.active = rt;
		t.ReadPixels(new Rect(0f, 0f, (float)((Texture)t).width, (float)((Texture)t).height), 0, 0);
		RenderTexture.active = active;
		return t;
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		if ((Object)(object)SCShader != (Object)null)
		{
			material.SetTexture("VHS", (Texture)(object)VHS);
			material.SetTexture("VHS2", (Texture)(object)VHS2);
			material.SetFloat("TRACKING", TRACKING);
			material.SetFloat("JITTER", JITTER);
			material.SetFloat("GLITCH", GLITCH);
			material.SetFloat("NOISE", NOISE);
			material.SetFloat("Brightness", Brightness);
			material.SetFloat("CONTRAST", 1f - Constrast);
			int num = 382;
			int num2 = 576;
			RenderTexture temporary = RenderTexture.GetTemporary(num, num2, 0);
			((Texture)temporary).filterMode = (FilterMode)2;
			Graphics.Blit((Texture)(object)sourceTexture, temporary, material);
			Graphics.Blit((Texture)(object)temporary, destTexture);
			RenderTexture.ReleaseTemporary(temporary);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
