using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UIWidgets.Tests;

public class SmokeTest : MonoBehaviour
{
	[SerializeField]
	private Accordion accordion;

	private void Start()
	{
	}

	private IEnumerator SimpleCheck()
	{
		yield return (object)new WaitForSeconds(5f);
		List<AccordionItem> items = accordion.Items;
		if (!accordion.Items[0].Open || !accordion.Items[0].ContentObject.activeSelf)
		{
			throw new UnityException("Overview is not active!");
		}
		foreach (AccordionItem item in items)
		{
			if (!(((Object)item.ToggleObject).name == "Exit"))
			{
				accordion.ToggleItem(item);
				yield return (object)new WaitForSeconds(5f);
			}
		}
		Application.Quit();
	}
}
