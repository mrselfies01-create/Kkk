using System.Collections;
using UnityEngine;

public class LighteningScript : MonoBehaviour
{
	[Header("General Settings")]
	public GameObject target;

	[Header("Material Settings")]
	public Material mat;

	public int columns = 2;

	public int rows = 8;

	public float framesPerSecond = 10f;

	public bool randomize;

	[Header("Line Renderer Settings")]
	public int points = 5;

	public float pointsDisplacement = 0.1f;

	public float lineScale = 1f;

	public bool distanceBasedDisplacement = true;

	public bool zDisplacement;

	private int max;

	private int index;

	private bool run;

	private LineRenderer rend;

	private Vector2[] offsets;

	private Vector2 size;

	private void Start()
	{
		Initialize();
		((MonoBehaviour)this).StartCoroutine(updateTiling());
	}

	private void OnDisable()
	{
		if ((Object)(object)rend != (Object)null)
		{
			((Renderer)rend).enabled = false;
		}
		run = false;
	}

	private void OnEnable()
	{
		if ((Object)(object)rend != (Object)null)
		{
			((Renderer)rend).enabled = true;
			Initialize();
			((MonoBehaviour)this).StartCoroutine(updateTiling());
		}
	}

	public void Initialize()
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		max = rows * columns;
		if ((Object)(object)rend == (Object)null)
		{
			rend = ((Component)this).gameObject.AddComponent<LineRenderer>();
		}
		rend.SetVertexCount(points);
		((Renderer)rend).material = mat;
		size = new Vector2(1f / (float)columns, 1f / (float)rows);
		mat.SetTextureScale("_MainTex", size);
		GetRandomOffsets();
		run = true;
		((Renderer)rend).sortingLayerName = "Foreground";
	}

	private void GetRandomOffsets()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		int i = 0;
		Vector2 val = default(Vector2);
		for (offsets = (Vector2[])(object)new Vector2[rows * columns]; i < max; i++)
		{
			((Vector2)(ref val))._002Ector((float)i / (float)columns - (float)(i / columns), (float)(i / columns) / (float)rows);
			offsets[i] = val;
		}
	}

	private IEnumerator updateTiling()
	{
		Vector2 val3 = default(Vector2);
		while (run)
		{
			index++;
			if (index >= rows * columns)
			{
				index = 0;
			}
			rend.SetVertexCount(points);
			rend.SetWidth(lineScale, lineScale);
			rend.SetPosition(0, ((Component)this).transform.position);
			rend.SetPosition(points - 1, target.transform.position);
			if (points >= 3)
			{
				for (int i = 1; i < points - 1; i++)
				{
					float num = (float)i / (float)(points - 1);
					Vector3 val = Vector3.Lerp(((Component)this).transform.position, target.transform.position, num);
					if (distanceBasedDisplacement)
					{
						float num2 = Vector3.Distance(((Component)this).transform.position, target.transform.position);
						num2 = num2 * pointsDisplacement / (float)points;
						val.y += Random.Range(0f - num2, num2);
						val.x += Random.Range(0f - num2, num2);
						if (zDisplacement)
						{
							val.z += Random.Range(0f - num2, num2);
						}
					}
					else
					{
						val.y += Random.Range(0f - pointsDisplacement, pointsDisplacement);
						val.x += Random.Range(0f - pointsDisplacement, pointsDisplacement);
						if (zDisplacement)
						{
							val.z += Random.Range(0f - pointsDisplacement, pointsDisplacement);
						}
					}
					rend.SetPosition(i, val);
				}
			}
			if (randomize)
			{
				if (Random.Range(0, 1) == 0)
				{
					size.y *= -1f;
					if (Random.Range(0, 1) == 0)
					{
						size.x *= -1f;
					}
				}
				Vector2 val2 = offsets[Random.Range(0, max)];
				mat.SetTextureOffset("_MainTex", val2);
			}
			else
			{
				((Vector2)(ref val3))._002Ector((float)index / (float)columns - (float)(index / columns), (float)(index / columns) / (float)rows);
				mat.SetTextureOffset("_MainTex", val3);
			}
			((Renderer)rend).sortingLayerName = "New Layer 2";
			((Renderer)rend).sortingOrder = 500;
			if (run)
			{
				yield return (object)new WaitForSeconds(1f / framesPerSecond);
			}
		}
	}
}
