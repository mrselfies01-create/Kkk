using System;
using System.Collections.Generic;
using Audial;
using UnityEngine;
using UnityEngine.Analytics;
using UnityEngine.UI;

public class UIScript : MonoBehaviour
{
	public ParticleSystem[] gasEffect;

	public ParticleSystem[] remainingEffects;

	public EffectLibrary effectLibrary;

	public ParticleSystem visualEffects;

	private float targetStartSpeed = 5f;

	private float targetSize;

	public float startSpeedMin = 5f;

	public float startSpeedNormal = 9.9f;

	public float startSpeedMax = 19f;

	public float startSizeMin;

	public float startSizeMax = 80f;

	public GameObject sparkEffect;

	public AudioClip startSound;

	private Animator anim;

	public CameraMovement cameraController;

	public Animator cameraAnimator;

	private CameraFilterPack_TV_Horror HorrorEffect;

	private CameraFilterPack_TV_80 TVEffect;

	private CameraFilterPack_Real_VHS VHSEffect;

	public Button enterButton;

	public RectTransform gear;

	public float CalculatedRotation;

	public float rotationSpeed = 0.01f;

	public float changeSpeed = 0.5f;

	public float target1;

	public float target2;

	public float target3;

	public float target4;

	public Color defaultParticleColor;

	public float currentMax1Speed;

	public float currentMax2Speed;

	public float currentMax3Speed;

	public float currentMax4Speed;

	public float currentRotationAngle;

	private bool channel1;

	private bool channel2;

	private bool channel3;

	private bool channel4;

	private bool playAmbient;

	public AudioClip[] Channel1;

	public AudioClip[] Channel2;

	public AudioClip[] Channel3;

	public AudioClip[] Channel4;

	public AudioClip[] Ambient;

	private bool echoActive;

	private bool chorusActive;

	private bool reverbActive;

	private bool crusherActive;

	private bool filterActive;

	private Reverb reverbFilter;

	private Phaser phaserFilter;

	private Delay echoFilter;

	private Crusher crusherFilter;

	private StateVariableFilter filterFilter;

	private Gate gateFilter;

	private float Channel1Time;

	private float Channel2Time;

	private float Channel3Time;

	private float Channel4Time;

	private float CleanupTime;

	private float CleanupDelay;

	public float CleanupRate = 60f;

	public float Channel1MinDelay;

	public float Channel1MaxDelay = 10f;

	public float Channel2MinDelay;

	public float Channel2MaxDelay = 10f;

	public float Channel3MinDelay;

	public float Channel3MaxDelay = 10f;

	public float Channel4MinDelay;

	public float Channel4MaxDelay;

	public float Channel1Delay;

	public float Channel2Delay;

	public float Channel3Delay;

	public float Channel4Delay;

	public float ambientVolume = 1f;

	public bool ScanMode;

	public bool ScanChannels;

	public float Channel1ChangeDelay;

	public float Channel2ChangeDelay;

	public float Channel3ChangeDelay;

	public float Channel4ChangeDelay;

	public float echoChangeDelay;

	public float reverbChangeDelay;

	public float phaserChangeDelay;

	public float filterChangeDelay;

	public bool ScanEffects;

	public bool ScanVisuals;

	public float visualChangeSpeed = 0.01f;

	public float targetVisualChangeSpeed = 0.01f;

	public float defaultVisualChangeSpeed = 0.05f;

	public float HorrorFade;

	public float HorrorDistort;

	public float TVFade;

	public float VHSTracking;

	public float VHSJitter;

	public float VHSGlitch;

	public float VHSNoise;

	public float VHSBrightness;

	public float VHSContrast = 1f;

	private float curHorrorFade;

	private float curHorrorDistort;

	private float curTVFade;

	private float curVHSTracking;

	private float curVHSJitter;

	private float curVHSGlitch;

	private float curVHSNoise;

	private float curVHSBrightness;

	private float curVHSContrast = 1f;

	public Button3D channel1button;

	public Button3D channel2button;

	public Button3D channel3button;

	public Button3D channel4button;

	public Button3D echoButton;

	public Button3D reverbButton;

	public Button3D phaserButton;

	public Button3D filterButton;

	public float ScanScale = 0.0002f;

	public HSBColor startColor;

	private AudioSource audio;

	public bool UIVisible = true;

	private float lastCrusherIntensity = 0.05f;

	private float lastFilterIntensity = 0.5f;

	private float lastEchoIntensity = 0.05f;

	public float minIntensityDist = 0.2f;

	public float echoIntensity = 0.5f;

	public float chorusIntensity = 0.5f;

	public float crusherIntensity = 0.5f;

	public float filterIntensity;

	public float reverbIntensity = 0.5f;

	public float inc = 0.0001f;

	public float particleinc = 1f;

	public float colorHueInc = 0.05f;

	public float ColorSaturationInc = 0.01f;

	public float targetHue;

	public float targetSaturation = 1f;

	public float minSaturation = 0.5f;

	private float targetEcho;

	private float targetChorus;

	private float targetReverb;

	private float targetCrusher;

	private float targetFilter;

	public void ReportFilter(string filtername)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary["DeviceName"] = SystemInfo.deviceName;
		dictionary["DeviceModel"] = SystemInfo.deviceModel;
		dictionary["DeviceType"] = SystemInfo.deviceType;
		dictionary["DeviceGraphicsDeviceMemorySize"] = SystemInfo.graphicsMemorySize;
		dictionary["DeviceMaxTextureSize"] = SystemInfo.maxTextureSize;
		dictionary["DeviceOperatingSystem"] = SystemInfo.operatingSystem;
		dictionary["DeviceSystemMemorySize"] = SystemInfo.systemMemorySize;
		Analytics.CustomEvent(filtername, (IDictionary<string, object>)dictionary);
	}

	private void Start()
	{
		Screen.sleepTimeout = -1;
		HorrorEffect = ((Component)cameraController).gameObject.GetComponentInChildren<CameraFilterPack_TV_Horror>();
		TVEffect = ((Component)cameraController).gameObject.GetComponentInChildren<CameraFilterPack_TV_80>();
		VHSEffect = ((Component)cameraController).gameObject.GetComponentInChildren<CameraFilterPack_Real_VHS>();
		int seed = DateTime.Now.Second * DateTime.Now.Minute * DateTime.Now.Day;
		Random.seed = seed;
		sparkEffect.SetActive(ScanMode);
		anim = ((Component)this).GetComponent<Animator>();
		currentMax1Speed = Channel1MaxDelay;
		currentMax2Speed = Channel2MaxDelay;
		currentMax3Speed = Channel3MaxDelay;
		currentMax4Speed = Channel4MaxDelay;
		audio = ((Component)this).GetComponent<AudioSource>();
		SetChannel1Delay();
		SetChannel2Delay();
		SetChannel3Delay();
		SetChannel4Delay();
		echoFilter = ((Component)this).GetComponent<Delay>();
		reverbFilter = ((Component)this).GetComponent<Reverb>();
		phaserFilter = ((Component)this).GetComponent<Phaser>();
		crusherFilter = ((Component)this).GetComponent<Crusher>();
		filterFilter = ((Component)this).GetComponent<StateVariableFilter>();
		gateFilter = ((Component)this).GetComponent<Gate>();
		((Behaviour)echoFilter).enabled = false;
		((Behaviour)reverbFilter).enabled = false;
		((Behaviour)phaserFilter).enabled = false;
		((Behaviour)crusherFilter).enabled = false;
		((Behaviour)filterFilter).enabled = false;
		ReportFilter("SpiritusStarted");
	}

	public void ShowVisual()
	{
		anim.SetTrigger("HideUI");
		UIVisible = true;
		cameraController.ShowVisual(UIVisible);
		ReportFilter("ShowingVisual");
	}

	public void ShowUI()
	{
		anim.SetTrigger("ShowUI");
		UIVisible = false;
		cameraController.ShowVisual(UIVisible);
		ReportFilter("ShowingUiFromVisual");
	}

	private float GetTarget()
	{
		float num = Random.Range(0f, 1f);
		if (num >= 0.9f)
		{
			return 1f;
		}
		if (num >= 0.8f)
		{
			return 0.9f;
		}
		if (num >= 0.5f)
		{
			return 0.8f;
		}
		if (num <= 0.1f)
		{
			return 0f;
		}
		if (num <= 0.2f)
		{
			return 0.1f;
		}
		return 0.2f;
	}

	private void FixedUpdate()
	{
		int num = 0;
		if (channel1)
		{
			num++;
		}
		if (channel2)
		{
			num++;
		}
		if (channel3)
		{
			num++;
		}
		if (channel4)
		{
			num++;
		}
		if (((Behaviour)phaserFilter).isActiveAndEnabled)
		{
			num++;
		}
		if (((Behaviour)crusherFilter).isActiveAndEnabled)
		{
			num++;
		}
		if (((Behaviour)echoFilter).isActiveAndEnabled)
		{
			num++;
		}
		if (((Behaviour)reverbFilter).isActiveAndEnabled)
		{
			num++;
		}
		if (((Behaviour)filterFilter).isActiveAndEnabled)
		{
			num++;
		}
		if (echoButton.pressed != echoActive)
		{
			echoButton.pressed = echoActive;
		}
		if (reverbButton.pressed != reverbActive)
		{
			reverbButton.pressed = reverbActive;
		}
		if (phaserButton.pressed != chorusActive)
		{
			phaserButton.pressed = chorusActive;
		}
		if (filterButton.pressed != filterActive)
		{
			filterButton.pressed = filterActive;
		}
		if (channel1button.pressed != channel1)
		{
			channel1button.pressed = channel1;
		}
		if (channel2button.pressed != channel2)
		{
			channel2button.pressed = channel2;
		}
		if (channel3button.pressed != channel3)
		{
			channel3button.pressed = channel3;
		}
		if (channel4button.pressed != channel4)
		{
			channel4button.pressed = channel4;
		}
		float num2 = Channel1Delay;
		if (num2 > Channel2Delay)
		{
			num2 = Channel2Delay;
		}
		if (num2 > Channel3Delay)
		{
			num2 = Channel3Delay;
		}
		if (num2 > Channel4Delay)
		{
			num2 = Channel4Delay;
		}
		float num3 = 1f - num2 / 2.5f;
		if (num3 < 0f)
		{
			num3 = 0f;
		}
		cameraAnimator.SetLayerWeight(1, (float)num / 10f * num3);
		ParticleSystem[] array = gasEffect;
		foreach (ParticleSystem val in array)
		{
			if (channel1 && channel2 && channel3 && channel4)
			{
				if (val.isStopped)
				{
					val.Play();
				}
			}
			else if (val.isPlaying)
			{
				val.Stop();
			}
		}
		ParticleSystem[] array2 = remainingEffects;
		foreach (ParticleSystem val2 in array2)
		{
			if ((channel1 || channel2 || channel3 || channel4) && ((Behaviour)echoFilter).isActiveAndEnabled && ((Behaviour)phaserFilter).isActiveAndEnabled && ((Behaviour)reverbFilter).isActiveAndEnabled && ((Behaviour)filterFilter).isActiveAndEnabled)
			{
				if (val2.isStopped)
				{
					val2.Play();
				}
			}
			else if (val2.isPlaying)
			{
				val2.Stop();
			}
		}
	}

	private void Update()
	{
		//IL_0bff: Unknown result type (might be due to invalid IL or missing references)
		//IL_133d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2e: Unknown result type (might be due to invalid IL or missing references)
		if (!UIVisible)
		{
			if (Input.touchCount > 0)
			{
				ShowUI();
			}
			else if (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1))
			{
				ShowUI();
			}
		}
		if (ScanChannels)
		{
			if (Channel1ChangeDelay <= 0f)
			{
				ToggleChannel1();
				Channel1ChangeDelay = Random.Range(1f, 10f);
			}
			if (Channel2ChangeDelay <= 0f)
			{
				ToggleChannel2();
				Channel2ChangeDelay = Random.Range(1f, 10f);
			}
			if (Channel3ChangeDelay <= 0f)
			{
				ToggleChannel3();
				Channel3ChangeDelay = Random.Range(1f, 10f);
			}
			if (Channel4ChangeDelay <= 0f)
			{
				ToggleChannel4();
				Channel4ChangeDelay = Random.Range(1f, 10f);
			}
			Channel1ChangeDelay -= Time.deltaTime;
			Channel2ChangeDelay -= Time.deltaTime;
			Channel3ChangeDelay -= Time.deltaTime;
			Channel4ChangeDelay -= Time.deltaTime;
		}
		if (ScanEffects)
		{
			if (echoChangeDelay <= 0f)
			{
				ToggleEffectChannel1();
				echoChangeDelay = Random.Range(1f, 10f);
			}
			if (reverbChangeDelay <= 0f)
			{
				ToggleEffectChannel3();
				reverbChangeDelay = Random.Range(1f, 10f);
			}
			if (phaserChangeDelay <= 0f)
			{
				ToggleEffectChannel2();
				if (chorusActive)
				{
					phaserChangeDelay = Random.Range(1f, 10f);
				}
				else
				{
					phaserChangeDelay = Random.Range(5f, 20f);
				}
			}
			if (filterChangeDelay <= 0f)
			{
				ToggleEffectChannel4();
				filterChangeDelay = Random.Range(1f, 10f);
			}
			echoChangeDelay -= Time.deltaTime;
			reverbChangeDelay -= Time.deltaTime;
			phaserChangeDelay -= Time.deltaTime;
			filterChangeDelay -= Time.deltaTime;
		}
		if (ScanVisuals && cameraController.VisualsOn)
		{
			if (HorrorFade < curHorrorFade + visualChangeSpeed && HorrorFade > curHorrorFade - visualChangeSpeed)
			{
				HorrorFade = Random.Range(0f, 1f);
			}
			if (HorrorFade < curHorrorFade)
			{
				curHorrorFade -= visualChangeSpeed;
			}
			if (HorrorFade > curHorrorFade)
			{
				curHorrorFade += visualChangeSpeed;
			}
			if (HorrorDistort < curHorrorDistort + visualChangeSpeed && HorrorDistort > curHorrorDistort - visualChangeSpeed)
			{
				HorrorDistort = Random.Range(0f, 1f);
			}
			if (HorrorDistort < curHorrorDistort)
			{
				curHorrorDistort -= visualChangeSpeed;
			}
			if (HorrorDistort > curHorrorDistort)
			{
				curHorrorDistort += visualChangeSpeed;
			}
			if (TVFade < curTVFade + visualChangeSpeed && TVFade > curTVFade - visualChangeSpeed)
			{
				TVFade = Random.Range(0f, 1f);
			}
			if (TVFade < curTVFade)
			{
				curTVFade -= visualChangeSpeed;
			}
			if (TVFade > curTVFade)
			{
				curTVFade += visualChangeSpeed;
			}
			if (VHSTracking < curVHSTracking + visualChangeSpeed && VHSTracking > curVHSTracking - visualChangeSpeed)
			{
				VHSTracking = Random.Range(0f, 0.1f);
			}
			if (VHSTracking < curVHSTracking)
			{
				curVHSTracking -= visualChangeSpeed;
			}
			if (VHSTracking > curVHSTracking)
			{
				curVHSTracking += visualChangeSpeed;
			}
			if (VHSJitter < curVHSJitter + visualChangeSpeed && VHSJitter > curVHSJitter - visualChangeSpeed)
			{
				VHSJitter = Random.Range(0f, 1f);
			}
			if (VHSJitter < curVHSJitter)
			{
				curVHSJitter -= visualChangeSpeed;
			}
			if (VHSJitter > curVHSJitter)
			{
				curVHSJitter += visualChangeSpeed;
			}
			if (VHSGlitch < curVHSGlitch + visualChangeSpeed && VHSGlitch > curVHSGlitch - visualChangeSpeed)
			{
				VHSGlitch = Random.Range(0f, 1f);
			}
			if (VHSGlitch < curVHSGlitch)
			{
				curVHSGlitch -= visualChangeSpeed;
			}
			if (VHSGlitch > curVHSGlitch)
			{
				curVHSGlitch += visualChangeSpeed;
			}
			if (VHSNoise < curVHSNoise + visualChangeSpeed && VHSNoise > curVHSNoise - visualChangeSpeed)
			{
				VHSNoise = Random.Range(0f, 1f);
			}
			if (VHSNoise < curVHSNoise)
			{
				curVHSNoise -= visualChangeSpeed;
			}
			if (VHSNoise > curVHSNoise)
			{
				curVHSNoise += visualChangeSpeed;
			}
			if (VHSBrightness < curVHSBrightness + visualChangeSpeed && VHSBrightness > curVHSBrightness - visualChangeSpeed)
			{
				VHSBrightness = Random.Range(0f, 1f);
			}
			if (VHSBrightness < curVHSBrightness)
			{
				curVHSBrightness -= visualChangeSpeed;
			}
			if (VHSBrightness > curVHSBrightness)
			{
				curVHSBrightness += visualChangeSpeed;
			}
			if (VHSContrast < curVHSContrast + visualChangeSpeed && VHSContrast > curVHSContrast - visualChangeSpeed)
			{
				VHSContrast = Random.Range(0f, 1.5f);
			}
			if (VHSContrast < curVHSContrast)
			{
				curVHSContrast -= visualChangeSpeed;
			}
			if (VHSContrast > curVHSContrast)
			{
				curVHSContrast += visualChangeSpeed;
			}
		}
		else
		{
			VHSGlitch = 0f;
			VHSTracking = 0f;
			VHSNoise = 0f;
			VHSContrast = 1f;
			VHSBrightness = 0f;
			VHSJitter = 0f;
			TVFade = 0f;
			HorrorFade = 0f;
			HorrorDistort = 0f;
			if (curVHSGlitch > 0f)
			{
				curVHSGlitch -= visualChangeSpeed * 5f;
			}
			if (curVHSTracking > 0f)
			{
				curVHSTracking -= visualChangeSpeed * 5f;
			}
			if (curVHSNoise > 0f)
			{
				curVHSNoise -= visualChangeSpeed * 5f;
			}
			if (curVHSBrightness > 0f)
			{
				curVHSBrightness -= visualChangeSpeed * 5f;
			}
			if (curVHSBrightness < 0f)
			{
				curVHSBrightness += visualChangeSpeed * 5f;
			}
			if (curVHSBrightness - visualChangeSpeed * 5f < 0f && curVHSBrightness + visualChangeSpeed * 5f > 0f)
			{
				curVHSBrightness = 0f;
			}
			if (curVHSContrast > 1f)
			{
				curVHSContrast -= visualChangeSpeed * 5f;
			}
			if (curVHSContrast < 1f)
			{
				curVHSContrast += visualChangeSpeed * 5f;
			}
			if (curVHSContrast - visualChangeSpeed * 5f < 1f && curVHSContrast + visualChangeSpeed * 5f > 1f)
			{
				curVHSContrast = 1f;
			}
			if (curVHSJitter > 0f)
			{
				curVHSJitter -= visualChangeSpeed * 5f;
			}
			if (curTVFade > 0f)
			{
				curTVFade -= visualChangeSpeed * 5f;
			}
			if (curHorrorFade > 0f)
			{
				curHorrorFade -= visualChangeSpeed * 5f;
			}
			if (curHorrorDistort > 0f)
			{
				curHorrorDistort -= visualChangeSpeed * 5f;
			}
		}
		if (Object.op_Implicit((Object)(object)TVEffect))
		{
			TVEffect.Fade = curTVFade;
		}
		if (Object.op_Implicit((Object)(object)HorrorEffect))
		{
			HorrorEffect.Fade = curHorrorFade;
			HorrorEffect.Distortion = curHorrorDistort;
		}
		if (Object.op_Implicit((Object)(object)VHSEffect))
		{
			VHSEffect.GLITCH = curVHSGlitch;
			VHSEffect.NOISE = curVHSNoise;
			VHSEffect.Brightness = curVHSBrightness;
			VHSEffect.Constrast = curVHSContrast;
			VHSEffect.JITTER = curVHSJitter;
			VHSEffect.TRACKING = curVHSTracking;
		}
		float num = rotationSpeed * 360f * Time.deltaTime;
		float num2 = 0f;
		if (channel1)
		{
			num2 += 3f;
		}
		if (channel2)
		{
			num2 += 3f;
		}
		if (channel3)
		{
			num2 += 3f;
		}
		if (channel4)
		{
			num2 += 3f;
		}
		if (chorusActive && num2 > 0f)
		{
			num2 += 3f;
		}
		if (echoActive && num2 > 0f)
		{
			num2 += 3f;
		}
		if (reverbActive && num2 > 0f)
		{
			num2 += 3f;
		}
		if (ScanMode)
		{
			num2 += 6f;
		}
		if (!ScanMode)
		{
			targetVisualChangeSpeed = 0.01f;
			visualEffects.startSpeed = startSpeedNormal;
			visualEffects.startSize = startSizeMax;
			visualEffects.startColor = defaultParticleColor;
			visualChangeSpeed = defaultVisualChangeSpeed;
		}
		if (ScanMode)
		{
			if (targetVisualChangeSpeed < visualChangeSpeed + 0.01f && targetVisualChangeSpeed > visualChangeSpeed - 0.01f)
			{
				targetVisualChangeSpeed = Random.Range(0.01f, 0.3f);
			}
			if (targetVisualChangeSpeed < visualChangeSpeed)
			{
				visualChangeSpeed -= 0.01f;
			}
			if (targetVisualChangeSpeed > visualChangeSpeed)
			{
				visualChangeSpeed += 0.01f;
			}
		}
		if (ScanMode)
		{
			if (startColor.h >= targetHue - colorHueInc && startColor.h <= targetHue + colorHueInc)
			{
				targetHue = GetTarget();
			}
			else
			{
				float num3 = 1f;
				if (startColor.h > targetHue)
				{
					num3 = -1f;
				}
				startColor.h += colorHueInc * num3;
				startColor.a = 1f;
				visualEffects.startColor = startColor.ToColor();
			}
			if (startColor.s >= targetSaturation - ColorSaturationInc && startColor.s <= targetSaturation + ColorSaturationInc)
			{
				targetSaturation = minSaturation + (1f - minSaturation) * GetTarget();
			}
			else
			{
				float num4 = 1f;
				if (startColor.s > targetSaturation)
				{
					num4 = -1f;
				}
				startColor.s += ColorSaturationInc * num4;
				startColor.b = startColor.s;
				startColor.a = 1f;
				visualEffects.startColor = startColor.ToColor();
			}
			if (visualEffects.startSpeed >= targetStartSpeed - particleinc && visualEffects.startSpeed <= targetStartSpeed + particleinc)
			{
				targetStartSpeed = startSpeedMin + (startSpeedMax - startSpeedMin) * GetTarget();
			}
			else
			{
				float num5 = 1f;
				if (visualEffects.startSpeed > targetStartSpeed)
				{
					num5 = -1f;
				}
				ParticleSystem obj = visualEffects;
				obj.startSpeed += particleinc * num5;
			}
			if (visualEffects.startSize >= targetSize - particleinc && visualEffects.startSize <= targetSize + particleinc)
			{
				targetSize = startSizeMax * GetTarget();
			}
			else
			{
				float num6 = 1f;
				if (visualEffects.startSize > targetSize)
				{
					num6 = -1f;
				}
				ParticleSystem obj2 = visualEffects;
				obj2.startSize += particleinc * num6;
			}
			if (echoIntensity >= targetEcho - inc && echoIntensity <= targetEcho + inc)
			{
				targetEcho = GetTarget();
			}
			else
			{
				float num7 = 1f;
				if (echoIntensity > targetEcho)
				{
					num7 = -1f;
				}
				echoIntensity += inc * num7;
			}
			if (chorusIntensity >= targetChorus - inc && chorusIntensity <= targetChorus + inc)
			{
				targetChorus = GetTarget();
			}
			else
			{
				float num8 = 1f;
				if (chorusIntensity > targetChorus)
				{
					num8 = -1f;
				}
				chorusIntensity += inc * num8;
			}
			if (reverbIntensity >= targetReverb - inc && reverbIntensity <= targetReverb + inc)
			{
				targetReverb = GetTarget();
			}
			else
			{
				float num9 = 1f;
				if (reverbIntensity > targetReverb)
				{
					num9 = -1f;
				}
				reverbIntensity += inc * num9;
			}
			if (crusherIntensity >= targetCrusher - inc && crusherIntensity <= targetCrusher + inc)
			{
				targetCrusher = GetTarget();
			}
			else
			{
				float num10 = 1f;
				if (crusherIntensity > targetCrusher)
				{
					num10 = -1f;
				}
				crusherIntensity += inc * num10;
			}
			if (filterIntensity >= targetFilter - inc && filterIntensity <= targetFilter + inc)
			{
				targetFilter = GetTarget();
			}
			else
			{
				float num11 = 1f;
				if (filterIntensity > targetFilter)
				{
					num11 = -1f;
				}
				filterIntensity += inc * num11;
			}
			if (echoActive && Mathf.Abs(echoIntensity - lastEchoIntensity) > minIntensityDist)
			{
				effectLibrary.SetDelay(echoFilter, echoIntensity);
				lastEchoIntensity = echoIntensity;
			}
			if (crusherActive && Mathf.Abs(crusherIntensity - lastCrusherIntensity) > minIntensityDist)
			{
				effectLibrary.SetCrusher(crusherFilter, crusherIntensity);
				lastCrusherIntensity = crusherIntensity;
			}
			if (filterActive && Mathf.Abs(filterIntensity - lastFilterIntensity) > minIntensityDist)
			{
				effectLibrary.SetFilter(filterFilter, filterIntensity);
				lastFilterIntensity = filterIntensity;
			}
			if (chorusActive)
			{
				effectLibrary.SetPhazer(phaserFilter, chorusIntensity);
			}
			if (reverbActive)
			{
				effectLibrary.SetReverb(reverbFilter, reverbIntensity);
			}
		}
		else
		{
			echoIntensity = 0.5f;
			reverbIntensity = 0.5f;
			chorusIntensity = 0.5f;
			crusherIntensity = 0.5f;
			filterIntensity = 0.5f;
		}
		currentRotationAngle += num * num2;
		((Transform)gear).rotation = Quaternion.Euler(new Vector3(0f, 0f, currentRotationAngle));
		if (target1 > currentMax1Speed - changeSpeed && target1 < currentMax1Speed + changeSpeed)
		{
			target1 = Random.Range(0.5f, Channel1MaxDelay);
		}
		else
		{
			float num12 = currentMax1Speed - target1;
			if (num12 < 0f)
			{
				currentMax1Speed += changeSpeed;
			}
			else
			{
				currentMax1Speed -= changeSpeed;
			}
		}
		if (target2 > currentMax2Speed - changeSpeed && target2 < currentMax2Speed + changeSpeed)
		{
			target2 = Random.Range(0.5f, Channel2MaxDelay);
		}
		else
		{
			float num13 = currentMax2Speed - target2;
			if (num13 < 0f)
			{
				currentMax2Speed += changeSpeed;
			}
			else
			{
				currentMax2Speed -= changeSpeed;
			}
		}
		if (target3 > currentMax3Speed - changeSpeed && target3 < currentMax3Speed + changeSpeed)
		{
			target3 = Random.Range(0.5f, Channel3MaxDelay);
		}
		else
		{
			float num14 = currentMax3Speed - target3;
			if (num14 < 0f)
			{
				currentMax3Speed += changeSpeed;
			}
			else
			{
				currentMax3Speed -= changeSpeed;
			}
		}
		if (target4 > currentMax4Speed - changeSpeed && target4 < currentMax4Speed + changeSpeed)
		{
			target4 = Random.Range(0.5f, Channel4MaxDelay);
		}
		else
		{
			float num15 = currentMax4Speed - target4;
			if (num15 < 0f)
			{
				currentMax4Speed += changeSpeed;
			}
			else
			{
				currentMax4Speed += changeSpeed;
			}
		}
		float deltaTime = Time.deltaTime;
		Channel1Time += deltaTime;
		Channel2Time += deltaTime;
		Channel3Time += deltaTime;
		Channel4Time += deltaTime;
		CleanupTime += deltaTime;
		if (playAmbient)
		{
		}
		if (Channel1Time > Channel1Delay && channel1)
		{
			int num16 = Random.Range(1, 850);
			string empty = string.Empty;
			empty = ((num16 <= 400) ? ("Channel 1/" + num16) : ((num16 > 800) ? ("SpiritusUpdate/Channel1/" + (num16 - 800)) : ("Channel 2/" + (num16 - 400))));
			AudioClip val = Resources.Load<AudioClip>(empty);
			audio.PlayOneShot(val);
			SetChannel1Delay();
			Channel1Time = 0f;
		}
		if (Channel2Time > Channel2Delay && channel2)
		{
			int num17 = Random.Range(1, 850);
			string empty2 = string.Empty;
			empty2 = ((num17 <= 400) ? ("Bank1male/" + num17) : ((num17 > 800) ? ("SpiritusUpdate/Channel2/" + (num17 - 800)) : ("Bank2female/" + (num17 - 400))));
			AudioClip val2 = Resources.Load<AudioClip>(empty2);
			audio.PlayOneShot(val2);
			SetChannel2Delay();
			Channel2Time = 0f;
		}
		if (Channel3Time > Channel3Delay && channel3)
		{
			int num18 = Random.Range(1, 850);
			string empty3 = string.Empty;
			empty3 = ((num18 <= 400) ? ("Channel 3/" + num18) : ((num18 > 800) ? ("SpiritusUpdate/Channel3/" + (num18 - 800)) : ("Bank3random/" + num18)));
			AudioClip val3 = Resources.Load<AudioClip>(empty3);
			audio.PlayOneShot(val3);
			SetChannel3Delay();
			Channel3Time = 0f;
		}
		if (Channel4Time > Channel4Delay && channel4)
		{
			int num19 = Random.Range(1, 750);
			string empty4 = string.Empty;
			empty4 = ((num19 <= 300) ? ("Channel 4/" + num19) : ((num19 > 700) ? ("SpiritusUpdate/Channel4/" + (num19 - 700)) : ("Bank4music/" + num19)));
			AudioClip val4 = Resources.Load<AudioClip>(empty4);
			audio.PlayOneShot(val4);
			SetChannel4Delay();
			Channel4Time = 0f;
		}
		if (CleanupTime > CleanupDelay)
		{
			Resources.UnloadUnusedAssets();
			SetCleanupDelay();
		}
	}

	private int NumChannelsActive()
	{
		int num = 0;
		if (channel1)
		{
			num++;
		}
		if (channel2)
		{
			num++;
		}
		if (channel3)
		{
			num++;
		}
		if (channel4)
		{
			num++;
		}
		return num;
	}

	private void SetChannel1Delay()
	{
		Channel1Delay = Random.Range(Channel1MinDelay, Channel1MaxDelay);
		if (ScanMode)
		{
			Channel1Delay = Random.Range(Channel1MinDelay + 0.5f, currentMax1Speed);
		}
	}

	private void SetChannel2Delay()
	{
		Channel2Delay = Random.Range(Channel2MinDelay, Channel2MaxDelay);
		if (ScanMode)
		{
			Channel2Delay = Random.Range(Channel2MinDelay + 0.5f, currentMax2Speed);
		}
	}

	private void SetCleanupDelay()
	{
		CleanupDelay += CleanupRate;
	}

	private void SetChannel3Delay()
	{
		Channel3Delay = Random.Range(Channel3MinDelay, Channel3MaxDelay);
		if (ScanMode)
		{
			Channel3Delay *= Random.Range(Channel3MinDelay + 0.5f, currentMax3Speed);
		}
	}

	private void SetChannel4Delay()
	{
		Channel4Delay = Random.Range(Channel4MinDelay, Channel4MaxDelay);
		if (ScanMode)
		{
			Channel4Delay *= Random.Range(Channel4MinDelay + 0.5f, currentMax4Speed);
		}
	}

	public void Enter()
	{
		ScanMode = !ScanMode;
		sparkEffect.SetActive(ScanMode);
	}

	public void ToggleScanChannel()
	{
		ScanChannels = !ScanChannels;
		Channel1ChangeDelay = Random.Range(1f, 10f);
		Channel2ChangeDelay = Random.Range(1f, 10f);
		Channel3ChangeDelay = Random.Range(1f, 10f);
		Channel4ChangeDelay = Random.Range(1f, 10f);
	}

	public void UpdateChannel1(Button3D btn)
	{
		if (Object.op_Implicit((Object)(object)btn))
		{
			btn.pressed = channel1;
		}
	}

	public void UpdateChannel2(Button3D btn)
	{
		if (Object.op_Implicit((Object)(object)btn))
		{
			btn.pressed = channel2;
		}
	}

	public void UpdateChannel3(Button3D btn)
	{
		if (Object.op_Implicit((Object)(object)btn))
		{
			btn.pressed = channel3;
		}
	}

	public void UpdateChannel4(Button3D btn)
	{
		if (Object.op_Implicit((Object)(object)btn))
		{
			btn.pressed = channel4;
		}
	}

	public void ToggleScanEffects()
	{
		ScanEffects = !ScanEffects;
		echoChangeDelay = Random.Range(1f, 10f);
		reverbChangeDelay = Random.Range(1f, 10f);
		phaserChangeDelay = Random.Range(1f, 10f);
		filterChangeDelay = Random.Range(1f, 10f);
	}

	public void ToggleScanVisuals()
	{
		ScanVisuals = !ScanVisuals;
		if (ScanVisuals)
		{
			HorrorFade = Random.Range(0f, 1f);
			HorrorDistort = Random.Range(0f, 1f);
			TVFade = Random.Range(0f, 1f);
			VHSTracking = Random.Range(0f, 0.1f);
			VHSJitter = Random.Range(0f, 1f);
			VHSGlitch = Random.Range(0f, 1f);
			VHSNoise = Random.Range(0f, 1f);
			VHSContrast = Random.Range(0f, 1.5f);
			VHSBrightness = Random.Range(-1f, 1f);
			curHorrorFade = 0f;
			curHorrorDistort = 0f;
			curTVFade = 0f;
			curVHSTracking = 0f;
			curVHSJitter = 0f;
			curVHSGlitch = 0f;
			curVHSNoise = 0f;
			curVHSContrast = 0.5f;
			curVHSBrightness = 0f;
		}
	}

	public void ToggleScanIntensity()
	{
	}

	public void ToggleChannel1()
	{
		channel1 = !channel1;
	}

	public void ToggleChannel2()
	{
		channel2 = !channel2;
	}

	public void ToggleChannel3()
	{
		channel3 = !channel3;
	}

	public void ToggleChannel4()
	{
		channel4 = !channel4;
	}

	public void ToggleEffectChannel1()
	{
		echoActive = !echoActive;
		((Behaviour)echoFilter).enabled = echoActive;
	}

	public void ToggleEffectChannel2()
	{
		chorusActive = !chorusActive;
		((Behaviour)phaserFilter).enabled = chorusActive;
	}

	public void ToggleEffectChannel3()
	{
		reverbActive = !reverbActive;
		((Behaviour)reverbFilter).enabled = reverbActive;
	}

	public void ToggleEffectChannel4()
	{
		filterActive = !filterActive;
		((Behaviour)filterFilter).enabled = filterActive;
	}

	public void ToggleGate()
	{
		((Behaviour)gateFilter).enabled = !((Behaviour)gateFilter).enabled;
	}
}
