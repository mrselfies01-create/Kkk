using UnityEngine;

public class SampleSongManager : MonoBehaviour
{
	public Song[] mySongs;
}
