using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Blur/Tilt_Shift")]
public class CameraFilterPack_Blur_Tilt_Shift : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	[Range(0f, 20f)]
	public float Amount = 3f;

	[Range(2f, 16f)]
	public int FastFilter = 8;

	[Range(0f, 1f)]
	public float Smooth = 0.5f;

	[Range(0f, 1f)]
	public float Size = 0.5f;

	[Range(-1f, 1f)]
	public float Position = 0.5f;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/BlurTiltShift");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			int fastFilter = FastFilter;
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Amount", Amount);
			material.SetFloat("_Value1", Smooth);
			material.SetFloat("_Value2", Size);
			material.SetFloat("_Value3", Position);
			material.SetVector("_ScreenResolution", Vector4.op_Implicit(new Vector2((float)(Screen.width / fastFilter), (float)(Screen.height / fastFilter))));
			int num = ((Texture)sourceTexture).width / fastFilter;
			int num2 = ((Texture)sourceTexture).height / fastFilter;
			if (FastFilter > 1)
			{
				RenderTexture temporary = RenderTexture.GetTemporary(num, num2, 0);
				RenderTexture temporary2 = RenderTexture.GetTemporary(num, num2, 0);
				((Texture)temporary).filterMode = (FilterMode)2;
				Graphics.Blit((Texture)(object)sourceTexture, temporary, material, 2);
				Graphics.Blit((Texture)(object)temporary, temporary2, material, 0);
				material.SetFloat("_Amount", Amount * 2f);
				Graphics.Blit((Texture)(object)temporary2, temporary, material, 2);
				Graphics.Blit((Texture)(object)temporary, temporary2, material, 0);
				material.SetTexture("_MainTex2", (Texture)(object)temporary2);
				RenderTexture.ReleaseTemporary(temporary);
				RenderTexture.ReleaseTemporary(temporary2);
				Graphics.Blit((Texture)(object)sourceTexture, destTexture, material, 1);
			}
			else
			{
				Graphics.Blit((Texture)(object)sourceTexture, destTexture, material, 0);
			}
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
