using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Glasses/Futuristic Montain")]
public class CameraFilterPack_Glasses_On_5 : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	[Range(0f, 1f)]
	public float Fade = 0.2f;

	[Range(0f, 0.1f)]
	public float VisionBlur = 0.005f;

	public Color GlassesColor = new Color(0.1f, 0.1f, 0.1f, 1f);

	public Color GlassesColor2 = new Color(0.45f, 0.45f, 0.45f, 0.25f);

	[Range(0f, 1f)]
	public float GlassDistortion = 0.6f;

	[Range(0f, 1f)]
	public float GlassAberration = 0.3f;

	[Range(0f, 1f)]
	public float UseFinalGlassColor;

	[Range(0f, 1f)]
	public float UseScanLine = 0.4f;

	[Range(1f, 512f)]
	public float UseScanLineSize = 358f;

	public Color GlassColor = new Color(0.1f, 0.3f, 1f, 1f);

	private Material SCMaterial;

	private Texture2D Texture2;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		ref Texture2D texture = ref Texture2;
		Object obj = Resources.Load("CameraFilterPack_Glasses_On6");
		texture = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		SCShader = Shader.Find("CameraFilterPack/Glasses_On");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("UseFinalGlassColor", UseFinalGlassColor);
			material.SetFloat("Fade", Fade);
			material.SetFloat("VisionBlur", VisionBlur);
			material.SetFloat("GlassDistortion", GlassDistortion);
			material.SetFloat("GlassAberration", GlassAberration);
			material.SetColor("GlassesColor", GlassesColor);
			material.SetColor("GlassesColor2", GlassesColor2);
			material.SetColor("GlassColor", GlassColor);
			material.SetFloat("UseScanLineSize", UseScanLineSize);
			material.SetFloat("UseScanLine", UseScanLine);
			material.SetTexture("_MainTex2", (Texture)(object)Texture2);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
