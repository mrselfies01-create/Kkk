using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/3D/Ghost")]
public class CameraFilterPack_3D_Ghost : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	public bool _Visualize;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	[Range(0f, 100f)]
	public float _FixDistance = 5f;

	[Range(-0.5f, 0.99f)]
	public float Ghost_Near = 0.08f;

	[Range(0f, 1f)]
	public float Ghost_Far = 0.55f;

	[Range(0f, 2f)]
	public float Intensity = 1f;

	[Range(0f, 1f)]
	public float GhostWithoutObject = 1f;

	[Range(-1f, 1f)]
	public float GhostPosX;

	[Range(-1f, 1f)]
	public float GhostPosY;

	[Range(0.1f, 8f)]
	public float GhostFade2 = 2f;

	[Range(-1f, 1f)]
	public float GhostFade;

	[Range(0.5f, 1.5f)]
	public float GhostSize = 0.9f;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/3D_Ghost");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value2", Intensity);
			material.SetFloat("GhostPosX", GhostPosX);
			material.SetFloat("GhostPosY", GhostPosY);
			material.SetFloat("GhostFade", GhostFade);
			material.SetFloat("GhostFade2", GhostFade2);
			material.SetFloat("GhostSize", GhostSize);
			material.SetFloat("_Visualize", (float)(_Visualize ? 1 : 0));
			material.SetFloat("_FixDistance", _FixDistance);
			material.SetFloat("Drop_Near", Ghost_Near);
			material.SetFloat("Drop_Far", Ghost_Far);
			material.SetFloat("Drop_With_Obj", GhostWithoutObject);
			material.SetVector("_ScreenResolution", new Vector4((float)((Texture)sourceTexture).width, (float)((Texture)sourceTexture).height, 0f, 0f));
			((Component)this).GetComponent<Camera>().depthTextureMode = (DepthTextureMode)1;
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
