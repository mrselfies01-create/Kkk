using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/3D/Anomaly")]
public class CameraFilterPack_3D_Anomaly : MonoBehaviour
{
	public Shader SCShader;

	public bool _Visualize;

	private float TimeX = 1f;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	[Range(0f, 100f)]
	public float _FixDistance = 23f;

	[Range(-0.5f, 0.99f)]
	public float Anomaly_Near = 0.045f;

	[Range(0f, 1f)]
	public float Anomaly_Far = 0.11f;

	[Range(0f, 2f)]
	public float Intensity = 1f;

	[Range(0f, 1f)]
	public float AnomalyWithoutObject = 1f;

	[Range(0.1f, 1f)]
	public float Anomaly_Distortion = 0.25f;

	[Range(4f, 64f)]
	public float Anomaly_Distortion_Size = 12f;

	[Range(-4f, 8f)]
	public float Anomaly_Intensity = 2f;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/3D_Anomaly");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value2", Intensity);
			material.SetFloat("Anomaly_Distortion", Anomaly_Distortion);
			material.SetFloat("Anomaly_Distortion_Size", Anomaly_Distortion_Size);
			material.SetFloat("Anomaly_Intensity", Anomaly_Intensity);
			material.SetFloat("_Visualize", (float)(_Visualize ? 1 : 0));
			material.SetFloat("_FixDistance", _FixDistance);
			material.SetFloat("Anomaly_Near", Anomaly_Near);
			material.SetFloat("Anomaly_Far", Anomaly_Far);
			material.SetFloat("Anomaly_With_Obj", AnomalyWithoutObject);
			material.SetVector("_ScreenResolution", new Vector4((float)((Texture)sourceTexture).width, (float)((Texture)sourceTexture).height, 0f, 0f));
			((Component)this).GetComponent<Camera>().depthTextureMode = (DepthTextureMode)1;
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
