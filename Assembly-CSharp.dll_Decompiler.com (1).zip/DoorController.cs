using UnityEngine;
using UnityEngine.Events;

public class DoorController : MonoBehaviour
{
	public bool doorOpen;

	private Animator anim;

	public UnityEvent doorDoneOpening = new UnityEvent();

	public UnityEvent doorDoneClosing = new UnityEvent();

	private void Start()
	{
		anim = ((Component)this).GetComponent<Animator>();
	}

	public void ToggleDoor()
	{
		doorOpen = !doorOpen;
		anim.SetBool("DoorOpen", doorOpen);
	}

	public void DoorDoneOpening()
	{
		doorDoneOpening.Invoke();
	}

	public void DoorDoneClosing()
	{
		doorDoneClosing.Invoke();
	}

	private void Update()
	{
	}
}
