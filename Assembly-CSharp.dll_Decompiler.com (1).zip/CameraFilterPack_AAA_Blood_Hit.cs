using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/AAA/Blood_Hit")]
public class CameraFilterPack_AAA_Blood_Hit : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	[Range(0f, 1f)]
	public float Hit_Left = 1f;

	[Range(0f, 1f)]
	public float Hit_Up;

	[Range(0f, 1f)]
	public float Hit_Right;

	[Range(0f, 1f)]
	public float Hit_Down;

	[Range(0f, 1f)]
	public float Blood_Hit_Left;

	[Range(0f, 1f)]
	public float Blood_Hit_Up;

	[Range(0f, 1f)]
	public float Blood_Hit_Right;

	[Range(0f, 1f)]
	public float Blood_Hit_Down;

	[Range(0f, 1f)]
	public float Hit_Full;

	[Range(0f, 1f)]
	public float Blood_Hit_Full_1;

	[Range(0f, 1f)]
	public float Blood_Hit_Full_2;

	[Range(0f, 1f)]
	public float Blood_Hit_Full_3;

	[Range(0f, 1f)]
	public float LightReflect = 0.5f;

	private Material SCMaterial;

	private Texture2D Texture2;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		ref Texture2D texture = ref Texture2;
		Object obj = Resources.Load("CameraFilterPack_AAA_Blood_Hit1");
		texture = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		SCShader = Shader.Find("CameraFilterPack/AAA_Blood_Hit");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value", LightReflect);
			material.SetFloat("_Value2", Mathf.Clamp(Hit_Left, 0f, 1f));
			material.SetFloat("_Value3", Mathf.Clamp(Hit_Up, 0f, 1f));
			material.SetFloat("_Value4", Mathf.Clamp(Hit_Right, 0f, 1f));
			material.SetFloat("_Value5", Mathf.Clamp(Hit_Down, 0f, 1f));
			material.SetFloat("_Value6", Mathf.Clamp(Blood_Hit_Left, 0f, 1f));
			material.SetFloat("_Value7", Mathf.Clamp(Blood_Hit_Up, 0f, 1f));
			material.SetFloat("_Value8", Mathf.Clamp(Blood_Hit_Right, 0f, 1f));
			material.SetFloat("_Value9", Mathf.Clamp(Blood_Hit_Down, 0f, 1f));
			material.SetFloat("_Value10", Mathf.Clamp(Hit_Full, 0f, 1f));
			material.SetFloat("_Value11", Mathf.Clamp(Blood_Hit_Full_1, 0f, 1f));
			material.SetFloat("_Value12", Mathf.Clamp(Blood_Hit_Full_2, 0f, 1f));
			material.SetFloat("_Value13", Mathf.Clamp(Blood_Hit_Full_3, 0f, 1f));
			material.SetTexture("_MainTex2", (Texture)(object)Texture2);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
