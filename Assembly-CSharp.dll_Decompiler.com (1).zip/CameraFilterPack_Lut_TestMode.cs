using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Lut/TestMode")]
public class CameraFilterPack_Lut_TestMode : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	public Texture2D LutTexture;

	private Texture3D converted3DLut;

	[Range(0f, 1f)]
	public float Blend = 1f;

	[Range(0f, 3f)]
	public float OriginalIntensity = 1f;

	[Range(-1f, 1f)]
	public float ResultIntensity;

	[Range(-1f, 1f)]
	public float FinalIntensity;

	[Range(0f, 1f)]
	public float TestMode = 0.5f;

	private string MemoPath;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		SCShader = Shader.Find("CameraFilterPack/Lut_TestMode");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	public void SetIdentityLut()
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Expected O, but got Unknown
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		int num = 16;
		Color[] array = (Color[])(object)new Color[num * num * num];
		float num2 = 1f / (1f * (float)num - 1f);
		for (int i = 0; i < num; i++)
		{
			for (int j = 0; j < num; j++)
			{
				for (int k = 0; k < num; k++)
				{
					ref Color reference = ref array[i + j * num + k * num * num];
					reference = new Color((float)i * 1f * num2, (float)j * 1f * num2, (float)k * 1f * num2, 1f);
				}
			}
		}
		if (Object.op_Implicit((Object)(object)converted3DLut))
		{
			Object.DestroyImmediate((Object)(object)converted3DLut);
		}
		converted3DLut = new Texture3D(num, num, num, (TextureFormat)5, false);
		converted3DLut.SetPixels(array);
		converted3DLut.Apply();
	}

	public bool ValidDimensions(Texture2D tex2d)
	{
		if (!Object.op_Implicit((Object)(object)tex2d))
		{
			return false;
		}
		int height = ((Texture)tex2d).height;
		if (height != Mathf.FloorToInt(Mathf.Sqrt((float)((Texture)tex2d).width)))
		{
			return false;
		}
		return true;
	}

	public void Convert(Texture2D temp2DTex)
	{
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Expected O, but got Unknown
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)temp2DTex))
		{
			int num = ((Texture)temp2DTex).width * ((Texture)temp2DTex).height;
			num = ((Texture)temp2DTex).height;
			if (!ValidDimensions(temp2DTex))
			{
				Debug.LogWarning((object)("The given 2D texture " + ((Object)temp2DTex).name + " cannot be used as a 3D LUT."));
				return;
			}
			Color[] pixels = temp2DTex.GetPixels();
			Color[] array = (Color[])(object)new Color[pixels.Length];
			for (int i = 0; i < num; i++)
			{
				for (int j = 0; j < num; j++)
				{
					for (int k = 0; k < num; k++)
					{
						int num2 = num - j - 1;
						ref Color reference = ref array[i + j * num + k * num * num];
						reference = pixels[k * num + i + num2 * num * num];
					}
				}
			}
			if (Object.op_Implicit((Object)(object)converted3DLut))
			{
				Object.DestroyImmediate((Object)(object)converted3DLut);
			}
			converted3DLut = new Texture3D(num, num, num, (TextureFormat)5, false);
			converted3DLut.SetPixels(array);
			converted3DLut.Apply();
		}
		else
		{
			SetIdentityLut();
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Invalid comparison between Unknown and I4
		if ((Object)(object)SCShader != (Object)null || !SystemInfo.supports3DTextures)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			if ((Object)(object)converted3DLut == (Object)null)
			{
				Convert(LutTexture);
			}
			((Texture)converted3DLut).wrapMode = (TextureWrapMode)1;
			material.SetTexture("_LutTex", (Texture)(object)converted3DLut);
			material.SetFloat("_Blend", Blend);
			material.SetFloat("_Intensity", OriginalIntensity);
			material.SetFloat("_Extra", ResultIntensity);
			material.SetFloat("_Extra2", FinalIntensity);
			material.SetFloat("_Extra3", TestMode);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material, ((int)QualitySettings.activeColorSpace == 1) ? 1 : 0);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void OnValidate()
	{
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
