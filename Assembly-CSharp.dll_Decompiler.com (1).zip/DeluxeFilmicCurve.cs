using System;
using UnityEngine;

[Serializable]
public class DeluxeFilmicCurve
{
	[SerializeField]
	public float m_BlackPoint;

	[SerializeField]
	public float m_WhitePoint = 1f;

	[SerializeField]
	public float m_CrossOverPoint = 0.3f;

	[SerializeField]
	public float m_ToeStrength = 0.98f;

	[SerializeField]
	public float m_ShoulderStrength;

	[SerializeField]
	public float m_Highlights = 0.5f;

	public float m_k;

	public Vector4 m_ToeCoef;

	public Vector4 m_ShoulderCoef;

	public float GetExposure()
	{
		float highlights = m_Highlights;
		float num = 2f + (1f - highlights) * 20f;
		return num * Mathf.Exp(-2f);
	}

	public float ComputeK(float t, float c, float b, float s, float w)
	{
		float num = (1f - t) * (c - b);
		float num2 = (1f - s) * (w - c) + (1f - t) * (c - b);
		return num / num2;
	}

	public float Toe(float x, float t, float c, float b, float s, float w, float k)
	{
		float num = m_ToeCoef.x * x;
		float num2 = m_ToeCoef.y * x;
		return (num + m_ToeCoef.z) / (num2 + m_ToeCoef.w);
	}

	public float Shoulder(float x, float t, float c, float b, float s, float w, float k)
	{
		float num = m_ShoulderCoef.x * x;
		float num2 = m_ShoulderCoef.y * x;
		return (num + m_ShoulderCoef.z) / (num2 + m_ShoulderCoef.w) + k;
	}

	public float Graph(float x, float t, float c, float b, float s, float w, float k)
	{
		if (x <= m_CrossOverPoint)
		{
			return Toe(x, t, c, b, s, w, k);
		}
		return Shoulder(x, t, c, b, s, w, k);
	}

	public void StoreK()
	{
		m_k = ComputeK(m_ToeStrength, m_CrossOverPoint, m_BlackPoint, m_ShoulderStrength, m_WhitePoint);
	}

	public void ComputeShaderCoefficients(float t, float c, float b, float s, float w, float k)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		float num = k * (1f - t);
		float num2 = k * (1f - t) * (0f - b);
		float num3 = 0f - t;
		float num4 = c - (1f - t) * b;
		m_ToeCoef = new Vector4(num, num3, num2, num4);
		float num5 = 1f - k;
		float num6 = (1f - k) * (0f - c);
		float num7 = (1f - s) * w - c;
		m_ShoulderCoef = new Vector4(num5, s, num6, num7);
	}

	public void UpdateCoefficients()
	{
		StoreK();
		ComputeShaderCoefficients(m_ToeStrength, m_CrossOverPoint, m_BlackPoint, m_ShoulderStrength, m_WhitePoint, m_k);
	}
}
