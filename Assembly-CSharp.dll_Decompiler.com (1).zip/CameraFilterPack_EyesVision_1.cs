using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Vision/Eyes 1")]
public class CameraFilterPack_EyesVision_1 : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	[Range(1f, 32f)]
	public float _EyeWave = 15f;

	[Range(0f, 10f)]
	public float _EyeSpeed = 1f;

	[Range(0f, 8f)]
	public float _EyeMove = 2f;

	[Range(0f, 1f)]
	public float _EyeBlink = 1f;

	private Material SCMaterial;

	private Texture2D Texture2;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		ref Texture2D texture = ref Texture2;
		Object obj = Resources.Load("CameraFilterPack_eyes_vision_1");
		texture = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		SCShader = Shader.Find("CameraFilterPack/EyesVision_1");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value", _EyeWave);
			material.SetFloat("_Value2", _EyeSpeed);
			material.SetFloat("_Value3", _EyeMove);
			material.SetFloat("_Value4", _EyeBlink);
			material.SetTexture("_MainTex2", (Texture)(object)Texture2);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
