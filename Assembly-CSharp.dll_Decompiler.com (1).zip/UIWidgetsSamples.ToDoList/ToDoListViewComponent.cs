using System;
using UIWidgets;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgetsSamples.ToDoList;

public class ToDoListViewComponent : ListViewItem, IListViewItemHeight
{
	[SerializeField]
	public Toggle Toggle;

	[SerializeField]
	public Text Task;

	[NonSerialized]
	public ToDoListItem Item;

	private LayoutGroup layoutGroup;

	public float Height => CalculateHeight();

	public LayoutGroup LayoutGroup
	{
		get
		{
			if ((Object)(object)layoutGroup == (Object)null)
			{
				layoutGroup = ((Component)this).GetComponent<LayoutGroup>();
			}
			return layoutGroup;
		}
	}

	protected override void Start()
	{
		((UIBehaviour)this).Start();
		((UnityEvent<bool>)(object)Toggle.onValueChanged).AddListener((UnityAction<bool>)OnToggle);
	}

	private void OnToggle(bool toggle)
	{
		Item.Done = toggle;
	}

	public void SetData(ToDoListItem item)
	{
		Item = item;
		if (Item == null)
		{
			Toggle.isOn = false;
			Task.text = string.Empty;
		}
		else
		{
			Toggle.isOn = Item.Done;
			Task.text = Item.Task.Replace("\\n", "\n");
		}
	}

	private float CalculateHeight()
	{
		((Component)this).gameObject.SetActive(true);
		LayoutGroup.CalculateLayoutInputHorizontal();
		LayoutGroup.SetLayoutHorizontal();
		LayoutGroup.CalculateLayoutInputVertical();
		LayoutGroup.SetLayoutVertical();
		Transform transform = ((Component)this).transform;
		float preferredHeight = LayoutUtility.GetPreferredHeight((RectTransform)(object)((transform is RectTransform) ? transform : null));
		((Component)this).gameObject.SetActive(false);
		return preferredHeight;
	}

	protected override void OnDestroy()
	{
		((UIBehaviour)this).OnDestroy();
		if ((Object)(object)Toggle != (Object)null)
		{
			((UnityEvent<bool>)(object)Toggle.onValueChanged).RemoveListener((UnityAction<bool>)OnToggle);
		}
	}
}
