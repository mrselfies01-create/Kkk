using System;
using UIWidgets;
using UnityEngine;

namespace UIWidgetsSamples.ToDoList;

[Serializable]
public class ToDoListItem : IItemHeight
{
	[SerializeField]
	public bool Done;

	[SerializeField]
	public string Task;

	[SerializeField]
	private float height;

	public float Height
	{
		get
		{
			return height;
		}
		set
		{
			height = value;
		}
	}
}
