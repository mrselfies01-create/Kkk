using UIWidgets;
using UnityEngine.UI;

namespace UIWidgetsSamples.ToDoList;

public class ToDoListView : ListViewCustomHeight<ToDoListViewComponent, ToDoListItem>
{
	private bool isStarted;

	protected override void Awake()
	{
		Start();
	}

	public override void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			base.Start();
		}
	}

	protected override void SetData(ToDoListViewComponent component, ToDoListItem item)
	{
		component.SetData(item);
	}

	protected override void HighlightColoring(ToDoListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.HighlightColoring(component);
		((Graphic)component.Task).color = HighlightedColor;
	}

	protected override void SelectColoring(ToDoListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.SelectColoring(component);
		((Graphic)component.Task).color = base.SelectedColor;
	}

	protected override void DefaultColoring(ToDoListViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.DefaultColoring(component);
		((Graphic)component.Task).color = base.DefaultColor;
	}
}
