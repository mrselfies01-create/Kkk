using System;

namespace EasyLayout;

[Flags]
public enum HorizontalAligns
{
	Left = 0,
	Center = 1,
	Right = 2
}
