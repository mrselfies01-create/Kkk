using System;
using UnityEngine;

namespace EasyLayout;

[Serializable]
public struct Padding
{
	[SerializeField]
	public float Left;

	[SerializeField]
	public float Right;

	[SerializeField]
	public float Top;

	[SerializeField]
	public float Bottom;

	public Padding(float left, float right, float top, float bottom)
	{
		Left = left;
		Right = right;
		Top = top;
		Bottom = bottom;
	}

	public override string ToString()
	{
		return $"Padding(left: {Left}, right: {Right}, top: {Top}, bottom: {Bottom})";
	}
}
