using System;

namespace EasyLayout;

[Flags]
public enum ChildrenSize
{
	DoNothing = 0,
	SetPreferred = 1,
	SetMaxFromPreferred = 2,
	FitContainer = 3
}
