using System;

namespace EasyLayout;

[Flags]
public enum LayoutTypes
{
	Compact = 0,
	Grid = 1
}
