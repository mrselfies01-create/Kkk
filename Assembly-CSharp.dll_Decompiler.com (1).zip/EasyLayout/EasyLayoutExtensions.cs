using System;
using System.Collections.Generic;

namespace EasyLayout;

public static class EasyLayoutExtensions
{
	public static float SumFloat<T>(this List<T> list, Func<T, float> calculate)
	{
		float num = 0f;
		for (int i = 0; i < list.Count; i++)
		{
			num += calculate(list[i]);
		}
		return num;
	}

	public static List<TOutput> Convert<TInput, TOutput>(this List<TInput> input, Converter<TInput, TOutput> converter)
	{
		return input.ConvertAll(converter);
	}
}
