using System;

namespace EasyLayout;

[Flags]
public enum InnerAligns
{
	Top = 0,
	Middle = 1,
	Bottom = 2
}
