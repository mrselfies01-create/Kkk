using System.Collections.Generic;
using UnityEngine;

namespace EasyLayout;

public class EasyLayoutCompact
{
	public static List<List<RectTransform>> Group(List<RectTransform> uiElements, float baseLength, EasyLayout layout)
	{
		float num = baseLength;
		float num2 = ((layout.Stacking != 0) ? layout.Spacing.y : layout.Spacing.x);
		List<List<RectTransform>> list = new List<List<RectTransform>>();
		List<RectTransform> list2 = new List<RectTransform>();
		foreach (RectTransform uiElement in uiElements)
		{
			float length = layout.GetLength(uiElement);
			if (list2.Count == 0)
			{
				num -= length;
				list2.Add(uiElement);
				continue;
			}
			if (num >= length + num2)
			{
				num -= length + num2;
				list2.Add(uiElement);
				continue;
			}
			list.Add(list2);
			num = baseLength;
			num -= length;
			list2 = new List<RectTransform>();
			list2.Add(uiElement);
		}
		if (list2.Count > 0)
		{
			list.Add(list2);
		}
		return list;
	}
}
