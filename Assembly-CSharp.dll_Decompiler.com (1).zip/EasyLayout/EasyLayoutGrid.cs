using System.Collections.Generic;
using UnityEngine;

namespace EasyLayout;

public class EasyLayoutGrid
{
	public static int GetMaxColumnsCount(List<RectTransform> uiElements, float baseLength, EasyLayout layout, int maxColumns)
	{
		float num = baseLength;
		float num2 = ((layout.Stacking != 0) ? layout.Spacing.y : layout.Spacing.x);
		bool flag = false;
		int num3 = maxColumns;
		int num4 = 0;
		foreach (RectTransform uiElement in uiElements)
		{
			float length = layout.GetLength(uiElement);
			if (num4 == maxColumns)
			{
				flag = true;
				num3 = Mathf.Min(num3, num4);
				num4 = 1;
				num = baseLength - length;
			}
			else if (num4 == 0)
			{
				num4 = 1;
				num = baseLength - length;
			}
			else if (num >= length + num2)
			{
				num -= length + num2;
				num4++;
			}
			else
			{
				flag = true;
				num3 = Mathf.Min(num3, num4);
				num4 = 1;
				num = baseLength - length;
			}
		}
		if (!flag)
		{
			num3 = num4;
		}
		return num3;
	}

	public static List<List<RectTransform>> Group(List<RectTransform> uiElements, float baseLength, EasyLayout layout, int maxColumns = 0)
	{
		int num = 999999;
		int maxColumnsCount;
		while (true)
		{
			maxColumnsCount = GetMaxColumnsCount(uiElements, baseLength, layout, num);
			if (num == maxColumnsCount || maxColumnsCount == 1)
			{
				break;
			}
			num = maxColumnsCount;
		}
		num = maxColumnsCount;
		List<List<RectTransform>> list = new List<List<RectTransform>>();
		List<RectTransform> list2 = new List<RectTransform>();
		int num2 = 0;
		foreach (RectTransform uiElement in uiElements)
		{
			if (num2 > 0 && num2 % num == 0)
			{
				list.Add(list2);
				list2 = new List<RectTransform>();
			}
			list2.Add(uiElement);
			num2++;
		}
		if (list2.Count > 0)
		{
			list.Add(list2);
		}
		return list;
	}
}
