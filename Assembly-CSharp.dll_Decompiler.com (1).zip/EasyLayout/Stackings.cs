using System;

namespace EasyLayout;

[Flags]
public enum Stackings
{
	Horizontal = 0,
	Vertical = 1
}
