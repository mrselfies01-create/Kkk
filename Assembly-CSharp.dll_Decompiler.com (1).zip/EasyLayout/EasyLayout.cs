using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace EasyLayout;

[ExecuteInEditMode]
[RequireComponent(typeof(RectTransform))]
public class EasyLayout : LayoutGroup
{
	[SerializeField]
	public Anchors GroupPosition;

	[SerializeField]
	public Stackings Stacking;

	[SerializeField]
	public LayoutTypes LayoutType;

	[SerializeField]
	public HorizontalAligns RowAlign;

	[SerializeField]
	public InnerAligns InnerAlign;

	[SerializeField]
	public Anchors CellAlign;

	[SerializeField]
	public Vector2 Spacing = new Vector2(5f, 5f);

	[SerializeField]
	public bool Symmetric = true;

	[SerializeField]
	public Vector2 Margin = new Vector2(5f, 5f);

	[SerializeField]
	public Padding PaddingInner = default(Padding);

	[SerializeField]
	public float MarginTop = 5f;

	[SerializeField]
	public float MarginBottom = 5f;

	[SerializeField]
	public float MarginLeft = 5f;

	[SerializeField]
	public float MarginRight = 5f;

	[SerializeField]
	public bool RightToLeft;

	[SerializeField]
	public bool TopToBottom = true;

	[SerializeField]
	public bool SkipInactive = true;

	public Func<IEnumerable<GameObject>, IEnumerable<GameObject>> Filter;

	public ChildrenSize ChildrenWidth;

	public ChildrenSize ChildrenHeight;

	[SerializeField]
	[Obsolete("Use ChildrenWidth with ChildrenSize.SetPreferred instead.")]
	public bool ControlWidth;

	[SerializeField]
	[Obsolete("Use ChildrenHeight with ChildrenSize.SetPreferred instead.")]
	public bool ControlHeight;

	[SerializeField]
	[Obsolete("Use ChildrenWidth with ChildrenSize.SetMaxFromPreferred instead.")]
	public bool MaxWidth;

	[SerializeField]
	[Obsolete("Use ChildrenHeight with ChildrenSize.SetMaxFromPreferred instead.")]
	public bool MaxHeight;

	private Vector2 _blockSize;

	private Vector2 _uiSize;

	private static readonly Dictionary<Anchors, Vector2> groupPositions = new Dictionary<Anchors, Vector2>
	{
		{
			Anchors.LowerLeft,
			new Vector2(0f, 0f)
		},
		{
			Anchors.LowerCenter,
			new Vector2(0.5f, 0f)
		},
		{
			Anchors.LowerRight,
			new Vector2(1f, 0f)
		},
		{
			Anchors.MiddleLeft,
			new Vector2(0f, 0.5f)
		},
		{
			Anchors.MiddleCenter,
			new Vector2(0.5f, 0.5f)
		},
		{
			Anchors.MiddleRight,
			new Vector2(1f, 0.5f)
		},
		{
			Anchors.UpperLeft,
			new Vector2(0f, 1f)
		},
		{
			Anchors.UpperCenter,
			new Vector2(0.5f, 1f)
		},
		{
			Anchors.UpperRight,
			new Vector2(1f, 1f)
		}
	};

	private static readonly Dictionary<HorizontalAligns, float> rowAligns = new Dictionary<HorizontalAligns, float>
	{
		{
			HorizontalAligns.Left,
			0f
		},
		{
			HorizontalAligns.Center,
			0.5f
		},
		{
			HorizontalAligns.Right,
			1f
		}
	};

	private static readonly Dictionary<InnerAligns, float> innerAligns = new Dictionary<InnerAligns, float>
	{
		{
			InnerAligns.Top,
			0f
		},
		{
			InnerAligns.Middle,
			0.5f
		},
		{
			InnerAligns.Bottom,
			1f
		}
	};

	private float max_width = -1f;

	private float max_height = -1f;

	private DrivenRectTransformTracker propertiesTracker;

	[SerializeField]
	private int version;

	public Vector2 BlockSize
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _blockSize;
		}
		protected set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_blockSize = value;
		}
	}

	public Vector2 UISize
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _uiSize;
		}
		protected set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_uiSize = value;
		}
	}

	public override float minHeight
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Vector2 blockSize = BlockSize;
			return ((Vector2)(ref blockSize))[1];
		}
	}

	public override float minWidth
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Vector2 blockSize = BlockSize;
			return ((Vector2)(ref blockSize))[0];
		}
	}

	public override float preferredHeight
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Vector2 blockSize = BlockSize;
			return ((Vector2)(ref blockSize))[1];
		}
	}

	public override float preferredWidth
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Vector2 blockSize = BlockSize;
			return ((Vector2)(ref blockSize))[0];
		}
	}

	protected override void OnDisable()
	{
		((DrivenRectTransformTracker)(ref propertiesTracker)).Clear();
		((LayoutGroup)this).OnDisable();
	}

	private void OnRectTransformRemoved()
	{
		((LayoutGroup)this).SetDirty();
	}

	public override void SetLayoutHorizontal()
	{
		RepositionUIElements();
	}

	public override void SetLayoutVertical()
	{
	}

	public override void CalculateLayoutInputHorizontal()
	{
		((LayoutGroup)this).CalculateLayoutInputHorizontal();
		CalculateLayoutSize();
	}

	public override void CalculateLayoutInputVertical()
	{
	}

	public float GetLength(RectTransform ui, bool scaled = true)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (scaled)
		{
			return (Stacking != 0) ? ScaledHeight(ui) : ScaledWidth(ui);
		}
		float result;
		if (Stacking == Stackings.Horizontal)
		{
			Rect rect = ui.rect;
			result = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = ui.rect;
			result = ((Rect)(ref rect2)).height;
		}
		return result;
	}

	private float GetRowWidth(List<RectTransform> row)
	{
		return row.Select(ScaledWidth).Sum() + Spacing.x * (float)(row.Count - 1);
	}

	private float GetRowHeight(List<RectTransform> row)
	{
		return row.Select(ScaledHeight).Max() + Spacing.y;
	}

	private Vector2 CalculateGroupSize(List<List<RectTransform>> group)
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		float num;
		if (LayoutType == LayoutTypes.Compact)
		{
			num = group.Select(GetRowWidth).Max();
		}
		else
		{
			float[] maxColumnsWidths = GetMaxColumnsWidths(group);
			num = maxColumnsWidths.Sum() + (float)maxColumnsWidths.Length * Spacing.x - Spacing.x;
		}
		float num2 = group.Select(GetRowHeight).Sum() - Spacing.y;
		num += PaddingInner.Left + PaddingInner.Right;
		num2 += PaddingInner.Top + PaddingInner.Bottom;
		return new Vector2(num, num2);
	}

	public void NeedUpdateLayout()
	{
		UpdateLayout();
	}

	private void UpdateBlockSize()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (Symmetric)
		{
			BlockSize = new Vector2(UISize.x + Margin.x * 2f, UISize.y + Margin.y * 2f);
		}
		else
		{
			BlockSize = new Vector2(UISize.x + MarginLeft + MarginRight, UISize.y + MarginLeft + MarginRight);
		}
	}

	public void CalculateLayoutSize()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		List<List<RectTransform>> list = GroupUIElements();
		if (list.Count == 0)
		{
			UISize = new Vector2(0f, 0f);
			UpdateBlockSize();
		}
		else
		{
			UISize = CalculateGroupSize(list);
			UpdateBlockSize();
		}
	}

	private void RepositionUIElements()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		List<List<RectTransform>> list = GroupUIElements();
		if (list.Count == 0)
		{
			UISize = new Vector2(0f, 0f);
			UpdateBlockSize();
			return;
		}
		UISize = CalculateGroupSize(list);
		UpdateBlockSize();
		Vector2 val = groupPositions[GroupPosition];
		Rect rect = ((LayoutGroup)this).rectTransform.rect;
		float num = ((Rect)(ref rect)).width * (val.x - ((LayoutGroup)this).rectTransform.pivot.x);
		Rect rect2 = ((LayoutGroup)this).rectTransform.rect;
		Vector2 startPosition = default(Vector2);
		((Vector2)(ref startPosition))._002Ector(num, ((Rect)(ref rect2)).height * (val.y - ((LayoutGroup)this).rectTransform.pivot.y));
		startPosition.x -= val.x * UISize.x;
		startPosition.y += (1f - val.y) * UISize.y;
		startPosition.x += GetMarginLeft() * ((1f - val.x) * 2f - 1f);
		startPosition.y += GetMarginTop() * ((1f - val.y) * 2f - 1f);
		startPosition.x += PaddingInner.Left;
		startPosition.y -= PaddingInner.Top;
		SetPositions(list, startPosition, UISize);
	}

	public void UpdateLayout()
	{
		((LayoutGroup)this).CalculateLayoutInputHorizontal();
		RepositionUIElements();
	}

	private Vector2 GetUIPosition(RectTransform ui, Vector2 position, Vector2 align)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		float num = ScaledWidth(ui) * ui.pivot.x;
		float num2 = ScaledHeight(ui) * ui.pivot.y;
		float num3 = position.x + num + align.x;
		float num4 = position.y - ScaledHeight(ui) + num2 - align.y;
		return new Vector2(num3, num4);
	}

	private List<float> GetRowsWidths(List<List<RectTransform>> group)
	{
		List<float> list = new List<float>();
		foreach (int item in Enumerable.Range(0, group.Count))
		{
			float num = group[item].Convert(ScaledWidth).Sum();
			list.Add(num + (float)(group[item].Count - 1) * Spacing.x);
		}
		return list;
	}

	private float GetMaxColumnWidth(List<RectTransform> column)
	{
		return column.Convert(ScaledWidth).Max();
	}

	private float[] GetMaxColumnsWidths(List<List<RectTransform>> group)
	{
		return Transpose(group).Select(GetMaxColumnWidth).ToArray();
	}

	private List<float> GetColumnsHeights(List<List<RectTransform>> group)
	{
		List<float> list = new List<float>();
		foreach (int item in Enumerable.Range(0, group.Count))
		{
			float num = group[item].Convert(ScaledHeight).Sum();
			list.Add(num + (float)(group[item].Count - 1) * Spacing.y);
		}
		return list;
	}

	private float GetMaxRowHeight(List<RectTransform> row)
	{
		return row.Select(ScaledHeight).Max();
	}

	private float[] GetMaxRowsHeights(List<List<RectTransform>> group)
	{
		return Transpose(group).Convert(GetMaxRowHeight).ToArray();
	}

	private Vector2 GetMaxCellSize(List<List<RectTransform>> group)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		List<Vector2> source = group.Convert(GetMaxCellSize);
		return new Vector2(((IEnumerable<Vector2>)source).Max<Vector2, float>((Func<Vector2, float>)GetWidth), ((IEnumerable<Vector2>)source).Max<Vector2, float>((Func<Vector2, float>)GetHeight));
	}

	private float GetWidth(Vector2 size)
	{
		return size.x;
	}

	private float GetHeight(Vector2 size)
	{
		return size.y;
	}

	private Vector2 GetMaxCellSize(List<RectTransform> row)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(((IEnumerable<RectTransform>)row).Max<RectTransform, float>((Func<RectTransform, float>)ScaledWidth), ((IEnumerable<RectTransform>)row).Max<RectTransform, float>((Func<RectTransform, float>)ScaledHeight));
	}

	private Vector2 GetAlignByWidth(RectTransform ui, float maxWidth, Vector2 cellMaxSize, float emptyWidth)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (LayoutType == LayoutTypes.Compact)
		{
			return new Vector2(emptyWidth * rowAligns[RowAlign], (cellMaxSize.y - ScaledHeight(ui)) * innerAligns[InnerAlign]);
		}
		Vector2 val = groupPositions[CellAlign];
		return new Vector2((maxWidth - ScaledWidth(ui)) * val.x, (cellMaxSize.y - ScaledHeight(ui)) * (1f - val.y));
	}

	private Vector2 GetAlignByHeight(RectTransform ui, float maxHeight, Vector2 cellMaxSize, float emptyHeight)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (LayoutType == LayoutTypes.Compact)
		{
			return new Vector2((cellMaxSize.x - ScaledWidth(ui)) * innerAligns[InnerAlign], emptyHeight * rowAligns[RowAlign]);
		}
		Vector2 val = groupPositions[CellAlign];
		return new Vector2((cellMaxSize.x - ScaledWidth(ui)) * (1f - val.x), (maxHeight - ScaledHeight(ui)) * val.y);
	}

	private void SetPositions(List<List<RectTransform>> group, Vector2 startPosition, Vector2 groupSize)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		Vector2 position = startPosition;
		if (Stacking == Stackings.Horizontal)
		{
			List<float> rowsWidths = GetRowsWidths(group);
			float[] maxColumnsWidths = GetMaxColumnsWidths(group);
			Vector2 alignByWidth = default(Vector2);
			((Vector2)(ref alignByWidth))._002Ector(0f, 0f);
			int num = 0;
			{
				foreach (List<RectTransform> item in group)
				{
					Vector2 maxCellSize = GetMaxCellSize(item);
					int num2 = 0;
					foreach (RectTransform item2 in item)
					{
						alignByWidth = GetAlignByWidth(item2, maxColumnsWidths[num2], maxCellSize, groupSize.x - rowsWidths[num]);
						Vector2 uIPosition = GetUIPosition(item2, position, alignByWidth);
						if (((Transform)item2).localPosition.x != uIPosition.x || ((Transform)item2).localPosition.y != uIPosition.y)
						{
							((Transform)item2).localPosition = Vector2.op_Implicit(uIPosition);
						}
						position.x += ((LayoutType != 0) ? maxColumnsWidths[num2] : ScaledWidth(item2)) + Spacing.x;
						num2++;
					}
					position.x = startPosition.x;
					position.y -= maxCellSize.y + Spacing.y;
					num++;
				}
				return;
			}
		}
		group = Transpose(group);
		List<float> columnsHeights = GetColumnsHeights(group);
		float[] maxRowsHeights = GetMaxRowsHeights(group);
		Vector2 alignByHeight = default(Vector2);
		((Vector2)(ref alignByHeight))._002Ector(0f, 0f);
		int num3 = 0;
		foreach (List<RectTransform> item3 in group)
		{
			Vector2 maxCellSize2 = GetMaxCellSize(item3);
			int num4 = 0;
			foreach (RectTransform item4 in item3)
			{
				alignByHeight = GetAlignByHeight(item4, maxRowsHeights[num4], maxCellSize2, groupSize.y - columnsHeights[num3]);
				Vector2 uIPosition2 = GetUIPosition(item4, position, alignByHeight);
				if (((Transform)item4).localPosition.x != uIPosition2.x || ((Transform)item4).localPosition.y != uIPosition2.y)
				{
					((Transform)item4).localPosition = Vector2.op_Implicit(uIPosition2);
				}
				position.y -= ((LayoutType != 0) ? maxRowsHeights[num4] : ScaledHeight(item4)) + Spacing.y;
				num4++;
			}
			position.y = startPosition.y;
			position.x += maxCellSize2.x + Spacing.x;
			num3++;
		}
	}

	private void ResizeElements(List<RectTransform> elements)
	{
		((DrivenRectTransformTracker)(ref propertiesTracker)).Clear();
		if ((ChildrenWidth != 0 || ChildrenHeight != 0) && elements != null && elements.Count != 0)
		{
			max_width = ((ChildrenWidth != ChildrenSize.SetMaxFromPreferred) ? (-1f) : elements.Select(GetPreferredWidth).Max());
			max_height = ((ChildrenHeight != ChildrenSize.SetMaxFromPreferred) ? (-1f) : elements.Select(GetPreferredHeight).Max());
			elements.ForEach(ResizeChild);
		}
	}

	public static float GetPreferredWidth(RectTransform rect)
	{
		if ((Object)(object)rect == (Object)null)
		{
			return 1f;
		}
		if (((Component)rect).gameObject.activeInHierarchy)
		{
			return Mathf.Max(1f, LayoutUtility.GetPreferredWidth(rect));
		}
		float num = 1f;
		ILayoutElement[] components = ((Component)rect).GetComponents<ILayoutElement>();
		int num2 = components.Max((ILayoutElement x) => x.layoutPriority);
		ILayoutElement[] array = components;
		foreach (ILayoutElement val in array)
		{
			if (val.layoutPriority == num2)
			{
				num = Mathf.Max(num, Mathf.Max(val.preferredWidth, val.minWidth));
			}
		}
		return num;
	}

	public static float GetPreferredHeight(RectTransform rect)
	{
		if ((Object)(object)rect == (Object)null)
		{
			return 1f;
		}
		if (((Component)rect).gameObject.activeInHierarchy)
		{
			return Mathf.Max(1f, LayoutUtility.GetPreferredHeight(rect));
		}
		float num = 1f;
		ILayoutElement[] components = ((Component)rect).GetComponents<ILayoutElement>();
		int num2 = components.Max((ILayoutElement x) => x.layoutPriority);
		ILayoutElement[] array = components;
		foreach (ILayoutElement val in array)
		{
			if (val.layoutPriority == num2)
			{
				num = Mathf.Max(num, Mathf.Max(val.preferredHeight, val.minHeight));
			}
		}
		return num;
	}

	public static float GetFlexibleWidth(RectTransform rect)
	{
		if ((Object)(object)rect == (Object)null)
		{
			return 1f;
		}
		if (((Component)rect).gameObject.activeInHierarchy)
		{
			return Mathf.Max(1f, LayoutUtility.GetFlexibleWidth(rect));
		}
		float num = 1f;
		ILayoutElement[] components = ((Component)rect).GetComponents<ILayoutElement>();
		int num2 = components.Max((ILayoutElement x) => x.layoutPriority);
		ILayoutElement[] array = components;
		foreach (ILayoutElement val in array)
		{
			if (val.layoutPriority == num2)
			{
				num = Mathf.Max(num, val.flexibleWidth);
			}
		}
		return num;
	}

	public static float GetFlexibleHeight(RectTransform rect)
	{
		if ((Object)(object)rect == (Object)null)
		{
			return 1f;
		}
		if (((Component)rect).gameObject.activeInHierarchy)
		{
			return Mathf.Max(1f, LayoutUtility.GetFlexibleHeight(rect));
		}
		float num = 1f;
		ILayoutElement[] components = ((Component)rect).GetComponents<ILayoutElement>();
		int num2 = components.Max((ILayoutElement x) => x.layoutPriority);
		ILayoutElement[] array = components;
		foreach (ILayoutElement val in array)
		{
			if (val.layoutPriority == num2)
			{
				num = Mathf.Max(num, val.flexibleHeight);
			}
		}
		return num;
	}

	private void ResizeChild(RectTransform child)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		DrivenTransformProperties val = (DrivenTransformProperties)0;
		if (ChildrenWidth != 0)
		{
			val = (DrivenTransformProperties)(val | 0x1000);
			float num = ((max_width == -1f) ? GetPreferredWidth(child) : max_width);
			child.SetSizeWithCurrentAnchors((Axis)0, num);
		}
		if (ChildrenHeight != 0)
		{
			val = (DrivenTransformProperties)(val | 0x2000);
			float num2 = ((max_height == -1f) ? GetPreferredHeight(child) : max_height);
			child.SetSizeWithCurrentAnchors((Axis)1, num2);
		}
		((DrivenRectTransformTracker)(ref propertiesTracker)).Add((Object)(object)this, child, val);
	}

	private bool IsIgnoreLayout(Transform rect)
	{
		ILayoutIgnorer component = ((Component)rect).GetComponent<ILayoutIgnorer>();
		return component != null && component.ignoreLayout;
	}

	private List<RectTransform> GetUIElements()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Expected O, but got Unknown
		List<RectTransform> list = ((LayoutGroup)this).rectChildren;
		if (!SkipInactive)
		{
			list = new List<RectTransform>();
			foreach (Transform item in ((Component)this).transform)
			{
				Transform val = item;
				if (!IsIgnoreLayout(val))
				{
					list.Add((RectTransform)(object)((val is RectTransform) ? val : null));
				}
			}
		}
		if (Filter != null)
		{
			IEnumerable<GameObject> source = Filter(list.Convert(GetGameObject));
			List<RectTransform> list2 = source.Select(GetRectTransform).ToList();
			ResizeElements(list2);
			return list2;
		}
		ResizeElements(list);
		return list;
	}

	private GameObject GetGameObject(RectTransform element)
	{
		return ((Component)element).gameObject;
	}

	private RectTransform GetRectTransform(GameObject go)
	{
		Transform transform = go.transform;
		return (RectTransform)(object)((transform is RectTransform) ? transform : null);
	}

	public float GetMarginTop()
	{
		return (!Symmetric) ? MarginTop : Margin.y;
	}

	public float GetMarginBottom()
	{
		return (!Symmetric) ? MarginBottom : Margin.y;
	}

	public float GetMarginLeft()
	{
		return (!Symmetric) ? MarginLeft : Margin.x;
	}

	public float GetMarginRight()
	{
		return (!Symmetric) ? MarginRight : Margin.y;
	}

	private void ReverseList(List<RectTransform> list)
	{
		list.Reverse();
	}

	private List<List<RectTransform>> GroupUIElements()
	{
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		float length = GetLength(((LayoutGroup)this).rectTransform, scaled: false);
		length -= ((Stacking != 0) ? (GetMarginTop() + GetMarginBottom()) : (GetMarginLeft() + GetMarginRight()));
		List<RectTransform> uIElements = GetUIElements();
		List<List<RectTransform>> list = ((LayoutType != 0) ? EasyLayoutGrid.Group(uIElements, length, this) : EasyLayoutCompact.Group(uIElements, length, this));
		if (Stacking == Stackings.Vertical)
		{
			list = Transpose(list);
		}
		if (!TopToBottom)
		{
			list.Reverse();
		}
		if (RightToLeft)
		{
			list.ForEach(ReverseList);
		}
		Rect rect = ((LayoutGroup)this).rectTransform.rect;
		float width = ((Rect)(ref rect)).width - (GetMarginLeft() + GetMarginRight());
		Rect rect2 = ((LayoutGroup)this).rectTransform.rect;
		float height = ((Rect)(ref rect2)).height - (GetMarginTop() + GetMarginBottom());
		if (LayoutType == LayoutTypes.Grid)
		{
			if (ChildrenWidth == ChildrenSize.FitContainer)
			{
				ResizeColumnWidthToFit(width, list);
			}
			if (ChildrenHeight == ChildrenSize.FitContainer)
			{
				ResizeRowHeightToFit(height, list);
			}
		}
		else if (Stacking == Stackings.Horizontal)
		{
			if (ChildrenWidth == ChildrenSize.FitContainer)
			{
				ResizeWidthToFit(width, list);
			}
			if (ChildrenHeight == ChildrenSize.FitContainer)
			{
				ResizeRowHeightToFit(height, list);
			}
		}
		else
		{
			if (ChildrenHeight == ChildrenSize.FitContainer)
			{
				ResizeHeightToFit(height, list);
			}
			if (ChildrenWidth == ChildrenSize.FitContainer)
			{
				ResizeColumnWidthToFit(width, list);
			}
		}
		return list;
	}

	private float GetRectWidth(RectTransform rect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Rect rect2 = rect.rect;
		return ((Rect)(ref rect2)).width;
	}

	private float GetRectHeight(RectTransform rect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Rect rect2 = rect.rect;
		return ((Rect)(ref rect2)).height;
	}

	private void ResizeWidthToFit(float width, List<List<RectTransform>> group)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		foreach (List<RectTransform> item in group)
		{
			float num = width - item.SumFloat(GetRectWidth) - (float)(item.Count - 1) * Spacing.x;
			if (num <= 0f)
			{
				continue;
			}
			float num2 = num / item.SumFloat(GetFlexibleWidth);
			foreach (RectTransform item2 in item)
			{
				float flexibleWidth = GetFlexibleWidth(item2);
				Rect rect = item2.rect;
				item2.SetSizeWithCurrentAnchors((Axis)0, ((Rect)(ref rect)).width + num2 * flexibleWidth);
			}
		}
	}

	private float GetMaxPreferredWidth(List<RectTransform> row)
	{
		return ((IEnumerable<RectTransform>)row).Max<RectTransform, float>((Func<RectTransform, float>)GetPreferredWidth);
	}

	private float GetMaxFlexibleWidth(List<RectTransform> row)
	{
		return ((IEnumerable<RectTransform>)row).Max<RectTransform, float>((Func<RectTransform, float>)GetFlexibleWidth);
	}

	private void ResizeColumnWidthToFit(float width, List<List<RectTransform>> group)
	{
		List<List<RectTransform>> list = Transpose(group);
		List<float> list2 = list.Convert(GetMaxPreferredWidth);
		List<float> list3 = list.Convert(GetMaxFlexibleWidth);
		float num = width - list2.Sum() - (float)(list.Count - 1) * Spacing.x - PaddingInner.Left - PaddingInner.Right;
		if (num <= 0f)
		{
			return;
		}
		float num2 = num / list3.Sum();
		int num3 = 0;
		foreach (List<RectTransform> item in list)
		{
			foreach (RectTransform item2 in item)
			{
				item2.SetSizeWithCurrentAnchors((Axis)0, list2[num3] + num2 * list3[num3]);
			}
			num3++;
		}
	}

	private void ResizeHeightToFit(float height, List<List<RectTransform>> group)
	{
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		foreach (List<RectTransform> item in Transpose(group))
		{
			float num = height - item.SumFloat(GetRectHeight) - (float)(item.Count - 1) * Spacing.y;
			if (num <= 0f)
			{
				continue;
			}
			float num2 = num / item.SumFloat(GetFlexibleHeight);
			foreach (RectTransform item2 in item)
			{
				float num3 = Mathf.Max(1f, GetFlexibleHeight(item2));
				Rect rect = item2.rect;
				item2.SetSizeWithCurrentAnchors((Axis)1, ((Rect)(ref rect)).height + num2 * num3);
			}
		}
	}

	private float GetMaxPreferredHeight(List<RectTransform> column)
	{
		return ((IEnumerable<RectTransform>)column).Max<RectTransform, float>((Func<RectTransform, float>)GetPreferredWidth);
	}

	private float GetMaxFlexibleHeight(List<RectTransform> column)
	{
		return ((IEnumerable<RectTransform>)column).Max<RectTransform, float>((Func<RectTransform, float>)GetFlexibleHeight);
	}

	private void ResizeRowHeightToFit(float height, List<List<RectTransform>> group)
	{
		List<float> list = group.Convert(GetMaxPreferredHeight);
		List<float> list2 = group.Convert(GetMaxFlexibleHeight);
		float num = height - list.Sum() - (float)(group.Count - 1) * Spacing.y - PaddingInner.Top - PaddingInner.Bottom;
		if (num <= 0f)
		{
			return;
		}
		float num2 = num / list2.Sum();
		int num3 = 0;
		foreach (List<RectTransform> item in group)
		{
			foreach (RectTransform item2 in item)
			{
				item2.SetSizeWithCurrentAnchors((Axis)1, list[num3] + num2 * list2[num3]);
			}
			num3++;
		}
	}

	public static List<List<T>> Transpose<T>(List<List<T>> group)
	{
		List<List<T>> list = new List<List<T>>();
		int num = 0;
		foreach (List<T> item in group)
		{
			int num2 = 0;
			foreach (T item2 in item)
			{
				if (list.Count <= num2)
				{
					list.Add(new List<T>());
				}
				list[num2].Add(item2);
				num2++;
			}
			num++;
		}
		return list;
	}

	private static void Log(IEnumerable<float> values)
	{
		Debug.Log((object)("[" + string.Join("; ", values.Select((float x) => x.ToString()).ToArray()) + "]"));
	}

	private float ScaledWidth(RectTransform ui)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = ui.rect;
		return ((Rect)(ref rect)).width * ((Transform)ui).localScale.x;
	}

	private float ScaledHeight(RectTransform ui)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = ui.rect;
		return ((Rect)(ref rect)).height * ((Transform)ui).localScale.y;
	}

	protected override void Awake()
	{
		((UIBehaviour)this).Awake();
		Upgrade();
	}

	public virtual void Upgrade()
	{
		if (version == 0)
		{
			if (ControlWidth)
			{
				ChildrenWidth = ((!MaxWidth) ? ChildrenSize.SetPreferred : ChildrenSize.SetMaxFromPreferred);
			}
			if (ControlHeight)
			{
				ChildrenHeight = ((!MaxHeight) ? ChildrenSize.SetPreferred : ChildrenSize.SetMaxFromPreferred);
			}
		}
		version = 1;
	}
}
