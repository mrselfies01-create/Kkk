using System.Collections.Generic;
using Audial;
using UnityEngine;

public class MixerGUI : MonoBehaviour
{
	private GameObject drums;

	private GameObject bass;

	private GameObject piano;

	private GameObject master;

	private Fader[] faders = new Fader[4];

	private Crusher masterCrusher;

	private List<MonoBehaviour>[] audialComponents = new List<MonoBehaviour>[5];

	private void Awake()
	{
		for (int i = 0; i < audialComponents.Length; i++)
		{
			audialComponents[i] = new List<MonoBehaviour>();
		}
		drums = GameObject.Find("Drums");
		MonoBehaviour[] components = drums.GetComponents<MonoBehaviour>();
		for (int j = 0; j < components.Length; j++)
		{
			if (((object)components[j]).GetType().Namespace == "Audial")
			{
				if (((object)components[j]).GetType().Name == "Fader")
				{
					faders[0] = (Fader)(object)components[j];
					continue;
				}
				audialComponents[0].Add(components[j]);
				((Behaviour)components[j]).enabled = false;
			}
		}
		bass = GameObject.Find("Bass");
		components = bass.GetComponents<MonoBehaviour>();
		for (int k = 0; k < components.Length; k++)
		{
			if (((object)components[k]).GetType().Namespace == "Audial")
			{
				if (((object)components[k]).GetType().Name == "Fader")
				{
					faders[1] = (Fader)(object)components[k];
					continue;
				}
				audialComponents[1].Add(components[k]);
				((Behaviour)components[k]).enabled = false;
			}
		}
		piano = GameObject.Find("Piano");
		components = piano.GetComponents<MonoBehaviour>();
		for (int l = 0; l < components.Length; l++)
		{
			if (((object)components[l]).GetType().Namespace == "Audial")
			{
				if (((object)components[l]).GetType().Name == "Fader")
				{
					faders[2] = (Fader)(object)components[l];
					continue;
				}
				audialComponents[2].Add(components[l]);
				((Behaviour)components[l]).enabled = false;
			}
		}
		master = GameObject.Find("AudioListener");
		components = master.GetComponents<MonoBehaviour>();
		for (int m = 0; m < components.Length; m++)
		{
			if (((object)components[m]).GetType().Namespace == "Audial")
			{
				if (((object)components[m]).GetType().Name.ToString() == "Crusher")
				{
					masterCrusher = (Crusher)(object)components[m];
					continue;
				}
				audialComponents[4].Add(components[m]);
				((Behaviour)components[m]).enabled = false;
			}
		}
	}

	private void Update()
	{
	}

	private void DrawInstrument(string name, int index)
	{
		string text = ((!((Behaviour)audialComponents[index][0]).enabled) ? "OFF" : "ON");
		string text2 = ((!faders[index].Mute) ? "OFF" : "ON");
		GUILayout.BeginVertical(GUIStyle.op_Implicit("Box"), (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.Label(name, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.BeginHorizontal((GUILayoutOption[])(object)new GUILayoutOption[0]);
		if (GUILayout.Button("Effects", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			audialComponents[index].ForEach(delegate(MonoBehaviour component)
			{
				((Behaviour)component).enabled = !((Behaviour)component).enabled;
			});
		}
		GUILayout.Label(text, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal((GUILayoutOption[])(object)new GUILayoutOption[0]);
		if (GUILayout.Button("Mute", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			faders[index].Mute = !faders[index].Mute;
		}
		GUILayout.Label(text2, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
	}

	private void OnGUI()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginArea(new Rect(0f, 300f, (float)Screen.width, (float)(Screen.height - 300)));
		GUILayout.BeginHorizontal((GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.FlexibleSpace();
		GUILayout.BeginHorizontal(GUIStyle.op_Implicit("Box"), (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.BeginVertical((GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.Label(string.Empty, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.Label("Audial Effects", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.Label("Channel Status", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.EndVertical();
		DrawInstrument("Drums", 0);
		DrawInstrument("Bass", 1);
		DrawInstrument("Piano", 2);
		GUILayout.BeginVertical(GUIStyle.op_Implicit("Box"), (GUILayoutOption[])(object)new GUILayoutOption[0]);
		string text = ((!((Behaviour)audialComponents[4][0]).enabled) ? "OFF" : "ON");
		GUILayout.Label("Master", (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.BeginHorizontal((GUILayoutOption[])(object)new GUILayoutOption[0]);
		if (GUILayout.Button("Effects", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			audialComponents[4].ForEach(delegate(MonoBehaviour component)
			{
				((Behaviour)component).enabled = !((Behaviour)component).enabled;
			});
		}
		GUILayout.Label(text, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal((GUILayoutOption[])(object)new GUILayoutOption[0]);
		string text2 = ((!((Behaviour)masterCrusher).enabled) ? "OFF" : "ON");
		if (GUILayout.Button("BitCrusher", (GUILayoutOption[])(object)new GUILayoutOption[0]))
		{
			((Behaviour)masterCrusher).enabled = !((Behaviour)masterCrusher).enabled;
		}
		GUILayout.Label(text2, (GUILayoutOption[])(object)new GUILayoutOption[0]);
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.EndArea();
	}
}
