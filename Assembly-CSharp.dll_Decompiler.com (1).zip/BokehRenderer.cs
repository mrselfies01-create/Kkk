using UnityEngine;

internal class BokehRenderer
{
	private Texture2D m_CurrentTexture;

	private Material m_FlareMaterial;

	private int m_CurrentWidth;

	private int m_CurrentHeight;

	private float m_CurrentRelativeScaleX;

	private float m_CurrentRelativeScaleY;

	public void RebuildMeshIfNeeded(int width, int height, float spriteRelativeScaleX, float spriteRelativeScaleY, ref Mesh[] meshes)
	{
		if (m_CurrentWidth == width && m_CurrentHeight == height && m_CurrentRelativeScaleX == spriteRelativeScaleX && m_CurrentRelativeScaleY == spriteRelativeScaleY && meshes != null)
		{
			return;
		}
		if (meshes != null)
		{
			Mesh[] array = meshes;
			foreach (Mesh val in array)
			{
				Object.DestroyImmediate((Object)(object)val, true);
			}
		}
		meshes = null;
		BuildMeshes(width, height, spriteRelativeScaleX, spriteRelativeScaleY, ref meshes);
	}

	public void BuildMeshes(int width, int height, float spriteRelativeScaleX, float spriteRelativeScaleY, ref Mesh[] meshes)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Expected O, but got Unknown
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		int num = 10833;
		int num2 = width * height;
		int num3 = Mathf.CeilToInt(1f * (float)num2 / (1f * (float)num));
		meshes = (Mesh[])(object)new Mesh[num3];
		int num4 = num2;
		m_CurrentWidth = width;
		m_CurrentHeight = height;
		m_CurrentRelativeScaleX = spriteRelativeScaleX;
		m_CurrentRelativeScaleY = spriteRelativeScaleY;
		int num5 = 0;
		for (int i = 0; i < num3; i++)
		{
			Mesh val = new Mesh();
			((Object)val).hideFlags = (HideFlags)61;
			int num6 = num4;
			if (num4 > num)
			{
				num6 = num;
			}
			num4 -= num6;
			Vector3[] vertices = (Vector3[])(object)new Vector3[num6 * 4];
			int[] triangles = new int[num6 * 6];
			Vector2[] array = (Vector2[])(object)new Vector2[num6 * 4];
			Vector2[] array2 = (Vector2[])(object)new Vector2[num6 * 4];
			Vector3[] normals = (Vector3[])(object)new Vector3[num6 * 4];
			Color[] colors = (Color[])(object)new Color[num6 * 4];
			float num7 = m_CurrentRelativeScaleX * (float)width;
			float num8 = m_CurrentRelativeScaleY * (float)height;
			for (int j = 0; j < num6; j++)
			{
				int num9 = num5 % width;
				int num10 = (num5 - num9) / width;
				SetupSprite(j, num9, num10, vertices, triangles, array, array2, normals, colors, new Vector2((float)num9 / (float)width, 1f - (float)num10 / (float)height), num7 * 0.5f, num8 * 0.5f);
				num5++;
			}
			val.vertices = vertices;
			val.triangles = triangles;
			val.colors = colors;
			val.uv = array;
			val.uv2 = array2;
			val.normals = normals;
			val.RecalculateBounds();
			val.UploadMeshData(true);
			meshes[i] = val;
		}
	}

	public void Clear(ref Mesh[] meshes)
	{
		if (meshes != null)
		{
			Mesh[] array = meshes;
			foreach (Mesh val in array)
			{
				Object.DestroyImmediate((Object)(object)val, true);
			}
		}
		meshes = null;
	}

	public void SetTexture(Texture2D texture)
	{
		m_CurrentTexture = texture;
		m_FlareMaterial.SetTexture("_MainTex", (Texture)(object)m_CurrentTexture);
	}

	public void SetMaterial(Material flareMaterial)
	{
		m_FlareMaterial = flareMaterial;
	}

	public void RenderFlare(RenderTexture brightPixels, RenderTexture destination, float intensity, ref Mesh[] meshes)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		RenderTexture active = RenderTexture.active;
		RenderTexture.active = destination;
		GL.Clear(true, true, Color.black);
		Matrix4x4 val = Matrix4x4.Ortho(0f, (float)m_CurrentWidth, 0f, (float)m_CurrentHeight, -1f, 1f);
		m_FlareMaterial.SetMatrix("_FlareProj", val);
		m_FlareMaterial.SetTexture("_BrightTexture", (Texture)(object)brightPixels);
		m_FlareMaterial.SetFloat("_Intensity", intensity);
		if (m_FlareMaterial.SetPass(0))
		{
			for (int i = 0; i < meshes.Length; i++)
			{
				Graphics.DrawMeshNow(meshes[i], Matrix4x4.identity);
			}
		}
		else
		{
			Debug.LogError((object)"Can't render flare mesh");
		}
		RenderTexture.active = active;
	}

	public void SetupSprite(int idx, int x, int y, Vector3[] vertices, int[] triangles, Vector2[] uv0, Vector2[] uv1, Vector3[] normals, Color[] colors, Vector2 targetPixelUV, float halfWidth, float halfHeight)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		int num = idx * 4;
		int num2 = idx * 6;
		triangles[num2] = num;
		triangles[num2 + 1] = num + 2;
		triangles[num2 + 2] = num + 1;
		triangles[num2 + 3] = num + 2;
		triangles[num2 + 4] = num + 3;
		triangles[num2 + 5] = num + 1;
		ref Vector3 reference = ref vertices[num];
		reference = new Vector3(0f - halfWidth + (float)x, 0f - halfHeight + (float)y, 0f);
		ref Vector3 reference2 = ref vertices[num + 1];
		reference2 = new Vector3(halfWidth + (float)x, 0f - halfHeight + (float)y, 0f);
		ref Vector3 reference3 = ref vertices[num + 2];
		reference3 = new Vector3(0f - halfWidth + (float)x, halfHeight + (float)y, 0f);
		ref Vector3 reference4 = ref vertices[num + 3];
		reference4 = new Vector3(halfWidth + (float)x, halfHeight + (float)y, 0f);
		Vector2 val = targetPixelUV;
		ref Color reference5 = ref colors[num];
		reference5 = new Color((0f - halfWidth) / (float)m_CurrentWidth + val.x, (0f - halfHeight) * -1f / (float)m_CurrentHeight + val.y, 0f, 0f);
		ref Color reference6 = ref colors[num + 1];
		reference6 = new Color(halfWidth / (float)m_CurrentWidth + val.x, (0f - halfHeight) * -1f / (float)m_CurrentHeight + val.y, 0f, 0f);
		ref Color reference7 = ref colors[num + 2];
		reference7 = new Color((0f - halfWidth) / (float)m_CurrentWidth + val.x, halfHeight * -1f / (float)m_CurrentHeight + val.y, 0f, 0f);
		ref Color reference8 = ref colors[num + 3];
		reference8 = new Color(halfWidth / (float)m_CurrentWidth + val.x, halfHeight * -1f / (float)m_CurrentHeight + val.y, 0f, 0f);
		ref Vector3 reference9 = ref normals[num];
		reference9 = -Vector3.forward;
		ref Vector3 reference10 = ref normals[num + 1];
		reference10 = -Vector3.forward;
		ref Vector3 reference11 = ref normals[num + 2];
		reference11 = -Vector3.forward;
		ref Vector3 reference12 = ref normals[num + 3];
		reference12 = -Vector3.forward;
		ref Vector2 reference13 = ref uv0[num];
		reference13 = new Vector2(0f, 0f);
		ref Vector2 reference14 = ref uv0[num + 1];
		reference14 = new Vector2(1f, 0f);
		ref Vector2 reference15 = ref uv0[num + 2];
		reference15 = new Vector2(0f, 1f);
		ref Vector2 reference16 = ref uv0[num + 3];
		reference16 = new Vector2(1f, 1f);
		uv1[num] = targetPixelUV;
		uv1[num + 1] = targetPixelUV;
		uv1[num + 2] = targetPixelUV;
		uv1[num + 3] = targetPixelUV;
	}
}
