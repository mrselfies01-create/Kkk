using UnityEngine;

public class AspectScript : MonoBehaviour
{
	public float desiredAspect = 75f;

	private float lastDesired;

	public int lastWidth;

	public int lastHeight;

	private Camera cam;

	private void Start()
	{
		cam = ((Component)this).GetComponent<Camera>();
		lastDesired = desiredAspect;
		UpdateAspect();
	}

	private void Update()
	{
		UpdateAspect();
	}

	private void UpdateAspect()
	{
		bool flag = false;
		if (lastDesired != desiredAspect)
		{
			flag = true;
		}
		if (lastWidth != cam.pixelWidth)
		{
			flag = true;
		}
		if (lastHeight != cam.pixelHeight)
		{
			flag = true;
		}
		if (flag)
		{
			cam.fieldOfView = desiredAspect / ((float)cam.pixelWidth / (float)cam.pixelHeight);
		}
		lastDesired = desiredAspect;
		lastWidth = cam.pixelWidth;
		lastHeight = cam.pixelHeight;
	}
}
