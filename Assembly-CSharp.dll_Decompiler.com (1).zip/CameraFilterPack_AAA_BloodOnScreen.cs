using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/AAA/Blood On Screen")]
public class CameraFilterPack_AAA_BloodOnScreen : MonoBehaviour
{
	public Shader SCShader;

	private float TimeX = 1f;

	[Range(0.02f, 1.6f)]
	public float Blood_On_Screen = 1f;

	public Color Blood_Color = Color.red;

	[Range(0f, 2f)]
	public float Blood_Intensify = 0.7f;

	[Range(0f, 2f)]
	public float Blood_Darkness = 0.5f;

	[Range(0f, 1f)]
	public float Blood_Distortion_Speed = 0.25f;

	[Range(0f, 1f)]
	public float Blood_Fade = 1f;

	private Material SCMaterial;

	private Texture2D Texture2;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void Start()
	{
		ref Texture2D texture = ref Texture2;
		Object obj = Resources.Load("CameraFilterPack_AAA_BloodOnScreen1");
		texture = (Texture2D)(object)((obj is Texture2D) ? obj : null);
		SCShader = Shader.Find("CameraFilterPack/AAA_BloodOnScreen");
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value", Mathf.Clamp(Blood_On_Screen, 0.02f, 1.6f));
			material.SetFloat("_Value2", Mathf.Clamp(Blood_Intensify, 0f, 2f));
			material.SetFloat("_Value3", Mathf.Clamp(Blood_Darkness, 0f, 2f));
			material.SetFloat("_Value4", Mathf.Clamp(Blood_Fade, 0f, 1f));
			material.SetFloat("_Value5", Mathf.Clamp(Blood_Distortion_Speed, 0f, 2f));
			material.SetColor("_Color2", Blood_Color);
			material.SetTexture("_MainTex2", (Texture)(object)Texture2);
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void Update()
	{
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
