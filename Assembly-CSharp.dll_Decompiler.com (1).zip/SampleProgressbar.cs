using UIWidgets;
using UnityEngine;

[RequireComponent(typeof(Progressbar))]
public class SampleProgressbar : MonoBehaviour
{
	private void Start()
	{
		Progressbar component = ((Component)this).GetComponent<Progressbar>();
		component.TextFunc = (Progressbar x) => $"Exp to next level: {x.Value} / {x.Max}";
	}
}
