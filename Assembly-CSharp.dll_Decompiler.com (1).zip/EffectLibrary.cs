using Audial;
using UnityEngine;

public class EffectLibrary : MonoBehaviour
{
	public AudioEchoFilter minimumEcho;

	public AudioEchoFilter normalEcho;

	public AudioEchoFilter maximumEcho;

	public AudioChorusFilter minimumChorus;

	public AudioChorusFilter normalChorus;

	public AudioChorusFilter maximumChorus;

	public AudioReverbFilter minimumReverbo;

	public AudioReverbFilter normalReverbo;

	public AudioReverbFilter maximumReverbo;

	public Reverb minimumReverb;

	public Phaser minimumPhaser;

	public Delay minimumDelay;

	public Crusher minimumCrusher;

	public Reverb maximumReverb;

	public Phaser maximumPhaser;

	public Delay maximumDelay;

	public Crusher normalCrusher;

	public Reverb normalReverb;

	public Phaser normalPhaser;

	public Delay normalDelay;

	public Crusher maximumCrusher;

	public StateVariableFilter normalFilter;

	public StateVariableFilter maximumFilter;

	public StateVariableFilter minimumFilter;

	private void Start()
	{
	}

	private void Update()
	{
	}

	public void SetPhazer(Phaser filter, float r)
	{
		float num = 1f;
		Phaser phaser;
		Phaser phaser2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			phaser = minimumPhaser;
			phaser2 = normalPhaser;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			phaser = normalPhaser;
			phaser2 = maximumPhaser;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		filter.Rate = phaser.Rate * (1f - num) + phaser2.Rate * num;
		filter.Intensity = phaser.Intensity * (1f - num) + phaser2.Intensity * num;
		filter.Width = phaser.Width * (1f - num) + phaser2.Width * num;
		filter.DryWet = phaser.DryWet * (1f - num) + phaser2.DryWet * num;
	}

	public void SetCrusher(Crusher filter, float r)
	{
		float num = 1f;
		Crusher crusher;
		Crusher crusher2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			crusher = minimumCrusher;
			crusher2 = normalCrusher;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			crusher = normalCrusher;
			crusher2 = maximumCrusher;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		filter.BitDepth = (int)((float)crusher.BitDepth * (1f - num) + (float)crusher2.BitDepth * num);
		filter.DryWet = crusher.DryWet * (1f - num) + crusher2.DryWet * num;
		filter.SampleRate = crusher.SampleRate * (1f - num) + crusher2.SampleRate * num;
	}

	public void SetFilter(StateVariableFilter filter, float r)
	{
		float num = 1f;
		StateVariableFilter stateVariableFilter;
		StateVariableFilter stateVariableFilter2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			stateVariableFilter = minimumFilter;
			stateVariableFilter2 = normalFilter;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			stateVariableFilter = normalFilter;
			stateVariableFilter2 = maximumFilter;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		filter.Drive = (int)(stateVariableFilter.Drive * (1f - num) + stateVariableFilter2.Drive * num);
		filter.AdditiveGain = stateVariableFilter.AdditiveGain * (1f - num) + stateVariableFilter2.AdditiveGain * num;
		filter.Frequency = stateVariableFilter.Frequency * (1f - num) + stateVariableFilter2.Frequency * num;
	}

	public void SetDelay(Delay filter, float r)
	{
		float num = 1f;
		Delay delay;
		Delay delay2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			delay = minimumDelay;
			delay2 = normalDelay;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			delay = normalDelay;
			delay2 = maximumDelay;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		filter.DecayLength = delay.DecayLength * (1f - num) + delay2.DecayLength * num;
		filter.DelayCount = (int)((float)delay.DelayCount * (1f - num) + (float)delay2.DelayCount * num);
		filter.BPM = delay.BPM * (1f - num) + delay2.BPM * num;
		filter.DryWet = delay.DryWet * (1f - num) + delay2.DryWet * num;
		filter.Pan = delay.Pan * (1f - num) + delay2.Pan * num;
	}

	public void SetReverb(Reverb filter, float r)
	{
		float num = 1f;
		Reverb reverb;
		Reverb reverb2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			reverb = minimumReverb;
			reverb2 = normalReverb;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			reverb = normalReverb;
			reverb2 = maximumReverb;
		}
		filter.DryWet = reverb.DryWet * (1f - num) + reverb2.DryWet * num;
		filter.ReverbGain = reverb.ReverbGain * (1f - num) + reverb2.ReverbGain * num;
		filter.ReverbTime = reverb.ReverbTime * (1f - num) + reverb2.ReverbTime * num;
	}

	public void SetEcho(AudioEchoFilter filter, float r)
	{
		float num = 1f;
		AudioEchoFilter val;
		AudioEchoFilter val2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			val = minimumEcho;
			val2 = normalEcho;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			val = normalEcho;
			val2 = maximumEcho;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		filter.decayRatio = val.decayRatio * (1f - num) + val2.decayRatio * num;
		filter.delay = val.delay * (1f - num) + val2.delay * num;
		filter.dryMix = val.dryMix * (1f - num) + val2.dryMix * num;
		filter.wetMix = val.wetMix * (1f - num) + val2.wetMix * num;
	}

	public void SetChorus(AudioChorusFilter filter, float r)
	{
		float num = 1f;
		AudioChorusFilter val;
		AudioChorusFilter val2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			val = minimumChorus;
			val2 = normalChorus;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			val = normalChorus;
			val2 = maximumChorus;
		}
		filter.delay = val.delay * (1f - num) + val2.delay * num;
		filter.depth = val.depth * (1f - num) + val2.depth * num;
		filter.dryMix = val.dryMix * (1f - num) + val2.dryMix * num;
		filter.rate = val.rate * (1f - num) + val2.rate * num;
		filter.wetMix1 = val.wetMix1 * (1f - num) + val2.wetMix1 * num;
		filter.wetMix2 = val.wetMix2 * (1f - num) + val2.wetMix2 * num;
		filter.wetMix3 = val.wetMix3 * (1f - num) + val2.wetMix3 * num;
	}

	public void SetReverbOld(AudioReverbFilter filter, float r)
	{
		float num = 1f;
		AudioReverbFilter val;
		AudioReverbFilter val2;
		if (r <= 0.5f)
		{
			num = r * 2f;
			val = minimumReverbo;
			val2 = normalReverbo;
		}
		else
		{
			num = (r - 0.5f) * 2f;
			val = normalReverbo;
			val2 = maximumReverbo;
		}
		filter.decayTime = val.decayTime * (1f - num) + val2.decayTime * num;
		filter.decayHFRatio = val.decayHFRatio * (1f - num) + val2.decayHFRatio * num;
		filter.density = val.density * (1f - num) + val2.density * num;
		filter.diffusion = val.diffusion * (1f - num) + val2.diffusion * num;
		filter.dryLevel = val.dryLevel * (1f - num) + val2.dryLevel * num;
		filter.reflectionsDelay = val.reflectionsDelay * (1f - num) + val2.reflectionsDelay * num;
		filter.reflectionsLevel = val.reflectionsLevel * (1f - num) + val2.reflectionsLevel * num;
		filter.reverbDelay = val.reverbDelay * (1f - num) + val2.reverbDelay * num;
		filter.reverbLevel = val.reverbLevel * (1f - num) + val2.reverbLevel * num;
		filter.room = val.room * (1f - num) + val2.room * num;
		filter.roomHF = val.roomHF * (1f - num) + val2.roomHF * num;
		filter.roomLF = val.roomLF * (1f - num) + val2.roomLF * num;
		filter.roomRolloff = val.roomRolloff * (1f - num) + val2.roomRolloff * num;
	}
}
