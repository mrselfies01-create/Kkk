using System.Collections.Generic;
using UnityEngine;

public class SampleNameManager : MonoBehaviour
{
	public List<string> acceptedNames = new List<string>();
}
