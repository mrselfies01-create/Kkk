using UnityEngine;

public class UBHelper : MonoBehaviour
{
	private class Styles
	{
		public GUIStyle header = GUIStyle.op_Implicit("ShurikenModuleTitle");

		public GUIStyle headerArrow = GUIStyle.op_Implicit("AC RightArrow");

		private RectOffset m_Border;

		private float m_FixedHeight;

		private Vector2 m_ContentOffset;

		private TextAnchor m_TextAlign;

		private FontStyle m_TextStyle;

		private int m_FontSize;

		internal Styles()
		{
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			header.font = new GUIStyle(GUIStyle.op_Implicit("Label")).font;
		}

		public void Backup()
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			m_Border = s_Styles.header.border;
			m_FixedHeight = s_Styles.header.fixedHeight;
			m_ContentOffset = s_Styles.header.contentOffset;
			m_TextAlign = s_Styles.header.alignment;
			m_TextStyle = s_Styles.header.fontStyle;
			m_FontSize = s_Styles.header.fontSize;
		}

		public void Apply()
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Expected O, but got Unknown
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			s_Styles.header.border = new RectOffset(7, 7, 4, 4);
			s_Styles.header.fixedHeight = 22f;
			s_Styles.header.contentOffset = new Vector2(20f, -2f);
			s_Styles.header.alignment = (TextAnchor)3;
			s_Styles.header.fontStyle = (FontStyle)1;
			s_Styles.header.fontSize = 12;
		}

		public void Revert()
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			s_Styles.header.border = m_Border;
			s_Styles.header.fixedHeight = m_FixedHeight;
			s_Styles.header.contentOffset = m_ContentOffset;
			s_Styles.header.alignment = m_TextAlign;
			s_Styles.header.fontStyle = m_TextStyle;
			s_Styles.header.fontSize = m_FontSize;
		}
	}

	private static Styles s_Styles;

	static UBHelper()
	{
		s_Styles = new Styles();
	}

	public static bool GroupHeader(string text, bool isExpanded)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Invalid comparison between Unknown and I4
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = GUILayoutUtility.GetRect(16f, 22f, s_Styles.header);
		s_Styles.Backup();
		s_Styles.Apply();
		if ((int)Event.current.type == 7)
		{
			s_Styles.header.Draw(rect, text, isExpanded, isExpanded, isExpanded, isExpanded);
		}
		Event current = Event.current;
		if ((int)current.type == 0 && ((Rect)(ref rect)).Contains(current.mousePosition))
		{
			isExpanded = !isExpanded;
			current.Use();
		}
		s_Styles.Revert();
		return isExpanded;
	}
}
