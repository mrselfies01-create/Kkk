using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Analytics;

public class LoadingScript : MonoBehaviour
{
	[SerializeField]
	private int scene = 1;

	private bool loading;

	private void Start()
	{
	}

	private void Update()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		if (!loading)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary["DeviceName"] = SystemInfo.deviceName;
			dictionary["DeviceModel"] = SystemInfo.deviceModel;
			dictionary["DeviceType"] = SystemInfo.deviceType;
			dictionary["DeviceGraphicsDeviceMemorySize"] = SystemInfo.graphicsMemorySize;
			dictionary["DeviceMaxTextureSize"] = SystemInfo.maxTextureSize;
			dictionary["DeviceOperatingSystem"] = SystemInfo.operatingSystem;
			dictionary["DeviceSystemMemorySize"] = SystemInfo.systemMemorySize;
			Analytics.CustomEvent("LoadingGame", (IDictionary<string, object>)dictionary);
			loading = true;
			((MonoBehaviour)this).StartCoroutine(LoadNewScene());
		}
	}

	private IEnumerator LoadNewScene()
	{
		yield return (object)new WaitForSeconds(2f);
		AsyncOperation async = Application.LoadLevelAsync(scene);
		while (!async.isDone)
		{
			yield return null;
		}
	}
}
