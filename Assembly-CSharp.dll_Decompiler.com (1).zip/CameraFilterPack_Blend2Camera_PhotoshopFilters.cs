using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Camera Filter Pack/Blend 2 Camera/PhotoshopFilters")]
public class CameraFilterPack_Blend2Camera_PhotoshopFilters : MonoBehaviour
{
	public enum filters
	{
		Darken,
		Multiply,
		ColorBurn,
		LinearBurn,
		DarkerColor,
		Lighten,
		Screen,
		ColorDodge,
		LinearDodge,
		LighterColor,
		Overlay,
		SoftLight,
		HardLight,
		VividLight,
		LinearLight,
		PinLight,
		HardMix,
		Difference,
		Exclusion,
		Subtract,
		Divide,
		Hue,
		Saturation,
		Color,
		Luminosity
	}

	private string ShaderName = "CameraFilterPack/Blend2Camera_Darken";

	public Shader SCShader;

	public Camera Camera2;

	public filters filterchoice;

	private filters filterchoicememo;

	private float TimeX = 1f;

	private Vector4 ScreenResolution;

	private Material SCMaterial;

	[Range(0f, 1f)]
	public float SwitchCameraToCamera2;

	[Range(0f, 1f)]
	public float BlendFX = 0.5f;

	private RenderTexture Camera2tex;

	private Material material
	{
		get
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
			return SCMaterial;
		}
	}

	private void ChangeFilters()
	{
		if (filterchoice == filters.Darken)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Darken";
		}
		if (filterchoice == filters.Multiply)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Multiply";
		}
		if (filterchoice == filters.ColorBurn)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_ColorBurn";
		}
		if (filterchoice == filters.LinearBurn)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_LinearBurn";
		}
		if (filterchoice == filters.DarkerColor)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_DarkerColor";
		}
		if (filterchoice == filters.Lighten)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Lighten";
		}
		if (filterchoice == filters.Screen)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Screen";
		}
		if (filterchoice == filters.ColorDodge)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_ColorDodge";
		}
		if (filterchoice == filters.LinearDodge)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_LinearDodge";
		}
		if (filterchoice == filters.LighterColor)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_LighterColor";
		}
		if (filterchoice == filters.Overlay)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Overlay";
		}
		if (filterchoice == filters.SoftLight)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_SoftLight";
		}
		if (filterchoice == filters.HardLight)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_HardLight";
		}
		if (filterchoice == filters.VividLight)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_VividLight";
		}
		if (filterchoice == filters.LinearLight)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_LinearLight";
		}
		if (filterchoice == filters.PinLight)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_PinLight";
		}
		if (filterchoice == filters.HardMix)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_HardMix";
		}
		if (filterchoice == filters.Difference)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Difference";
		}
		if (filterchoice == filters.Exclusion)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Exclusion";
		}
		if (filterchoice == filters.Subtract)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Subtract";
		}
		if (filterchoice == filters.Divide)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Divide";
		}
		if (filterchoice == filters.Hue)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Hue";
		}
		if (filterchoice == filters.Saturation)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Saturation";
		}
		if (filterchoice == filters.Color)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Color";
		}
		if (filterchoice == filters.Luminosity)
		{
			ShaderName = "CameraFilterPack/Blend2Camera_Luminosity";
		}
	}

	private void Start()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected O, but got Unknown
		filterchoicememo = filterchoice;
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
		ChangeFilters();
		SCShader = Shader.Find(ShaderName);
		if (!SystemInfo.supportsImageEffects)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)SCShader != (Object)null)
		{
			TimeX += Time.deltaTime;
			if (TimeX > 100f)
			{
				TimeX = 0f;
			}
			if ((Object)(object)Camera2 != (Object)null)
			{
				material.SetTexture("_MainTex2", (Texture)(object)Camera2tex);
			}
			material.SetFloat("_TimeX", TimeX);
			material.SetFloat("_Value", BlendFX);
			material.SetFloat("_Value2", SwitchCameraToCamera2);
			material.SetVector("_ScreenResolution", new Vector4((float)((Texture)sourceTexture).width, (float)((Texture)sourceTexture).height, 0f, 0f));
			Graphics.Blit((Texture)(object)sourceTexture, destTexture, material);
		}
		else
		{
			Graphics.Blit((Texture)(object)sourceTexture, destTexture);
		}
	}

	private void OnValidate()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Expected O, but got Unknown
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Expected O, but got Unknown
		if (filterchoice != filterchoicememo)
		{
			ChangeFilters();
			SCShader = Shader.Find(ShaderName);
			Object.DestroyImmediate((Object)(object)SCMaterial);
			if ((Object)(object)SCMaterial == (Object)null)
			{
				SCMaterial = new Material(SCShader);
				((Object)SCMaterial).hideFlags = (HideFlags)61;
			}
		}
		filterchoicememo = filterchoice;
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
	}

	private void Update()
	{
	}

	private void OnEnable()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2tex = new RenderTexture(Screen.width, Screen.height, 24);
			Camera2.targetTexture = Camera2tex;
		}
	}

	private void OnDisable()
	{
		if ((Object)(object)Camera2 != (Object)null)
		{
			Camera2.targetTexture = null;
		}
		if (Object.op_Implicit((Object)(object)SCMaterial))
		{
			Object.DestroyImmediate((Object)(object)SCMaterial);
		}
	}
}
