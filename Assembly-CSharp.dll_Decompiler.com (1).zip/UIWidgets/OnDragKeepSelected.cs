using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[Obsolete("No more useful.")]
public class OnDragKeepSelected : MonoBehaviour, IEndDragHandler, IEventSystemHandler
{
	public void OnEndDrag(PointerEventData eventData)
	{
		EventSystem.current.SetSelectedGameObject(EventSystem.current.lastSelectedGameObject);
	}
}
