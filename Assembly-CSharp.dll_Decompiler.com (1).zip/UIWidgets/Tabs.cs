using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/Tabs", 290)]
public class Tabs : MonoBehaviour
{
	[SerializeField]
	public Transform Container;

	[SerializeField]
	public Button DefaultTabButton;

	[SerializeField]
	public Button ActiveTabButton;

	[SerializeField]
	private Tab[] tabObjects = new Tab[0];

	[SerializeField]
	[Tooltip("If true does not deactivate hidden tabs.")]
	public bool KeepTabsActive;

	[SerializeField]
	public TabSelectEvent OnTabSelect = new TabSelectEvent();

	private List<Button> defaultButtons = new List<Button>();

	private List<Button> activeButtons = new List<Button>();

	private List<UnityAction> callbacks = new List<UnityAction>();

	public Tab[] TabObjects
	{
		get
		{
			return tabObjects;
		}
		set
		{
			tabObjects = value;
			UpdateButtons();
		}
	}

	public Tab SelectedTab { get; protected set; }

	private void Start()
	{
		if ((Object)(object)Container == (Object)null)
		{
			throw new NullReferenceException("Container is null. Set object of type GameObject to Container.");
		}
		if ((Object)(object)DefaultTabButton == (Object)null)
		{
			throw new NullReferenceException("DefaultTabButton is null. Set object of type GameObject to DefaultTabButton.");
		}
		if ((Object)(object)ActiveTabButton == (Object)null)
		{
			throw new NullReferenceException("ActiveTabButton is null. Set object of type GameObject to ActiveTabButton.");
		}
		((Component)DefaultTabButton).gameObject.SetActive(false);
		((Component)ActiveTabButton).gameObject.SetActive(false);
		UpdateButtons();
	}

	private void UpdateButtons()
	{
		if (tabObjects.Length == 0)
		{
			throw new ArgumentException("TabObjects array is empty. Fill it.");
		}
		RemoveCallbacks();
		CreateButtons();
		AddCallbacks();
		SelectTab(tabObjects[0].Name);
	}

	private void AddCallback(Tab tab, int index)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Expected O, but got Unknown
		string tabName = tab.Name;
		UnityAction item = (UnityAction)delegate
		{
			SelectTab(tabName);
		};
		callbacks.Add(item);
		((UnityEvent)defaultButtons[index].onClick).AddListener(callbacks[index]);
	}

	private void AddCallbacks()
	{
		tabObjects.ForEach(AddCallback);
	}

	private void RemoveCallback(Tab tab, int index)
	{
		if (tab != null && index < callbacks.Count)
		{
			((UnityEvent)defaultButtons[index].onClick).RemoveListener(callbacks[index]);
		}
	}

	private void RemoveCallbacks()
	{
		if (callbacks.Count > 0)
		{
			tabObjects.ForEach(RemoveCallback);
			callbacks.Clear();
		}
	}

	private void OnDestroy()
	{
		RemoveCallbacks();
	}

	public void SelectTab(string tabName)
	{
		int num = Array.FindIndex(tabObjects, (Tab x) => x.Name == tabName);
		if (num == -1)
		{
			throw new ArgumentException($"Tab with name \"{tabName}\" not found.");
		}
		if (KeepTabsActive)
		{
			tabObjects[num].TabObject.transform.SetAsLastSibling();
		}
		else
		{
			tabObjects.ForEach(DeactivateTab);
			tabObjects[num].TabObject.SetActive(true);
		}
		defaultButtons.ForEach(ActivateButton);
		((Component)defaultButtons[num]).gameObject.SetActive(false);
		activeButtons.ForEach(DeactivateButton);
		((Component)activeButtons[num]).gameObject.SetActive(true);
		SelectedTab = tabObjects[num];
		((UnityEvent<int>)OnTabSelect).Invoke(num);
	}

	private void DeactivateTab(Tab tab)
	{
		tab.TabObject.SetActive(false);
	}

	private void ActivateButton(Button button)
	{
		((Component)button).gameObject.SetActive(true);
	}

	private void DeactivateButton(Button button)
	{
		((Component)button).gameObject.SetActive(false);
	}

	private void CreateButtons()
	{
		if (tabObjects.Length > defaultButtons.Count)
		{
			for (int i = defaultButtons.Count; i < tabObjects.Length; i++)
			{
				Button val = Object.Instantiate<Button>(DefaultTabButton);
				((Component)val).transform.SetParent(Container, false);
				defaultButtons.Add(val);
				Button val2 = Object.Instantiate<Button>(ActiveTabButton);
				((Component)val2).transform.SetParent(Container, false);
				activeButtons.Add(val2);
			}
		}
		if (tabObjects.Length < defaultButtons.Count)
		{
			for (int num = defaultButtons.Count; num > tabObjects.Length; num--)
			{
				Object.Destroy((Object)(object)defaultButtons[num]);
				Object.Destroy((Object)(object)activeButtons[num]);
				defaultButtons.RemoveAt(num);
				activeButtons.RemoveAt(num);
			}
		}
		defaultButtons.ForEach(SetButtonName);
		activeButtons.ForEach(SetButtonName);
	}

	private void SetButtonName(Button button, int index)
	{
		((Component)button).gameObject.SetActive(true);
		Text componentInChildren = ((Component)button).GetComponentInChildren<Text>();
		if (Object.op_Implicit((Object)(object)componentInChildren))
		{
			componentInChildren.text = tabObjects[index].Name;
		}
	}
}
