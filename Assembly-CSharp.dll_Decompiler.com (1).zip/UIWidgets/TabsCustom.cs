using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class TabsCustom<TTab, TButton> : MonoBehaviour where TTab : Tab where TButton : TabButton
{
	[SerializeField]
	public Transform Container;

	[SerializeField]
	public TButton DefaultTabButton;

	[SerializeField]
	public TButton ActiveTabButton;

	[SerializeField]
	private TTab[] tabObjects = new TTab[0];

	[SerializeField]
	[Tooltip("If true does not deactivate hidden tabs.")]
	public bool KeepTabsActive;

	[SerializeField]
	public TabSelectEvent OnTabSelect = new TabSelectEvent();

	private List<TButton> defaultButtons = new List<TButton>();

	private List<TButton> activeButtons = new List<TButton>();

	private List<UnityAction> callbacks = new List<UnityAction>();

	public TTab[] TabObjects
	{
		get
		{
			return tabObjects;
		}
		set
		{
			tabObjects = value;
			UpdateButtons();
		}
	}

	public TTab SelectedTab { get; protected set; }

	private void Start()
	{
		if ((Object)(object)Container == (Object)null)
		{
			throw new NullReferenceException("Container is null. Set object of type GameObject to Container.");
		}
		if ((Object)(object)DefaultTabButton == (Object)null)
		{
			throw new NullReferenceException("DefaultTabButton is null. Set object of type GameObject to DefaultTabButton.");
		}
		if ((Object)(object)ActiveTabButton == (Object)null)
		{
			throw new NullReferenceException("ActiveTabButton is null. Set object of type GameObject to ActiveTabButton.");
		}
		((Component)DefaultTabButton).gameObject.SetActive(false);
		((Component)ActiveTabButton).gameObject.SetActive(false);
		UpdateButtons();
	}

	private void UpdateButtons()
	{
		if (tabObjects.Length == 0)
		{
			throw new ArgumentException("TabObjects array is empty. Fill it.");
		}
		RemoveCallbacks();
		CreateButtons();
		AddCallbacks();
		SelectTab(tabObjects[0]);
	}

	private void AddCallback(TTab tab, int index)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected O, but got Unknown
		UnityAction item = (UnityAction)delegate
		{
			SelectTab(tab);
		};
		callbacks.Add(item);
		TButton val = defaultButtons[index];
		((UnityEvent)((Button)val).onClick).AddListener(callbacks[index]);
	}

	private void AddCallbacks()
	{
		tabObjects.ForEach(AddCallback);
	}

	private void RemoveCallback(TTab tab, int index)
	{
		if (tab != null && index < callbacks.Count)
		{
			TButton val = defaultButtons[index];
			((UnityEvent)((Button)val).onClick).RemoveListener(callbacks[index]);
		}
	}

	private void RemoveCallbacks()
	{
		if (callbacks.Count > 0)
		{
			tabObjects.ForEach(RemoveCallback);
			callbacks.Clear();
		}
	}

	private void OnDestroy()
	{
		RemoveCallbacks();
	}

	public void SelectTab(TTab tab)
	{
		int num = Array.IndexOf(tabObjects, tab);
		if (num == -1)
		{
			throw new ArgumentException($"Tab with name \"{tab.Name}\" not found.");
		}
		SelectedTab = tabObjects[num];
		if (KeepTabsActive)
		{
			tabObjects[num].TabObject.transform.SetAsLastSibling();
		}
		else
		{
			tabObjects.ForEach(DeactivateTab);
			tabObjects[num].TabObject.SetActive(true);
		}
		defaultButtons.ForEach(ActivateButton);
		TButton val = defaultButtons[num];
		((Component)val).gameObject.SetActive(false);
		activeButtons.ForEach(DeactivateButton);
		TButton val2 = activeButtons[num];
		((Component)val2).gameObject.SetActive(true);
		((UnityEvent<int>)OnTabSelect).Invoke(num);
	}

	private void DeactivateTab(TTab tab)
	{
		tab.TabObject.SetActive(false);
	}

	private void ActivateButton(TButton button)
	{
		((Component)button).gameObject.SetActive(true);
	}

	private void DeactivateButton(TButton button)
	{
		((Component)button).gameObject.SetActive(false);
	}

	private void CreateButtons()
	{
		if (tabObjects.Length > defaultButtons.Count)
		{
			for (int i = defaultButtons.Count; i < tabObjects.Length; i++)
			{
				TButton item = Object.Instantiate<TButton>(DefaultTabButton);
				((Component)item).transform.SetParent(Container, false);
				defaultButtons.Add(item);
				TButton item2 = Object.Instantiate<TButton>(ActiveTabButton);
				((Component)item2).transform.SetParent(Container, false);
				activeButtons.Add(item2);
			}
		}
		if (tabObjects.Length < defaultButtons.Count)
		{
			for (int num = defaultButtons.Count; num > tabObjects.Length; num--)
			{
				Object.Destroy((Object)(object)defaultButtons[num]);
				Object.Destroy((Object)(object)activeButtons[num]);
				defaultButtons.RemoveAt(num);
				activeButtons.RemoveAt(num);
			}
		}
		defaultButtons.ForEach(SetButtonData);
		activeButtons.ForEach(SetButtonData);
	}

	protected virtual void SetButtonData(TButton button, int index)
	{
	}
}
