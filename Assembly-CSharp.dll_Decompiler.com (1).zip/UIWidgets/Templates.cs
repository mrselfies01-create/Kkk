using System;
using System.Collections.Generic;
using UnityEngine;

namespace UIWidgets;

public class Templates<T> where T : MonoBehaviour, ITemplatable
{
	private Dictionary<string, T> templates = new Dictionary<string, T>();

	private Dictionary<string, Stack<T>> cache = new Dictionary<string, Stack<T>>();

	private bool findTemplatesCalled;

	private Action<T> onCreateCallback;

	public Templates(Action<T> onCreateCallback = null)
	{
		this.onCreateCallback = onCreateCallback;
	}

	public void FindTemplates()
	{
		findTemplatesCalled = true;
		Resources.FindObjectsOfTypeAll<T>().ForEach(AddTemplate);
	}

	private void AddTemplate(T template)
	{
		Add(((Object)template).name, template);
		((Component)template).gameObject.SetActive(false);
	}

	public void ClearCache()
	{
		cache.Keys.ForEach(ClearCache);
	}

	public void ClearCache(string name)
	{
		if (cache.ContainsKey(name))
		{
			cache[name].ForEach(DestroyCached);
			cache[name].Clear();
			cache[name].TrimExcess();
		}
	}

	private void DestroyCached(T cached)
	{
		if ((Object)(object)cached != (Object)null && (Object)(object)((Component)cached).gameObject != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)cached).gameObject);
		}
	}

	public bool Exists(string name)
	{
		return templates.ContainsKey(name);
	}

	public T Get(string name)
	{
		if (!Exists(name))
		{
			throw new ArgumentException("Not found template with name '" + name + "'");
		}
		return templates[name];
	}

	public void Delete(string name)
	{
		if (Exists(name))
		{
			templates.Remove(name);
			ClearCache(name);
		}
	}

	public void Add(string name, T template, bool replace = true)
	{
		if (Exists(name))
		{
			if (!replace)
			{
				throw new ArgumentException("Template with name '" + name + "' already exists.");
			}
			ClearCache(name);
			templates[name] = template;
		}
		else
		{
			templates.Add(name, template);
		}
		template.IsTemplate = true;
		template.TemplateName = name;
	}

	public T Instance(string name)
	{
		if (!findTemplatesCalled)
		{
			FindTemplates();
		}
		if (!Exists(name))
		{
			throw new ArgumentException("Not found template with name '" + name + "'");
		}
		if ((Object)(object)templates[name] == (Object)null)
		{
			templates.Clear();
			FindTemplates();
		}
		T val;
		if (cache.ContainsKey(name) && cache[name].Count > 0)
		{
			val = cache[name].Pop();
		}
		else
		{
			val = Object.Instantiate<T>(templates[name]);
			val.TemplateName = name;
			val.IsTemplate = false;
			if (onCreateCallback != null)
			{
				onCreateCallback(val);
			}
		}
		((Component)val).transform.SetParent(((Component)templates[name]).transform.parent, false);
		return val;
	}

	public void ToCache(T instance)
	{
		((Component)instance).gameObject.SetActive(false);
		if (!cache.ContainsKey(instance.TemplateName))
		{
			cache[instance.TemplateName] = new Stack<T>();
		}
		cache[instance.TemplateName].Push(instance);
	}
}
