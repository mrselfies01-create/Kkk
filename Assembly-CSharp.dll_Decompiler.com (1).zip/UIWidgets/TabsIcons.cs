using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/TabsIcons", 295)]
public class TabsIcons : TabsCustom<TabIcons, TabIconButton>
{
	protected override void SetButtonData(TabIconButton button, int index)
	{
		button.SetData(base.TabObjects[index]);
	}
}
