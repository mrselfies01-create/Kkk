using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class ResizeListener : UIBehaviour
{
	private RectTransform rectTransform;

	public UnityEvent OnResize = new UnityEvent();

	private Rect old_rect;

	public RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	protected override void OnRectTransformDimensionsChange()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (!((object)(Rect)(ref old_rect)).Equals((object?)RectTransform.rect))
		{
			old_rect = RectTransform.rect;
			OnResize.Invoke();
		}
	}
}
