using System;
using UnityEngine;

namespace UIWidgets;

[Serializable]
public class TabIcons : Tab
{
	public Sprite IconDefault;

	public Sprite IconActive;
}
