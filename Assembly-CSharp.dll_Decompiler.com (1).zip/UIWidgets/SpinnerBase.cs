using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public abstract class SpinnerBase<T> : InputField, IPointerDownHandler, IEventSystemHandler where T : struct
{
	[SerializeField]
	protected T _min;

	[SerializeField]
	protected T _max;

	[SerializeField]
	protected T _step;

	[SerializeField]
	protected T _value;

	[SerializeField]
	public SpinnerValidation Validation;

	[SerializeField]
	public float HoldStartDelay = 0.5f;

	[SerializeField]
	public float HoldChangeDelay = 0.1f;

	[SerializeField]
	protected ButtonAdvanced _plusButton;

	[SerializeField]
	protected ButtonAdvanced _minusButton;

	public UnityEvent onPlusClick = new UnityEvent();

	public UnityEvent onMinusClick = new UnityEvent();

	private IEnumerator corutine;

	public T Min
	{
		get
		{
			return _min;
		}
		set
		{
			_min = value;
		}
	}

	public T Max
	{
		get
		{
			return _max;
		}
		set
		{
			_max = value;
		}
	}

	public T Step
	{
		get
		{
			return _step;
		}
		set
		{
			_step = value;
		}
	}

	public T Value
	{
		get
		{
			return _value;
		}
		set
		{
			SetValue(value);
		}
	}

	public ButtonAdvanced PlusButton
	{
		get
		{
			return _plusButton;
		}
		set
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Expected O, but got Unknown
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Expected O, but got Unknown
			if ((Object)(object)_plusButton != (Object)null)
			{
				((UnityEvent)((Button)_plusButton).onClick).RemoveListener(new UnityAction(OnPlusClick));
				((UnityEvent<PointerEventData>)_plusButton.onPointerDown).RemoveListener((UnityAction<PointerEventData>)OnPlusButtonDown);
				((UnityEvent<PointerEventData>)_plusButton.onPointerUp).RemoveListener((UnityAction<PointerEventData>)OnPlusButtonUp);
			}
			_plusButton = value;
			if ((Object)(object)_plusButton != (Object)null)
			{
				((UnityEvent)((Button)_plusButton).onClick).AddListener(new UnityAction(OnPlusClick));
				((UnityEvent<PointerEventData>)_plusButton.onPointerDown).AddListener((UnityAction<PointerEventData>)OnPlusButtonDown);
				((UnityEvent<PointerEventData>)_plusButton.onPointerUp).AddListener((UnityAction<PointerEventData>)OnPlusButtonUp);
			}
		}
	}

	public ButtonAdvanced MinusButton
	{
		get
		{
			return _minusButton;
		}
		set
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Expected O, but got Unknown
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Expected O, but got Unknown
			if ((Object)(object)_minusButton != (Object)null)
			{
				((UnityEvent)((Button)_minusButton).onClick).RemoveListener(new UnityAction(OnMinusClick));
				((UnityEvent<PointerEventData>)_minusButton.onPointerDown).RemoveListener((UnityAction<PointerEventData>)OnMinusButtonDown);
				((UnityEvent<PointerEventData>)_minusButton.onPointerUp).RemoveListener((UnityAction<PointerEventData>)OnMinusButtonUp);
			}
			_minusButton = value;
			if ((Object)(object)_minusButton != (Object)null)
			{
				((UnityEvent)((Button)_minusButton).onClick).AddListener(new UnityAction(OnMinusClick));
				((UnityEvent<PointerEventData>)_minusButton.onPointerDown).AddListener((UnityAction<PointerEventData>)OnMinusButtonDown);
				((UnityEvent<PointerEventData>)_minusButton.onPointerUp).AddListener((UnityAction<PointerEventData>)OnMinusButtonUp);
			}
		}
	}

	public abstract void Plus();

	public abstract void Minus();

	protected abstract void SetValue(T newValue);

	protected override void Start()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected O, but got Unknown
		((UIBehaviour)this).Start();
		((InputField)this).onValidateInput = new OnValidateInput(SpinnerValidate);
		((UnityEvent<string>)(object)((InputField)this).onValueChanged).AddListener((UnityAction<string>)ValueChange);
		((UnityEvent<string>)(object)((InputField)this).onEndEdit).AddListener((UnityAction<string>)ValueEndEdit);
		PlusButton = _plusButton;
		MinusButton = _minusButton;
		Value = _value;
	}

	private IEnumerator HoldPlus()
	{
		yield return (object)new WaitForSeconds(HoldStartDelay);
		while (true)
		{
			Plus();
			yield return (object)new WaitForSeconds(HoldChangeDelay);
		}
	}

	private IEnumerator HoldMinus()
	{
		yield return (object)new WaitForSeconds(HoldStartDelay);
		while (true)
		{
			Minus();
			yield return (object)new WaitForSeconds(HoldChangeDelay);
		}
	}

	public void OnMinusClick()
	{
		Minus();
		onMinusClick.Invoke();
	}

	public void OnPlusClick()
	{
		Plus();
		onPlusClick.Invoke();
	}

	public void OnPlusButtonDown(PointerEventData eventData)
	{
		if (corutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(corutine);
		}
		corutine = HoldPlus();
		((MonoBehaviour)this).StartCoroutine(corutine);
	}

	public void OnPlusButtonUp(PointerEventData eventData)
	{
		((MonoBehaviour)this).StopCoroutine(corutine);
	}

	public void OnMinusButtonDown(PointerEventData eventData)
	{
		if (corutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(corutine);
		}
		corutine = HoldMinus();
		((MonoBehaviour)this).StartCoroutine(corutine);
	}

	public void OnMinusButtonUp(PointerEventData eventData)
	{
		((MonoBehaviour)this).StopCoroutine(corutine);
	}

	protected virtual void onDestroy()
	{
		((UnityEvent<string>)(object)((InputField)this).onValueChanged).RemoveListener((UnityAction<string>)ValueChange);
		((UnityEvent<string>)(object)((InputField)this).onEndEdit).RemoveListener((UnityAction<string>)ValueEndEdit);
		PlusButton = null;
		MinusButton = null;
	}

	protected abstract void ValueChange(string value);

	protected abstract void ValueEndEdit(string value);

	private char SpinnerValidate(string validateText, int charIndex, char addedChar)
	{
		if (Validation == SpinnerValidation.OnEndInput)
		{
			return ValidateShort(validateText, charIndex, addedChar);
		}
		return ValidateFull(validateText, charIndex, addedChar);
	}

	protected abstract char ValidateShort(string validateText, int charIndex, char addedChar);

	protected abstract char ValidateFull(string validateText, int charIndex, char addedChar);

	protected abstract T InBounds(T value);
}
