using UnityEngine.EventSystems;

namespace UIWidgets;

public interface IDropSupport<T>
{
	bool CanReceiveDrop(T data, PointerEventData eventData);

	void Drop(T data, PointerEventData eventData);

	void DropCanceled(T data, PointerEventData eventData);
}
