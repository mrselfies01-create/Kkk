using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class SubmitEventInt : UnityEvent<int>
{
}
