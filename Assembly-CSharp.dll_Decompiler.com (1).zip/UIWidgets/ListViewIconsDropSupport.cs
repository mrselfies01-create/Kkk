using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[RequireComponent(typeof(ListViewIcons))]
public class ListViewIconsDropSupport : MonoBehaviour, IDropSupport<TreeNode<TreeViewItem>>, IDropSupport<ListViewIconsItemDescription>
{
	public bool CanReceiveDrop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		return data.Nodes == null || data.Nodes.Count == 0;
	}

	public void Drop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		ListViewIcons component = ((Component)this).GetComponent<ListViewIcons>();
		component.DataSource.Add(new ListViewIconsItemDescription
		{
			Name = data.Item.Name,
			LocalizedName = data.Item.LocalizedName,
			Icon = data.Item.Icon,
			Value = data.Item.Value
		});
		data.Parent = null;
	}

	public void DropCanceled(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
	}

	public bool CanReceiveDrop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		return true;
	}

	public void Drop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		ListViewIcons component = ((Component)this).GetComponent<ListViewIcons>();
		component.DataSource.Add(data);
	}

	public void DropCanceled(ListViewIconsItemDescription data, PointerEventData eventData)
	{
	}
}
