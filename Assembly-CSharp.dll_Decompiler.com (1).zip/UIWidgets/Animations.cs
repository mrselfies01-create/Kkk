using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public static class Animations
{
	public static IEnumerator Rotate(RectTransform rectTransform, float time = 0.5f, float start_angle = 0f, float end_angle = 90f)
	{
		if ((Object)(object)rectTransform != (Object)null)
		{
			Quaternion rotation = ((Transform)rectTransform).rotation;
			Vector3 start_rotarion = ((Quaternion)(ref rotation)).eulerAngles;
			float end_time = Time.time + time;
			while (Time.time <= end_time)
			{
				float rotation_x = Mathf.Lerp(start_angle, end_angle, 1f - (end_time - Time.time) / time);
				((Transform)rectTransform).rotation = Quaternion.Euler(rotation_x, start_rotarion.y, start_rotarion.z);
				yield return null;
			}
			((Transform)rectTransform).rotation = Quaternion.Euler(start_rotarion);
		}
	}

	public static IEnumerator RotateZ(RectTransform rectTransform, float time = 0.5f, float start_angle = 0f, float end_angle = 90f)
	{
		if ((Object)(object)rectTransform != (Object)null)
		{
			Quaternion rotation = ((Transform)rectTransform).rotation;
			Vector3 start_rotarion = ((Quaternion)(ref rotation)).eulerAngles;
			float end_time = Time.time + time;
			while (Time.time <= end_time)
			{
				float rotation_z = Mathf.Lerp(start_angle, end_angle, 1f - (end_time - Time.time) / time);
				((Transform)rectTransform).rotation = Quaternion.Euler(start_rotarion.x, start_rotarion.y, rotation_z);
				yield return null;
			}
			((Transform)rectTransform).rotation = Quaternion.Euler(start_rotarion);
		}
	}

	public static IEnumerator Collapse(RectTransform rectTransform, float time = 0.5f, bool isHorizontal = false)
	{
		if (!((Object)(object)rectTransform != (Object)null))
		{
			yield break;
		}
		Rect rect = rectTransform.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		LayoutElement layoutElement = ((Component)rectTransform).GetComponent<LayoutElement>() ?? ((Component)rectTransform).gameObject.AddComponent<LayoutElement>();
		if (size.x == 0f || size.y == 0f)
		{
			size = new Vector2(layoutElement.preferredWidth, layoutElement.preferredHeight);
		}
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			if (isHorizontal)
			{
				float num = Mathf.Lerp(size.x, 0f, 1f - (end_time - Time.time) / time);
				rectTransform.SetSizeWithCurrentAnchors((Axis)0, num);
				layoutElement.preferredWidth = num;
			}
			else
			{
				float num2 = Mathf.Lerp(size.y, 0f, 1f - (end_time - Time.time) / time);
				rectTransform.SetSizeWithCurrentAnchors((Axis)1, num2);
				layoutElement.preferredHeight = num2;
			}
			yield return null;
		}
		if (isHorizontal)
		{
			rectTransform.SetSizeWithCurrentAnchors((Axis)0, size.x);
			layoutElement.preferredWidth = size.x;
		}
		else
		{
			rectTransform.SetSizeWithCurrentAnchors((Axis)1, size.y);
			layoutElement.preferredHeight = size.y;
		}
	}

	public static IEnumerator Open(RectTransform rectTransform, float time = 0.5f, bool isHorizontal = false)
	{
		if (!((Object)(object)rectTransform != (Object)null))
		{
			yield break;
		}
		Rect rect = rectTransform.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		LayoutElement layoutElement = ((Component)rectTransform).GetComponent<LayoutElement>() ?? ((Component)rectTransform).gameObject.AddComponent<LayoutElement>();
		if (size.x == 0f || size.y == 0f)
		{
			size = new Vector2(layoutElement.preferredWidth, layoutElement.preferredHeight);
		}
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			if (isHorizontal)
			{
				float num = Mathf.Lerp(0f, size.x, 1f - (end_time - Time.time) / time);
				rectTransform.SetSizeWithCurrentAnchors((Axis)0, num);
				layoutElement.preferredWidth = num;
			}
			else
			{
				float num2 = Mathf.Lerp(0f, size.y, 1f - (end_time - Time.time) / time);
				rectTransform.SetSizeWithCurrentAnchors((Axis)1, num2);
				layoutElement.preferredHeight = num2;
			}
			yield return null;
		}
		if (isHorizontal)
		{
			rectTransform.SetSizeWithCurrentAnchors((Axis)0, size.x);
			layoutElement.preferredWidth = size.x;
		}
		else
		{
			rectTransform.SetSizeWithCurrentAnchors((Axis)1, size.y);
			layoutElement.preferredHeight = size.y;
		}
	}
}
