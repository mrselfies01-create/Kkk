using System;
using System.Collections;
using System.Collections.Generic;

namespace UIWidgets;

public interface IObservableList<T> : IList<T>, IObservable, ICollectionChanged, ICollectionItemChanged, IDisposable, IEnumerable, ICollection<T>, IEnumerable<T>
{
	void BeginUpdate();

	void EndUpdate();
}
