using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(LayoutGroup))]
public class ResizableHeader : MonoBehaviour, IDropSupport<ResizableHeaderDragCell>
{
	[SerializeField]
	public ListViewBase List;

	[SerializeField]
	public bool AllowResize = true;

	[SerializeField]
	public bool AllowReorder = true;

	[NonSerialized]
	[HideInInspector]
	public bool ProcessCellReorder;

	[SerializeField]
	public bool OnDragUpdate = true;

	[SerializeField]
	public float ActiveRegion = 5f;

	[SerializeField]
	public Camera CurrentCamera;

	[SerializeField]
	public Texture2D CursorTexture;

	[SerializeField]
	public Vector2 CursorHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D AllowDropCursor;

	[SerializeField]
	public Vector2 AllowDropCursorHotSpot = new Vector2(4f, 2f);

	[SerializeField]
	public Texture2D DeniedDropCursor;

	[SerializeField]
	public Vector2 DeniedDropCursorHotSpot = new Vector2(4f, 2f);

	[SerializeField]
	public Texture2D DefaultCursorTexture;

	[SerializeField]
	public Vector2 DefaultCursorHotSpot;

	private RectTransform rectTransform;

	private Canvas canvas;

	private RectTransform canvasRect;

	private List<LayoutElement> childrenLayouts = new List<LayoutElement>();

	private List<RectTransform> children = new List<RectTransform>();

	private List<int> positions;

	private LayoutElement leftTarget;

	private LayoutElement rightTarget;

	private bool processDrag;

	private List<float> widths;

	private LayoutGroup layout;

	private bool inActiveRegion;

	private float widthLimit;

	private List<RaycastResult> raycastResults = new List<RaycastResult>();

	public RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	public bool InActiveRegion => inActiveRegion;

	private void Start()
	{
		layout = ((Component)this).GetComponent<LayoutGroup>();
		if ((Object)(object)layout != (Object)null)
		{
			Utilites.UpdateLayout(layout);
		}
		Init();
	}

	public void OnInitializePotentialDrag(PointerEventData eventData)
	{
	}

	public void Init()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Expected O, but got Unknown
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		ref RectTransform reference = ref canvasRect;
		Transform obj = Utilites.FindCanvas(((Component)this).transform);
		reference = (RectTransform)(object)((obj is RectTransform) ? obj : null);
		canvas = ((Component)canvasRect).GetComponent<Canvas>();
		children.Clear();
		childrenLayouts.Clear();
		int num = 0;
		foreach (Transform item2 in ((Component)this).transform)
		{
			Transform val = item2;
			LayoutElement item = ((Component)val).GetComponent<LayoutElement>() ?? ((Component)val).gameObject.AddComponent<LayoutElement>();
			children.Add((RectTransform)(object)((val is RectTransform) ? val : null));
			childrenLayouts.Add(item);
			ResizableHeaderDragCell resizableHeaderDragCell = ((Component)val).gameObject.AddComponent<ResizableHeaderDragCell>();
			resizableHeaderDragCell.Position = num;
			resizableHeaderDragCell.ResizableHeader = this;
			resizableHeaderDragCell.AllowDropCursor = AllowDropCursor;
			resizableHeaderDragCell.AllowDropCursorHotSpot = AllowDropCursorHotSpot;
			resizableHeaderDragCell.DeniedDropCursor = DeniedDropCursor;
			resizableHeaderDragCell.DeniedDropCursorHotSpot = DeniedDropCursorHotSpot;
			ResizableHeaderCell resizableHeaderCell = ((Component)val).gameObject.AddComponent<ResizableHeaderCell>();
			((UnityEvent<PointerEventData>)resizableHeaderCell.OnInitializePotentialDragEvent).AddListener((UnityAction<PointerEventData>)OnInitializePotentialDrag);
			((UnityEvent<PointerEventData>)resizableHeaderCell.OnBeginDragEvent).AddListener((UnityAction<PointerEventData>)OnBeginDrag);
			((UnityEvent<PointerEventData>)resizableHeaderCell.OnDragEvent).AddListener((UnityAction<PointerEventData>)OnDrag);
			((UnityEvent<PointerEventData>)resizableHeaderCell.OnEndDragEvent).AddListener((UnityAction<PointerEventData>)OnEndDrag);
			num++;
		}
		positions = Enumerable.Range(0, num).ToList();
		CalculateWidths();
	}

	private void LateUpdate()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (AllowResize && !processDrag && !ProcessCellReorder && !((Object)(object)CursorTexture == (Object)null) && Input.mousePresent)
		{
			inActiveRegion = CheckInActiveRegion(Vector2.op_Implicit(Input.mousePosition), CurrentCamera);
			if (inActiveRegion)
			{
				Cursor.SetCursor(CursorTexture, CursorHotSpot, Utilites.GetCursorMode());
			}
			else
			{
				Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
			}
		}
	}

	private bool CheckInActiveRegion(Vector2 position, Camera currentCamera)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		Vector2 val = default(Vector2);
		if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, position, currentCamera, ref val))
		{
			return false;
		}
		Rect rect = RectTransform.rect;
		if (!((Rect)(ref rect)).Contains(val))
		{
			return false;
		}
		val += new Vector2(((Rect)(ref rect)).width * RectTransform.pivot.x, 0f);
		int num = 0;
		foreach (RectTransform child in children)
		{
			if (num != 0)
			{
				flag = CheckLeft(child, val);
				if (flag)
				{
					break;
				}
			}
			if (num != children.Count - 1)
			{
				flag = CheckRight(child, val);
				if (flag)
				{
					break;
				}
			}
			num++;
		}
		return flag;
	}

	public virtual void OnBeginDrag(PointerEventData eventData)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		if (!AllowResize || ProcessCellReorder)
		{
			return;
		}
		processDrag = false;
		Vector2 val = default(Vector2);
		if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.pressPosition, eventData.pressEventCamera, ref val))
		{
			return;
		}
		Rect rect = RectTransform.rect;
		val += new Vector2(((Rect)(ref rect)).width * RectTransform.pivot.x, 0f);
		int num = 0;
		foreach (RectTransform child in children)
		{
			if (num != 0)
			{
				processDrag = CheckLeft(child, val);
				if (processDrag)
				{
					leftTarget = childrenLayouts[num - 1];
					rightTarget = childrenLayouts[num];
					Rect rect2 = children[num - 1].rect;
					float width = ((Rect)(ref rect2)).width;
					Rect rect3 = children[num].rect;
					widthLimit = width + ((Rect)(ref rect3)).width;
					break;
				}
			}
			if (num != children.Count - 1)
			{
				processDrag = CheckRight(child, val);
				if (processDrag)
				{
					leftTarget = childrenLayouts[num];
					rightTarget = childrenLayouts[num + 1];
					Rect rect4 = children[num].rect;
					float width2 = ((Rect)(ref rect4)).width;
					Rect rect5 = children[num + 1].rect;
					widthLimit = width2 + ((Rect)(ref rect5)).width;
					break;
				}
			}
			num++;
		}
	}

	private bool CheckLeft(RectTransform childRectTransform, Vector2 point)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = childRectTransform.rect;
		((Rect)(ref rect)).position = ((Rect)(ref rect)).position + new Vector2(childRectTransform.anchoredPosition.x, 0f);
		((Rect)(ref rect)).width = ActiveRegion;
		return ((Rect)(ref rect)).Contains(point);
	}

	private bool CheckRight(RectTransform childRectTransform, Vector2 point)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = childRectTransform.rect;
		((Rect)(ref rect)).position = ((Rect)(ref rect)).position + new Vector2(childRectTransform.anchoredPosition.x, 0f);
		((Rect)(ref rect)).position = new Vector2(((Rect)(ref rect)).position.x + ((Rect)(ref rect)).width - ActiveRegion - 1f, ((Rect)(ref rect)).position.y);
		((Rect)(ref rect)).width = ActiveRegion + 1f;
		return ((Rect)(ref rect)).Contains(point);
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (processDrag)
		{
			Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
			CalculateWidths();
			ResetChildren();
			if (!OnDragUpdate)
			{
				Resize();
			}
			processDrag = false;
		}
	}

	public void OnDrag(PointerEventData eventData)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (processDrag)
		{
			if ((Object)(object)canvas == (Object)null)
			{
				throw new MissingComponentException(((Object)((Component)this).gameObject).name + " not in Canvas hierarchy.");
			}
			Cursor.SetCursor(CursorTexture, CursorHotSpot, Utilites.GetCursorMode());
			Vector2 val = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position, CurrentCamera, ref val);
			Vector2 val2 = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position - eventData.delta, CurrentCamera, ref val2);
			Vector2 val3 = val - val2;
			if (val3.x > 0f)
			{
				leftTarget.preferredWidth = Mathf.Min(leftTarget.preferredWidth + val3.x, widthLimit - rightTarget.minWidth);
				rightTarget.preferredWidth = widthLimit - leftTarget.preferredWidth;
			}
			else
			{
				rightTarget.preferredWidth = Mathf.Min(rightTarget.preferredWidth - val3.x, widthLimit - leftTarget.minWidth);
				leftTarget.preferredWidth = widthLimit - rightTarget.preferredWidth;
			}
			if ((Object)(object)layout != (Object)null)
			{
				Utilites.UpdateLayout(layout);
			}
			if (OnDragUpdate)
			{
				CalculateWidths();
				Resize();
			}
		}
	}

	private float GetRectWidth(RectTransform rect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Rect rect2 = rect.rect;
		return ((Rect)(ref rect2)).width;
	}

	private void CalculateWidths()
	{
		widths = children.Select(GetRectWidth).ToList();
	}

	private void ResetChildren()
	{
		childrenLayouts.ForEach(ResetChildrenWidth);
	}

	private void ResetChildrenWidth(LayoutElement element, int index)
	{
		element.preferredWidth = widths[index];
	}

	public void Resize()
	{
		if (!((Object)(object)List == (Object)null) && widths.Count >= 2)
		{
			List.Start();
			List.ForEachComponent(ResizeComponent);
		}
	}

	private void Reorder()
	{
		if (!((Object)(object)List == (Object)null) && widths.Count >= 2)
		{
			List.Start();
			List.ForEachComponent(ReorderComponent);
		}
	}

	private void ResizeGameObject(GameObject go, int i)
	{
		LayoutElement component = go.GetComponent<LayoutElement>();
		int index = positions.IndexOf(i);
		if (Object.op_Implicit((Object)(object)component))
		{
			component.preferredWidth = widths[index];
			return;
		}
		Transform transform = go.transform;
		((RectTransform)((transform is RectTransform) ? transform : null)).SetSizeWithCurrentAnchors((Axis)0, widths[index]);
	}

	private void ResizeComponent(ListViewItem component)
	{
		if (component is IResizableItem resizableItem)
		{
			resizableItem.ObjectsToResize.ForEach(ResizeGameObject);
		}
	}

	private void ReorderComponent(ListViewItem component)
	{
		if (!(component is IResizableItem { ObjectsToResize: var objectsToResize }))
		{
			return;
		}
		int num = 0;
		foreach (int position in positions)
		{
			objectsToResize[position].transform.SetSiblingIndex(num);
			num++;
		}
	}

	public void Reorder(int oldColumnPosition, int newColumnPosition)
	{
		int num = positions.IndexOf(oldColumnPosition);
		int num2 = positions.IndexOf(newColumnPosition);
		((Transform)children[num]).SetSiblingIndex(num2);
		ChangePosition(childrenLayouts, num, num2);
		ChangePosition(children, num, num2);
		ChangePosition(positions, num, num2);
		Reorder();
	}

	public bool CanReceiveDrop(ResizableHeaderDragCell cell, PointerEventData eventData)
	{
		if (!AllowReorder)
		{
			return false;
		}
		ResizableHeaderDragCell resizableHeaderDragCell = FindTarget(eventData);
		return (Object)(object)resizableHeaderDragCell != (Object)null && (Object)(object)resizableHeaderDragCell != (Object)(object)cell;
	}

	public void Drop(ResizableHeaderDragCell cell, PointerEventData eventData)
	{
		ResizableHeaderDragCell resizableHeaderDragCell = FindTarget(eventData);
		Reorder(cell.Position, resizableHeaderDragCell.Position);
	}

	public void DropCanceled(ResizableHeaderDragCell cell, PointerEventData eventData)
	{
	}

	private void ChangePosition<T>(List<T> list, int oldPosition, int newPosition)
	{
		T item = list[oldPosition];
		list.RemoveAt(oldPosition);
		list.Insert(newPosition, item);
	}

	private ResizableHeaderDragCell FindTarget(PointerEventData eventData)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		raycastResults.Clear();
		EventSystem.current.RaycastAll(eventData, raycastResults);
		foreach (RaycastResult raycastResult in raycastResults)
		{
			RaycastResult current = raycastResult;
			if (((RaycastResult)(ref current)).isValid)
			{
				ResizableHeaderDragCell component = ((RaycastResult)(ref current)).gameObject.GetComponent<ResizableHeaderDragCell>();
				if ((Object)(object)component != (Object)null && ((Component)component).transform.IsChildOf(((Component)this).transform))
				{
					return component;
				}
			}
		}
		return null;
	}

	private void OnDestroy()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Expected O, but got Unknown
		children.Clear();
		childrenLayouts.Clear();
		foreach (Transform item in ((Component)this).transform)
		{
			Transform val = item;
			ResizableHeaderCell component = ((Component)val).GetComponent<ResizableHeaderCell>();
			if (!((Object)(object)component == (Object)null))
			{
				((UnityEvent<PointerEventData>)component.OnInitializePotentialDragEvent).RemoveListener((UnityAction<PointerEventData>)OnInitializePotentialDrag);
				((UnityEvent<PointerEventData>)component.OnBeginDragEvent).RemoveListener((UnityAction<PointerEventData>)OnBeginDrag);
				((UnityEvent<PointerEventData>)component.OnDragEvent).RemoveListener((UnityAction<PointerEventData>)OnDrag);
				((UnityEvent<PointerEventData>)component.OnEndDragEvent).RemoveListener((UnityAction<PointerEventData>)OnEndDrag);
			}
		}
	}
}
