using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/CenteredSlider", 300)]
public class CenteredSlider : CenteredSliderBase<int>
{
	protected override float ValueToPosition(int value)
	{
		value = InBounds(value);
		float num = RangeSize() / 2f;
		if (value == 0)
		{
			return num + GetStartPoint();
		}
		if (value > 0)
		{
			float num2 = num / (float)limitMax;
			return num2 * (float)value + GetStartPoint() + num;
		}
		float num3 = num / (float)limitMin;
		return num3 * (float)(limitMin - value) + GetStartPoint();
	}

	protected override int PositionToValue(float position)
	{
		float num = RangeSize() / 2f;
		if (position == num)
		{
			return 0;
		}
		float num2 = 0f;
		if (position > num)
		{
			float num3 = num / (float)limitMax;
			num2 = (position - num) / num3;
		}
		else
		{
			float num4 = num / (float)limitMin;
			num2 = (0f - position) / num4 + (float)base.LimitMin;
		}
		if (WholeNumberOfSteps)
		{
			return InBounds(Mathf.RoundToInt(num2 / (float)step) * step);
		}
		return InBounds(Mathf.RoundToInt(num2));
	}

	protected override Vector2 PositionLimits()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(ValueToPosition(base.LimitMin), ValueToPosition(base.LimitMax));
	}

	protected override int InBounds(int value)
	{
		return Mathf.Clamp(value, limitMin, limitMax);
	}

	protected override void Increase()
	{
		base.Value += step;
	}

	protected override void Decrease()
	{
		base.Value -= step;
	}

	protected override bool IsPositiveValue()
	{
		return base.Value > 0;
	}
}
