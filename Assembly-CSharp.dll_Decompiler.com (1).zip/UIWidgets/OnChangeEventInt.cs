using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class OnChangeEventInt : UnityEvent<int>
{
}
