using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class NodeToggleEvent : UnityEvent<int>
{
}
