namespace UIWidgets;

public interface ITemplatable
{
	bool IsTemplate { get; set; }

	string TemplateName { get; set; }
}
