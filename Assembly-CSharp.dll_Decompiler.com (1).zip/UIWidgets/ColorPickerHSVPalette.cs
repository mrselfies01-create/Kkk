using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerHSVPalette : MonoBehaviour
{
	[SerializeField]
	private Image palette;

	private RectTransform paletteRect;

	private OnDragListener dragListener;

	[SerializeField]
	private Shader paletteShader;

	[SerializeField]
	private RectTransform paletteCursor;

	[SerializeField]
	private Slider slider;

	[SerializeField]
	private Image sliderBackground;

	[SerializeField]
	private Shader sliderShader;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected bool inUpdateMode;

	protected ColorHSV currentColorHSV;

	public Image Palette
	{
		get
		{
			return palette;
		}
		set
		{
			SetPalette(value);
		}
	}

	public Shader PaletteShader
	{
		get
		{
			return paletteShader;
		}
		set
		{
			paletteShader = value;
			UpdateMaterial();
		}
	}

	public RectTransform PaletteCursor
	{
		get
		{
			return paletteCursor;
		}
		set
		{
			paletteCursor = value;
			if ((Object)(object)paletteCursor != (Object)null)
			{
				UpdateView();
			}
		}
	}

	public Slider Slider
	{
		get
		{
			return slider;
		}
		set
		{
			SetSlider(value);
		}
	}

	public Image SliderBackground
	{
		get
		{
			return sliderBackground;
		}
		set
		{
			sliderBackground = value;
			UpdateMaterial();
		}
	}

	public Shader SliderShader
	{
		get
		{
			return sliderShader;
		}
		set
		{
			sliderShader = value;
			UpdateMaterial();
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			SetPaletteMode(value);
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			Palette = palette;
			Slider = slider;
			SliderBackground = sliderBackground;
		}
	}

	protected virtual void OnEnable()
	{
		UpdateMaterial();
	}

	protected virtual void SetPalette(Image value)
	{
		if ((Object)(object)dragListener != (Object)null)
		{
			((UnityEvent<PointerEventData>)dragListener.OnDragEvent).RemoveListener((UnityAction<PointerEventData>)OnDrag);
		}
		palette = value;
		if ((Object)(object)palette != (Object)null)
		{
			ref RectTransform reference = ref paletteRect;
			Transform transform = ((Component)palette).transform;
			reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			dragListener = ((Component)palette).GetComponent<OnDragListener>() ?? ((Component)palette).gameObject.AddComponent<OnDragListener>();
			((UnityEvent<PointerEventData>)dragListener.OnDragEvent).AddListener((UnityAction<PointerEventData>)OnDrag);
			UpdateMaterial();
		}
		else
		{
			paletteRect = null;
		}
	}

	protected virtual void SetSlider(Slider value)
	{
		if ((Object)(object)slider != (Object)null)
		{
			((UnityEvent<float>)(object)slider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		slider = value;
		if ((Object)(object)slider != (Object)null)
		{
			((UnityEvent<float>)(object)slider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetPaletteMode(ColorPickerPaletteMode value)
	{
		paletteMode = value;
		bool flag = paletteMode == ColorPickerPaletteMode.Hue || paletteMode == ColorPickerPaletteMode.Saturation || paletteMode == ColorPickerPaletteMode.Value;
		((Component)this).gameObject.SetActive(flag);
		slider.maxValue = ((paletteMode != ColorPickerPaletteMode.Hue) ? 255 : 359);
		if (flag)
		{
			UpdateView();
		}
	}

	private void SliderValueChanged(float value)
	{
		ValueChanged();
	}

	protected virtual void ValueChanged()
	{
		if (!inUpdateMode)
		{
			currentColorHSV = GetColor();
			((UnityEvent<ColorHSV>)OnChangeHSV).Invoke(currentColorHSV);
		}
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColorHSV = new ColorHSV(Color32.op_Implicit(color));
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		currentColorHSV = color;
		UpdateView();
	}

	protected virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = paletteRect.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		Vector2 val = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(paletteRect, eventData.position, eventData.pressEventCamera, ref val);
		val.x = Mathf.Clamp(val.x, 0f, size.x);
		val.y = Mathf.Clamp(val.y, 0f - size.y, 0f);
		((Transform)paletteCursor).localPosition = Vector2.op_Implicit(val);
		ValueChanged();
	}

	protected ColorHSV GetColor()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Vector2 cursorCoords = GetCursorCoords();
		int num = Mathf.RoundToInt(slider.value);
		float x = cursorCoords.x;
		float y = cursorCoords.y;
		return paletteMode switch
		{
			ColorPickerPaletteMode.Hue => new ColorHSV(num, Mathf.RoundToInt(y * 255f), Mathf.RoundToInt(x * 255f), currentColorHSV.A), 
			ColorPickerPaletteMode.Saturation => new ColorHSV(Mathf.RoundToInt(x * 359f), num, Mathf.RoundToInt(y * 255f), currentColorHSV.A), 
			ColorPickerPaletteMode.Value => new ColorHSV(Mathf.RoundToInt(x * 359f), Mathf.RoundToInt(y * 255f), num, currentColorHSV.A), 
			_ => currentColorHSV, 
		};
	}

	protected Vector2 GetCursorCoords()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = ((Transform)paletteCursor).localPosition;
		Rect rect = paletteRect.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		float num = localPosition.x / size.x;
		float num2 = localPosition.y / size.y + 1f;
		return new Vector2(num, num2);
	}

	protected virtual void UpdateView()
	{
		UpdateViewReal();
	}

	protected virtual void UpdateViewReal()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		inUpdateMode = true;
		if ((Object)(object)slider != (Object)null)
		{
			slider.value = GetSliderValue();
		}
		if ((Object)(object)sliderBackground != (Object)null)
		{
			Color[] sliderColors = GetSliderColors();
			((Graphic)sliderBackground).material.SetColor("_ColorBottom", sliderColors[0]);
			((Graphic)sliderBackground).material.SetColor("_ColorTop", sliderColors[1]);
		}
		if ((Object)(object)paletteCursor != (Object)null && (Object)(object)palette != (Object)null && (Object)(object)paletteRect != (Object)null)
		{
			Vector2 paletteCoords = GetPaletteCoords();
			Rect rect = paletteRect.rect;
			Vector2 size = ((Rect)(ref rect)).size;
			((Transform)paletteCursor).localPosition = new Vector3(paletteCoords.x * size.x, (0f - (1f - paletteCoords.y)) * size.y, 0f);
		}
		if ((Object)(object)palette != (Object)null)
		{
			Color[] paletteColors = GetPaletteColors();
			((Graphic)palette).material.SetColor("_ColorLeft", paletteColors[0]);
			((Graphic)palette).material.SetColor("_ColorRight", paletteColors[1]);
			((Graphic)palette).material.SetColor("_ColorBottom", paletteColors[2]);
			((Graphic)palette).material.SetColor("_ColorTop", paletteColors[3]);
		}
		inUpdateMode = false;
	}

	protected int GetSliderValue()
	{
		return paletteMode switch
		{
			ColorPickerPaletteMode.Hue => currentColorHSV.H, 
			ColorPickerPaletteMode.Saturation => currentColorHSV.S, 
			ColorPickerPaletteMode.Value => currentColorHSV.V, 
			_ => 0, 
		};
	}

	protected Color[] GetSliderColors()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		return paletteMode switch
		{
			ColorPickerPaletteMode.Hue => (Color[])(object)new Color[2]
			{
				new Color(0f, 1f, 1f, 1f),
				new Color(1f, 1f, 1f, 1f)
			}, 
			ColorPickerPaletteMode.Saturation => (Color[])(object)new Color[2]
			{
				new Color((float)currentColorHSV.H / 359f, 0f, (float)Mathf.Max(80, currentColorHSV.V) / 255f, 1f),
				new Color((float)currentColorHSV.H / 359f, 1f, (float)Mathf.Max(80, currentColorHSV.V) / 255f, 1f)
			}, 
			ColorPickerPaletteMode.Value => (Color[])(object)new Color[2]
			{
				new Color((float)currentColorHSV.H / 359f, (float)currentColorHSV.S / 255f, 0f, 1f),
				new Color((float)currentColorHSV.H / 359f, (float)currentColorHSV.S / 255f, 1f, 1f)
			}, 
			_ => (Color[])(object)new Color[2]
			{
				new Color(0f, 0f, 0f, 1f),
				new Color(1f, 1f, 1f, 1f)
			}, 
		};
	}

	protected Vector2 GetPaletteCoords()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		return (Vector2)(paletteMode switch
		{
			ColorPickerPaletteMode.Hue => new Vector2((float)currentColorHSV.V / 255f, (float)currentColorHSV.S / 255f), 
			ColorPickerPaletteMode.Saturation => new Vector2((float)currentColorHSV.H / 359f, (float)currentColorHSV.V / 255f), 
			ColorPickerPaletteMode.Value => new Vector2((float)currentColorHSV.H / 359f, (float)currentColorHSV.S / 255f), 
			_ => new Vector2(0f, 0f), 
		});
	}

	protected Color[] GetPaletteColors()
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		return paletteMode switch
		{
			ColorPickerPaletteMode.Hue => (Color[])(object)new Color[4]
			{
				new Color((float)currentColorHSV.H / 359f / 2f, 0f, 0f, 1f),
				new Color((float)currentColorHSV.H / 359f / 2f, 1f, 0f, 1f),
				new Color((float)currentColorHSV.H / 359f / 2f, 0f, 0f, 1f),
				new Color((float)currentColorHSV.H / 359f / 2f, 0f, 1f, 1f)
			}, 
			ColorPickerPaletteMode.Saturation => (Color[])(object)new Color[4]
			{
				new Color(0f, (float)currentColorHSV.S / 255f / 2f, 0f, 1f),
				new Color(1f, (float)currentColorHSV.S / 255f / 2f, 0f, 1f),
				new Color(0f, (float)currentColorHSV.S / 255f / 2f, 0f, 1f),
				new Color(0f, (float)currentColorHSV.S / 255f / 2f, 1f, 1f)
			}, 
			ColorPickerPaletteMode.Value => (Color[])(object)new Color[4]
			{
				new Color(0f, 0f, (float)currentColorHSV.V / 255f / 2f, 1f),
				new Color(1f, 0f, (float)currentColorHSV.V / 255f / 2f, 1f),
				new Color(0f, 0f, (float)currentColorHSV.V / 255f / 2f, 1f),
				new Color(0f, 1f, (float)currentColorHSV.V / 255f / 2f, 1f)
			}, 
			_ => (Color[])(object)new Color[4]
			{
				new Color(0f, 0f, 1f, 1f),
				new Color(1f, 1f, 1f, 1f),
				new Color(0f, 0f, 1f, 1f),
				new Color(1f, 1f, 1f, 1f)
			}, 
		};
	}

	protected virtual void UpdateMaterial()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected O, but got Unknown
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Expected O, but got Unknown
		if ((Object)(object)paletteShader != (Object)null && (Object)(object)palette != (Object)null)
		{
			((Graphic)palette).material = new Material(paletteShader);
		}
		if ((Object)(object)sliderShader != (Object)null && (Object)(object)sliderBackground != (Object)null)
		{
			((Graphic)sliderBackground).material = new Material(sliderShader);
		}
		UpdateViewReal();
	}

	protected virtual void OnDestroy()
	{
		dragListener = null;
		slider = null;
	}
}
