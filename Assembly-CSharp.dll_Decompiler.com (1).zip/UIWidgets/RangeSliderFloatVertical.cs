using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/RangeSliderFloatVertical", 300)]
public class RangeSliderFloatVertical : RangeSliderFloat
{
	protected override bool IsHorizontal()
	{
		return false;
	}
}
