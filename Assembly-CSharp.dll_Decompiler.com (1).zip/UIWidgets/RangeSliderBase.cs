using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public abstract class RangeSliderBase<T> : MonoBehaviour, IPointerClickHandler, IEventSystemHandler where T : struct
{
	[Serializable]
	public class OnChangeEvent : UnityEvent<T, T>
	{
	}

	[SerializeField]
	protected T valueMin;

	[SerializeField]
	protected T valueMax;

	[SerializeField]
	protected T step;

	[SerializeField]
	protected T limitMin;

	[SerializeField]
	protected T limitMax;

	[SerializeField]
	protected RangeSliderHandle handleMin;

	protected RectTransform handleMinRect;

	[SerializeField]
	protected RangeSliderHandle handleMax;

	protected RectTransform handleMaxRect;

	[SerializeField]
	protected RectTransform UsableRangeRect;

	[SerializeField]
	protected RectTransform FillRect;

	protected RectTransform rangeSliderRect;

	public OnChangeEvent OnValuesChange = new OnChangeEvent();

	public UnityEvent OnChange = new UnityEvent();

	public bool WholeNumberOfSteps;

	private bool initCalled;

	public T ValueMin
	{
		get
		{
			return valueMin;
		}
		set
		{
			if (!EqualityComparer<T>.Default.Equals(valueMin, InBoundsMin(value)))
			{
				valueMin = InBoundsMin(value);
				UpdateMinHandle();
				UpdateFill();
				((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
				OnChange.Invoke();
			}
		}
	}

	public T ValueMax
	{
		get
		{
			return valueMax;
		}
		set
		{
			if (!EqualityComparer<T>.Default.Equals(valueMax, InBoundsMax(value)))
			{
				valueMax = InBoundsMax(value);
				UpdateMaxHandle();
				UpdateFill();
				((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
				OnChange.Invoke();
			}
		}
	}

	public T Step
	{
		get
		{
			return step;
		}
		set
		{
			step = value;
		}
	}

	public T LimitMin
	{
		get
		{
			return limitMin;
		}
		set
		{
			limitMin = value;
			ValueMin = valueMin;
			ValueMax = valueMax;
		}
	}

	public T LimitMax
	{
		get
		{
			return limitMax;
		}
		set
		{
			limitMax = value;
			ValueMin = valueMin;
			ValueMax = valueMax;
		}
	}

	public RectTransform HandleMinRect
	{
		get
		{
			if ((Object)(object)handleMin != (Object)null && (Object)(object)handleMinRect == (Object)null)
			{
				ref RectTransform reference = ref handleMinRect;
				Transform transform = ((Component)handleMin).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return handleMinRect;
		}
	}

	public RangeSliderHandle HandleMin
	{
		get
		{
			return handleMin;
		}
		set
		{
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			handleMin = value;
			handleMinRect = null;
			handleMin.IsHorizontal = IsHorizontal;
			handleMin.PositionLimits = MinPositionLimits;
			handleMin.PositionChanged = UpdateMinValue;
			handleMin.OnSubmit = SelectMaxHandle;
			handleMin.Increase = IncreaseMin;
			handleMin.Decrease = DecreaseMin;
			HandleMinRect.anchorMin = new Vector2(0f, 0f);
			HandleMinRect.anchorMax = ((!IsHorizontal()) ? new Vector2(1f, 0f) : new Vector2(0f, 1f));
		}
	}

	public RectTransform HandleMaxRect
	{
		get
		{
			if ((Object)(object)handleMax != (Object)null && (Object)(object)handleMaxRect == (Object)null)
			{
				ref RectTransform reference = ref handleMaxRect;
				Transform transform = ((Component)handleMax).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return handleMaxRect;
		}
	}

	public RangeSliderHandle HandleMax
	{
		get
		{
			return handleMax;
		}
		set
		{
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			handleMax = value;
			handleMaxRect = null;
			handleMax.IsHorizontal = IsHorizontal;
			handleMax.PositionLimits = MaxPositionLimits;
			handleMax.PositionChanged = UpdateMaxValue;
			handleMax.OnSubmit = SelectMinHandle;
			handleMax.Increase = IncreaseMax;
			handleMax.Decrease = DecreaseMax;
			HandleMaxRect.anchorMin = new Vector2(0f, 0f);
			HandleMaxRect.anchorMax = ((!IsHorizontal()) ? new Vector2(1f, 0f) : new Vector2(0f, 1f));
		}
	}

	public RectTransform RangeSliderRect
	{
		get
		{
			if ((Object)(object)rangeSliderRect == (Object)null)
			{
				ref RectTransform reference = ref rangeSliderRect;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rangeSliderRect;
		}
	}

	private void Awake()
	{
	}

	private void Init()
	{
		if (!initCalled)
		{
			initCalled = true;
			HandleMin = handleMin;
			HandleMax = handleMax;
			UpdateMinHandle();
			UpdateMaxHandle();
			UpdateFill();
		}
	}

	private void Start()
	{
		Init();
	}

	public void SetValue(T min, T max)
	{
		T x = valueMin;
		T x2 = valueMax;
		valueMin = min;
		valueMax = max;
		valueMin = InBoundsMin(valueMin);
		valueMax = InBoundsMax(valueMax);
		bool flag = EqualityComparer<T>.Default.Equals(x, valueMin);
		bool flag2 = EqualityComparer<T>.Default.Equals(x2, valueMax);
		if (!flag || !flag2)
		{
			UpdateMinHandle();
			UpdateMaxHandle();
			UpdateFill();
			((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
			OnChange.Invoke();
		}
	}

	public void SetLimit(T min, T max)
	{
		T x = valueMin;
		T x2 = valueMax;
		limitMin = min;
		limitMax = max;
		valueMin = InBoundsMin(valueMin);
		valueMax = InBoundsMax(valueMax);
		bool flag = EqualityComparer<T>.Default.Equals(x, valueMin);
		bool flag2 = EqualityComparer<T>.Default.Equals(x2, valueMax);
		if (!flag || !flag2)
		{
			UpdateMinHandle();
			UpdateMaxHandle();
			UpdateFill();
			((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
			OnChange.Invoke();
		}
	}

	protected virtual bool IsHorizontal()
	{
		return true;
	}

	protected float FillSize()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		float result;
		if (IsHorizontal())
		{
			Rect rect = UsableRangeRect.rect;
			result = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = UsableRangeRect.rect;
			result = ((Rect)(ref rect2)).height;
		}
		return result;
	}

	protected float MinHandleSize()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (IsHorizontal())
		{
			Rect rect = HandleMinRect.rect;
			return ((Rect)(ref rect)).width;
		}
		Rect rect2 = HandleMinRect.rect;
		return ((Rect)(ref rect2)).height;
	}

	protected float MaxHandleSize()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (IsHorizontal())
		{
			Rect rect = HandleMaxRect.rect;
			return ((Rect)(ref rect)).width;
		}
		Rect rect2 = HandleMaxRect.rect;
		return ((Rect)(ref rect2)).height;
	}

	protected void UpdateMinValue(float position)
	{
		valueMin = PositionToValue(position - GetStartPoint());
		UpdateMinHandle();
		UpdateFill();
		((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
		OnChange.Invoke();
	}

	protected void UpdateMaxValue(float position)
	{
		valueMax = PositionToValue(position - GetStartPoint());
		UpdateMaxHandle();
		UpdateFill();
		((UnityEvent<T, T>)OnValuesChange).Invoke(valueMin, valueMax);
		OnChange.Invoke();
	}

	protected abstract float ValueToPosition(T value);

	protected abstract T PositionToValue(float position);

	protected float GetStartPoint()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return (!IsHorizontal()) ? ((0f - UsableRangeRect.sizeDelta.y) / 2f) : ((0f - UsableRangeRect.sizeDelta.x) / 2f);
	}

	protected abstract Vector2 MinPositionLimits();

	protected abstract Vector2 MaxPositionLimits();

	protected abstract T InBounds(T value);

	protected abstract T InBoundsMin(T value);

	protected abstract T InBoundsMax(T value);

	protected abstract void IncreaseMin();

	protected abstract void DecreaseMin();

	protected abstract void IncreaseMax();

	protected abstract void DecreaseMax();

	protected void UpdateMinHandle()
	{
		UpdateHandle(HandleMinRect, valueMin);
	}

	protected void UpdateMaxHandle()
	{
		UpdateHandle(HandleMaxRect, valueMax);
	}

	private void UpdateFill()
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (IsHorizontal())
		{
			FillRect.anchoredPosition = new Vector2(HandleMinRect.anchoredPosition.x, FillRect.anchoredPosition.y);
			Vector2 sizeDelta = default(Vector2);
			((Vector2)(ref sizeDelta))._002Ector(HandleMaxRect.anchoredPosition.x - HandleMinRect.anchoredPosition.x, FillRect.sizeDelta.y);
			FillRect.sizeDelta = sizeDelta;
		}
		else
		{
			FillRect.anchoredPosition = new Vector2(FillRect.anchoredPosition.x, HandleMinRect.anchoredPosition.y);
			Vector2 sizeDelta2 = default(Vector2);
			((Vector2)(ref sizeDelta2))._002Ector(FillRect.sizeDelta.x, HandleMaxRect.anchoredPosition.y - HandleMinRect.anchoredPosition.y);
			FillRect.sizeDelta = sizeDelta2;
		}
	}

	protected void UpdateHandle(RectTransform handleTransform, T value)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 anchoredPosition = handleTransform.anchoredPosition;
		if (IsHorizontal())
		{
			float num = ValueToPosition(value);
			Rect rect = handleTransform.rect;
			anchoredPosition.x = num + ((Rect)(ref rect)).width * (handleTransform.pivot.x - 0.5f);
		}
		else
		{
			float num2 = ValueToPosition(value);
			Rect rect2 = handleTransform.rect;
			anchoredPosition.y = num2 + ((Rect)(ref rect2)).height * (handleTransform.pivot.y - 0.5f);
		}
		handleTransform.anchoredPosition = anchoredPosition;
	}

	private void SelectMinHandle()
	{
		if ((Object)(object)EventSystem.current != (Object)null && !EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)handleMin).gameObject);
		}
	}

	private void SelectMaxHandle()
	{
		if ((Object)(object)EventSystem.current != (Object)null && !EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)handleMax).gameObject);
		}
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		if (RectTransformUtility.ScreenPointToLocalPointInRectangle(UsableRangeRect, eventData.position, eventData.pressEventCamera, ref val))
		{
			Vector2 val2 = val;
			Rect rect = UsableRangeRect.rect;
			val = val2 - ((Rect)(ref rect)).position;
			float num = ((!IsHorizontal()) ? val.y : val.x) + GetStartPoint();
			float num2 = num - MaxHandleSize();
			float num3 = ((!IsHorizontal()) ? HandleMinRect.anchoredPosition.y : HandleMinRect.anchoredPosition.x);
			float num4 = ((!IsHorizontal()) ? HandleMaxRect.anchoredPosition.y : HandleMaxRect.anchoredPosition.x);
			float num5 = num - num3;
			float num6 = num4 - num2;
			if (num5 < num6)
			{
				UpdateMinValue(num);
			}
			else
			{
				UpdateMaxValue(num2);
			}
		}
	}
}
