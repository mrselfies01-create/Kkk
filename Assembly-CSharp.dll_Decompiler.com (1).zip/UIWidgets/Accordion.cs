using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/Accordion", 350)]
public class Accordion : MonoBehaviour
{
	[SerializeField]
	[FormerlySerializedAs("Items")]
	protected List<AccordionItem> items = new List<AccordionItem>();

	[SerializeField]
	public bool OnlyOneOpen = true;

	[SerializeField]
	public bool Animate = true;

	[SerializeField]
	public float AnimationDuration = 0.5f;

	[SerializeField]
	public AccordionDirection Direction = AccordionDirection.Vertical;

	[SerializeField]
	public AccordionEvent OnToggleItem = new AccordionEvent();

	protected List<UnityAction> callbacks = new List<UnityAction>();

	public List<AccordionItem> Items
	{
		get
		{
			return items;
		}
		protected set
		{
			if (items != null)
			{
				RemoveCallbacks();
			}
			items = value;
			if (items != null)
			{
				AddCallbacks();
			}
		}
	}

	protected virtual void Start()
	{
		AddCallbacks();
		UpdateLayout();
	}

	protected virtual void AddCallback(AccordionItem item)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		if (item.Open)
		{
			Open(item, animate: false);
		}
		else
		{
			Close(item, animate: false);
		}
		UnityAction val = (UnityAction)delegate
		{
			ToggleItem(item);
		};
		item.ToggleObject.AddComponent<AccordionItemComponent>().OnClick.AddListener(val);
		ref RectTransform contentObjectRect = ref item.ContentObjectRect;
		Transform transform = item.ContentObject.transform;
		contentObjectRect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		item.ContentLayoutElement = item.ContentObject.GetComponent<LayoutElement>() ?? item.ContentObject.AddComponent<LayoutElement>();
		AccordionItem accordionItem = item;
		Rect rect = item.ContentObjectRect.rect;
		accordionItem.ContentObjectHeight = ((Rect)(ref rect)).height;
		if (item.ContentObjectHeight == 0f)
		{
			item.ContentObjectHeight = item.ContentLayoutElement.preferredHeight;
		}
		AccordionItem accordionItem2 = item;
		Rect rect2 = item.ContentObjectRect.rect;
		accordionItem2.ContentObjectWidth = ((Rect)(ref rect2)).width;
		if (item.ContentObjectWidth == 0f)
		{
			item.ContentObjectWidth = item.ContentLayoutElement.preferredWidth;
		}
		callbacks.Add(val);
	}

	protected virtual void AddCallbacks()
	{
		Items.ForEach(AddCallback);
	}

	protected virtual void RemoveCallback(AccordionItem item, int index)
	{
		if (item != null && !((Object)(object)item.ToggleObject == (Object)null))
		{
			AccordionItemComponent component = item.ToggleObject.GetComponent<AccordionItemComponent>();
			if ((Object)(object)component != (Object)null && index < callbacks.Count)
			{
				component.OnClick.RemoveListener(callbacks[index]);
			}
		}
	}

	protected virtual void RemoveCallbacks()
	{
		Items.ForEach(RemoveCallback);
		callbacks.Clear();
	}

	protected virtual void OnDestroy()
	{
		RemoveCallbacks();
	}

	public virtual void ToggleItem(AccordionItem item)
	{
		if (item.Open)
		{
			if (!OnlyOneOpen)
			{
				Close(item);
			}
			return;
		}
		if (OnlyOneOpen)
		{
			Items.Where(IsOpen).ForEach(Close);
		}
		Open(item);
	}

	public virtual void Open(AccordionItem item)
	{
		if (!item.Open)
		{
			if (OnlyOneOpen)
			{
				Items.Where(IsOpen).ForEach(Close);
			}
			Open(item, Animate);
		}
	}

	public virtual void Close(AccordionItem item)
	{
		if (item.Open)
		{
			Close(item, Animate);
		}
	}

	protected bool IsOpen(AccordionItem item)
	{
		return item.Open;
	}

	protected bool IsHorizontal()
	{
		return Direction == AccordionDirection.Horizontal;
	}

	protected virtual void Open(AccordionItem item, bool animate)
	{
		if (item.CurrentCorutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(item.CurrentCorutine);
			if (IsHorizontal())
			{
				item.ContentObjectRect.SetSizeWithCurrentAnchors((Axis)0, item.ContentObjectWidth);
				item.ContentLayoutElement.preferredWidth = item.ContentObjectWidth;
			}
			else
			{
				item.ContentObjectRect.SetSizeWithCurrentAnchors((Axis)1, item.ContentObjectHeight);
				item.ContentLayoutElement.preferredHeight = item.ContentObjectHeight;
			}
			item.ContentObject.SetActive(false);
		}
		if (animate)
		{
			item.CurrentCorutine = ((MonoBehaviour)this).StartCoroutine(OpenCorutine(item));
		}
		else
		{
			item.ContentObject.SetActive(true);
			((UnityEvent<AccordionItem>)OnToggleItem).Invoke(item);
		}
		item.ContentObject.SetActive(true);
		item.Open = true;
	}

	protected virtual void Close(AccordionItem item, bool animate)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		if (item.CurrentCorutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(item.CurrentCorutine);
			item.ContentObject.SetActive(true);
			if (IsHorizontal())
			{
				item.ContentObjectRect.SetSizeWithCurrentAnchors((Axis)0, item.ContentObjectWidth);
				item.ContentLayoutElement.preferredWidth = item.ContentObjectWidth;
			}
			else
			{
				item.ContentObjectRect.SetSizeWithCurrentAnchors((Axis)1, item.ContentObjectHeight);
				item.ContentLayoutElement.preferredHeight = item.ContentObjectHeight;
			}
		}
		if ((Object)(object)item.ContentObjectRect != (Object)null)
		{
			Rect rect = item.ContentObjectRect.rect;
			item.ContentObjectHeight = ((Rect)(ref rect)).height;
			Rect rect2 = item.ContentObjectRect.rect;
			item.ContentObjectWidth = ((Rect)(ref rect2)).width;
		}
		if (animate)
		{
			item.CurrentCorutine = ((MonoBehaviour)this).StartCoroutine(HideCorutine(item));
			return;
		}
		item.ContentObject.SetActive(false);
		item.Open = false;
		((UnityEvent<AccordionItem>)OnToggleItem).Invoke(item);
	}

	protected virtual IEnumerator OpenCorutine(AccordionItem item)
	{
		item.ContentObject.SetActive(true);
		item.Open = true;
		yield return ((MonoBehaviour)this).StartCoroutine(Animations.Open(item.ContentObjectRect, AnimationDuration, IsHorizontal()));
		UpdateLayout();
		((UnityEvent<AccordionItem>)OnToggleItem).Invoke(item);
	}

	protected void UpdateLayout()
	{
		Utilites.UpdateLayout(((Component)this).GetComponent<LayoutGroup>());
	}

	protected virtual IEnumerator HideCorutine(AccordionItem item)
	{
		yield return ((MonoBehaviour)this).StartCoroutine(Animations.Collapse(item.ContentObjectRect, AnimationDuration, IsHorizontal()));
		item.Open = false;
		item.ContentObject.SetActive(false);
		UpdateLayout();
		((UnityEvent<AccordionItem>)OnToggleItem).Invoke(item);
	}
}
