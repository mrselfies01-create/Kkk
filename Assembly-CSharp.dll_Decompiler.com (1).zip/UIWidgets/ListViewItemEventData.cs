using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

public class ListViewItemEventData : BaseEventData
{
	public GameObject NewSelectedObject;

	public ListViewItemEventData(EventSystem eventSystem)
		: base(eventSystem)
	{
	}
}
