using UnityEngine;

namespace UIWidgets;

public interface IResizableItem
{
	GameObject[] ObjectsToResize { get; }
}
