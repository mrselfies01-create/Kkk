using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ColorAlphaChangedEvent : UnityEvent<byte>
{
}
