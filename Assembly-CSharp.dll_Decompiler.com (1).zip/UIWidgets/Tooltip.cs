using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[AddComponentMenu("UI/Tooltip", 300)]
[RequireComponent(typeof(RectTransform))]
public class Tooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler, IEventSystemHandler
{
	[SerializeField]
	private GameObject tooltipObject;

	[SerializeField]
	public float ShowDelay = 0.3f;

	private Vector2 anchoredPosition;

	private Transform canvasTransform;

	private Transform tooltipObjectParent;

	private IEnumerator currentCorutine;

	public GameObject TooltipObject
	{
		get
		{
			return tooltipObject;
		}
		set
		{
			tooltipObject = value;
			if ((Object)(object)tooltipObject != (Object)null)
			{
				tooltipObjectParent = tooltipObject.transform.parent;
			}
		}
	}

	private void Start()
	{
		TooltipObject = tooltipObject;
		if ((Object)(object)TooltipObject != (Object)null)
		{
			canvasTransform = Utilites.FindCanvas(tooltipObjectParent);
			TooltipObject.SetActive(false);
		}
	}

	private IEnumerator ShowCorutine()
	{
		yield return (object)new WaitForSeconds(ShowDelay);
		if ((Object)(object)canvasTransform != (Object)null)
		{
			ref Vector2 reference = ref anchoredPosition;
			Transform transform = TooltipObject.transform;
			reference = ((RectTransform)((transform is RectTransform) ? transform : null)).anchoredPosition;
			tooltipObjectParent = tooltipObject.transform.parent;
			TooltipObject.transform.SetParent(canvasTransform);
		}
		TooltipObject.SetActive(true);
	}

	public void Show()
	{
		if (!((Object)(object)TooltipObject == (Object)null))
		{
			currentCorutine = ShowCorutine();
			((MonoBehaviour)this).StartCoroutine(currentCorutine);
		}
	}

	private IEnumerator HideCoroutine()
	{
		if (currentCorutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(currentCorutine);
		}
		if ((Object)(object)TooltipObject != (Object)null)
		{
			TooltipObject.SetActive(false);
			yield return null;
			if ((Object)(object)canvasTransform != (Object)null)
			{
				TooltipObject.transform.SetParent(tooltipObjectParent);
				Transform transform = TooltipObject.transform;
				((RectTransform)((transform is RectTransform) ? transform : null)).anchoredPosition = anchoredPosition;
			}
		}
	}

	public void Hide()
	{
		((MonoBehaviour)this).StartCoroutine(HideCoroutine());
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		Show();
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		Hide();
	}

	public void OnSelect(BaseEventData eventData)
	{
		Show();
	}

	public void OnDeselect(BaseEventData eventData)
	{
		Hide();
	}
}
