using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

public class DraggableHandle : MonoBehaviour, IDragHandler, IInitializePotentialDragHandler, IEventSystemHandler
{
	private RectTransform drag;

	private Canvas canvas;

	private RectTransform canvasRect;

	public void Drag(RectTransform newDrag)
	{
		drag = newDrag;
	}

	public virtual void OnInitializePotentialDrag(PointerEventData eventData)
	{
		ref RectTransform reference = ref canvasRect;
		Transform obj = Utilites.FindCanvas(((Component)this).transform);
		reference = (RectTransform)(object)((obj is RectTransform) ? obj : null);
		canvas = ((Component)canvasRect).GetComponent<Canvas>();
	}

	public virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)canvas == (Object)null)
		{
			throw new MissingComponentException(((Object)((Component)this).gameObject).name + " not in Canvas hierarchy.");
		}
		Vector2 val = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(drag, eventData.position, eventData.pressEventCamera, ref val);
		Vector2 val2 = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(drag, eventData.position - eventData.delta, eventData.pressEventCamera, ref val2);
		Vector3 localPosition = default(Vector3);
		((Vector3)(ref localPosition))._002Ector(((Transform)drag).localPosition.x + (val.x - val2.x), ((Transform)drag).localPosition.y + (val.y - val2.y), ((Transform)drag).localPosition.z);
		((Transform)drag).localPosition = localPosition;
	}
}
