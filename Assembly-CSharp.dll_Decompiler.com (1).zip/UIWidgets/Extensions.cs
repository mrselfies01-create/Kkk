using System;
using System.Collections.Generic;

namespace UIWidgets;

public static class Extensions
{
	public static void ForEach<T>(this IEnumerable<T> enumerable, Action<T, int> handler)
	{
		int num = 0;
		foreach (T item in enumerable)
		{
			handler(item, num);
			num++;
		}
	}

	public static void ForEach<T>(this IEnumerable<T> enumerable, Action<T> handler)
	{
		foreach (T item in enumerable)
		{
			handler(item);
		}
	}

	public static ObservableList<T> ToObservableList<T>(this IEnumerable<T> enumerable, bool observeItems = true)
	{
		return new ObservableList<T>(enumerable, observeItems);
	}

	public static float SumFloat<T>(this IList<T> list, Func<T, float> calculate)
	{
		float num = 0f;
		for (int i = 0; i < list.Count; i++)
		{
			num += calculate(list[i]);
		}
		return num;
	}

	public static float SumFloat<T>(this ObservableList<T> list, Func<T, float> calculate)
	{
		float num = 0f;
		for (int i = 0; i < list.Count; i++)
		{
			num += calculate(list[i]);
		}
		return num;
	}

	public static List<TOutput> Convert<TInput, TOutput>(this List<TInput> input, Converter<TInput, TOutput> converter)
	{
		return input.ConvertAll(converter);
	}
}
