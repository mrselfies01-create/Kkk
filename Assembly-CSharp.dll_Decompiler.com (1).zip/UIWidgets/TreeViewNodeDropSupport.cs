using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[RequireComponent(typeof(TreeViewComponent))]
public class TreeViewNodeDropSupport : MonoBehaviour, IDropSupport<TreeNode<TreeViewItem>>, IDropSupport<ListViewIconsItemDescription>
{
	private TreeViewComponent source;

	public TreeViewComponent Source
	{
		get
		{
			if ((Object)(object)source == (Object)null)
			{
				source = ((Component)this).GetComponent<TreeViewComponent>();
			}
			return source;
		}
	}

	public bool CanReceiveDrop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		return data.CanBeParent(Source.Node);
	}

	public void Drop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		data.Parent = Source.Node;
	}

	public void DropCanceled(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
	}

	public bool CanReceiveDrop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		return true;
	}

	public void Drop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		TreeNode<TreeViewItem> node = Source.Node;
		if (node.Nodes == null)
		{
			node.Nodes = new ObservableList<TreeNode<TreeViewItem>>();
		}
		TreeViewItem treeViewItem = new TreeViewItem(data.Name);
		treeViewItem.LocalizedName = data.LocalizedName;
		treeViewItem.Icon = data.Icon;
		treeViewItem.Value = data.Value;
		TreeViewItem nodeItem = treeViewItem;
		TreeNode<TreeViewItem> item = new TreeNode<TreeViewItem>(nodeItem);
		node.Nodes.Add(item);
	}

	public void DropCanceled(ListViewIconsItemDescription data, PointerEventData eventData)
	{
	}
}
