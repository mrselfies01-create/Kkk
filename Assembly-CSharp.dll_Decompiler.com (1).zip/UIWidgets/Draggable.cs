using UnityEngine;

namespace UIWidgets;

[RequireComponent(typeof(RectTransform))]
public class Draggable : MonoBehaviour
{
	[SerializeField]
	private GameObject handle;

	private DraggableHandle handleScript;

	public GameObject Handle
	{
		get
		{
			return handle;
		}
		set
		{
			SetHandle(value);
		}
	}

	private void Start()
	{
		SetHandle(handle ?? ((Component)this).gameObject);
	}

	protected virtual void SetHandle(GameObject value)
	{
		if (Object.op_Implicit((Object)(object)handle))
		{
			Object.Destroy((Object)(object)handleScript);
		}
		handle = value;
		handleScript = handle.AddComponent<DraggableHandle>();
		DraggableHandle draggableHandle = handleScript;
		Transform transform = ((Component)this).gameObject.transform;
		draggableHandle.Drag((RectTransform)(object)((transform is RectTransform) ? transform : null));
	}
}
