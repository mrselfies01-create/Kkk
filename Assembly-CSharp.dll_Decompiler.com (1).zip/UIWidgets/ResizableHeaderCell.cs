using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class ResizableHeaderCell : MonoBehaviour, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	public PointerUnityEvent OnInitializePotentialDragEvent = new PointerUnityEvent();

	public PointerUnityEvent OnBeginDragEvent = new PointerUnityEvent();

	public PointerUnityEvent OnDragEvent = new PointerUnityEvent();

	public PointerUnityEvent OnEndDragEvent = new PointerUnityEvent();

	public void OnInitializePotentialDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)OnInitializePotentialDragEvent).Invoke(eventData);
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)OnBeginDragEvent).Invoke(eventData);
	}

	public void OnDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)OnDragEvent).Invoke(eventData);
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)OnEndDragEvent).Invoke(eventData);
	}
}
