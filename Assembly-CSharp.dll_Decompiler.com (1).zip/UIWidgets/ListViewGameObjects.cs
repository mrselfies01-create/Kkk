using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

[AddComponentMenu("UI/ListViewGameObjects", 255)]
public class ListViewGameObjects : ListViewBase
{
	[SerializeField]
	private List<GameObject> objects = new List<GameObject>();

	private List<UnityAction<PointerEventData>> callbacksEnter = new List<UnityAction<PointerEventData>>();

	private List<UnityAction<PointerEventData>> callbacksExit = new List<UnityAction<PointerEventData>>();

	public Func<IEnumerable<GameObject>, IEnumerable<GameObject>> SortFunc;

	public ListViewGameObjectsEvent OnSelectObject = new ListViewGameObjectsEvent();

	public ListViewGameObjectsEvent OnDeselectObject = new ListViewGameObjectsEvent();

	public ListViewGameObjectsEvent OnPointerEnterObject = new ListViewGameObjectsEvent();

	public ListViewGameObjectsEvent OnPointerExitObject = new ListViewGameObjectsEvent();

	[NonSerialized]
	private bool isStartedListViewGameObjects;

	public List<GameObject> Objects
	{
		get
		{
			return new List<GameObject>(objects);
		}
		private set
		{
			UpdateItems(value);
		}
	}

	private void Awake()
	{
		Start();
	}

	public override void Start()
	{
		if (!isStartedListViewGameObjects)
		{
			isStartedListViewGameObjects = true;
			base.Start();
			DestroyGameObjects = true;
			UpdateItems();
			((UnityEvent<int, ListViewItem>)OnSelect).AddListener((UnityAction<int, ListViewItem>)OnSelectCallback);
			((UnityEvent<int, ListViewItem>)OnDeselect).AddListener((UnityAction<int, ListViewItem>)OnDeselectCallback);
		}
	}

	private void OnSelectCallback(int index, ListViewItem item)
	{
		((UnityEvent<int, GameObject>)OnSelectObject).Invoke(index, objects[index]);
	}

	private void OnDeselectCallback(int index, ListViewItem item)
	{
		((UnityEvent<int, GameObject>)OnDeselectObject).Invoke(index, objects[index]);
	}

	private void OnPointerEnterCallback(int index)
	{
		((UnityEvent<int, GameObject>)OnPointerEnterObject).Invoke(index, objects[index]);
	}

	private void OnPointerExitCallback(int index)
	{
		((UnityEvent<int, GameObject>)OnPointerExitObject).Invoke(index, objects[index]);
	}

	public override void UpdateItems()
	{
		UpdateItems(objects);
	}

	public virtual int Add(GameObject item)
	{
		List<GameObject> list = Objects;
		list.Add(item);
		UpdateItems(list);
		return objects.IndexOf(item);
	}

	public virtual int Remove(GameObject item)
	{
		int num = objects.IndexOf(item);
		if (num == -1)
		{
			return num;
		}
		List<GameObject> list = Objects;
		list.Remove(item);
		UpdateItems(list);
		return num;
	}

	private void RemoveCallback(ListViewItem item, int index)
	{
		if (!((Object)(object)item == (Object)null))
		{
			if (index < callbacksEnter.Count)
			{
				((UnityEvent<PointerEventData>)item.onPointerEnter).RemoveListener(callbacksEnter[index]);
			}
			if (index < callbacksExit.Count)
			{
				((UnityEvent<PointerEventData>)item.onPointerExit).RemoveListener(callbacksExit[index]);
			}
		}
	}

	private void RemoveCallbacks()
	{
		base.Items.ForEach(RemoveCallback);
		callbacksEnter.Clear();
		callbacksExit.Clear();
	}

	private void AddCallbacks()
	{
		base.Items.ForEach(AddCallback);
	}

	private void AddCallback(ListViewItem item, int index)
	{
		callbacksEnter.Add(delegate
		{
			OnPointerEnterCallback(index);
		});
		callbacksExit.Add(delegate
		{
			OnPointerExitCallback(index);
		});
		((UnityEvent<PointerEventData>)item.onPointerEnter).AddListener(callbacksEnter[index]);
		((UnityEvent<PointerEventData>)item.onPointerExit).AddListener(callbacksExit[index]);
	}

	private List<GameObject> SortItems(IEnumerable<GameObject> newItems)
	{
		IEnumerable<GameObject> enumerable = newItems;
		if (SortFunc != null)
		{
			enumerable = SortFunc(enumerable);
		}
		return enumerable.ToList();
	}

	public override void Clear()
	{
		if (DestroyGameObjects)
		{
			objects.ForEach((Action<GameObject>)Object.Destroy);
		}
		UpdateItems(new List<GameObject>());
	}

	private void UpdateItems(List<GameObject> newItems)
	{
		RemoveCallbacks();
		newItems = SortItems(newItems);
		List<int> second = (from x in base.SelectedIndicies
			select (objects.Count <= x) ? (-1) : newItems.IndexOf(objects[x]) into x
			where x != -1
			select x).ToList();
		base.SelectedIndicies.Except(second).ForEach(base.Deselect);
		objects = newItems;
		base.Items = newItems.Convert((GameObject x) => x.GetComponent<ListViewItem>() ?? x.AddComponent<ListViewItem>());
		base.SelectedIndicies = second;
		AddCallbacks();
	}

	protected override void OnDestroy()
	{
		((UnityEvent<int, ListViewItem>)OnSelect).RemoveListener((UnityAction<int, ListViewItem>)OnSelectCallback);
		((UnityEvent<int, ListViewItem>)OnDeselect).RemoveListener((UnityAction<int, ListViewItem>)OnDeselectCallback);
		RemoveCallbacks();
		base.OnDestroy();
	}
}
