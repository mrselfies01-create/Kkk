using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public abstract class ListViewBase : MonoBehaviour, ISelectHandler, IDeselectHandler, ISubmitHandler, ICancelHandler, IEventSystemHandler
{
	[SerializeField]
	[HideInInspector]
	private List<ListViewItem> items = new List<ListViewItem>();

	private List<UnityAction> callbacks = new List<UnityAction>();

	[SerializeField]
	[HideInInspector]
	public bool DestroyGameObjects = true;

	[SerializeField]
	public bool Multiple;

	[SerializeField]
	private int selectedIndex = -1;

	[SerializeField]
	private List<int> selectedIndicies = new List<int>();

	public ListViewBaseEvent OnSelect = new ListViewBaseEvent();

	public ListViewBaseEvent OnDeselect = new ListViewBaseEvent();

	public UnityEvent onSubmit = new UnityEvent();

	public UnityEvent onCancel = new UnityEvent();

	public UnityEvent onItemSelect = new UnityEvent();

	public UnityEvent onItemCancel = new UnityEvent();

	[SerializeField]
	public Transform Container;

	public ListViewFocusEvent OnFocusIn = new ListViewFocusEvent();

	public ListViewFocusEvent OnFocusOut = new ListViewFocusEvent();

	[NonSerialized]
	protected bool SetItemIndicies = true;

	private GameObject Unused;

	[NonSerialized]
	private bool isStartedListViewBase;

	public List<ListViewItem> Items
	{
		get
		{
			return new List<ListViewItem>(items);
		}
		set
		{
			UpdateItems(value);
		}
	}

	public int SelectedIndex
	{
		get
		{
			return selectedIndex;
		}
		set
		{
			if (value == -1)
			{
				if (selectedIndex != -1)
				{
					Deselect(selectedIndex);
				}
				selectedIndex = value;
			}
			else
			{
				Select(value);
			}
		}
	}

	public List<int> SelectedIndicies
	{
		get
		{
			return new List<int>(selectedIndicies);
		}
		set
		{
			IEnumerable<int> enumerable = selectedIndicies.Except(value);
			IEnumerable<int> enumerable2 = value.Except(selectedIndicies);
			enumerable.ForEach(Deselect);
			enumerable2.ForEach(Select);
		}
	}

	private void Awake()
	{
		Start();
	}

	public virtual void Start()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		if (!isStartedListViewBase)
		{
			isStartedListViewBase = true;
			Unused = new GameObject("unused base");
			Unused.SetActive(false);
			Unused.transform.SetParent(((Component)this).transform, false);
			if (selectedIndex != -1 && selectedIndicies.Count == 0)
			{
				selectedIndicies.Add(selectedIndex);
			}
			selectedIndicies.RemoveAll(NotIsValid);
			if (selectedIndicies.Count == 0)
			{
				selectedIndex = -1;
			}
		}
	}

	protected bool NotIsValid(int index)
	{
		return !IsValid(index);
	}

	public virtual void UpdateItems()
	{
		UpdateItems(items);
	}

	private void RemoveCallback(ListViewItem item, int index)
	{
		if (!((Object)(object)item == (Object)null))
		{
			if (index < callbacks.Count)
			{
				item.onClick.RemoveListener(callbacks[index]);
			}
			((UnityEvent<ListViewItem>)item.onSubmit).RemoveListener((UnityAction<ListViewItem>)Toggle);
			((UnityEvent<ListViewItem>)item.onCancel).RemoveListener((UnityAction<ListViewItem>)OnItemCancel);
			((UnityEvent<ListViewItem>)item.onSelect).RemoveListener((UnityAction<ListViewItem>)HighlightColoring);
			((UnityEvent<ListViewItem>)item.onDeselect).RemoveListener((UnityAction<ListViewItem>)Coloring);
			((UnityEvent<AxisEventData, ListViewItem>)item.onMove).RemoveListener((UnityAction<AxisEventData, ListViewItem>)OnItemMove);
		}
	}

	private void OnItemCancel(ListViewItem item)
	{
		if (!EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)this).gameObject);
			onItemCancel.Invoke();
		}
	}

	private void RemoveCallbacks()
	{
		if (callbacks.Count > 0)
		{
			items.ForEach(RemoveCallback);
		}
		callbacks.Clear();
	}

	private void AddCallbacks()
	{
		items.ForEach(AddCallback);
	}

	private void AddCallback(ListViewItem item, int index)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected O, but got Unknown
		callbacks.Insert(index, (UnityAction)delegate
		{
			Toggle(item);
		});
		item.onClick.AddListener(callbacks[index]);
		((UnityEvent<ListViewItem>)item.onSubmit).AddListener((UnityAction<ListViewItem>)OnItemSubmit);
		((UnityEvent<ListViewItem>)item.onCancel).AddListener((UnityAction<ListViewItem>)OnItemCancel);
		((UnityEvent<ListViewItem>)item.onSelect).AddListener((UnityAction<ListViewItem>)HighlightColoring);
		((UnityEvent<ListViewItem>)item.onDeselect).AddListener((UnityAction<ListViewItem>)Coloring);
		((UnityEvent<AxisEventData, ListViewItem>)item.onMove).AddListener((UnityAction<AxisEventData, ListViewItem>)OnItemMove);
	}

	private void OnItemSelect(ListViewItem item)
	{
		onItemSelect.Invoke();
	}

	private void OnItemSubmit(ListViewItem item)
	{
		Toggle(item);
		if (!IsSelected(item.Index))
		{
			HighlightColoring(item);
		}
	}

	protected virtual void OnItemMove(AxisEventData eventData, ListViewItem item)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected I4, but got Unknown
		MoveDirection moveDir = eventData.moveDir;
		switch ((int)moveDir)
		{
		case 0:
			break;
		case 2:
			break;
		case 1:
			if (item.Index > 0)
			{
				SelectComponentByIndex(item.Index - 1);
			}
			break;
		case 3:
			if (IsValid(item.Index + 1))
			{
				SelectComponentByIndex(item.Index + 1);
			}
			break;
		}
	}

	protected virtual void ScrollTo(int index)
	{
	}

	public virtual int Add(ListViewItem item)
	{
		((Component)item).transform.SetParent(Container, false);
		AddCallback(item, items.Count);
		items.Add(item);
		item.Index = callbacks.Count - 1;
		return callbacks.Count - 1;
	}

	public virtual void Clear()
	{
		items.Clear();
		UpdateItems();
	}

	protected virtual int Remove(ListViewItem item)
	{
		RemoveCallbacks();
		int index = item.Index;
		selectedIndicies = (from x in selectedIndicies
			where x != index
			select (x <= index) ? x : x--).ToList();
		if (selectedIndex == index)
		{
			Deselect(index);
			selectedIndex = ((selectedIndicies.Count <= 0) ? (-1) : selectedIndicies.Last());
		}
		else if (selectedIndex > index)
		{
			selectedIndex--;
		}
		items.Remove(item);
		Free((Component)(object)item);
		AddCallbacks();
		return index;
	}

	private void Free(Component item)
	{
		if ((Object)(object)item == (Object)null)
		{
			return;
		}
		if (DestroyGameObjects)
		{
			if (!((Object)(object)item.gameObject == (Object)null))
			{
				Object.Destroy((Object)(object)item.gameObject);
			}
		}
		else if (!((Object)(object)item.transform == (Object)null) && !((Object)(object)Unused == (Object)null) && !((Object)(object)Unused.transform == (Object)null))
		{
			item.transform.SetParent(Unused.transform, false);
		}
	}

	private void UpdateItems(List<ListViewItem> newItems)
	{
		RemoveCallbacks();
		items.Where((ListViewItem item) => (Object)(object)item != (Object)null && !newItems.Contains(item)).ForEach(Free);
		newItems.ForEach(UpdateItem);
		items = newItems;
		AddCallbacks();
	}

	private void UpdateItem(ListViewItem item, int index)
	{
		if (!((Object)(object)item == (Object)null))
		{
			if (SetItemIndicies)
			{
				item.Index = index;
			}
			((Component)item).transform.SetParent(Container, false);
		}
	}

	public virtual bool IsValid(int index)
	{
		return index >= 0 && index < items.Count;
	}

	protected ListViewItem GetItem(int index)
	{
		return items.Find((ListViewItem x) => x.Index == index);
	}

	public virtual void Select(int index)
	{
		if (index == -1)
		{
			return;
		}
		if (!IsValid(index))
		{
			string message = $"Index must be between 0 and Items.Count ({items.Count - 1}). Gameobject {((Object)this).name}.";
			throw new IndexOutOfRangeException(message);
		}
		if (IsSelected(index) && Multiple)
		{
			return;
		}
		if (!Multiple)
		{
			if (selectedIndex != -1 && selectedIndex != index)
			{
				Deselect(selectedIndex);
			}
			selectedIndicies.Clear();
		}
		selectedIndicies.Add(index);
		selectedIndex = index;
		SelectItem(index);
		((UnityEvent<int, ListViewItem>)OnSelect).Invoke(index, GetItem(index));
	}

	protected void SilentDeselect(List<int> indicies)
	{
		selectedIndicies = selectedIndicies.Except(indicies).ToList();
		selectedIndex = ((selectedIndicies.Count <= 0) ? (-1) : selectedIndicies[selectedIndicies.Count - 1]);
	}

	protected void SilentSelect(List<int> indicies)
	{
		if (indicies == null)
		{
			indicies = new List<int>();
		}
		selectedIndicies.AddRange(indicies.Except(selectedIndicies));
		selectedIndex = ((selectedIndicies.Count <= 0) ? (-1) : selectedIndicies[selectedIndicies.Count - 1]);
	}

	public void Deselect(int index)
	{
		if (index != -1 && IsSelected(index))
		{
			selectedIndicies.Remove(index);
			selectedIndex = ((selectedIndicies.Count <= 0) ? (-1) : selectedIndicies.Last());
			if (IsValid(index))
			{
				DeselectItem(index);
				((UnityEvent<int, ListViewItem>)OnDeselect).Invoke(index, GetItem(index));
			}
		}
	}

	public bool IsSelected(int index)
	{
		return selectedIndicies.Contains(index);
	}

	public void Toggle(int index)
	{
		if (IsSelected(index) && Multiple)
		{
			Deselect(index);
		}
		else
		{
			Select(index);
		}
	}

	private void Toggle(ListViewItem item)
	{
		bool flag = Input.GetKey((KeyCode)304) || Input.GetKey((KeyCode)303);
		bool flag2 = selectedIndicies.Count > 0;
		if (Multiple && flag && flag2 && selectedIndicies[0] != item.Index)
		{
			selectedIndicies.GetRange(1, selectedIndicies.Count - 1).ForEach(Deselect);
			int num = Mathf.Min(selectedIndicies[0], item.Index);
			int num2 = Mathf.Max(selectedIndicies[0], item.Index);
			Enumerable.Range(num, num2 - num + 1).ForEach(Select);
		}
		else
		{
			Toggle(item.Index);
		}
	}

	protected int GetComponentIndex(ListViewItem item)
	{
		return item.Index;
	}

	protected void SetComponentAsLastSibling(ListViewItem item)
	{
		((Component)item).transform.SetAsLastSibling();
	}

	protected virtual void SelectItem(int index)
	{
	}

	protected virtual void DeselectItem(int index)
	{
	}

	protected virtual void Coloring(ListViewItem component)
	{
	}

	protected virtual void HighlightColoring(ListViewItem component)
	{
	}

	protected virtual void OnDestroy()
	{
		RemoveCallbacks();
		items.ForEach(Free);
	}

	public virtual bool SelectComponent()
	{
		if (items.Count == 0)
		{
			return false;
		}
		int index = ((SelectedIndex != -1) ? SelectedIndex : 0);
		SelectComponentByIndex(index);
		return true;
	}

	protected void SelectComponentByIndex(int index)
	{
		ScrollTo(index);
		ListViewItemEventData listViewItemEventData = new ListViewItemEventData(EventSystem.current);
		listViewItemEventData.NewSelectedObject = ((Component)GetItem(index)).gameObject;
		ListViewItemEventData listViewItemEventData2 = listViewItemEventData;
		ExecuteEvents.Execute<ISelectHandler>(listViewItemEventData2.NewSelectedObject, (BaseEventData)(object)listViewItemEventData2, ExecuteEvents.selectHandler);
	}

	void ISelectHandler.OnSelect(BaseEventData eventData)
	{
		if (!EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)this).gameObject);
		}
		((UnityEvent<BaseEventData>)OnFocusIn).Invoke(eventData);
	}

	void IDeselectHandler.OnDeselect(BaseEventData eventData)
	{
		((UnityEvent<BaseEventData>)OnFocusOut).Invoke(eventData);
	}

	void ISubmitHandler.OnSubmit(BaseEventData eventData)
	{
		SelectComponent();
		onSubmit.Invoke();
	}

	void ICancelHandler.OnCancel(BaseEventData eventData)
	{
		onCancel.Invoke();
	}

	public virtual void ForEachComponent(Action<ListViewItem> func)
	{
		items.ForEach(func);
	}
}
