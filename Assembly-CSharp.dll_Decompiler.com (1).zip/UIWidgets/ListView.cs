using System;
using System.Collections.Generic;
using System.Linq;
using EasyLayout;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/ListView", 250)]
public class ListView : ListViewBase
{
	[SerializeField]
	[Obsolete("Use DataSource instead.")]
	private List<string> strings = new List<string>();

	private ObservableList<string> dataSource;

	[SerializeField]
	private TextAsset file;

	[SerializeField]
	public List<string> CommentsStartWith = new List<string> { "#", "//" };

	[SerializeField]
	public ListViewSources Source;

	[SerializeField]
	public bool Unique = true;

	[SerializeField]
	public bool AllowEmptyItems;

	[SerializeField]
	private Color backgroundColor = Color.white;

	[SerializeField]
	private Color textColor = Color.black;

	[SerializeField]
	public Color HighlightedBackgroundColor = new Color(203f, 230f, 244f, 255f);

	[SerializeField]
	public Color HighlightedTextColor = Color.black;

	[SerializeField]
	private Color selectedBackgroundColor = new Color(53f, 83f, 227f, 255f);

	[SerializeField]
	private Color selectedTextColor = Color.black;

	[SerializeField]
	public ImageAdvanced DefaultItem;

	private List<ListViewStringComponent> components = new List<ListViewStringComponent>();

	private List<UnityAction<PointerEventData>> callbacksEnter = new List<UnityAction<PointerEventData>>();

	private List<UnityAction<PointerEventData>> callbacksExit = new List<UnityAction<PointerEventData>>();

	[SerializeField]
	[FormerlySerializedAs("Sort")]
	private bool sort = true;

	private Func<IEnumerable<string>, IEnumerable<string>> sortFunc = (IEnumerable<string> items) => items.OrderBy((string x) => x);

	public ListViewEvent OnSelectString = new ListViewEvent();

	public ListViewEvent OnDeselectString = new ListViewEvent();

	[SerializeField]
	private ScrollRect scrollRect;

	private float itemHeight;

	private float itemWidth;

	private float scrollHeight;

	private float scrollWidth;

	private int maxVisibleItems;

	private int visibleItems;

	private int topHiddenItems;

	private int bottomHiddenItems;

	[SerializeField]
	private ListViewDirection direction = ListViewDirection.Vertical;

	[NonSerialized]
	private bool isStartedListView;

	private LayoutGroup layout;

	protected ILayoutBridge LayoutBridge;

	private List<string> SelectedItemsCache;

	private List<ListViewStringComponent> componentsCache = new List<ListViewStringComponent>();

	private bool needResize;

	public ObservableList<string> DataSource
	{
		get
		{
			if (dataSource == null)
			{
				dataSource = new ObservableList<string>(strings);
				dataSource.OnChange += UpdateItems;
				strings = null;
			}
			return dataSource;
		}
		set
		{
			SetNewItems(value);
			SetScrollValue(0f);
		}
	}

	[Obsolete("Use DataSource instead.")]
	public List<string> Strings
	{
		get
		{
			return new List<string>(DataSource);
		}
		set
		{
			SetNewItems(new ObservableList<string>(value));
			SetScrollValue(0f);
		}
	}

	[Obsolete("Use DataSource instead.")]
	public new List<string> Items
	{
		get
		{
			return new List<string>(DataSource);
		}
		set
		{
			SetNewItems(new ObservableList<string>(value));
			SetScrollValue(0f);
		}
	}

	public TextAsset File
	{
		get
		{
			return file;
		}
		set
		{
			file = value;
			if ((Object)(object)file != (Object)null)
			{
				GetItemsFromFile(file);
				SetScrollValue(0f);
			}
		}
	}

	public Color BackgroundColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return backgroundColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			backgroundColor = value;
			UpdateColors();
		}
	}

	public Color TextColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return textColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			textColor = value;
			UpdateColors();
		}
	}

	public Color SelectedBackgroundColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return selectedBackgroundColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			selectedBackgroundColor = value;
			UpdateColors();
		}
	}

	public Color SelectedTextColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return selectedTextColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			selectedTextColor = value;
			UpdateColors();
		}
	}

	public bool Sort
	{
		get
		{
			return sort;
		}
		set
		{
			sort = value;
			if (Sort && isStartedListView && sortFunc != null)
			{
				UpdateItems();
			}
		}
	}

	public Func<IEnumerable<string>, IEnumerable<string>> SortFunc
	{
		get
		{
			return sortFunc;
		}
		set
		{
			sortFunc = value;
			if (Sort && isStartedListView && sortFunc != null)
			{
				UpdateItems();
			}
		}
	}

	public ScrollRect ScrollRect
	{
		get
		{
			return scrollRect;
		}
		set
		{
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ae: Expected O, but got Unknown
			if ((Object)(object)scrollRect != (Object)null)
			{
				ResizeListener component = ((Component)scrollRect).GetComponent<ResizeListener>();
				if ((Object)(object)component != (Object)null)
				{
					component.OnResize.RemoveListener(new UnityAction(SetNeedResize));
				}
				((UnityEvent<Vector2>)(object)scrollRect.onValueChanged).RemoveListener((UnityAction<Vector2>)OnScrollUpdate);
			}
			scrollRect = value;
			if ((Object)(object)scrollRect != (Object)null)
			{
				ResizeListener resizeListener = ((Component)scrollRect).GetComponent<ResizeListener>() ?? ((Component)scrollRect).gameObject.AddComponent<ResizeListener>();
				resizeListener.OnResize.AddListener(new UnityAction(SetNeedResize));
				((UnityEvent<Vector2>)(object)scrollRect.onValueChanged).AddListener((UnityAction<Vector2>)OnScrollUpdate);
			}
		}
	}

	public ListViewDirection Direction
	{
		get
		{
			return direction;
		}
		set
		{
			direction = value;
			if (Object.op_Implicit((Object)(object)scrollRect))
			{
				scrollRect.horizontal = IsHorizontal();
				scrollRect.vertical = !IsHorizontal();
			}
			if (CanOptimize() && layout is global::EasyLayout.EasyLayout)
			{
				LayoutBridge.IsHorizontal = IsHorizontal();
				CalculateMaxVisibleItems();
			}
			UpdateView();
		}
	}

	public global::EasyLayout.EasyLayout Layout => layout as global::EasyLayout.EasyLayout;

	private void Awake()
	{
		Start();
	}

	public override void Start()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		if (isStartedListView)
		{
			return;
		}
		isStartedListView = true;
		base.Start();
		base.Items = new List<ListViewItem>();
		SelectedItemsCache = base.SelectedIndicies.Convert(GetDataItem);
		DestroyGameObjects = false;
		if ((Object)(object)DefaultItem == (Object)null)
		{
			throw new NullReferenceException("DefaultItem is null. Set component of type ImageAdvanced to DefaultItem.");
		}
		((Component)DefaultItem).gameObject.SetActive(true);
		if ((Object)(object)((Component)DefaultItem).GetComponentInChildren<Text>() == (Object)null)
		{
			throw new MissingComponentException("DefaultItem don't have child with 'Text' component. Add child with 'Text' component to DefaultItem.");
		}
		if (CanOptimize())
		{
			ScrollRect = scrollRect;
			Transform transform = ((Component)scrollRect).transform;
			RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			Rect rect = val.rect;
			scrollHeight = ((Rect)(ref rect)).height;
			Rect rect2 = val.rect;
			scrollWidth = ((Rect)(ref rect2)).width;
			layout = ((Component)Container).GetComponent<LayoutGroup>();
			if (layout is global::EasyLayout.EasyLayout)
			{
				ref ILayoutBridge layoutBridge = ref LayoutBridge;
				global::EasyLayout.EasyLayout obj = layout as global::EasyLayout.EasyLayout;
				Transform transform2 = ((Component)DefaultItem).transform;
				layoutBridge = new EasyLayoutBridge(obj, (RectTransform)(object)((transform2 is RectTransform) ? transform2 : null));
				LayoutBridge.IsHorizontal = IsHorizontal();
			}
			else if (layout is HorizontalOrVerticalLayoutGroup)
			{
				ref ILayoutBridge layoutBridge2 = ref LayoutBridge;
				object obj2 = (object)/*isinst with value type is only supported in some contexts*/;
				Transform transform3 = ((Component)DefaultItem).transform;
				layoutBridge2 = new StandardLayoutBridge((HorizontalOrVerticalLayoutGroup)obj2, (RectTransform)(object)((transform3 is RectTransform) ? transform3 : null));
			}
			CalculateItemSize();
			CalculateMaxVisibleItems();
		}
		((Component)DefaultItem).gameObject.SetActive(false);
		UpdateItems();
		((UnityEvent<int, ListViewItem>)OnSelect).AddListener((UnityAction<int, ListViewItem>)OnSelectCallback);
		((UnityEvent<int, ListViewItem>)OnDeselect).AddListener((UnityAction<int, ListViewItem>)OnDeselectCallback);
	}

	protected virtual void CalculateItemSize()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (LayoutBridge != null)
		{
			Vector2 itemSize = LayoutBridge.GetItemSize();
			itemHeight = itemSize.y;
			itemWidth = itemSize.x;
		}
	}

	protected string GetDataItem(int index)
	{
		return DataSource[index];
	}

	protected bool IsHorizontal()
	{
		return direction == ListViewDirection.Horizontal;
	}

	private void CalculateMaxVisibleItems()
	{
		if (IsHorizontal())
		{
			maxVisibleItems = Mathf.CeilToInt(scrollWidth / itemWidth) + 1;
		}
		else
		{
			maxVisibleItems = Mathf.CeilToInt(scrollHeight / itemHeight) + 1;
		}
	}

	private void Resize()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		needResize = false;
		Transform transform = ((Component)scrollRect).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		Rect rect = val.rect;
		scrollHeight = ((Rect)(ref rect)).height;
		Rect rect2 = val.rect;
		scrollWidth = ((Rect)(ref rect2)).width;
		CalculateMaxVisibleItems();
		UpdateView();
	}

	private bool CanOptimize()
	{
		return (Object)(object)scrollRect != (Object)null && ((Object)(object)layout != (Object)null || (Object)(object)((Component)Container).GetComponent<global::EasyLayout.EasyLayout>() != (Object)null);
	}

	private void OnSelectCallback(int index, ListViewItem item)
	{
		if (SelectedItemsCache != null)
		{
			SelectedItemsCache.Add(DataSource[index]);
		}
		((UnityEvent<int, string>)OnSelectString).Invoke(index, DataSource[index]);
		if ((Object)(object)item != (Object)null)
		{
			SelectColoring(item as ListViewStringComponent);
		}
	}

	private void OnDeselectCallback(int index, ListViewItem item)
	{
		if (SelectedItemsCache != null)
		{
			SelectedItemsCache.Remove(DataSource[index]);
		}
		((UnityEvent<int, string>)OnDeselectString).Invoke(index, DataSource[index]);
		if ((Object)(object)item != (Object)null)
		{
			DefaultColoring(item as ListViewStringComponent);
		}
	}

	public override void UpdateItems()
	{
		if (Source == ListViewSources.List)
		{
			SetNewItems(DataSource);
			return;
		}
		Source = ListViewSources.List;
		GetItemsFromFile(File);
	}

	public override void Clear()
	{
		DataSource.Clear();
	}

	public void GetItemsFromFile()
	{
		GetItemsFromFile(File);
	}

	private string StringTrimEnd(string str)
	{
		return str.TrimEnd(new char[0]);
	}

	private bool IsStringNotEmpty(string str)
	{
		return str != string.Empty;
	}

	private bool NotComment(string str)
	{
		return !CommentsStartWith.Any((string comment) => str.StartsWith(comment));
	}

	public void GetItemsFromFile(TextAsset sourceFile)
	{
		if (!((Object)(object)file == (Object)null))
		{
			IEnumerable<string> enumerable = sourceFile.text.Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None).Select(StringTrimEnd);
			if (Unique)
			{
				enumerable = enumerable.Distinct();
			}
			if (!AllowEmptyItems)
			{
				enumerable = enumerable.Where(IsStringNotEmpty);
			}
			if (CommentsStartWith.Count > 0)
			{
				enumerable = enumerable.Where(NotComment);
			}
			SetNewItems(enumerable.ToObservableList());
		}
	}

	public virtual List<int> FindIndicies(string item)
	{
		return (from i in Enumerable.Range(0, DataSource.Count)
			where DataSource[i] == item
			select i).ToList();
	}

	public virtual int FindIndex(string item)
	{
		return DataSource.IndexOf(item);
	}

	public virtual int Add(string item)
	{
		List<int> second = ((!Sort || SortFunc == null) ? null : FindIndicies(item));
		DataSource.Add(item);
		if (Sort && SortFunc != null)
		{
			List<int> list = FindIndicies(item);
			int[] array = list.Except(second).ToArray();
			if (array.Length > 0)
			{
				return array[0];
			}
			if (list.Count > 0)
			{
				return list[0];
			}
			return -1;
		}
		return DataSource.Count - 1;
	}

	public virtual int Remove(string item)
	{
		int num = FindIndex(item);
		if (num == -1)
		{
			return num;
		}
		DataSource.Remove(item);
		return num;
	}

	private void RemoveCallback(ListViewStringComponent component, int index)
	{
		if (!((Object)(object)component == (Object)null))
		{
			if (index < callbacksEnter.Count)
			{
				((UnityEvent<PointerEventData>)component.onPointerEnter).RemoveListener(callbacksEnter[index]);
			}
			if (index < callbacksExit.Count)
			{
				((UnityEvent<PointerEventData>)component.onPointerExit).RemoveListener(callbacksExit[index]);
			}
		}
	}

	private void RemoveCallbacks()
	{
		components.ForEach(RemoveCallback);
		callbacksEnter.Clear();
		callbacksExit.Clear();
	}

	private void AddCallbacks()
	{
		components.ForEach(AddCallback);
	}

	private void AddCallback(ListViewStringComponent component, int index)
	{
		callbacksEnter.Add(delegate
		{
			OnPointerEnterCallback(component);
		});
		callbacksExit.Add(delegate
		{
			OnPointerExitCallback(component);
		});
		((UnityEvent<PointerEventData>)component.onPointerEnter).AddListener(callbacksEnter[index]);
		((UnityEvent<PointerEventData>)component.onPointerExit).AddListener(callbacksExit[index]);
	}

	public override bool IsValid(int index)
	{
		return index >= 0 && index < DataSource.Count;
	}

	private void OnPointerEnterCallback(ListViewStringComponent component)
	{
		if (!IsValid(component.Index))
		{
			string message = $"Index must be between 0 and Items.Count ({DataSource.Count})";
			throw new IndexOutOfRangeException(message);
		}
		if (!IsSelected(component.Index))
		{
			HighlightColoring(component);
		}
	}

	private void OnPointerExitCallback(ListViewStringComponent component)
	{
		if (!IsValid(component.Index))
		{
			string message = $"Index must be between 0 and Items.Count ({DataSource.Count})";
			throw new IndexOutOfRangeException(message);
		}
		if (!IsSelected(component.Index))
		{
			DefaultColoring(component);
		}
	}

	protected void SetScrollValue(float value)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		Vector2 anchoredPosition = scrollRect.content.anchoredPosition;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(anchoredPosition.x, value);
		if (val != anchoredPosition)
		{
			scrollRect.content.anchoredPosition = val;
			ScrollUpdate();
		}
	}

	protected float GetScrollValue()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Vector2 anchoredPosition = scrollRect.content.anchoredPosition;
		return Mathf.Max(0f, (!IsHorizontal()) ? anchoredPosition.y : (0f - anchoredPosition.x));
	}

	protected float GetItemSize()
	{
		return (!IsHorizontal()) ? (itemHeight + LayoutBridge.GetSpacing()) : (itemWidth + LayoutBridge.GetSpacing());
	}

	protected float GetScrollSize()
	{
		return (!IsHorizontal()) ? scrollHeight : scrollWidth;
	}

	protected override void ScrollTo(int index)
	{
		if (CanOptimize())
		{
			int firstVisibleIndex = GetFirstVisibleIndex(strict: true);
			int lastVisibleIndex = GetLastVisibleIndex(strict: true);
			if (firstVisibleIndex > index)
			{
				float scrollValue = (float)index * GetItemSize();
				SetScrollValue(scrollValue);
			}
			else if (lastVisibleIndex < index)
			{
				float scrollValue2 = (float)(index + 1) * GetItemSize() - LayoutBridge.GetSpacing() + LayoutBridge.GetMargin() - GetScrollSize();
				SetScrollValue(scrollValue2);
			}
		}
	}

	private int GetLastVisibleIndex(bool strict = false)
	{
		float num = GetScrollValue() + GetScrollSize();
		int num2 = ((!strict) ? Mathf.CeilToInt(num / GetItemSize()) : Mathf.FloorToInt(num / GetItemSize()));
		return num2 - 1;
	}

	private int GetFirstVisibleIndex(bool strict = false)
	{
		int num = ((!strict) ? Mathf.FloorToInt(GetScrollValue() / GetItemSize()) : Mathf.CeilToInt(GetScrollValue() / GetItemSize()));
		if (strict)
		{
			return num;
		}
		return Mathf.Min(num, Mathf.Max(0, DataSource.Count - visibleItems));
	}

	private ListViewStringComponent ComponentTopToBottom()
	{
		int index = components.Count - 1;
		ListViewStringComponent listViewStringComponent = components[index];
		components.RemoveAt(index);
		components.Insert(0, listViewStringComponent);
		((Component)listViewStringComponent).transform.SetAsFirstSibling();
		return listViewStringComponent;
	}

	private ListViewStringComponent ComponentBottomToTop()
	{
		ListViewStringComponent listViewStringComponent = components[0];
		components.RemoveAt(0);
		components.Add(listViewStringComponent);
		((Component)listViewStringComponent).transform.SetAsLastSibling();
		return listViewStringComponent;
	}

	private void OnScrollUpdate(Vector2 position)
	{
		ScrollUpdate();
	}

	private void OnScroll(float value)
	{
		ScrollUpdate();
	}

	private void ScrollUpdate()
	{
		int num = topHiddenItems;
		topHiddenItems = GetFirstVisibleIndex();
		bottomHiddenItems = Mathf.Max(0, DataSource.Count - visibleItems - topHiddenItems);
		if (num != topHiddenItems)
		{
			if (num == topHiddenItems + 1)
			{
				ListViewStringComponent listViewStringComponent = ComponentTopToBottom();
				listViewStringComponent.Index = topHiddenItems;
				listViewStringComponent.Text.text = DataSource[topHiddenItems];
				Coloring(listViewStringComponent);
			}
			else if (num == topHiddenItems - 1)
			{
				ListViewStringComponent listViewStringComponent2 = ComponentBottomToTop();
				int index = (listViewStringComponent2.Index = topHiddenItems + visibleItems - 1);
				listViewStringComponent2.Text.text = DataSource[index];
				Coloring(listViewStringComponent2);
			}
			else
			{
				int[] new_indicies = Enumerable.Range(topHiddenItems, visibleItems).ToArray();
				components.ForEach(delegate(ListViewStringComponent x, int i)
				{
					x.Index = new_indicies[i];
					x.Text.text = DataSource[new_indicies[i]];
					Coloring(x);
				});
			}
		}
		if (LayoutBridge != null)
		{
			LayoutBridge.SetFiller(CalculateTopFillerSize(), CalculateBottomFillerSize());
			LayoutBridge.UpdateLayout();
		}
	}

	private bool IsNullComponent(ListViewStringComponent component)
	{
		return (Object)(object)component == (Object)null;
	}

	private List<ListViewStringComponent> GetNewComponents()
	{
		componentsCache.RemoveAll(IsNullComponent);
		List<ListViewStringComponent> new_components = new List<ListViewStringComponent>();
		DataSource.ForEach(delegate(string x, int i)
		{
			if (i < visibleItems)
			{
				if (components.Count > 0)
				{
					new_components.Add(components[0]);
					components.RemoveAt(0);
				}
				else if (componentsCache.Count > 0)
				{
					((Component)componentsCache[0]).gameObject.SetActive(true);
					new_components.Add(componentsCache[0]);
					componentsCache.RemoveAt(0);
				}
				else
				{
					ImageAdvanced imageAdvanced = Object.Instantiate<ImageAdvanced>(DefaultItem);
					((Component)imageAdvanced).gameObject.SetActive(true);
					ListViewStringComponent listViewStringComponent = ((Component)imageAdvanced).GetComponent<ListViewStringComponent>();
					if ((Object)(object)listViewStringComponent == (Object)null)
					{
						listViewStringComponent = ((Component)imageAdvanced).gameObject.AddComponent<ListViewStringComponent>();
						listViewStringComponent.Background = imageAdvanced;
						listViewStringComponent.Text = ((Component)imageAdvanced).GetComponentInChildren<Text>();
					}
					Utilites.FixInstantiated((Component)(object)DefaultItem, (Component)(object)imageAdvanced);
					((Component)listViewStringComponent).gameObject.SetActive(true);
					new_components.Add(listViewStringComponent);
				}
			}
		});
		components.ForEach(delegate(ListViewStringComponent x)
		{
			x.MovedToCache();
			x.Index = -1;
			((Component)x).gameObject.SetActive(false);
		});
		componentsCache.AddRange(components);
		components.Clear();
		return new_components;
	}

	private void UpdateView()
	{
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		RemoveCallbacks();
		if (CanOptimize() && DataSource.Count > 0)
		{
			visibleItems = ((maxVisibleItems >= DataSource.Count) ? DataSource.Count : maxVisibleItems);
		}
		else
		{
			visibleItems = DataSource.Count;
		}
		components = GetNewComponents();
		base.Items = components.Convert((Converter<ListViewStringComponent, ListViewItem>)((ListViewStringComponent x) => x));
		components.ForEach(SetComponentData);
		AddCallbacks();
		topHiddenItems = 0;
		bottomHiddenItems = DataSource.Count() - visibleItems;
		if (LayoutBridge != null)
		{
			LayoutBridge.SetFiller(CalculateTopFillerSize(), CalculateBottomFillerSize());
			LayoutBridge.UpdateLayout();
		}
		if ((Object)(object)scrollRect != (Object)null)
		{
			Transform transform = ((Component)scrollRect).transform;
			RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			Rect rect = val.rect;
			val.SetSizeWithCurrentAnchors((Axis)0, ((Rect)(ref rect)).width);
		}
	}

	private void SetComponentData(ListViewStringComponent component, int index)
	{
		component.Index = index;
		component.Text.text = DataSource[index];
		Coloring(component);
	}

	private bool IndexNotFound(int index)
	{
		return index == -1;
	}

	private void SetNewItems(ObservableList<string> newItems)
	{
		DataSource.OnChange -= UpdateItems;
		if (Sort && SortFunc != null)
		{
			newItems.BeginUpdate();
			string[] array = SortFunc(newItems).ToArray();
			newItems.Clear();
			newItems.AddRange(array);
			newItems.EndUpdate();
		}
		SilentDeselect(base.SelectedIndicies);
		List<int> list = SelectedItemsCache.Convert(newItems.IndexOf);
		list.RemoveAll(IndexNotFound);
		dataSource = newItems;
		SilentSelect(list);
		SelectedItemsCache = base.SelectedIndicies.Convert(GetDataItem);
		UpdateView();
		DataSource.OnChange += UpdateItems;
	}

	private float CalculateBottomFillerSize()
	{
		return (bottomHiddenItems != 0) ? ((float)bottomHiddenItems * GetItemSize() - LayoutBridge.GetSpacing()) : 0f;
	}

	private float CalculateTopFillerSize()
	{
		return (topHiddenItems != 0) ? ((float)topHiddenItems * GetItemSize() - LayoutBridge.GetSpacing()) : 0f;
	}

	private List<int> NewSelectedIndicies(ObservableList<string> newItems)
	{
		List<int> selected_indicies = new List<int>();
		if (newItems.Count == 0)
		{
			return selected_indicies;
		}
		List<string> new_items_copy = new List<string>(newItems);
		List<string> selected_items = base.SelectedIndicies.Convert(GetDataItem);
		selected_items = selected_items.Where(delegate(string x)
		{
			bool flag = newItems.Contains(x);
			if (flag)
			{
				new_items_copy.Remove(x);
			}
			return flag;
		}).ToList();
		newItems.ForEach(delegate(string item, int index)
		{
			if (selected_items.Contains(item))
			{
				selected_items.Remove(item);
				selected_indicies.Add(index);
			}
		});
		return selected_indicies;
	}

	protected override void Coloring(ListViewItem component)
	{
		if (!((Object)(object)component == (Object)null))
		{
			if (base.SelectedIndicies.Contains(component.Index))
			{
				SelectColoring(component);
			}
			else
			{
				DefaultColoring(component);
			}
		}
	}

	private void UpdateColors()
	{
		components.ForEach(Coloring);
	}

	private ListViewStringComponent GetComponent(int index)
	{
		return components.Find((ListViewStringComponent x) => x.Index == index);
	}

	public int Set(string item, bool allowDuplicate = true)
	{
		int num;
		if (!allowDuplicate)
		{
			num = DataSource.IndexOf(item);
			if (num == -1)
			{
				num = Add(item);
			}
		}
		else
		{
			num = Add(item);
		}
		Select(num);
		return num;
	}

	protected override void SelectItem(int index)
	{
		SelectColoring(GetComponent(index));
	}

	protected override void DeselectItem(int index)
	{
		DefaultColoring(GetComponent(index));
	}

	protected override void HighlightColoring(ListViewItem component)
	{
		if (!IsSelected(component.Index))
		{
			HighlightColoring(component as ListViewStringComponent);
		}
	}

	protected virtual void HighlightColoring(ListViewStringComponent component)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)component == (Object)null))
		{
			((Graphic)component.Background).color = HighlightedBackgroundColor;
			((Graphic)component.Text).color = HighlightedTextColor;
		}
	}

	protected virtual void SelectColoring(ListViewItem component)
	{
		if (!((Object)(object)component == (Object)null))
		{
			SelectColoring(component as ListViewStringComponent);
		}
	}

	protected virtual void SelectColoring(ListViewStringComponent component)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)component == (Object)null))
		{
			((Graphic)component.Background).color = selectedBackgroundColor;
			((Graphic)component.Text).color = selectedTextColor;
		}
	}

	protected virtual void DefaultColoring(ListViewItem component)
	{
		if (!((Object)(object)component == (Object)null))
		{
			DefaultColoring(component as ListViewStringComponent);
		}
	}

	protected virtual void DefaultColoring(ListViewStringComponent component)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)component == (Object)null))
		{
			((Graphic)component.Background).color = backgroundColor;
			((Graphic)component.Text).color = textColor;
		}
	}

	protected override void OnDestroy()
	{
		((UnityEvent<int, ListViewItem>)OnSelect).RemoveListener((UnityAction<int, ListViewItem>)OnSelectCallback);
		((UnityEvent<int, ListViewItem>)OnDeselect).RemoveListener((UnityAction<int, ListViewItem>)OnDeselectCallback);
		ScrollRect = null;
		RemoveCallbacks();
		base.OnDestroy();
	}

	private void Update()
	{
		if (needResize)
		{
			Resize();
		}
	}

	private void SetNeedResize()
	{
		if (CanOptimize())
		{
			needResize = true;
		}
	}
}
