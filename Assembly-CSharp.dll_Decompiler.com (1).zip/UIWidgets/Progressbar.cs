using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/Progressbar", 260)]
public class Progressbar : MonoBehaviour
{
	[SerializeField]
	public int Max = 100;

	[SerializeField]
	private int _value;

	[SerializeField]
	private ProgressbarDirection Direction;

	[SerializeField]
	private ProgressbarTypes type;

	[SerializeField]
	public RawImage IndeterminateBar;

	[SerializeField]
	public GameObject DeterminateBar;

	[SerializeField]
	public Image EmptyBar;

	[SerializeField]
	public Text EmptyBarText;

	[SerializeField]
	private Image fullBar;

	[SerializeField]
	public Text FullBarText;

	[SerializeField]
	public RectTransform BarMask;

	[SerializeField]
	private ProgressbarTextTypes textType;

	[SerializeField]
	public float Speed = 0.1f;

	private Func<Progressbar, string> textFunc = TextPercent;

	private IEnumerator currentAnimation;

	public int Value
	{
		get
		{
			return _value;
		}
		set
		{
			if (value > Max)
			{
				value = Max;
			}
			_value = value;
			UpdateProgressbar();
		}
	}

	public ProgressbarTypes Type
	{
		get
		{
			return type;
		}
		set
		{
			type = value;
			ToggleType();
		}
	}

	public Image FullBar
	{
		get
		{
			return fullBar;
		}
		set
		{
			fullBar = value;
		}
	}

	private RectTransform FullBarRectTransform
	{
		get
		{
			Transform transform = ((Component)fullBar).transform;
			return (RectTransform)(object)((transform is RectTransform) ? transform : null);
		}
	}

	[SerializeField]
	public ProgressbarTextTypes TextType
	{
		get
		{
			return textType;
		}
		set
		{
			textType = value;
			ToggleTextType();
		}
	}

	public Func<Progressbar, string> TextFunc
	{
		get
		{
			return textFunc;
		}
		set
		{
			textFunc = value;
			UpdateText();
		}
	}

	public bool IsAnimationRun { get; protected set; }

	public static string TextNone(Progressbar bar)
	{
		return string.Empty;
	}

	public static string TextPercent(Progressbar bar)
	{
		return $"{(float)bar.Value / (float)bar.Max:P0}";
	}

	public static string TextRange(Progressbar bar)
	{
		return $"{bar.Value} / {bar.Max}";
	}

	public void Animate(int? targetValue = null)
	{
		if (currentAnimation != null)
		{
			((MonoBehaviour)this).StopCoroutine(currentAnimation);
		}
		if (Type == ProgressbarTypes.Indeterminate)
		{
			currentAnimation = IndeterminateAnimation();
		}
		else
		{
			currentAnimation = DeterminateAnimation((!targetValue.HasValue) ? Max : targetValue.Value);
		}
		IsAnimationRun = true;
		((MonoBehaviour)this).StartCoroutine(currentAnimation);
	}

	public void Stop()
	{
		if (IsAnimationRun)
		{
			((MonoBehaviour)this).StopCoroutine(currentAnimation);
			IsAnimationRun = false;
		}
	}

	private IEnumerator DeterminateAnimation(int targetValue)
	{
		if (targetValue > Max)
		{
			targetValue = Max;
		}
		int delta = targetValue - Value;
		if (delta != 0)
		{
			while (true)
			{
				if (delta > 0)
				{
					_value++;
				}
				else
				{
					_value--;
				}
				UpdateProgressbar();
				if (_value == targetValue)
				{
					break;
				}
				yield return (object)new WaitForSeconds(Speed);
			}
		}
		IsAnimationRun = false;
	}

	private IEnumerator IndeterminateAnimation()
	{
		while (true)
		{
			Rect r = IndeterminateBar.uvRect;
			if (Direction == ProgressbarDirection.Horizontal)
			{
				((Rect)(ref r)).x = Time.time * Speed % 1f;
			}
			else
			{
				((Rect)(ref r)).y = Time.time * Speed % 1f;
			}
			IndeterminateBar.uvRect = r;
			yield return null;
		}
	}

	public void Refresh()
	{
		FullBar = fullBar;
		ToggleType();
		ToggleTextType();
		UpdateProgressbar();
	}

	private void UpdateProgressbar()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)BarMask != (Object)null && (Object)(object)FullBar != (Object)null)
		{
			float num = (float)Value / (float)Max;
			RectTransform barMask = BarMask;
			Vector2 sizeDelta;
			if (Direction == ProgressbarDirection.Horizontal)
			{
				Rect rect = FullBarRectTransform.rect;
				sizeDelta = new Vector2(((Rect)(ref rect)).width * num, BarMask.sizeDelta.y);
			}
			else
			{
				float x = BarMask.sizeDelta.x;
				Rect rect2 = FullBarRectTransform.rect;
				sizeDelta = new Vector2(x, ((Rect)(ref rect2)).height * num);
			}
			barMask.sizeDelta = sizeDelta;
		}
		UpdateText();
	}

	private void UpdateText()
	{
		string text = textFunc(this);
		if ((Object)(object)FullBarText != (Object)null)
		{
			FullBarText.text = text;
		}
		if ((Object)(object)EmptyBarText != (Object)null)
		{
			EmptyBarText.text = text;
		}
	}

	private void ToggleType()
	{
		bool flag = type == ProgressbarTypes.Determinate;
		if ((Object)(object)DeterminateBar != (Object)null)
		{
			DeterminateBar.gameObject.SetActive(flag);
		}
		if ((Object)(object)IndeterminateBar != (Object)null)
		{
			((Component)IndeterminateBar).gameObject.SetActive(!flag);
		}
	}

	private void ToggleTextType()
	{
		if (TextType == ProgressbarTextTypes.None)
		{
			textFunc = TextNone;
		}
		else if (TextType == ProgressbarTextTypes.Percent)
		{
			textFunc = TextPercent;
		}
		else if (TextType == ProgressbarTextTypes.Range)
		{
			textFunc = TextRange;
		}
	}
}
