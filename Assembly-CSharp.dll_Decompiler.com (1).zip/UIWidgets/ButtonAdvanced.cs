using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/Progressbar", 210)]
public class ButtonAdvanced : Button, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IEventSystemHandler
{
	public PointerUnityEvent onPointerDown = new PointerUnityEvent();

	public PointerUnityEvent onPointerUp = new PointerUnityEvent();

	public PointerUnityEvent onPointerEnter = new PointerUnityEvent();

	public PointerUnityEvent onPointerExit = new PointerUnityEvent();

	public override void OnPointerDown(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerDown).Invoke(eventData);
		((Selectable)this).OnPointerDown(eventData);
	}

	public override void OnPointerUp(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerUp).Invoke(eventData);
		((Selectable)this).OnPointerUp(eventData);
	}

	public override void OnPointerEnter(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerEnter).Invoke(eventData);
		((Selectable)this).OnPointerEnter(eventData);
	}

	public override void OnPointerExit(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerExit).Invoke(eventData);
		((Selectable)this).OnPointerExit(eventData);
	}
}
