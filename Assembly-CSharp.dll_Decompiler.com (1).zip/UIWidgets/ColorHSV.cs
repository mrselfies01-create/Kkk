using UnityEngine;

namespace UIWidgets;

public struct ColorHSV
{
	public int H;

	public int S;

	public int V;

	public byte A;

	public ColorHSV(int h, int s, int v, byte a)
	{
		H = h;
		S = s;
		V = v;
		A = a;
	}

	public ColorHSV(Color color)
	{
		float[] array = new float[3] { color.r, color.g, color.b };
		float num = Mathf.Max(array);
		float num2 = Mathf.Min(array);
		float num3 = num - num2;
		H = 0;
		if (num3 == 0f)
		{
			H = 0;
		}
		else if (num == color.r && color.g >= color.b)
		{
			H = Mathf.RoundToInt(60f * ((color.g - color.b) / num3));
		}
		else if (num == color.r && color.g < color.b)
		{
			H = Mathf.RoundToInt(60f * ((color.g - color.b) / num3)) + 360;
		}
		else if (num == color.g)
		{
			H = Mathf.RoundToInt(60f * ((color.b - color.r) / num3)) + 120;
		}
		else if (num == color.b)
		{
			H = Mathf.RoundToInt(60f * ((color.r - color.g) / num3)) + 240;
		}
		if (H < 0)
		{
			H += 360;
		}
		S = ((num != 0f) ? Mathf.RoundToInt((1f - num2 / num) * 255f) : 0);
		V = Mathf.RoundToInt(num * 255f);
		A = (byte)Mathf.RoundToInt(color.a * 255f);
	}

	public static implicit operator Color32(ColorHSV color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return Color32.op_Implicit((Color)color);
	}

	public static implicit operator Color(ColorHSV color)
	{
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Abs((float)color.H / 360f % 1f);
		float num2 = Mathf.Abs((float)color.S / 256f % 1f);
		float num3 = Mathf.Abs((float)color.V / 256f % 1f);
		num = Mathf.Clamp(num, 0.001f, 0.999f);
		num2 = Mathf.Clamp(num2, 0.001f, 0.999f);
		num3 = Mathf.Clamp(num3, 0.001f, 0.999f);
		float num4 = num * 6f;
		if (num4 == 6f)
		{
			num4 = 0f;
		}
		int num5 = (int)num4;
		float num6 = num3 * (1f - num2);
		float num7 = num3 * (1f - num2 * (num4 - (float)num5));
		float num8 = num3 * (1f - num2 * (1f - (num4 - (float)num5)));
		return (Color)(num5 switch
		{
			0 => new Color(num3, num8, num6, (float)(int)color.A), 
			1 => new Color(num7, num3, num6, (float)(int)color.A), 
			2 => new Color(num6, num3, num8, (float)(int)color.A), 
			3 => new Color(num6, num7, num3, (float)(int)color.A), 
			4 => new Color(num8, num6, num3, (float)(int)color.A), 
			_ => new Color(num3, num6, num7, (float)(int)color.A), 
		});
	}

	public override string ToString()
	{
		return $"HSVA({H}, {S}, {V}, {A})";
	}

	public string ToString(string format)
	{
		return $"HSVA({H.ToString(format)}, {S.ToString(format)}, {V.ToString(format)}, {A.ToString(format)})";
	}
}
