using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class ListViewCustomHeight<TComponent, TItem> : ListViewCustom<TComponent, TItem> where TComponent : ListViewItem where TItem : IItemHeight
{
	[SerializeField]
	[Tooltip("Calculate height automaticly without using IListViewItemHeight.Height.")]
	private bool ForceAutoHeightCalculation = true;

	private TComponent defaultItemCopy;

	private RectTransform defaultItemCopyRect;

	private bool IsCanCalculateHeight;

	private LayoutGroup defaultItemlayoutGroup;

	protected TComponent DefaultItemCopy
	{
		get
		{
			if ((Object)(object)defaultItemCopy == (Object)null)
			{
				defaultItemCopy = Object.Instantiate<TComponent>(DefaultItem);
				((Component)defaultItemCopy).transform.SetParent(((Component)DefaultItem).transform.parent);
				Utilites.FixInstantiated((Component)(object)DefaultItem, (Component)(object)defaultItemCopy);
				((Object)((Component)defaultItemCopy).gameObject).name = "DefaultItemCopy";
				((Component)defaultItemCopy).gameObject.SetActive(false);
			}
			return defaultItemCopy;
		}
	}

	protected RectTransform DefaultItemCopyRect
	{
		get
		{
			if ((Object)(object)defaultItemCopyRect == (Object)null)
			{
				ref RectTransform reference = ref defaultItemCopyRect;
				Transform transform = ((Component)defaultItemCopy).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return defaultItemCopyRect;
		}
	}

	public ListViewCustomHeight()
	{
		IsCanCalculateHeight = typeof(IListViewItemHeight).IsAssignableFrom(typeof(TComponent));
	}

	protected override void Awake()
	{
		Start();
	}

	protected override void CalculateMaxVisibleItems()
	{
		SetItemsHeight(base.DataSource);
		float height = scrollHeight;
		maxVisibleItems = base.DataSource.OrderBy(GetItemHeight).TakeWhile(delegate(TItem x)
		{
			height -= x.Height;
			return height > 0f;
		}).Count() + 2;
	}

	protected override void CalculateItemSize()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)DefaultItem).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		ILayoutElement[] source = ((Component)val).GetComponents<ILayoutElement>();
		if (itemHeight == 0f)
		{
			float num = source.Max((ILayoutElement x) => Mathf.Max(x.minHeight, x.preferredHeight));
			float num2;
			if (num > 0f)
			{
				num2 = num;
			}
			else
			{
				Rect rect = val.rect;
				num2 = ((Rect)(ref rect)).height;
			}
			itemHeight = num2;
		}
		if (itemWidth == 0f)
		{
			float num3 = source.Max((ILayoutElement x) => Mathf.Max(x.minWidth, x.preferredWidth));
			float num4;
			if (num3 > 0f)
			{
				num4 = num3;
			}
			else
			{
				Rect rect2 = val.rect;
				num4 = ((Rect)(ref rect2)).width;
			}
			itemWidth = num4;
		}
	}

	protected override void ScrollTo(int index)
	{
		if (CanOptimize())
		{
			float scrollValue = GetScrollValue();
			float num = GetScrollValue() + scrollHeight;
			float num2 = ItemStartAt(index);
			float num3 = ItemEndAt(index) + LayoutBridge.GetMargin();
			if (num2 < scrollValue)
			{
				SetScrollValue(num2);
			}
			else if (num3 > num)
			{
				SetScrollValue(num3 - GetScrollSize());
			}
		}
	}

	protected override float CalculateBottomFillerSize()
	{
		if (bottomHiddenItems == 0)
		{
			return 0f;
		}
		float num = base.DataSource.GetRange(topHiddenItems + visibleItems, bottomHiddenItems).SumFloat(GetItemHeight);
		return Mathf.Max(0f, num + LayoutBridge.GetSpacing() * (float)(bottomHiddenItems - 1));
	}

	protected override float CalculateTopFillerSize()
	{
		if (topHiddenItems == 0)
		{
			return 0f;
		}
		float num = base.DataSource.GetRange(0, topHiddenItems).SumFloat(GetItemHeight);
		return Mathf.Max(0f, num + LayoutBridge.GetSpacing() * (float)(topHiddenItems - 1));
	}

	private float GetItemHeight(TItem item)
	{
		return item.Height;
	}

	private float ItemStartAt(int index)
	{
		float num = base.DataSource.GetRange(0, index).SumFloat(GetItemHeight);
		return num + LayoutBridge.GetSpacing() * (float)index;
	}

	private float ItemEndAt(int index)
	{
		float num = base.DataSource.GetRange(0, index + 1).SumFloat(GetItemHeight);
		return num + LayoutBridge.GetSpacing() * (float)index;
	}

	public override int Add(TItem item)
	{
		if (item == null)
		{
			throw new ArgumentNullException("item", "Item is null.");
		}
		if (item.Height == 0f)
		{
			item.Height = CalculateItemHeight(item);
		}
		return base.Add(item);
	}

	private void SetItemsHeight(ObservableList<TItem> items, bool forceUpdate = true)
	{
		items.ForEach(delegate(TItem x)
		{
			if (x.Height == 0f || forceUpdate)
			{
				x.Height = CalculateItemHeight(x);
			}
		});
	}

	public override void Resize()
	{
		SetItemsHeight(base.DataSource);
		base.Resize();
	}

	protected override void SetNewItems(ObservableList<TItem> newItems)
	{
		SetItemsHeight(newItems);
		base.SetNewItems(newItems);
	}

	private int GetIndexByHeight(float height)
	{
		float spacing = LayoutBridge.GetSpacing();
		return base.DataSource.TakeWhile(delegate(TItem item, int index)
		{
			height -= item.Height;
			if (index > 0)
			{
				height -= spacing;
			}
			return height >= 0f;
		}).Count();
	}

	protected override int GetLastVisibleIndex(bool strict = false)
	{
		int indexByHeight = GetIndexByHeight(GetScrollValue() + scrollHeight);
		return (!strict) ? (indexByHeight + 2) : indexByHeight;
	}

	protected override int GetFirstVisibleIndex(bool strict = false)
	{
		int indexByHeight = GetIndexByHeight(GetScrollValue());
		if (strict)
		{
			return indexByHeight;
		}
		return Mathf.Min(indexByHeight, Mathf.Max(0, base.DataSource.Count - visibleItems));
	}

	private float CalculateItemHeight(TItem item)
	{
		if ((Object)(object)defaultItemlayoutGroup == (Object)null)
		{
			TComponent val = DefaultItemCopy;
			defaultItemlayoutGroup = ((Component)val).GetComponent<LayoutGroup>();
		}
		float num = 0f;
		if ((!IsCanCalculateHeight || ForceAutoHeightCalculation) && (Object)(object)defaultItemlayoutGroup != (Object)null)
		{
			TComponent val2 = DefaultItemCopy;
			((Component)val2).gameObject.SetActive(true);
			SetData(DefaultItemCopy, item);
			defaultItemlayoutGroup.CalculateLayoutInputHorizontal();
			defaultItemlayoutGroup.SetLayoutHorizontal();
			defaultItemlayoutGroup.CalculateLayoutInputVertical();
			defaultItemlayoutGroup.SetLayoutVertical();
			num = LayoutUtility.GetPreferredHeight(DefaultItemCopyRect);
			TComponent val3 = DefaultItemCopy;
			((Component)val3).gameObject.SetActive(false);
		}
		else
		{
			SetData(DefaultItemCopy, item);
			num = (DefaultItemCopy as IListViewItemHeight).Height;
		}
		return num;
	}

	public override void ForEachComponent(Action<ListViewItem> func)
	{
		base.ForEachComponent(func);
		func(DefaultItemCopy);
	}
}
