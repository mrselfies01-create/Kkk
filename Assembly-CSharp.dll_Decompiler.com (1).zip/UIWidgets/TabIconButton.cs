using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class TabIconButton : TabButton
{
	[SerializeField]
	public Text Name;

	[SerializeField]
	public Image Icon;

	[SerializeField]
	public bool SetNativeSize;

	public virtual void SetData(TabIcons tab)
	{
	}
}
