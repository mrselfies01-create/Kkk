using System;
using System.Collections;
using System.Collections.Generic;
using EasyLayout;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class Notify : MonoBehaviour, ITemplatable
{
	[SerializeField]
	private Button hideButton;

	[SerializeField]
	private Text text;

	[SerializeField]
	private float HideDelay = 10f;

	private bool isTemplate = true;

	private static Templates<Notify> templates;

	public Func<Notify, IEnumerator> ShowAnimation;

	public Func<Notify, IEnumerator> HideAnimation;

	private Func<Notify, IEnumerator> oldShowAnimation;

	private Func<Notify, IEnumerator> oldHideAnimation;

	private IEnumerator showCorutine;

	private IEnumerator hideCorutine;

	public bool SlideUpOnHide = true;

	public float SequenceDelay;

	private static NotifySequenceManager notifyManager;

	private Action OnHideCallback;

	private static Stack<RectTransform> slides = new Stack<RectTransform>();

	public Button HideButton
	{
		get
		{
			return hideButton;
		}
		set
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			if ((Object)(object)hideButton != (Object)null)
			{
				((UnityEvent)hideButton.onClick).RemoveListener(new UnityAction(Hide));
			}
			hideButton = value;
			if ((Object)(object)hideButton != (Object)null)
			{
				((UnityEvent)hideButton.onClick).AddListener(new UnityAction(Hide));
			}
		}
	}

	public Text Text
	{
		get
		{
			return text;
		}
		set
		{
			text = value;
		}
	}

	public bool IsTemplate
	{
		get
		{
			return isTemplate;
		}
		set
		{
			isTemplate = value;
		}
	}

	public string TemplateName { get; set; }

	public static Templates<Notify> Templates
	{
		get
		{
			if (templates == null)
			{
				templates = new Templates<Notify>(AddCloseCallback);
			}
			return templates;
		}
		set
		{
			templates = value;
		}
	}

	public static NotifySequenceManager NotifyManager
	{
		get
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Expected O, but got Unknown
			if ((Object)(object)notifyManager == (Object)null)
			{
				GameObject val = new GameObject("NotifySequenceManager");
				notifyManager = val.AddComponent<NotifySequenceManager>();
			}
			return notifyManager;
		}
	}

	private void Awake()
	{
		if (IsTemplate)
		{
			((Component)this).gameObject.SetActive(false);
		}
	}

	private static void FindTemplates()
	{
		Templates.FindTemplates();
	}

	private void OnDestroy()
	{
		HideButton = null;
		if (!IsTemplate)
		{
			templates = null;
		}
		else if (TemplateName != null)
		{
			DeleteTemplate(TemplateName);
		}
	}

	public static void ClearCache()
	{
		Templates.ClearCache();
	}

	public static void ClearCache(string templateName)
	{
		Templates.ClearCache(templateName);
	}

	public static Notify GetTemplate(string template)
	{
		return Templates.Get(template);
	}

	public static void DeleteTemplate(string template)
	{
		Templates.Delete(template);
	}

	public static void AddTemplate(string template, Notify notifyTemplate, bool replace = true)
	{
		Templates.Add(template, notifyTemplate, replace);
	}

	public static Notify Template(string template)
	{
		return Templates.Instance(template);
	}

	private static void AddCloseCallback(Notify notify)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		if (!((Object)(object)notify.hideButton == (Object)null))
		{
			((UnityEvent)notify.hideButton.onClick).AddListener(new UnityAction(notify.Hide));
		}
	}

	public void Show(string message = null, float? customHideDelay = null, Transform container = null, Func<Notify, IEnumerator> showAnimation = null, Func<Notify, IEnumerator> hideAnimation = null, bool? slideUpOnHide = null, NotifySequence sequenceType = NotifySequence.None, float sequenceDelay = 0.3f, bool clearSequence = false)
	{
		if (clearSequence)
		{
			NotifyManager.Clear();
		}
		SequenceDelay = sequenceDelay;
		oldShowAnimation = ShowAnimation;
		oldHideAnimation = HideAnimation;
		if (message != null && (Object)(object)text != (Object)null)
		{
			text.text = message;
		}
		if ((Object)(object)container != (Object)null)
		{
			((Component)this).transform.SetParent(container, false);
		}
		if (customHideDelay.HasValue)
		{
			HideDelay = customHideDelay.Value;
		}
		if (slideUpOnHide.HasValue)
		{
			SlideUpOnHide = slideUpOnHide.Value;
		}
		if (showAnimation != null)
		{
			ShowAnimation = showAnimation;
		}
		if (hideAnimation != null)
		{
			HideAnimation = hideAnimation;
		}
		if (sequenceType != 0)
		{
			NotifyManager.Add(this, sequenceType);
		}
		else
		{
			Display();
		}
	}

	public void Display(Action onHideCallback = null)
	{
		((Component)this).transform.SetAsLastSibling();
		((Component)this).gameObject.SetActive(true);
		OnHideCallback = onHideCallback;
		if (ShowAnimation != null)
		{
			showCorutine = ShowAnimation(this);
			((MonoBehaviour)this).StartCoroutine(showCorutine);
		}
		else
		{
			showCorutine = null;
		}
		if (HideDelay > 0f)
		{
			hideCorutine = HideCorutine();
			((MonoBehaviour)this).StartCoroutine(hideCorutine);
		}
		else
		{
			hideCorutine = null;
		}
	}

	private IEnumerator HideCorutine()
	{
		yield return (object)new WaitForSeconds(HideDelay);
		if (HideAnimation != null)
		{
			yield return ((MonoBehaviour)this).StartCoroutine(HideAnimation(this));
		}
		Hide();
	}

	public void Hide()
	{
		if (SlideUpOnHide)
		{
			SlideUp();
		}
		if (OnHideCallback != null)
		{
			OnHideCallback();
		}
		Return();
	}

	public void Return()
	{
		Templates.ToCache(this);
		ShowAnimation = oldShowAnimation;
		HideAnimation = oldHideAnimation;
		if ((Object)(object)text != (Object)null)
		{
			text.text = Templates.Get(TemplateName).text.text;
		}
	}

	private RectTransform GetSlide()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected O, but got Unknown
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		RectTransform val2;
		if (slides.Count == 0)
		{
			GameObject val = new GameObject("SlideUp");
			val.SetActive(false);
			val2 = val.AddComponent<RectTransform>();
			val.AddComponent<SlideUp>();
			Image val3 = val.AddComponent<Image>();
			((Graphic)val3).color = Color.clear;
		}
		else
		{
			do
			{
				val2 = ((slides.Count <= 0) ? GetSlide() : slides.Pop());
			}
			while ((Object)(object)val2 == (Object)null);
		}
		return val2;
	}

	private void SlideUp()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		RectTransform slide = GetSlide();
		SlideUp component = ((Component)slide).GetComponent<SlideUp>();
		Transform transform = ((Component)this).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		((Transform)slide).localRotation = ((Transform)val).localRotation;
		((Transform)slide).localPosition = ((Transform)val).localPosition;
		((Transform)slide).localScale = ((Transform)val).localScale;
		slide.anchorMin = val.anchorMin;
		slide.anchorMax = val.anchorMax;
		slide.anchoredPosition = val.anchoredPosition;
		slide.anchoredPosition3D = val.anchoredPosition3D;
		slide.sizeDelta = val.sizeDelta;
		slide.pivot = val.pivot;
		((Component)slide).transform.SetParent(((Component)this).transform.parent, false);
		((Component)slide).transform.SetSiblingIndex(((Component)this).transform.GetSiblingIndex());
		((Component)slide).gameObject.SetActive(true);
		component.Run();
	}

	public static void FreeSlide(RectTransform slide)
	{
		slides.Push(slide);
	}

	public static IEnumerator AnimationRotate(Notify notify)
	{
		Transform transform = ((Component)notify).transform;
		RectTransform rect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		Quaternion rotation = ((Transform)rect).rotation;
		Vector3 start_rotarion = ((Quaternion)(ref rotation)).eulerAngles;
		float time = 0.5f;
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			float rotation_x = Mathf.Lerp(0f, 90f, 1f - (end_time - Time.time) / time);
			((Transform)rect).rotation = Quaternion.Euler(rotation_x, start_rotarion.y, start_rotarion.z);
			yield return null;
		}
		((Transform)rect).rotation = Quaternion.Euler(start_rotarion);
	}

	public static IEnumerator AnimationCollapse(Notify notify)
	{
		Transform transform = ((Component)notify).transform;
		RectTransform rect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		global::EasyLayout.EasyLayout layout = ((Component)notify).GetComponentInParent<global::EasyLayout.EasyLayout>();
		Rect rect2 = rect.rect;
		float max_height = ((Rect)(ref rect2)).height;
		float speed = 200f;
		float time = max_height / speed;
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			float height = Mathf.Lerp(max_height, 0f, 1f - (end_time - Time.time) / time);
			rect.SetSizeWithCurrentAnchors((Axis)1, height);
			if ((Object)(object)layout != (Object)null)
			{
				layout.UpdateLayout();
			}
			yield return null;
		}
		rect.SetSizeWithCurrentAnchors((Axis)1, max_height);
	}
}
