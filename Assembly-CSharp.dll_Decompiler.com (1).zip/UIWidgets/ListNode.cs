namespace UIWidgets;

public class ListNode<TItem>
{
	public int Depth;

	public TreeNode<TItem> Node;

	public ListNode(TreeNode<TItem> node, int depth)
	{
		Node = node;
		Depth = depth;
	}

	public override bool Equals(object obj)
	{
		ListNode<TItem> listNode = obj as ListNode<TItem>;
		if (listNode == null)
		{
			return this == null;
		}
		if (this == null)
		{
			return false;
		}
		return Node.Equals(listNode.Node);
	}

	public override int GetHashCode()
	{
		return base.GetHashCode();
	}

	public static bool operator ==(ListNode<TItem> a, ListNode<TItem> b)
	{
		bool flag = object.ReferenceEquals(null, a);
		bool flag2 = object.ReferenceEquals(null, b);
		if (flag && flag2)
		{
			return true;
		}
		if (flag != flag2)
		{
			return false;
		}
		return a.Node.Equals(b.Node);
	}

	public static bool operator !=(ListNode<TItem> a, ListNode<TItem> b)
	{
		bool flag = object.ReferenceEquals(null, a);
		bool flag2 = object.ReferenceEquals(null, b);
		if (flag && flag2)
		{
			return false;
		}
		if (flag != flag2)
		{
			return true;
		}
		return !a.Node.Equals(b.Node);
	}
}
