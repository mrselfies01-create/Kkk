namespace UIWidgets;

public enum SpinnerValidation
{
	OnKeyDown,
	OnEndInput
}
