using UnityEngine;

namespace UIWidgets;

public interface ILayoutBridge
{
	bool IsHorizontal { get; set; }

	bool UpdateContentSizeFitter { get; set; }

	void UpdateLayout();

	void SetFiller(float first, float last);

	Vector2 GetItemSize();

	float GetMargin();

	float GetFullMargin();

	float GetSpacing();
}
