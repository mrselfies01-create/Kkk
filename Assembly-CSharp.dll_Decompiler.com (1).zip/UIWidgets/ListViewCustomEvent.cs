using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewCustomEvent : UnityEvent<int>
{
}
