using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class AccordionItemComponent : MonoBehaviour, IPointerClickHandler, ISubmitHandler, IEventSystemHandler
{
	public UnityEvent OnClick = new UnityEvent();

	public virtual void OnPointerClick(PointerEventData eventData)
	{
		OnClick.Invoke();
	}

	public virtual void OnSubmit(BaseEventData eventData)
	{
		OnClick.Invoke();
	}
}
