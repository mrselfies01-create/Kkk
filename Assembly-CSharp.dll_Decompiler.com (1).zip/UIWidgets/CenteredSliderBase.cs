using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public abstract class CenteredSliderBase<T> : MonoBehaviour, IPointerClickHandler, IEventSystemHandler where T : struct
{
	[Serializable]
	public class OnChangeEvent : UnityEvent<T>
	{
	}

	[SerializeField]
	protected T _value;

	[SerializeField]
	protected T step;

	[SerializeField]
	protected T limitMin;

	[SerializeField]
	protected T limitMax;

	[SerializeField]
	protected RangeSliderHandle handle;

	protected RectTransform handleRect;

	[SerializeField]
	protected RectTransform UsableRangeRect;

	[SerializeField]
	protected RectTransform FillRect;

	protected RectTransform rangeSliderRect;

	public OnChangeEvent OnValuesChange = new OnChangeEvent();

	public UnityEvent OnChange = new UnityEvent();

	public bool WholeNumberOfSteps;

	private bool isInitCalled;

	public T Value
	{
		get
		{
			return _value;
		}
		set
		{
			SetValue(value);
		}
	}

	public T Step
	{
		get
		{
			return step;
		}
		set
		{
			step = value;
		}
	}

	public T LimitMin
	{
		get
		{
			return limitMin;
		}
		set
		{
			limitMin = value;
			SetValue(_value);
		}
	}

	public T LimitMax
	{
		get
		{
			return limitMax;
		}
		set
		{
			limitMax = value;
			SetValue(_value);
		}
	}

	public RectTransform HandleRect
	{
		get
		{
			if ((Object)(object)handle != (Object)null && (Object)(object)handleRect == (Object)null)
			{
				ref RectTransform reference = ref handleRect;
				Transform transform = ((Component)handle).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return handleRect;
		}
	}

	public RangeSliderHandle Handle
	{
		get
		{
			return handle;
		}
		set
		{
			SetHandle(value);
		}
	}

	public RectTransform RangeSliderRect
	{
		get
		{
			if ((Object)(object)rangeSliderRect == (Object)null)
			{
				ref RectTransform reference = ref rangeSliderRect;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rangeSliderRect;
		}
	}

	protected virtual void Init()
	{
		if (!isInitCalled)
		{
			isInitCalled = true;
			SetHandle(handle);
			UpdateHandle();
			UpdateFill();
		}
	}

	protected virtual void SetValue(T value)
	{
		if (!EqualityComparer<T>.Default.Equals(_value, InBounds(value)))
		{
			_value = InBounds(value);
			UpdateHandle();
			((UnityEvent<T>)OnValuesChange).Invoke(_value);
			OnChange.Invoke();
		}
	}

	protected virtual void SetHandle(RangeSliderHandle value)
	{
		handle = value;
		handle.IsHorizontal = IsHorizontal;
		handle.PositionLimits = PositionLimits;
		handle.PositionChanged = UpdateValue;
		handle.Increase = Increase;
		handle.Decrease = Decrease;
	}

	protected virtual void Start()
	{
		Init();
	}

	public void SetLimit(T min, T max)
	{
		limitMin = min;
		limitMax = max;
		LimitMin = limitMin;
		LimitMax = limitMax;
	}

	protected virtual bool IsHorizontal()
	{
		return true;
	}

	protected float RangeSize()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		float result;
		if (IsHorizontal())
		{
			Rect rect = UsableRangeRect.rect;
			result = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = UsableRangeRect.rect;
			result = ((Rect)(ref rect2)).height;
		}
		return result;
	}

	protected float HandleSize()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		float result;
		if (IsHorizontal())
		{
			Rect rect = HandleRect.rect;
			result = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = HandleRect.rect;
			result = ((Rect)(ref rect2)).height;
		}
		return result;
	}

	protected void UpdateValue(float position)
	{
		_value = PositionToValue(position - GetStartPoint());
		UpdateHandle();
		((UnityEvent<T>)OnValuesChange).Invoke(_value);
		OnChange.Invoke();
	}

	protected abstract float ValueToPosition(T value);

	protected abstract T PositionToValue(float position);

	protected float GetStartPoint()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return (!IsHorizontal()) ? ((0f - UsableRangeRect.sizeDelta.y) / 2f) : ((0f - UsableRangeRect.sizeDelta.x) / 2f);
	}

	protected abstract Vector2 PositionLimits();

	protected abstract T InBounds(T value);

	protected abstract void Increase();

	protected abstract void Decrease();

	protected void UpdateHandle()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		Vector2 anchoredPosition = HandleRect.anchoredPosition;
		if (IsHorizontal())
		{
			float num = ValueToPosition(_value);
			Rect rect = HandleRect.rect;
			anchoredPosition.x = num + ((Rect)(ref rect)).width * (HandleRect.pivot.x - 0.5f);
		}
		else
		{
			float num2 = ValueToPosition(_value);
			Rect rect2 = HandleRect.rect;
			anchoredPosition.y = num2 + ((Rect)(ref rect2)).width * (HandleRect.pivot.x - 0.5f);
		}
		HandleRect.anchoredPosition = anchoredPosition;
		UpdateFill();
	}

	protected abstract bool IsPositiveValue();

	protected virtual void UpdateFill()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		FillRect.anchorMin = new Vector2(0.5f, 0.5f);
		FillRect.anchorMax = new Vector2(0.5f, 0.5f);
		if (IsHorizontal())
		{
			if (IsPositiveValue())
			{
				FillRect.pivot = new Vector2(0f, 0.5f);
				FillRect.SetSizeWithCurrentAnchors((Axis)0, ((Transform)HandleRect).localPosition.x - ((Transform)UsableRangeRect).localPosition.x);
			}
			else
			{
				FillRect.pivot = new Vector2(1f, 0.5f);
				FillRect.SetSizeWithCurrentAnchors((Axis)0, ((Transform)UsableRangeRect).localPosition.x - ((Transform)HandleRect).localPosition.x);
			}
		}
		else if (IsPositiveValue())
		{
			FillRect.pivot = new Vector2(0.5f, 0f);
			FillRect.SetSizeWithCurrentAnchors((Axis)1, ((Transform)HandleRect).localPosition.y - ((Transform)UsableRangeRect).localPosition.y);
		}
		else
		{
			FillRect.pivot = new Vector2(0.5f, 1f);
			FillRect.SetSizeWithCurrentAnchors((Axis)1, ((Transform)UsableRangeRect).localPosition.y - ((Transform)HandleRect).localPosition.y);
		}
	}

	public virtual void OnPointerClick(PointerEventData eventData)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		if (RectTransformUtility.ScreenPointToLocalPointInRectangle(UsableRangeRect, eventData.position, eventData.pressEventCamera, ref val))
		{
			Vector2 val2 = val;
			Rect rect = UsableRangeRect.rect;
			val = val2 - ((Rect)(ref rect)).position;
			float position = ((!IsHorizontal()) ? val.y : val.x) + GetStartPoint();
			UpdateValue(position);
		}
	}
}
