using System;
using UnityEngine;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ColorRGBChangedEvent : UnityEvent<Color32>
{
}
