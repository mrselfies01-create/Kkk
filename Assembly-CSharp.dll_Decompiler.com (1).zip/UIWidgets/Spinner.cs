using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/Spinner", 270)]
public class Spinner : SpinnerBase<int>
{
	public OnChangeEventInt onValueChangeInt = new OnChangeEventInt();

	public SubmitEventInt onEndEditInt = new SubmitEventInt();

	public Spinner()
	{
		_max = 100;
		_step = 1;
	}

	public override void Plus()
	{
		base.Value += base.Step;
	}

	public override void Minus()
	{
		base.Value -= base.Step;
	}

	protected override void SetValue(int newValue)
	{
		if (_value != InBounds(newValue))
		{
			_value = InBounds(newValue);
			((InputField)this).text = _value.ToString();
			((UnityEvent<int>)onValueChangeInt).Invoke(_value);
		}
	}

	protected override void ValueChange(string value)
	{
		if (Validation != SpinnerValidation.OnEndInput)
		{
			if (value.Length == 0)
			{
				value = "0";
			}
			SetValue(int.Parse(value));
		}
	}

	protected override void ValueEndEdit(string value)
	{
		if (value.Length == 0)
		{
			value = "0";
		}
		SetValue(int.Parse(value));
		((UnityEvent<int>)onEndEditInt).Invoke(_value);
	}

	protected override char ValidateShort(string validateText, int charIndex, char addedChar)
	{
		if (charIndex != 0 || validateText.Length <= 0 || validateText[0] != '-')
		{
			if (addedChar >= '0' && addedChar <= '9')
			{
				return addedChar;
			}
			if (addedChar == '-' && charIndex == 0 && base.Min < 0)
			{
				return addedChar;
			}
		}
		return '\0';
	}

	protected override char ValidateFull(string validateText, int charIndex, char addedChar)
	{
		string text = validateText.Insert(charIndex, addedChar.ToString());
		if (base.Min > 0 && charIndex == 0 && addedChar == '-')
		{
			return '\0';
		}
		int num = ((text.Length <= 0 || text[0] != '-') ? 1 : 2);
		if (text.Length >= num)
		{
			if (!int.TryParse(text, out var result))
			{
				return '\0';
			}
			if (result != InBounds(result))
			{
				return '\0';
			}
			_value = result;
		}
		return addedChar;
	}

	protected override int InBounds(int value)
	{
		return Mathf.Clamp(value, _min, _max);
	}
}
