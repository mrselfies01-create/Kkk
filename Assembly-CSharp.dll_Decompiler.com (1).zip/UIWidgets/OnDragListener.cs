using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class OnDragListener : MonoBehaviour, IDragHandler, IEventSystemHandler
{
	[SerializeField]
	public PointerUnityEvent OnDragEvent = new PointerUnityEvent();

	public virtual void OnDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)OnDragEvent).Invoke(eventData);
	}
}
