using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

public abstract class DragSupport<T> : BaseDragSupport, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	[SerializeField]
	public Texture2D AllowDropCursor;

	[SerializeField]
	public Vector2 AllowDropCursorHotSpot = new Vector2(4f, 2f);

	[SerializeField]
	public Texture2D DeniedDropCursor;

	[SerializeField]
	public Vector2 DeniedDropCursorHotSpot = new Vector2(4f, 2f);

	[SerializeField]
	public Texture2D DefaultCursorTexture;

	[SerializeField]
	public Vector2 DefaultCursorHotSpot;

	protected bool IsDragged;

	protected IDropSupport<T> oldTarget;

	protected IDropSupport<T> currentTarget;

	private List<RaycastResult> raycastResults = new List<RaycastResult>();

	public T Data { get; protected set; }

	public virtual bool CanDrag(PointerEventData eventData)
	{
		return true;
	}

	protected abstract void InitDrag(PointerEventData eventData);

	public virtual void Dropped(bool success)
	{
		Data = default(T);
	}

	public virtual void OnBeginDrag(PointerEventData eventData)
	{
		if (CanDrag(eventData))
		{
			IsDragged = true;
			InitDrag(eventData);
		}
	}

	public virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		if (IsDragged)
		{
			oldTarget = currentTarget;
			currentTarget = FindTarget(eventData);
			if (oldTarget != null && currentTarget != oldTarget)
			{
				oldTarget.DropCanceled(Data, eventData);
			}
			if (currentTarget != null)
			{
				Cursor.SetCursor(AllowDropCursor, AllowDropCursorHotSpot, Utilites.GetCursorMode());
			}
			else
			{
				Cursor.SetCursor(DeniedDropCursor, DeniedDropCursorHotSpot, Utilites.GetCursorMode());
			}
			Transform obj = base.CanvasTransform;
			Vector2 val = default(Vector2);
			if (RectTransformUtility.ScreenPointToLocalPointInRectangle((RectTransform)(object)((obj is RectTransform) ? obj : null), Vector2.op_Implicit(Input.mousePosition), eventData.pressEventCamera, ref val))
			{
				((Transform)base.DragPoint).localPosition = Vector2.op_Implicit(val);
			}
		}
	}

	protected IDropSupport<T> FindTarget(PointerEventData eventData)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		raycastResults.Clear();
		EventSystem.current.RaycastAll(eventData, raycastResults);
		foreach (RaycastResult raycastResult in raycastResults)
		{
			RaycastResult current = raycastResult;
			if (((RaycastResult)(ref current)).isValid)
			{
				IDropSupport<T> component = ((RaycastResult)(ref current)).gameObject.GetComponent<IDropSupport<T>>();
				if (component != null)
				{
					return (!component.CanReceiveDrop(Data, eventData)) ? null : component;
				}
			}
		}
		return null;
	}

	public virtual void OnEndDrag(PointerEventData eventData)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (IsDragged)
		{
			IDropSupport<T> dropSupport = FindTarget(eventData);
			if (dropSupport != null)
			{
				dropSupport.Drop(Data, eventData);
				Dropped(success: true);
			}
			else
			{
				Dropped(success: false);
			}
			IsDragged = false;
			Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
		}
	}

	protected virtual void OnDestroy()
	{
		if (BaseDragSupport.DragPoints != null && (Object)(object)base.CanvasTransform != (Object)null && BaseDragSupport.DragPoints.ContainsKey(base.CanvasTransform))
		{
			BaseDragSupport.DragPoints.Remove(base.CanvasTransform);
		}
	}
}
