using System;
using System.Collections;
using System.Collections.Generic;

namespace UIWidgets;

public class DialogActions : IDictionary<string, Func<bool>>, IEnumerable, ICollection<KeyValuePair<string, Func<bool>>>, IEnumerable<KeyValuePair<string, Func<bool>>>
{
	private List<string> keys = new List<string>();

	private List<Func<bool>> values = new List<Func<bool>>();

	private List<KeyValuePair<string, Func<bool>>> elements = new List<KeyValuePair<string, Func<bool>>>();

	public int Count => elements.Count;

	public bool IsReadOnly => false;

	public Func<bool> this[string key]
	{
		get
		{
			int index = keys.IndexOf(key);
			return elements[index].Value;
		}
		set
		{
			int index = keys.IndexOf(key);
			elements[index] = new KeyValuePair<string, Func<bool>>(key, value);
		}
	}

	public ICollection<string> Keys => elements.Convert(GetKey);

	public ICollection<Func<bool>> Values => elements.Convert(GetValue);

	private string GetKey(KeyValuePair<string, Func<bool>> item)
	{
		return item.Key;
	}

	private Func<bool> GetValue(KeyValuePair<string, Func<bool>> item)
	{
		return item.Value;
	}

	public void Add(KeyValuePair<string, Func<bool>> item)
	{
		Add(item.Key, item.Value);
	}

	public void Add(string key, Func<bool> value)
	{
		if (key == null)
		{
			throw new ArgumentNullException("key", "Key is null.");
		}
		if (ContainsKey(key))
		{
			throw new ArgumentException($"An element with the same key ({key}) already exists.");
		}
		keys.Add(key);
		values.Add(value);
		elements.Add(new KeyValuePair<string, Func<bool>>(key, value));
	}

	public void Clear()
	{
		keys.Clear();
		values.Clear();
		elements.Clear();
	}

	public bool Contains(KeyValuePair<string, Func<bool>> item)
	{
		return elements.Contains(item);
	}

	public bool ContainsKey(string key)
	{
		if (key == null)
		{
			throw new ArgumentNullException("key", "Key is null.");
		}
		return keys.Contains(key);
	}

	public void CopyTo(KeyValuePair<string, Func<bool>>[] array, int arrayIndex)
	{
		elements.CopyTo(array, arrayIndex);
	}

	public IEnumerator<KeyValuePair<string, Func<bool>>> GetEnumerator()
	{
		return elements.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return elements.GetEnumerator();
	}

	public bool Remove(KeyValuePair<string, Func<bool>> item)
	{
		if (!elements.Contains(item))
		{
			return false;
		}
		int index = elements.IndexOf(item);
		keys.RemoveAt(index);
		values.RemoveAt(index);
		elements.RemoveAt(index);
		return true;
	}

	public bool Remove(string key)
	{
		if (key == null)
		{
			throw new ArgumentNullException("key", "Key is null.");
		}
		if (!ContainsKey(key))
		{
			return false;
		}
		int index = keys.IndexOf(key);
		keys.RemoveAt(index);
		values.RemoveAt(index);
		elements.RemoveAt(index);
		return true;
	}

	public bool TryGetValue(string key, out Func<bool> value)
	{
		if (key == null)
		{
			throw new ArgumentNullException("key", "Key is null.");
		}
		if (!ContainsKey(key))
		{
			value = null;
			return false;
		}
		value = values[keys.IndexOf(key)];
		return true;
	}
}
