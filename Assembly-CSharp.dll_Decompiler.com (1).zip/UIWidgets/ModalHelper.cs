using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(RectTransform))]
public class ModalHelper : MonoBehaviour, ITemplatable, IPointerClickHandler, IEventSystemHandler
{
	private bool isTemplate = true;

	private UnityEvent OnClick = new UnityEvent();

	private static Templates<ModalHelper> Templates = new Templates<ModalHelper>();

	private static Dictionary<int, ModalHelper> used = new Dictionary<int, ModalHelper>();

	private static string key = "ModalTemplate";

	public bool IsTemplate
	{
		get
		{
			return isTemplate;
		}
		set
		{
			isTemplate = value;
		}
	}

	public string TemplateName { get; set; }

	private void OnDestroy()
	{
		Templates.Delete(key);
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		OnClick.Invoke();
	}

	public static int Open(MonoBehaviour parent, Sprite sprite = null, Color? color = null, UnityAction onClick = null)
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		if (!Templates.Exists(key))
		{
			Templates.FindTemplates();
			CreateTemplate();
		}
		ModalHelper modalHelper = Templates.Instance(key);
		((Component)modalHelper).transform.SetParent(Utilites.FindCanvas(((Component)parent).transform), false);
		((Component)modalHelper).gameObject.SetActive(true);
		((Component)modalHelper).transform.SetAsLastSibling();
		Transform transform = ((Component)modalHelper).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		val.sizeDelta = new Vector2(0f, 0f);
		val.anchorMin = new Vector2(0f, 0f);
		val.anchorMax = new Vector2(1f, 1f);
		val.anchoredPosition = new Vector2(0f, 0f);
		Image component = ((Component)modalHelper).GetComponent<Image>();
		if ((Object)(object)sprite != (Object)null)
		{
			component.sprite = sprite;
		}
		if (color.HasValue)
		{
			((Graphic)component).color = color.Value;
		}
		((UnityEventBase)modalHelper.OnClick).RemoveAllListeners();
		if (onClick != null)
		{
			modalHelper.OnClick.AddListener(onClick);
		}
		used.Add(((Object)modalHelper).GetInstanceID(), modalHelper);
		return ((Object)modalHelper).GetInstanceID();
	}

	private static void CreateTemplate()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		GameObject val = new GameObject(key);
		ModalHelper template = val.AddComponent<ModalHelper>();
		val.AddComponent<Image>();
		Templates.Add(key, template);
	}

	public static void Close(int index)
	{
		if (used != null && used.ContainsKey(index))
		{
			((UnityEventBase)used[index].OnClick).RemoveAllListeners();
			Templates.ToCache(used[index]);
			used.Remove(index);
		}
	}
}
