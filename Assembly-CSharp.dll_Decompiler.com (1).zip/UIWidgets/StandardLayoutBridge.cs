using System;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class StandardLayoutBridge : ILayoutBridge
{
	private bool isHorizontal;

	private HorizontalOrVerticalLayoutGroup Layout;

	private RectTransform DefaultItem;

	private LayoutElement FirstFiller;

	private LayoutElement LastFiller;

	public bool IsHorizontal
	{
		get
		{
			return isHorizontal;
		}
		set
		{
			throw new NotSupportedException("HorizontalLayoutGroup Or VerticalLayoutGroup direction cannot be change in runtime.");
		}
	}

	public bool UpdateContentSizeFitter { get; set; }

	public StandardLayoutBridge(HorizontalOrVerticalLayoutGroup layout, RectTransform defaultItem)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected O, but got Unknown
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Expected O, but got Unknown
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		Utilites.UpdateLayout((LayoutGroup)(object)layout);
		Layout = layout;
		DefaultItem = defaultItem;
		isHorizontal = layout is HorizontalLayoutGroup;
		GameObject val = new GameObject("FirstFiller");
		Transform transform = val.transform;
		RectTransform val2 = (RectTransform)(((object)((transform is RectTransform) ? transform : null)) ?? ((object)val.AddComponent<RectTransform>()));
		((Transform)val2).SetParent(((Component)Layout).transform);
		((Transform)val2).localScale = Vector3.one;
		FirstFiller = val.AddComponent<LayoutElement>();
		GameObject val3 = new GameObject("LastFiller");
		Transform transform2 = val3.transform;
		RectTransform val4 = (RectTransform)(((object)((transform2 is RectTransform) ? transform2 : null)) ?? ((object)val3.AddComponent<RectTransform>()));
		((Transform)val4).SetParent(((Component)Layout).transform);
		((Transform)val4).localScale = Vector3.one;
		LastFiller = val3.AddComponent<LayoutElement>();
		Vector2 itemSize = GetItemSize();
		if (IsHorizontal)
		{
			val2.SetSizeWithCurrentAnchors((Axis)1, itemSize.y);
			val4.SetSizeWithCurrentAnchors((Axis)1, itemSize.y);
		}
		else
		{
			val2.SetSizeWithCurrentAnchors((Axis)0, itemSize.x);
			val4.SetSizeWithCurrentAnchors((Axis)0, itemSize.x);
		}
	}

	public void UpdateLayout()
	{
		Utilites.UpdateLayout((LayoutGroup)(object)Layout);
	}

	public void SetFiller(float first, float last)
	{
		if ((Object)(object)FirstFiller != (Object)null)
		{
			if (first == 0f)
			{
				((Component)FirstFiller).gameObject.SetActive(false);
			}
			else
			{
				((Component)FirstFiller).gameObject.SetActive(true);
				((Component)FirstFiller).transform.SetAsFirstSibling();
				if (IsHorizontal)
				{
					FirstFiller.preferredWidth = first;
				}
				else
				{
					FirstFiller.preferredHeight = first;
				}
			}
		}
		if (!((Object)(object)LastFiller != (Object)null))
		{
			return;
		}
		if (last == 0f)
		{
			((Component)LastFiller).gameObject.SetActive(false);
			return;
		}
		((Component)LastFiller).gameObject.SetActive(true);
		if (IsHorizontal)
		{
			LastFiller.preferredWidth = last;
		}
		else
		{
			LastFiller.preferredHeight = last;
		}
		((Component)LastFiller).transform.SetAsLastSibling();
	}

	public Vector2 GetItemSize()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(LayoutUtility.GetPreferredWidth(DefaultItem), LayoutUtility.GetPreferredHeight(DefaultItem));
	}

	public float GetMargin()
	{
		return (!IsHorizontal) ? ((LayoutGroup)Layout).padding.top : ((LayoutGroup)Layout).padding.left;
	}

	public float GetFullMargin()
	{
		return (!IsHorizontal) ? ((LayoutGroup)Layout).padding.vertical : ((LayoutGroup)Layout).padding.horizontal;
	}

	public float GetSpacing()
	{
		return Layout.spacing;
	}
}
