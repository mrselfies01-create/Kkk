namespace UIWidgets;

public enum ColorPickerInputMode
{
	None = -1,
	RGB,
	HSV
}
