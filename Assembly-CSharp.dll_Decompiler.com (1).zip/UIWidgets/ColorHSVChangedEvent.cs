using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ColorHSVChangedEvent : UnityEvent<ColorHSV>
{
}
