using EasyLayout;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public static class Utilites
{
	public static void FixInstantiated(Component source, Component instance)
	{
		FixInstantiated(source.gameObject, instance.gameObject);
	}

	public static void FixInstantiated(GameObject source, GameObject instance)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = source.transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		Transform transform2 = instance.transform;
		RectTransform val2 = (RectTransform)(object)((transform2 is RectTransform) ? transform2 : null);
		((Transform)val2).localPosition = ((Transform)val).localPosition;
		((Transform)val2).position = ((Transform)val).position;
		((Transform)val2).rotation = ((Transform)val).rotation;
		((Transform)val2).localScale = ((Transform)val).localScale;
		val2.anchoredPosition = val.anchoredPosition;
		val2.sizeDelta = val.sizeDelta;
	}

	public static Transform FindCanvas(Transform currentObject)
	{
		Canvas componentInParent = ((Component)currentObject).GetComponentInParent<Canvas>();
		if ((Object)(object)componentInParent == (Object)null)
		{
			return null;
		}
		return ((Component)componentInParent).transform;
	}

	public static Vector3 CalculateDragPosition(Vector3 screenPosition, Canvas canvas, RectTransform canvasRect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Invalid comparison between Unknown and I4
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Invalid comparison between Unknown and I4
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		Vector2 sizeDelta = canvasRect.sizeDelta;
		Vector2 val = Vector2.zero;
		Vector2 val2 = sizeDelta;
		bool flag = (int)canvas.renderMode == 0;
		bool flag2 = (int)canvas.renderMode == 1 && (Object)(object)canvas.worldCamera == (Object)null;
		Vector3 result;
		if (flag || flag2)
		{
			result = screenPosition;
		}
		else
		{
			Ray val3 = canvas.worldCamera.ScreenPointToRay(screenPosition);
			Plane val4 = default(Plane);
			((Plane)(ref val4))._002Ector(((Transform)canvasRect).forward, ((Transform)canvasRect).position);
			float num = default(float);
			((Plane)(ref val4)).Raycast(val3, ref num);
			result = ((Transform)canvasRect).InverseTransformPoint(((Ray)(ref val3)).origin + ((Ray)(ref val3)).direction * num);
			val = -Vector2.Scale(val2, canvasRect.pivot);
			val2 = sizeDelta - val;
		}
		result.x = Mathf.Clamp(result.x, val.x, val2.y);
		result.y = Mathf.Clamp(result.y, val.x, val2.y);
		return result;
	}

	public static CursorMode GetCursorMode()
	{
		return (CursorMode)0;
	}

	public static void UpdateLayout(LayoutGroup layout)
	{
		if (layout is global::EasyLayout.EasyLayout)
		{
			(layout as global::EasyLayout.EasyLayout).UpdateLayout();
			return;
		}
		layout.CalculateLayoutInputHorizontal();
		layout.SetLayoutHorizontal();
		layout.CalculateLayoutInputVertical();
		layout.SetLayoutVertical();
	}
}
