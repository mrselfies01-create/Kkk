using System;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

[Serializable]
public class AccordionItem
{
	public GameObject ToggleObject;

	public GameObject ContentObject;

	public bool Open;

	[HideInInspector]
	public Coroutine CurrentCorutine;

	[HideInInspector]
	public RectTransform ContentObjectRect;

	[HideInInspector]
	public LayoutElement ContentLayoutElement;

	[HideInInspector]
	public float ContentObjectHeight;

	[HideInInspector]
	public float ContentObjectWidth;
}
