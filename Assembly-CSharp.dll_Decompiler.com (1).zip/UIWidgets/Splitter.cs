using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class Splitter : MonoBehaviour, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	public SplitterType Type = SplitterType.Vertical;

	[SerializeField]
	public bool UpdateRectTransforms = true;

	[SerializeField]
	public bool UpdateLayoutElements = true;

	[SerializeField]
	public Camera CurrentCamera;

	[SerializeField]
	public Texture2D CursorTexture;

	[SerializeField]
	public Vector2 CursorHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D DefaultCursorTexture;

	[SerializeField]
	public Vector2 DefaultCursorHotSpot;

	public SplitterResizeEvent OnStartResize = new SplitterResizeEvent();

	public SplitterResizeEvent OnEndResize = new SplitterResizeEvent();

	private RectTransform rectTransform;

	private Canvas canvas;

	private RectTransform leftTarget;

	private RectTransform rightTarget;

	private LayoutElement leftTargetElement;

	private LayoutElement rightTargetElement;

	private Vector2 summarySize;

	private bool processDrag;

	private bool cursorSetted;

	public RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	private LayoutElement LeftTargetElement
	{
		get
		{
			if ((Object)(object)leftTargetElement == (Object)null)
			{
				leftTargetElement = ((Component)leftTarget).GetComponent<LayoutElement>() ?? ((Component)leftTarget).gameObject.AddComponent<LayoutElement>();
			}
			return leftTargetElement;
		}
	}

	private LayoutElement RightTargetElement
	{
		get
		{
			if ((Object)(object)rightTargetElement == (Object)null)
			{
				rightTargetElement = ((Component)rightTarget).GetComponent<LayoutElement>() ?? ((Component)rightTarget).gameObject.AddComponent<LayoutElement>();
			}
			return rightTargetElement;
		}
	}

	private void Start()
	{
		Init();
	}

	public void OnInitializePotentialDrag(PointerEventData eventData)
	{
		Init();
	}

	public void Init()
	{
		canvas = ((Component)Utilites.FindCanvas(((Component)this).transform)).GetComponent<Canvas>();
	}

	private void LateUpdate()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		if (!processDrag && !((Object)(object)CursorTexture == (Object)null) && Input.mousePresent && RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, Vector2.op_Implicit(Input.mousePosition), CurrentCamera, ref val))
		{
			Rect rect = RectTransform.rect;
			if (((Rect)(ref rect)).Contains(val))
			{
				cursorSetted = true;
				Cursor.SetCursor(CursorTexture, CursorHotSpot, Utilites.GetCursorMode());
			}
			else if (cursorSetted)
			{
				cursorSetted = false;
				Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
			}
		}
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		processDrag = false;
		Vector2 val = default(Vector2);
		if (RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.pressPosition, eventData.pressEventCamera, ref val))
		{
			int siblingIndex = ((Component)this).transform.GetSiblingIndex();
			if (siblingIndex != 0 && ((Component)this).transform.parent.childCount != siblingIndex + 1)
			{
				Cursor.SetCursor(CursorTexture, CursorHotSpot, Utilites.GetCursorMode());
				cursorSetted = true;
				processDrag = true;
				ref RectTransform reference = ref leftTarget;
				Transform child = ((Component)this).transform.parent.GetChild(siblingIndex - 1);
				reference = (RectTransform)(object)((child is RectTransform) ? child : null);
				LayoutElement obj = LeftTargetElement;
				Rect rect = leftTarget.rect;
				obj.preferredWidth = ((Rect)(ref rect)).width;
				LayoutElement obj2 = LeftTargetElement;
				Rect rect2 = leftTarget.rect;
				obj2.preferredHeight = ((Rect)(ref rect2)).height;
				ref RectTransform reference2 = ref rightTarget;
				Transform child2 = ((Component)this).transform.parent.GetChild(siblingIndex + 1);
				reference2 = (RectTransform)(object)((child2 is RectTransform) ? child2 : null);
				LayoutElement obj3 = RightTargetElement;
				Rect rect3 = rightTarget.rect;
				obj3.preferredWidth = ((Rect)(ref rect3)).width;
				LayoutElement obj4 = RightTargetElement;
				Rect rect4 = rightTarget.rect;
				obj4.preferredHeight = ((Rect)(ref rect4)).height;
				Rect rect5 = leftTarget.rect;
				float width = ((Rect)(ref rect5)).width;
				Rect rect6 = rightTarget.rect;
				float num = width + ((Rect)(ref rect6)).width;
				Rect rect7 = leftTarget.rect;
				float height = ((Rect)(ref rect7)).height;
				Rect rect8 = rightTarget.rect;
				summarySize = new Vector2(num, height + ((Rect)(ref rect8)).height);
				((UnityEvent<Splitter>)OnStartResize).Invoke(this);
			}
		}
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
		cursorSetted = false;
		processDrag = false;
		((UnityEvent<Splitter>)OnEndResize).Invoke(this);
	}

	public void OnDrag(PointerEventData eventData)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (processDrag)
		{
			if ((Object)(object)canvas == (Object)null)
			{
				throw new MissingComponentException(((Object)((Component)this).gameObject).name + " not in Canvas hierarchy.");
			}
			Vector2 val = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position, CurrentCamera, ref val);
			Vector2 val2 = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position - eventData.delta, CurrentCamera, ref val2);
			Vector2 delta = val - val2;
			if (UpdateRectTransforms)
			{
				PerformUpdateRectTransforms(delta);
			}
			if (UpdateLayoutElements)
			{
				PerformUpdateLayoutElements(delta);
			}
		}
	}

	private bool IsHorizontal()
	{
		return SplitterType.Horizontal == Type;
	}

	private void PerformUpdateRectTransforms(Vector2 delta)
	{
		if (!IsHorizontal())
		{
			float num;
			float num2;
			if (delta.x > 0f)
			{
				num = Mathf.Min(LeftTargetElement.preferredWidth + delta.x, summarySize.x - RightTargetElement.minWidth);
				num2 = summarySize.x - LeftTargetElement.preferredWidth;
			}
			else
			{
				num2 = Mathf.Min(RightTargetElement.preferredWidth - delta.x, summarySize.x - LeftTargetElement.minWidth);
				num = summarySize.x - RightTargetElement.preferredWidth;
			}
			leftTarget.SetSizeWithCurrentAnchors((Axis)0, num);
			rightTarget.SetSizeWithCurrentAnchors((Axis)0, num2);
			return;
		}
		delta.y *= -1f;
		float num3;
		float num4;
		if (delta.y > 0f)
		{
			num3 = Mathf.Min(LeftTargetElement.preferredHeight + delta.y, summarySize.y - RightTargetElement.minHeight);
			num4 = summarySize.y - LeftTargetElement.preferredHeight;
		}
		else
		{
			num4 = Mathf.Min(RightTargetElement.preferredHeight - delta.y, summarySize.y - LeftTargetElement.minHeight);
			num3 = summarySize.y - RightTargetElement.preferredHeight;
		}
		leftTarget.SetSizeWithCurrentAnchors((Axis)1, num3);
		rightTarget.SetSizeWithCurrentAnchors((Axis)1, num4);
	}

	private void PerformUpdateLayoutElements(Vector2 delta)
	{
		if (!IsHorizontal())
		{
			if (delta.x > 0f)
			{
				LeftTargetElement.preferredWidth = Mathf.Min(LeftTargetElement.preferredWidth + delta.x, summarySize.x - RightTargetElement.minWidth);
				RightTargetElement.preferredWidth = summarySize.x - LeftTargetElement.preferredWidth;
			}
			else
			{
				RightTargetElement.preferredWidth = Mathf.Min(RightTargetElement.preferredWidth - delta.x, summarySize.x - LeftTargetElement.minWidth);
				LeftTargetElement.preferredWidth = summarySize.x - RightTargetElement.preferredWidth;
			}
			return;
		}
		delta.y *= -1f;
		if (delta.y > 0f)
		{
			LeftTargetElement.preferredHeight = Mathf.Min(LeftTargetElement.preferredHeight + delta.y, summarySize.y - RightTargetElement.minHeight);
			RightTargetElement.preferredHeight = summarySize.y - LeftTargetElement.preferredHeight;
		}
		else
		{
			RightTargetElement.preferredHeight = Mathf.Min(RightTargetElement.preferredHeight - delta.y, summarySize.y - LeftTargetElement.minHeight);
			LeftTargetElement.preferredHeight = summarySize.y - RightTargetElement.preferredHeight;
		}
	}
}
