using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerRGBBlock : MonoBehaviour
{
	[SerializeField]
	private Slider rSlider;

	[SerializeField]
	private Spinner rInput;

	[SerializeField]
	private Image rSliderBackground;

	[SerializeField]
	private Slider gSlider;

	[SerializeField]
	private Spinner gInput;

	[SerializeField]
	private Image gSliderBackground;

	[SerializeField]
	private Slider bSlider;

	[SerializeField]
	private Spinner bInput;

	[SerializeField]
	private Image bSliderBackground;

	[SerializeField]
	private Shader defaultShader;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected bool inUpdateMode;

	protected Color32 currentColor;

	public Slider RSlider
	{
		get
		{
			return rSlider;
		}
		set
		{
			SetRSlider(value);
		}
	}

	public Spinner RInput
	{
		get
		{
			return rInput;
		}
		set
		{
			SetRInput(value);
		}
	}

	public Image RSliderBackground
	{
		get
		{
			return rSliderBackground;
		}
		set
		{
			rSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Slider GSlider
	{
		get
		{
			return gSlider;
		}
		set
		{
			SetGSlider(value);
		}
	}

	public Spinner GInput
	{
		get
		{
			return gInput;
		}
		set
		{
			SetGInput(value);
		}
	}

	public Image GSliderBackground
	{
		get
		{
			return gSliderBackground;
		}
		set
		{
			gSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Slider BSlider
	{
		get
		{
			return bSlider;
		}
		set
		{
			SetBSlider(value);
		}
	}

	public Spinner BInput
	{
		get
		{
			return bInput;
		}
		set
		{
			SetBInput(value);
		}
	}

	public Image BSliderBackground
	{
		get
		{
			return bSliderBackground;
		}
		set
		{
			bSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Shader DefaultShader
	{
		get
		{
			return defaultShader;
		}
		set
		{
			defaultShader = value;
			UpdateMaterial();
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
			((Component)this).gameObject.SetActive(inputMode == ColorPickerInputMode.RGB);
			UpdateView();
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			paletteMode = value;
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			RSlider = rSlider;
			RInput = rInput;
			RSliderBackground = rSliderBackground;
			GSlider = gSlider;
			GInput = gInput;
			GSliderBackground = gSliderBackground;
			BSlider = bSlider;
			BInput = bInput;
			BSliderBackground = bSliderBackground;
		}
	}

	protected virtual void OnEnable()
	{
		UpdateMaterial();
	}

	protected virtual void SetRSlider(Slider value)
	{
		if ((Object)(object)rSlider != (Object)null)
		{
			((UnityEvent<float>)(object)rSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		rSlider = value;
		if ((Object)(object)rSlider != (Object)null)
		{
			((UnityEvent<float>)(object)rSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetRInput(Spinner value)
	{
		if ((Object)(object)rInput != (Object)null)
		{
			((UnityEvent<string>)(object)((InputField)rInput).onEndEdit).RemoveListener((UnityAction<string>)SpinnerValueChanged);
		}
		rInput = value;
		if ((Object)(object)rInput != (Object)null)
		{
			((UnityEvent<string>)(object)((InputField)rInput).onEndEdit).AddListener((UnityAction<string>)SpinnerValueChanged);
		}
	}

	protected virtual void SetGSlider(Slider value)
	{
		if ((Object)(object)gSlider != (Object)null)
		{
			((UnityEvent<float>)(object)gSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		gSlider = value;
		if ((Object)(object)gSlider != (Object)null)
		{
			((UnityEvent<float>)(object)gSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetGInput(Spinner value)
	{
		if ((Object)(object)gInput != (Object)null)
		{
			((UnityEvent<int>)gInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		gInput = value;
		if ((Object)(object)gInput != (Object)null)
		{
			((UnityEvent<int>)gInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
		}
	}

	protected virtual void SetBSlider(Slider value)
	{
		if ((Object)(object)bSlider != (Object)null)
		{
			((UnityEvent<float>)(object)bSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		bSlider = value;
		if ((Object)(object)bSlider != (Object)null)
		{
			((UnityEvent<float>)(object)bSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetBInput(Spinner value)
	{
		if ((Object)(object)bInput != (Object)null)
		{
			((UnityEvent<int>)bInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		bInput = value;
		if ((Object)(object)bInput != (Object)null)
		{
			((UnityEvent<int>)bInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
		}
	}

	private void SpinnerValueChanged(int value)
	{
		ValueChanged();
	}

	private void SpinnerValueChanged(string str)
	{
		ValueChanged();
	}

	private void SliderValueChanged(float value)
	{
		ValueChanged();
	}

	protected virtual void ValueChanged()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (!inUpdateMode)
		{
			Color32 val = default(Color32);
			((Color32)(ref val))._002Ector(GetRed(), GetGreen(), GetBlue(), currentColor.a);
			((UnityEvent<Color32>)OnChangeRGB).Invoke(val);
		}
	}

	protected byte GetRed()
	{
		if ((Object)(object)rSlider != (Object)null)
		{
			return (byte)rSlider.value;
		}
		if ((Object)(object)rInput != (Object)null)
		{
			return (byte)rInput.Value;
		}
		return currentColor.r;
	}

	protected byte GetGreen()
	{
		if ((Object)(object)gSlider != (Object)null)
		{
			return (byte)gSlider.value;
		}
		if ((Object)(object)gInput != (Object)null)
		{
			return (byte)gInput.Value;
		}
		return currentColor.g;
	}

	protected byte GetBlue()
	{
		if ((Object)(object)bSlider != (Object)null)
		{
			return (byte)bSlider.value;
		}
		if ((Object)(object)bInput != (Object)null)
		{
			return (byte)bInput.Value;
		}
		return currentColor.b;
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	protected virtual void UpdateView()
	{
		UpdateViewReal();
	}

	protected virtual void UpdateViewReal()
	{
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		inUpdateMode = true;
		if ((Object)(object)rSlider != (Object)null)
		{
			rSlider.value = (int)currentColor.r;
		}
		if ((Object)(object)rInput != (Object)null)
		{
			rInput.Value = currentColor.r;
		}
		if ((Object)(object)gSlider != (Object)null)
		{
			gSlider.value = (int)currentColor.g;
		}
		if ((Object)(object)gInput != (Object)null)
		{
			gInput.Value = currentColor.g;
		}
		if ((Object)(object)bSlider != (Object)null)
		{
			bSlider.value = (int)currentColor.b;
		}
		if ((Object)(object)bInput != (Object)null)
		{
			bInput.Value = currentColor.b;
		}
		if ((Object)(object)rSliderBackground != (Object)null)
		{
			((Graphic)rSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32((byte)0, currentColor.g, currentColor.b, byte.MaxValue)));
			((Graphic)rSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(byte.MaxValue, currentColor.g, currentColor.b, byte.MaxValue)));
		}
		if ((Object)(object)gSliderBackground != (Object)null)
		{
			((Graphic)gSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32(currentColor.r, (byte)0, currentColor.b, byte.MaxValue)));
			((Graphic)gSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(currentColor.r, byte.MaxValue, currentColor.b, byte.MaxValue)));
		}
		if ((Object)(object)bSliderBackground != (Object)null)
		{
			((Graphic)bSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32(currentColor.r, currentColor.g, (byte)0, byte.MaxValue)));
			((Graphic)bSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(currentColor.r, currentColor.g, byte.MaxValue, byte.MaxValue)));
		}
		inUpdateMode = false;
	}

	protected virtual void UpdateMaterial()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		if (!((Object)(object)defaultShader == (Object)null))
		{
			if ((Object)(object)rSliderBackground != (Object)null)
			{
				((Graphic)rSliderBackground).material = new Material(defaultShader);
			}
			if ((Object)(object)gSliderBackground != (Object)null)
			{
				((Graphic)gSliderBackground).material = new Material(defaultShader);
			}
			if ((Object)(object)bSliderBackground != (Object)null)
			{
				((Graphic)bSliderBackground).material = new Material(defaultShader);
			}
			UpdateViewReal();
		}
	}

	protected virtual void OnDestroy()
	{
		rSlider = null;
		rInput = null;
		gSlider = null;
		gInput = null;
		bSlider = null;
		bInput = null;
	}
}
