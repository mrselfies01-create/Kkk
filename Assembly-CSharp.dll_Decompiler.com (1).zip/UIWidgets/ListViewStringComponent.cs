using UnityEngine.UI;

namespace UIWidgets;

public class ListViewStringComponent : ListViewItem
{
	public Text Text;
}
