using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class ListViewIconsItemComponent : ListViewItem, IResizableItem
{
	[SerializeField]
	public Image Icon;

	[SerializeField]
	public Text Text;

	public bool SetNativeSize = true;

	private ListViewIconsItemDescription item;

	public GameObject[] ObjectsToResize => (GameObject[])(object)new GameObject[2]
	{
		((Component)((Component)Icon).transform.parent).gameObject,
		((Component)Text).gameObject
	};

	public ListViewIconsItemDescription Item => item;

	public virtual void SetData(ListViewIconsItemDescription newItem)
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		item = newItem;
		if (item == null)
		{
			if ((Object)(object)Icon != (Object)null)
			{
				Icon.sprite = null;
			}
			Text.text = string.Empty;
		}
		else
		{
			if ((Object)(object)Icon != (Object)null)
			{
				Icon.sprite = item.Icon;
			}
			Text.text = item.LocalizedName ?? item.Name;
		}
		if (SetNativeSize && (Object)(object)Icon != (Object)null)
		{
			((Graphic)Icon).SetNativeSize();
		}
		if ((Object)(object)Icon != (Object)null)
		{
			((Graphic)Icon).color = ((!((Object)(object)Icon.sprite == (Object)null)) ? Color.white : Color.clear);
		}
	}

	public override void MovedToCache()
	{
		if ((Object)(object)Icon != (Object)null)
		{
			Icon.sprite = null;
		}
	}
}
