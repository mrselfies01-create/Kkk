using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/TreeView", 252)]
public class TreeView : TreeViewCustom<TreeViewComponent, TreeViewItem>
{
	protected override void SetData(TreeViewComponent component, ListNode<TreeViewItem> item)
	{
		component.SetData(item.Node, item.Depth);
	}

	protected override void HighlightColoring(TreeViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.HighlightColoring(component);
		((Graphic)component.Text).color = HighlightedColor;
	}

	protected override void SelectColoring(TreeViewComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.SelectColoring(component);
		((Graphic)component.Text).color = base.SelectedColor;
	}

	protected override void DefaultColoring(TreeViewComponent component)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)component == (Object)null))
		{
			base.DefaultColoring(component);
			if ((Object)(object)component.Text != (Object)null)
			{
				((Graphic)component.Text).color = base.DefaultColor;
			}
		}
	}
}
