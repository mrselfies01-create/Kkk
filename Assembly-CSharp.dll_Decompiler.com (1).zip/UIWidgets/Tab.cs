using System;
using UnityEngine;

namespace UIWidgets;

[Serializable]
public class Tab
{
	public string Name;

	public GameObject TabObject;
}
