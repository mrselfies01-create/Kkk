namespace UIWidgets;

public enum AccordionDirection
{
	Horizontal,
	Vertical
}
