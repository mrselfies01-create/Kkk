namespace UIWidgets;

public enum ProgressbarTypes
{
	Determinate,
	Indeterminate
}
