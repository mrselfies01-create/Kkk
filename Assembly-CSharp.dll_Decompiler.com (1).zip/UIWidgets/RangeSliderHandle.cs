using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(RectTransform))]
public class RangeSliderHandle : Selectable, IDragHandler, IInitializePotentialDragHandler, ISubmitHandler, IEventSystemHandler
{
	public Func<bool> IsHorizontal = ReturnTrue;

	public Action Decrease = DoNothing;

	public Action Increase = DoNothing;

	public Func<Vector2> PositionLimits;

	public Action<float> PositionChanged;

	public Action OnSubmit = DoNothing;

	private RectTransform rectTransform;

	public RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	private bool CanDrag(PointerEventData eventData)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Invalid comparison between Unknown and I4
		return ((UIBehaviour)this).IsActive() && ((Selectable)this).IsInteractable() && (int)eventData.button == 0;
	}

	private static bool ReturnTrue()
	{
		return true;
	}

	private static void DoNothing()
	{
	}

	void ISubmitHandler.OnSubmit(BaseEventData eventData)
	{
		OnSubmit();
	}

	public virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		if (CanDrag(eventData) && RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position, eventData.pressEventCamera, ref val))
		{
			Vector2 val2 = PositionLimits();
			Vector3 val3 = Vector2.op_Implicit(RectTransform.anchoredPosition);
			if (IsHorizontal())
			{
				val3.x = Mathf.Clamp(val3.x + val.x, val2.x, val2.y);
			}
			else
			{
				val3.y = Mathf.Clamp(val3.y + val.y, val2.x, val2.y);
			}
			if (IsNewPosition(val3))
			{
				RectTransform.anchoredPosition = Vector2.op_Implicit(val3);
				PositionChanged((!IsHorizontal()) ? val3.y : val3.x);
			}
		}
	}

	private bool IsNewPosition(Vector3 pos)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (IsHorizontal())
		{
			return RectTransform.anchoredPosition.x != pos.x;
		}
		return RectTransform.anchoredPosition.y != pos.y;
	}

	public virtual void OnInitializePotentialDrag(PointerEventData eventData)
	{
		eventData.useDragThreshold = false;
	}

	public override void OnMove(AxisEventData eventData)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected I4, but got Unknown
		if (!((UIBehaviour)this).IsActive() || !((Selectable)this).IsInteractable())
		{
			((Selectable)this).OnMove(eventData);
			return;
		}
		MoveDirection moveDir = eventData.moveDir;
		switch ((int)moveDir)
		{
		case 0:
			if (IsHorizontal() && (Object)(object)((Selectable)this).FindSelectableOnLeft() == (Object)null)
			{
				Decrease();
			}
			else
			{
				((Selectable)this).OnMove(eventData);
			}
			break;
		case 2:
			if (IsHorizontal() && (Object)(object)((Selectable)this).FindSelectableOnRight() == (Object)null)
			{
				Increase();
			}
			else
			{
				((Selectable)this).OnMove(eventData);
			}
			break;
		case 1:
			if (!IsHorizontal() && (Object)(object)((Selectable)this).FindSelectableOnUp() == (Object)null)
			{
				Increase();
			}
			else
			{
				((Selectable)this).OnMove(eventData);
			}
			break;
		case 3:
			if (!IsHorizontal() && (Object)(object)((Selectable)this).FindSelectableOnDown() == (Object)null)
			{
				Decrease();
			}
			else
			{
				((Selectable)this).OnMove(eventData);
			}
			break;
		}
	}

	public override Selectable FindSelectableOnLeft()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		Navigation navigation = ((Selectable)this).navigation;
		if ((int)((Navigation)(ref navigation)).mode == 3 && IsHorizontal())
		{
			return null;
		}
		return ((Selectable)this).FindSelectableOnLeft();
	}

	public override Selectable FindSelectableOnRight()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		Navigation navigation = ((Selectable)this).navigation;
		if ((int)((Navigation)(ref navigation)).mode == 3 && IsHorizontal())
		{
			return null;
		}
		return ((Selectable)this).FindSelectableOnRight();
	}

	public override Selectable FindSelectableOnUp()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		Navigation navigation = ((Selectable)this).navigation;
		if ((int)((Navigation)(ref navigation)).mode == 3 && !IsHorizontal())
		{
			return null;
		}
		return ((Selectable)this).FindSelectableOnUp();
	}

	public override Selectable FindSelectableOnDown()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Invalid comparison between Unknown and I4
		Navigation navigation = ((Selectable)this).navigation;
		if ((int)((Navigation)(ref navigation)).mode == 3 && !IsHorizontal())
		{
			return null;
		}
		return ((Selectable)this).FindSelectableOnDown();
	}
}
