using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class TabSelectEvent : UnityEvent<int>
{
}
