using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[RequireComponent(typeof(ListViewIconsItemComponent))]
public class ListViewIconsDragSupport : DragSupport<ListViewIconsItemDescription>
{
	[SerializeField]
	public ListViewIcons ListView;

	[SerializeField]
	public ListViewIconsItemComponent DragInfo;

	protected virtual void Start()
	{
		if ((Object)(object)DragInfo != (Object)null)
		{
			((Component)DragInfo).gameObject.SetActive(false);
		}
	}

	protected override void InitDrag(PointerEventData eventData)
	{
		base.Data = ((Component)this).GetComponent<ListViewIconsItemComponent>().Item;
		ShowDragInfo();
	}

	protected virtual void ShowDragInfo()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)DragInfo == (Object)null))
		{
			((Component)DragInfo).transform.SetParent((Transform)(object)base.DragPoint, false);
			((Component)DragInfo).transform.localPosition = new Vector3(-5f, 5f, 0f);
			DragInfo.SetData(base.Data);
			((Component)DragInfo).gameObject.SetActive(true);
		}
	}

	protected virtual void HideDragInfo()
	{
		if (!((Object)(object)DragInfo == (Object)null))
		{
			((Component)DragInfo).gameObject.SetActive(false);
		}
	}

	public override void Dropped(bool success)
	{
		HideDragInfo();
		if (success && (Object)(object)ListView != (Object)null)
		{
			ListView.DataSource.Remove(base.Data);
		}
		base.Dropped(success);
	}
}
