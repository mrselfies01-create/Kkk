using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerColorBlock : MonoBehaviour
{
	[SerializeField]
	private Image colorView;

	[SerializeField]
	private RectTransform alphaView;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected Color32 currentColor;

	public Image ColorView
	{
		get
		{
			return colorView;
		}
		set
		{
			colorView = value;
			if ((Object)(object)colorView != (Object)null)
			{
				UpdateView();
			}
		}
	}

	public RectTransform AlphaView
	{
		get
		{
			return alphaView;
		}
		set
		{
			alphaView = value;
			if ((Object)(object)alphaView != (Object)null)
			{
				UpdateView();
			}
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			paletteMode = value;
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			ColorView = colorView;
			AlphaView = alphaView;
		}
	}

	protected virtual void OnEnable()
	{
		UpdateView();
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	protected virtual void UpdateView()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		Color color = Color32.op_Implicit(currentColor);
		if ((Object)(object)alphaView != (Object)null)
		{
			alphaView.anchorMax = new Vector2(color.a, alphaView.anchorMax.y);
			alphaView.sizeDelta = Vector2.zero;
		}
		if ((Object)(object)colorView != (Object)null)
		{
			color.a = 1f;
			((Graphic)colorView).color = color;
		}
	}
}
