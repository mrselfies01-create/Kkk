using System;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class SelectEvent : UnityEvent<BaseEventData>
{
}
