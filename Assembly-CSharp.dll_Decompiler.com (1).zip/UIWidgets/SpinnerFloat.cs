using System.Globalization;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/SpinnerFloat", 270)]
public class SpinnerFloat : SpinnerBase<float>
{
	[SerializeField]
	private string format = "0.00";

	public OnChangeEventFloat onValueChangeFloat = new OnChangeEventFloat();

	public SubmitEventFloat onEndEditFloat = new SubmitEventFloat();

	private NumberStyles NumberStyle = NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands;

	private CultureInfo Culture = CultureInfo.InvariantCulture;

	public string Format
	{
		get
		{
			return format;
		}
		set
		{
			format = value;
			((InputField)this).text = _value.ToString(format);
		}
	}

	public SpinnerFloat()
	{
		_max = 100f;
		_step = 1f;
	}

	public override void Plus()
	{
		base.Value += base.Step;
	}

	public override void Minus()
	{
		base.Value -= base.Step;
	}

	protected override void SetValue(float newValue)
	{
		if (_value != InBounds(newValue))
		{
			_value = InBounds(newValue);
			((InputField)this).text = _value.ToString(format);
			((UnityEvent<float>)onValueChangeFloat).Invoke(_value);
		}
	}

	protected override void ValueChange(string value)
	{
		if (Validation != SpinnerValidation.OnEndInput)
		{
			if (value.Length == 0)
			{
				value = "0";
			}
			if (float.TryParse(value, NumberStyle, Culture, out var result))
			{
				SetValue(result);
			}
		}
	}

	protected override void ValueEndEdit(string value)
	{
		if (value.Length == 0)
		{
			value = "0";
		}
		if (float.TryParse(value, NumberStyle, Culture, out var result))
		{
			SetValue(result);
		}
		((UnityEvent<float>)onEndEditFloat).Invoke(_value);
	}

	protected override char ValidateShort(string validateText, int charIndex, char addedChar)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Invalid comparison between Unknown and I4
		if (charIndex != 0 || validateText.Length <= 0 || validateText[0] != '-')
		{
			if (addedChar >= '0' && addedChar <= '9')
			{
				return addedChar;
			}
			if (addedChar == '-' && charIndex == 0 && base.Min < 0f)
			{
				return addedChar;
			}
			if (addedChar == '.' && (int)((InputField)this).characterValidation == 2 && !validateText.Contains("."))
			{
				return addedChar;
			}
		}
		return '\0';
	}

	protected override char ValidateFull(string validateText, int charIndex, char addedChar)
	{
		string text = validateText.Insert(charIndex, addedChar.ToString());
		if (base.Min > 0f && charIndex == 0 && addedChar == '-')
		{
			return '\0';
		}
		int num = ((text.Length <= 0 || text[0] != '-') ? 1 : 2);
		if (text.Length >= num)
		{
			if (!float.TryParse(text, NumberStyle, Culture, out var result))
			{
				return '\0';
			}
			if (result != InBounds(result))
			{
				return '\0';
			}
			_value = result;
		}
		return addedChar;
	}

	protected override float InBounds(float value)
	{
		return Mathf.Clamp(value, _min, _max);
	}
}
