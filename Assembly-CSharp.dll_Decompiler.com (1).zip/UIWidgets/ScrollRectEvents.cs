using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(ScrollRect))]
public class ScrollRectEvents : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IEventSystemHandler
{
	[SerializeField]
	public float RequiredMovement = 50f;

	[SerializeField]
	public UnityEvent OnPullUp = new UnityEvent();

	[SerializeField]
	public UnityEvent OnPullDown = new UnityEvent();

	[SerializeField]
	public UnityEvent OnPullLeft = new UnityEvent();

	[SerializeField]
	public UnityEvent OnPullRight = new UnityEvent();

	private ScrollRect scrollRect;

	private bool initedPullUp;

	private bool initedPullDown;

	private bool initedPullLeft;

	private bool initedPullRight;

	private float MovementUp;

	private float MovementDown;

	private float MovementLeft;

	private float MovementRight;

	public ScrollRect ScrollRect
	{
		get
		{
			if ((Object)(object)scrollRect == (Object)null)
			{
				scrollRect = ((Component)this).GetComponent<ScrollRect>();
			}
			return scrollRect;
		}
	}

	public virtual void OnBeginDrag(PointerEventData eventData)
	{
		initedPullUp = false;
		initedPullDown = false;
		initedPullLeft = false;
		initedPullRight = false;
		MovementUp = 0f;
		MovementDown = 0f;
		MovementLeft = 0f;
		MovementRight = 0f;
	}

	public virtual void OnEndDrag(PointerEventData eventData)
	{
		initedPullUp = false;
		initedPullDown = false;
		initedPullLeft = false;
		initedPullRight = false;
		MovementUp = 0f;
		MovementDown = 0f;
		MovementLeft = 0f;
		MovementRight = 0f;
	}

	public virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)ScrollRect).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		Rect rect = val.rect;
		float height = ((Rect)(ref rect)).height;
		Rect rect2 = val.rect;
		float width = ((Rect)(ref rect2)).width;
		Rect rect3 = ScrollRect.content.rect;
		float num = Mathf.Max(0f, ((Rect)(ref rect3)).height - height);
		Rect rect4 = ScrollRect.content.rect;
		float num2 = Mathf.Max(0f, ((Rect)(ref rect4)).width - width);
		if (ScrollRect.content.anchoredPosition.y <= 0f && !initedPullUp)
		{
			MovementUp += 0f - eventData.delta.y;
			if (MovementUp >= RequiredMovement)
			{
				initedPullUp = true;
				OnPullUp.Invoke();
			}
		}
		if (ScrollRect.content.anchoredPosition.y >= num && !initedPullDown)
		{
			MovementDown += eventData.delta.y;
			if (MovementDown >= RequiredMovement)
			{
				initedPullDown = true;
				OnPullDown.Invoke();
			}
		}
		if (ScrollRect.content.anchoredPosition.x <= 0f && !initedPullLeft)
		{
			MovementLeft += 0f - eventData.delta.x;
			if (MovementLeft >= RequiredMovement)
			{
				initedPullLeft = true;
				OnPullLeft.Invoke();
			}
		}
		if (ScrollRect.content.anchoredPosition.x >= num2 && !initedPullRight)
		{
			MovementRight += eventData.delta.x;
			if (MovementRight >= RequiredMovement)
			{
				initedPullRight = true;
				OnPullRight.Invoke();
			}
		}
	}
}
