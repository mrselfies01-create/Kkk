namespace UIWidgets;

public interface IListViewItemHeight
{
	float Height { get; }
}
