using System;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewItemMove : UnityEvent<AxisEventData, ListViewItem>
{
}
