using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/CenteredSliderVertical", 300)]
public class CenteredSliderVertical : CenteredSlider
{
	protected override bool IsHorizontal()
	{
		return false;
	}
}
