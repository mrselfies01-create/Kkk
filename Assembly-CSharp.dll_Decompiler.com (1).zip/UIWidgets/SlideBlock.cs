using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class SlideBlock : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	[SerializeField]
	[Tooltip("Requirements: start value should be less than end value; Recommended start value = 0; end value = 1;")]
	public AnimationCurve Curve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public SlideBlockAxis Direction;

	[SerializeField]
	private bool isOpen;

	[SerializeField]
	private bool scrollRectSupport;

	[SerializeField]
	private GameObject optionalHandle;

	public UnityEvent OnOpen = new UnityEvent();

	public UnityEvent OnClose = new UnityEvent();

	private RectTransform rectTransform;

	private Vector2 closePosition;

	private IEnumerator currentAnimation;

	private float size;

	public bool IsOpen
	{
		get
		{
			return isOpen;
		}
		set
		{
			isOpen = value;
			ResetPosition();
		}
	}

	public bool ScrollRectSupport
	{
		get
		{
			return scrollRectSupport;
		}
		set
		{
			if (scrollRectSupport)
			{
				((Component)this).GetComponentsInChildren<ScrollRect>().ForEach(RemoveHandleEvents);
			}
			scrollRectSupport = value;
			if (scrollRectSupport)
			{
				((Component)this).GetComponentsInChildren<ScrollRect>().ForEach(AddHandleEvents);
			}
		}
	}

	public GameObject OptionalHandle
	{
		get
		{
			return optionalHandle;
		}
		set
		{
			if ((Object)(object)optionalHandle != (Object)null)
			{
				RemoveHandleEvents(optionalHandle);
			}
			optionalHandle = value;
			if ((Object)(object)optionalHandle != (Object)null)
			{
				AddHandleEvents(optionalHandle);
			}
		}
	}

	protected RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	private string GetWarning()
	{
		Keyframe[] keys = Curve.keys;
		if (((Keyframe)(ref keys[0])).value >= ((Keyframe)(ref keys[^1])).value)
		{
			return $"Curve requirements: start value (current: {((Keyframe)(ref keys[0])).value}) should be less than end value (current: {((Keyframe)(ref keys[^1])).value}).";
		}
		return string.Empty;
	}

	private void Start()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		string warning = GetWarning();
		if (warning != string.Empty)
		{
			Debug.LogWarning((object)warning, (Object)(object)this);
		}
		closePosition = RectTransform.anchoredPosition;
		float num;
		if (IsHorizontal())
		{
			Rect rect = RectTransform.rect;
			num = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = RectTransform.rect;
			num = ((Rect)(ref rect2)).height;
		}
		size = num;
		if (IsOpen)
		{
			if (Direction == SlideBlockAxis.LeftToRight)
			{
				closePosition = new Vector2(closePosition.x - size, closePosition.y);
			}
			if (Direction == SlideBlockAxis.RightToLeft)
			{
				closePosition = new Vector2(closePosition.x + size, closePosition.y);
			}
			else if (Direction == SlideBlockAxis.TopToBottom)
			{
				closePosition = new Vector2(closePosition.x, closePosition.y - size);
			}
			else if (Direction == SlideBlockAxis.BottomToTop)
			{
				closePosition = new Vector2(closePosition.x, closePosition.y + size);
			}
		}
		OptionalHandle = optionalHandle;
		ScrollRectSupport = scrollRectSupport;
	}

	private void AddScrollRectHandle()
	{
		((Component)this).GetComponentsInChildren<ScrollRect>().ForEach(AddHandleEvents);
	}

	private void RemoveScrollRectHandle()
	{
		((Component)this).GetComponentsInChildren<ScrollRect>().ForEach(RemoveHandleEvents);
	}

	private void AddHandleEvents(Component handleComponent)
	{
		AddHandleEvents(handleComponent.gameObject);
	}

	private void AddHandleEvents(GameObject handleObject)
	{
		SlideBlockHandle slideBlockHandle = handleObject.GetComponent<SlideBlockHandle>() ?? handleObject.AddComponent<SlideBlockHandle>();
		((UnityEvent<PointerEventData>)slideBlockHandle.BeginDragEvent).AddListener((UnityAction<PointerEventData>)OnBeginDrag);
		((UnityEvent<PointerEventData>)slideBlockHandle.DragEvent).AddListener((UnityAction<PointerEventData>)OnDrag);
		((UnityEvent<PointerEventData>)slideBlockHandle.EndDragEvent).AddListener((UnityAction<PointerEventData>)OnEndDrag);
	}

	private void RemoveHandleEvents(Component handleComponent)
	{
		RemoveHandleEvents(handleComponent.gameObject);
	}

	private void RemoveHandleEvents(GameObject handleObject)
	{
		SlideBlockHandle component = handleObject.GetComponent<SlideBlockHandle>();
		if ((Object)(object)component != (Object)null)
		{
			((UnityEvent<PointerEventData>)component.BeginDragEvent).RemoveListener((UnityAction<PointerEventData>)OnBeginDrag);
			((UnityEvent<PointerEventData>)component.DragEvent).RemoveListener((UnityAction<PointerEventData>)OnDrag);
			((UnityEvent<PointerEventData>)component.EndDragEvent).RemoveListener((UnityAction<PointerEventData>)OnEndDrag);
		}
	}

	private void ResetPosition()
	{
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		if (isOpen)
		{
			float num;
			if (IsHorizontal())
			{
				Rect rect = RectTransform.rect;
				num = ((Rect)(ref rect)).width;
			}
			else
			{
				Rect rect2 = RectTransform.rect;
				num = ((Rect)(ref rect2)).height;
			}
			size = num;
			if (Direction == SlideBlockAxis.LeftToRight)
			{
				RectTransform.anchoredPosition = new Vector2(closePosition.x + size, RectTransform.anchoredPosition.y);
			}
			else if (Direction == SlideBlockAxis.RightToLeft)
			{
				RectTransform.anchoredPosition = new Vector2(closePosition.x - size, RectTransform.anchoredPosition.y);
			}
			else if (Direction == SlideBlockAxis.TopToBottom)
			{
				RectTransform.anchoredPosition = new Vector2(RectTransform.anchoredPosition.x, closePosition.y - size);
			}
			else if (Direction == SlideBlockAxis.BottomToTop)
			{
				RectTransform.anchoredPosition = new Vector2(RectTransform.anchoredPosition.x, closePosition.y + size);
			}
		}
		else
		{
			RectTransform.anchoredPosition = closePosition;
		}
	}

	public void Toggle()
	{
		if (IsOpen)
		{
			Close();
		}
		else
		{
			Open();
		}
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		float num;
		if (IsHorizontal())
		{
			Rect rect = RectTransform.rect;
			num = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = RectTransform.rect;
			num = ((Rect)(ref rect2)).height;
		}
		size = num;
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		float num = ((!IsHorizontal()) ? (RectTransform.anchoredPosition.y - closePosition.y) : (RectTransform.anchoredPosition.x - closePosition.x));
		if (num == 0f)
		{
			isOpen = false;
			OnClose.Invoke();
			return;
		}
		int num2 = ((!IsReverse()) ? 1 : (-1));
		if (num == size * (float)num2)
		{
			isOpen = true;
			OnOpen.Invoke();
			return;
		}
		float num3 = num / (size * (float)num2);
		if (num3 >= 0.5f)
		{
			isOpen = false;
			Open();
		}
		else
		{
			isOpen = true;
			Close();
		}
	}

	public void OnDrag(PointerEventData eventData)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		if (currentAnimation != null)
		{
			((MonoBehaviour)this).StopCoroutine(currentAnimation);
		}
		Vector2 val = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position, eventData.pressEventCamera, ref val);
		Vector2 val2 = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position - eventData.delta, eventData.pressEventCamera, ref val2);
		Vector2 val3 = val - val2;
		if (Direction == SlideBlockAxis.LeftToRight)
		{
			float num = Mathf.Clamp(RectTransform.anchoredPosition.x + val3.x, closePosition.x, closePosition.x + size);
			RectTransform.anchoredPosition = new Vector2(num, RectTransform.anchoredPosition.y);
		}
		else if (Direction == SlideBlockAxis.RightToLeft)
		{
			float num2 = Mathf.Clamp(RectTransform.anchoredPosition.x + val3.x, closePosition.x - size, closePosition.x);
			RectTransform.anchoredPosition = new Vector2(num2, RectTransform.anchoredPosition.y);
		}
		else if (Direction == SlideBlockAxis.TopToBottom)
		{
			float num3 = Mathf.Clamp(RectTransform.anchoredPosition.y + val3.y, closePosition.y - size, closePosition.y);
			RectTransform.anchoredPosition = new Vector2(RectTransform.anchoredPosition.x, num3);
		}
		else if (Direction == SlideBlockAxis.BottomToTop)
		{
			float num4 = Mathf.Clamp(RectTransform.anchoredPosition.y + val3.y, closePosition.y, closePosition.y + size);
			RectTransform.anchoredPosition = new Vector2(RectTransform.anchoredPosition.x, num4);
		}
	}

	public void Open()
	{
		if (!IsOpen)
		{
			Animate();
		}
	}

	public void Close()
	{
		if (IsOpen)
		{
			Animate();
		}
	}

	private bool IsHorizontal()
	{
		return Direction == SlideBlockAxis.LeftToRight || SlideBlockAxis.RightToLeft == Direction;
	}

	private bool IsReverse()
	{
		return Direction == SlideBlockAxis.RightToLeft || SlideBlockAxis.TopToBottom == Direction;
	}

	private void Animate()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (currentAnimation != null)
		{
			((MonoBehaviour)this).StopCoroutine(currentAnimation);
		}
		float time = ((Keyframe)(ref Curve.keys[Curve.keys.Length - 1])).time;
		float num;
		if (IsHorizontal())
		{
			Rect rect = RectTransform.rect;
			num = ((Rect)(ref rect)).width;
		}
		else
		{
			Rect rect2 = RectTransform.rect;
			num = ((Rect)(ref rect2)).height;
		}
		size = num;
		float num2 = ((!IsHorizontal()) ? RectTransform.anchoredPosition.y : RectTransform.anchoredPosition.x);
		float num3 = num2 - ((!IsHorizontal()) ? closePosition.y : closePosition.x);
		int num4 = ((!IsReverse()) ? 1 : (-1));
		float num5 = ((!isOpen) ? (size * (float)num4 - num3) : (size * (float)num4));
		float num6 = ((num5 != 0f) ? (size / num5) : 1f);
		if (IsReverse())
		{
			num6 *= -1f;
		}
		currentAnimation = RunAnimation(Time.time, time, num2, num5, num6);
		((MonoBehaviour)this).StartCoroutine(currentAnimation);
	}

	private IEnumerator RunAnimation(float startTime, float animationLength, float startPosition, float movement, float acceleration)
	{
		int direction = ((!isOpen) ? 1 : (-1));
		float delta;
		do
		{
			delta = (Time.time - startTime) * acceleration;
			float value = Curve.Evaluate(delta);
			if (IsHorizontal())
			{
				RectTransform.anchoredPosition = new Vector2(startPosition + value * movement * (float)direction, RectTransform.anchoredPosition.y);
			}
			else
			{
				RectTransform.anchoredPosition = new Vector2(RectTransform.anchoredPosition.x, startPosition + value * movement * (float)direction);
			}
			yield return null;
		}
		while (delta < animationLength);
		isOpen = !isOpen;
		ResetPosition();
		if (IsOpen)
		{
			OnOpen.Invoke();
		}
		else
		{
			OnClose.Invoke();
		}
	}
}
