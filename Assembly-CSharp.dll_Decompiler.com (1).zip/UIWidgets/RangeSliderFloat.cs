using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/RangeSliderFloat", 310)]
public class RangeSliderFloat : RangeSliderBase<float>
{
	protected override float ValueToPosition(float value)
	{
		float num = FillSize() / (limitMax - limitMin);
		return num * (InBounds(value) - limitMin) + GetStartPoint();
	}

	protected override float PositionToValue(float position)
	{
		float num = FillSize() / (limitMax - limitMin);
		float num2 = position / num + base.LimitMin;
		if (WholeNumberOfSteps)
		{
			return InBounds(Mathf.Round(num2 / step) * step);
		}
		return InBounds(num2);
	}

	protected override Vector2 MinPositionLimits()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(ValueToPosition(base.LimitMin), ValueToPosition(valueMax - step));
	}

	protected override Vector2 MaxPositionLimits()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(ValueToPosition(valueMin + step), ValueToPosition(limitMax));
	}

	protected override float InBounds(float value)
	{
		if (value < limitMin)
		{
			return limitMin;
		}
		if (value > limitMax)
		{
			return limitMax;
		}
		return value;
	}

	protected override float InBoundsMin(float value)
	{
		if (value < limitMin)
		{
			return limitMin;
		}
		if (value > valueMax)
		{
			return valueMax;
		}
		return value;
	}

	protected override float InBoundsMax(float value)
	{
		if (value < valueMin)
		{
			return valueMin;
		}
		if (value > limitMax)
		{
			return limitMax;
		}
		return value;
	}

	protected override void IncreaseMin()
	{
		base.ValueMin += step;
	}

	protected override void DecreaseMin()
	{
		base.ValueMin -= step;
	}

	protected override void IncreaseMax()
	{
		base.ValueMax += step;
	}

	protected override void DecreaseMax()
	{
		base.ValueMax -= step;
	}
}
