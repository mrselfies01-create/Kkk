using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class TreeNodeToggle : UIBehaviour, IPointerUpHandler, IPointerDownHandler, IPointerClickHandler, IEventSystemHandler
{
	public UnityEvent OnClick = new UnityEvent();

	public void OnPointerUp(PointerEventData eventData)
	{
	}

	public void OnPointerDown(PointerEventData eventData)
	{
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		OnClick.Invoke();
	}
}
