using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

public class BringToFront : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
{
	[SerializeField]
	public bool WithParents;

	public virtual void OnPointerDown(PointerEventData eventData)
	{
		ToFront();
	}

	public virtual void ToFront()
	{
		ToFront(((Component)this).transform);
	}

	private void ToFront(Transform obj)
	{
		obj.SetAsLastSibling();
		if (WithParents && (Object)(object)obj.parent != (Object)null)
		{
			ToFront(obj.parent);
		}
	}
}
