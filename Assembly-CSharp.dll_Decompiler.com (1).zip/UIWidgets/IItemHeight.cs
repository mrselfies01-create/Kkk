namespace UIWidgets;

public interface IItemHeight
{
	float Height { get; set; }
}
