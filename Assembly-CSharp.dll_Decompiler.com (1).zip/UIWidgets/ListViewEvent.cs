using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewEvent : UnityEvent<int, string>
{
}
