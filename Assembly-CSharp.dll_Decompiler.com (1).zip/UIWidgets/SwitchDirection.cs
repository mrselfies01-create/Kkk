namespace UIWidgets;

public enum SwitchDirection
{
	LeftToRight,
	RightToLeft,
	BottomToTop,
	TopToBottom
}
