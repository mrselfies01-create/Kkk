using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class Dialog : MonoBehaviour, ITemplatable
{
	[SerializeField]
	private Button defaultButton;

	[SerializeField]
	private Text titleText;

	[SerializeField]
	private Text contentText;

	[SerializeField]
	private Image dialogIcon;

	private bool isTemplate = true;

	private static Templates<Dialog> templates;

	protected int? ModalKey;

	protected Stack<Button> buttonsCache = new Stack<Button>();

	protected Dictionary<string, Button> buttonsInUse = new Dictionary<string, Button>();

	protected Dictionary<string, UnityAction> buttonsActions = new Dictionary<string, UnityAction>();

	public Button DefaultButton
	{
		get
		{
			return defaultButton;
		}
		set
		{
			defaultButton = value;
		}
	}

	public Text TitleText
	{
		get
		{
			return titleText;
		}
		set
		{
			titleText = value;
		}
	}

	public Text ContentText
	{
		get
		{
			return contentText;
		}
		set
		{
			contentText = value;
		}
	}

	public Image Icon
	{
		get
		{
			return dialogIcon;
		}
		set
		{
			dialogIcon = value;
		}
	}

	public bool IsTemplate
	{
		get
		{
			return isTemplate;
		}
		set
		{
			isTemplate = value;
		}
	}

	public string TemplateName { get; set; }

	public static Templates<Dialog> Templates
	{
		get
		{
			if (templates == null)
			{
				templates = new Templates<Dialog>();
			}
			return templates;
		}
		set
		{
			templates = value;
		}
	}

	protected virtual void Awake()
	{
		if (IsTemplate)
		{
			((Component)this).gameObject.SetActive(false);
		}
	}

	protected virtual void OnDestroy()
	{
		DeactivateButtons();
		if (!IsTemplate)
		{
			templates = null;
		}
		else if (TemplateName != null)
		{
			Templates.Delete(TemplateName);
		}
	}

	public static Dialog Template(string template)
	{
		return Templates.Instance(template);
	}

	public virtual void Show(string title = null, string message = null, DialogActions buttons = null, string focusButton = null, Vector3? position = null, Sprite icon = null, bool modal = false, Sprite modalSprite = null, Color? modalColor = null, Canvas canvas = null)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		if (!position.HasValue)
		{
			position = new Vector3(0f, 0f, 0f);
		}
		if (title != null && (Object)(object)TitleText != (Object)null)
		{
			TitleText.text = title;
		}
		if (message != null && (Object)(object)ContentText != (Object)null)
		{
			contentText.text = message;
		}
		if ((Object)(object)icon != (Object)null && (Object)(object)Icon != (Object)null)
		{
			Icon.sprite = icon;
		}
		Transform val = ((!((Object)(object)canvas != (Object)null)) ? Utilites.FindCanvas(((Component)this).gameObject.transform) : ((Component)canvas).transform);
		if ((Object)(object)val != (Object)null)
		{
			((Component)this).transform.SetParent(val, false);
		}
		if (modal)
		{
			ModalKey = ModalHelper.Open((MonoBehaviour)(object)this, modalSprite, modalColor);
		}
		else
		{
			ModalKey = null;
		}
		((Component)this).transform.SetAsLastSibling();
		((Component)this).transform.localPosition = position.Value;
		((Component)this).gameObject.SetActive(true);
		CreateButtons(buttons, focusButton);
	}

	public virtual void Hide()
	{
		int? modalKey = ModalKey;
		if (modalKey.HasValue)
		{
			int? modalKey2 = ModalKey;
			ModalHelper.Close(modalKey2.Value);
		}
		Return();
	}

	protected virtual void CreateButtons(DialogActions buttons, string focusButton)
	{
		((Component)defaultButton).gameObject.SetActive(false);
		buttons?.ForEach(delegate(KeyValuePair<string, Func<bool>> x)
		{
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Expected O, but got Unknown
			Button button = GetButton();
			UnityAction value = (UnityAction)delegate
			{
				if (x.Value())
				{
					Hide();
				}
			};
			buttonsInUse.Add(x.Key, button);
			buttonsActions.Add(x.Key, value);
			((Component)button).gameObject.SetActive(true);
			((Component)button).transform.SetAsLastSibling();
			Text componentInChildren = ((Component)button).GetComponentInChildren<Text>();
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				componentInChildren.text = x.Key;
			}
			((UnityEvent)button.onClick).AddListener(buttonsActions[x.Key]);
			if (x.Key == focusButton)
			{
				((Selectable)button).Select();
			}
		});
	}

	protected virtual Button GetButton()
	{
		if (buttonsCache.Count > 0)
		{
			return buttonsCache.Pop();
		}
		Button val = Object.Instantiate<Button>(DefaultButton);
		Utilites.FixInstantiated((Component)(object)DefaultButton, (Component)(object)val);
		((Component)val).transform.SetParent(((Component)DefaultButton).transform.parent, false);
		return val;
	}

	protected virtual void Return()
	{
		Templates.ToCache(this);
		DeactivateButtons();
		ResetParametres();
	}

	protected virtual void DeactivateButtons()
	{
		buttonsInUse.ForEach(DeactivateButton);
		buttonsInUse.Clear();
		buttonsActions.Clear();
	}

	protected virtual void DeactivateButton(KeyValuePair<string, Button> button)
	{
		((Component)button.Value).gameObject.SetActive(false);
		((UnityEvent)button.Value.onClick).RemoveListener(buttonsActions[button.Key]);
		buttonsCache.Push(button.Value);
	}

	protected virtual void ResetParametres()
	{
		Dialog dialog = Templates.Get(TemplateName);
		if ((Object)(object)TitleText != (Object)null && (Object)(object)dialog.TitleText != (Object)null)
		{
			TitleText.text = dialog.TitleText.text;
		}
		if ((Object)(object)ContentText != (Object)null && (Object)(object)dialog.ContentText != (Object)null)
		{
			ContentText.text = dialog.ContentText.text;
		}
		if ((Object)(object)Icon != (Object)null && (Object)(object)dialog.Icon != (Object)null)
		{
			Icon.sprite = dialog.Icon.sprite;
		}
	}

	public static bool Close()
	{
		return true;
	}
}
