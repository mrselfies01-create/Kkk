namespace UIWidgets;

public delegate void OnChange();
