using System.Collections.Generic;
using UnityEngine;

namespace UIWidgets;

public abstract class BaseDragSupport : MonoBehaviour
{
	protected static Dictionary<Transform, RectTransform> DragPoints;

	private Transform canvasTransform;

	protected Transform CanvasTransform
	{
		get
		{
			if ((Object)(object)canvasTransform == (Object)null)
			{
				canvasTransform = Utilites.FindCanvas(((Component)this).transform);
			}
			return canvasTransform;
		}
	}

	public RectTransform DragPoint
	{
		get
		{
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Expected O, but got Unknown
			if (DragPoints == null)
			{
				DragPoints = new Dictionary<Transform, RectTransform>();
			}
			if (!DragPoints.ContainsKey(CanvasTransform))
			{
				GameObject val = new GameObject("DragPoint");
				RectTransform val2 = val.AddComponent<RectTransform>();
				((Transform)val2).SetParent(CanvasTransform, false);
				val2.SetSizeWithCurrentAnchors((Axis)0, 0f);
				val2.SetSizeWithCurrentAnchors((Axis)1, 0f);
				DragPoints.Add(CanvasTransform, val2);
			}
			return DragPoints[CanvasTransform];
		}
	}
}
