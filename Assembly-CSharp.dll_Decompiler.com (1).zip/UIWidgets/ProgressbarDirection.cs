namespace UIWidgets;

public enum ProgressbarDirection
{
	Horizontal,
	Vertical
}
