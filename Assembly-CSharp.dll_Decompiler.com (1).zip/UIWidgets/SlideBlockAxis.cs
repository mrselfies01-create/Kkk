namespace UIWidgets;

public enum SlideBlockAxis
{
	LeftToRight,
	TopToBottom,
	RightToLeft,
	BottomToTop
}
