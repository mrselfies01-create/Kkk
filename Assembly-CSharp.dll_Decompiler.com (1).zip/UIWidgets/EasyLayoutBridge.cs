using EasyLayout;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class EasyLayoutBridge : ILayoutBridge
{
	private bool isHorizontal;

	private global::EasyLayout.EasyLayout Layout;

	private RectTransform DefaultItem;

	public bool IsHorizontal
	{
		get
		{
			return isHorizontal;
		}
		set
		{
			isHorizontal = value;
			UpdateDirection();
		}
	}

	public bool UpdateContentSizeFitter { get; set; }

	public EasyLayoutBridge(global::EasyLayout.EasyLayout layout, RectTransform defaultItem)
	{
		Layout = layout;
		DefaultItem = defaultItem;
	}

	private void UpdateDirection()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		Layout.Stacking = (isHorizontal ? Stackings.Vertical : Stackings.Horizontal);
		if (UpdateContentSizeFitter)
		{
			ContentSizeFitter component = ((Component)Layout).GetComponent<ContentSizeFitter>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.horizontalFit = (FitMode)(IsHorizontal ? 2 : 0);
				component.verticalFit = (FitMode)((!IsHorizontal) ? 2 : 0);
			}
		}
		Transform transform = ((Component)Layout).transform;
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		val.pivot = new Vector2(0f, 1f);
		if (isHorizontal)
		{
			val.anchorMin = new Vector2(0f, 0f);
			val.anchorMax = new Vector2(0f, 1f);
		}
		else
		{
			val.anchorMin = new Vector2(0f, 1f);
			val.anchorMax = new Vector2(1f, 1f);
		}
		val.sizeDelta = new Vector2(0f, 0f);
	}

	public void UpdateLayout()
	{
		Layout.UpdateLayout();
	}

	public void SetFiller(float first, float last)
	{
		Padding paddingInner = ((!IsHorizontal) ? new Padding(0f, 0f, first, last) : new Padding(first, last, 0f, 0f));
		Layout.PaddingInner = paddingInner;
	}

	public Vector2 GetItemSize()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = DefaultItem.rect;
		float width = ((Rect)(ref rect)).width;
		Rect rect2 = DefaultItem.rect;
		return new Vector2(width, ((Rect)(ref rect2)).height);
	}

	public float GetMargin()
	{
		return (!IsHorizontal) ? Layout.GetMarginTop() : Layout.GetMarginLeft();
	}

	public float GetFullMargin()
	{
		return (!IsHorizontal) ? (Layout.GetMarginTop() + Layout.GetMarginBottom()) : (Layout.GetMarginLeft() + Layout.GetMarginRight());
	}

	public float GetSpacing()
	{
		return (!IsHorizontal) ? Layout.Spacing.y : Layout.Spacing.x;
	}
}
