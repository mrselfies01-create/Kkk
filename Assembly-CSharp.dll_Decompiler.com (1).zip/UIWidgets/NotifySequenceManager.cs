using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UIWidgets;

public class NotifySequenceManager : MonoBehaviour
{
	private static Notify currentNotify;

	private static List<Notify> notifySequence = new List<Notify>();

	private IEnumerator nextDelay;

	public void Clear()
	{
		if ((Object)(object)currentNotify != (Object)null)
		{
			currentNotify.Return();
			currentNotify = null;
		}
		notifySequence.ForEach(ReturnNotify);
		notifySequence.Clear();
	}

	private void ReturnNotify(Notify notify)
	{
		notify.Return();
	}

	public void Add(Notify notification, NotifySequence type)
	{
		if (type == NotifySequence.Last)
		{
			notifySequence.Add(notification);
		}
		else
		{
			notifySequence.Insert(0, notification);
		}
	}

	private void Update()
	{
		if (!((Object)(object)currentNotify != (Object)null) && notifySequence.Count != 0)
		{
			currentNotify = notifySequence[0];
			notifySequence.RemoveAt(0);
			currentNotify.Display(NotifyDelay);
		}
	}

	private void NotifyDelay()
	{
		if (nextDelay != null)
		{
			((MonoBehaviour)this).StopCoroutine(nextDelay);
		}
		if (notifySequence.Count > 0 && notifySequence[0].SequenceDelay > 0f)
		{
			nextDelay = NextDelay();
			((MonoBehaviour)this).StartCoroutine(nextDelay);
		}
		else
		{
			currentNotify = null;
		}
	}

	private IEnumerator NextDelay()
	{
		yield return (object)new WaitForSeconds(notifySequence[0].SequenceDelay);
		currentNotify = null;
	}
}
