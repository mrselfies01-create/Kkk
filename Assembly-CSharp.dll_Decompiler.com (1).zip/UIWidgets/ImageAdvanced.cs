using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/ImageAdvanced", 240)]
public class ImageAdvanced : Image, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IEventSystemHandler
{
	public PointerUnityEvent onPointerDown = new PointerUnityEvent();

	public PointerUnityEvent onPointerUp = new PointerUnityEvent();

	public PointerUnityEvent onPointerEnter = new PointerUnityEvent();

	public PointerUnityEvent onPointerExit = new PointerUnityEvent();

	public virtual void OnPointerDown(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerDown).Invoke(eventData);
	}

	public virtual void OnPointerUp(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerUp).Invoke(eventData);
	}

	public virtual void OnPointerEnter(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerEnter).Invoke(eventData);
	}

	public virtual void OnPointerExit(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerExit).Invoke(eventData);
	}
}
