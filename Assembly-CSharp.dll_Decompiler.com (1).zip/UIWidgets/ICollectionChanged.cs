namespace UIWidgets;

public interface ICollectionChanged
{
	event OnChange OnCollectionChange;
}
