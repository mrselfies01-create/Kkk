using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[RequireComponent(typeof(TreeView))]
public class TreeViewDropSupport : MonoBehaviour, IDropSupport<TreeNode<TreeViewItem>>, IDropSupport<ListViewIconsItemDescription>
{
	private TreeView source;

	public TreeView Source
	{
		get
		{
			if ((Object)(object)source == (Object)null)
			{
				source = ((Component)this).GetComponent<TreeView>();
			}
			return source;
		}
	}

	public bool CanReceiveDrop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		return Source.Nodes == null || !Source.Nodes.Contains(data);
	}

	public void Drop(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
		if (Source.Nodes == null)
		{
			Source.Nodes = new ObservableList<TreeNode<TreeViewItem>>();
		}
		Source.Nodes.Add(data);
	}

	public void DropCanceled(TreeNode<TreeViewItem> data, PointerEventData eventData)
	{
	}

	public bool CanReceiveDrop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		return true;
	}

	public void Drop(ListViewIconsItemDescription data, PointerEventData eventData)
	{
		if (Source.Nodes == null)
		{
			Source.Nodes = new ObservableList<TreeNode<TreeViewItem>>();
		}
		TreeViewItem treeViewItem = new TreeViewItem(data.Name);
		treeViewItem.LocalizedName = data.LocalizedName;
		treeViewItem.Icon = data.Icon;
		treeViewItem.Value = data.Value;
		TreeViewItem nodeItem = treeViewItem;
		TreeNode<TreeViewItem> item = new TreeNode<TreeViewItem>(nodeItem);
		Source.Nodes.Add(item);
	}

	public void DropCanceled(ListViewIconsItemDescription data, PointerEventData eventData)
	{
	}
}
