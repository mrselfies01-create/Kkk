using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

[AddComponentMenu("UI/ListViewIcons", 252)]
public class ListViewIcons : ListViewCustom<ListViewIconsItemComponent, ListViewIconsItemDescription>
{
	[NonSerialized]
	private bool isStartedListViewIcons;

	protected Comparison<ListViewIconsItemDescription> ItemsComparison = (ListViewIconsItemDescription x, ListViewIconsItemDescription y) => (x.LocalizedName ?? x.Name).CompareTo(y.LocalizedName ?? y.Name);

	protected override void Awake()
	{
		Start();
	}

	public override void Start()
	{
		if (isStartedListViewIcons)
		{
			return;
		}
		isStartedListViewIcons = true;
		base.Start();
		base.SortFunc = (IEnumerable<ListViewIconsItemDescription> list) => list.OrderBy((ListViewIconsItemDescription item) => item.LocalizedName ?? item.Name);
	}

	protected override void SetData(ListViewIconsItemComponent component, ListViewIconsItemDescription item)
	{
		component.SetData(item);
	}

	protected override void HighlightColoring(ListViewIconsItemComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.HighlightColoring(component);
		((Graphic)component.Text).color = HighlightedColor;
	}

	protected override void SelectColoring(ListViewIconsItemComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.SelectColoring(component);
		((Graphic)component.Text).color = base.SelectedColor;
	}

	protected override void DefaultColoring(ListViewIconsItemComponent component)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		base.DefaultColoring(component);
		((Graphic)component.Text).color = base.DefaultColor;
	}
}
