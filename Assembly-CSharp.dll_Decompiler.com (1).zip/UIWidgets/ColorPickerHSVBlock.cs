using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerHSVBlock : MonoBehaviour
{
	[SerializeField]
	private Slider hSlider;

	[SerializeField]
	private Spinner hInput;

	[SerializeField]
	private Image hSliderBackground;

	[SerializeField]
	private Slider sSlider;

	[SerializeField]
	private Spinner sInput;

	[SerializeField]
	private Image sSliderBackground;

	[SerializeField]
	private Slider vSlider;

	[SerializeField]
	private Spinner vInput;

	[SerializeField]
	private Image vSliderBackground;

	[SerializeField]
	private Shader defaultShader;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected bool inUpdateMode;

	protected ColorHSV currentColorHSV;

	public Slider HSlider
	{
		get
		{
			return hSlider;
		}
		set
		{
			SetHSlider(value);
		}
	}

	public Spinner HInput
	{
		get
		{
			return hInput;
		}
		set
		{
			SetHInput(value);
		}
	}

	public Image HSliderBackground
	{
		get
		{
			return hSliderBackground;
		}
		set
		{
			hSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Slider SSlider
	{
		get
		{
			return sSlider;
		}
		set
		{
			SetSSlider(value);
		}
	}

	public Spinner SInput
	{
		get
		{
			return sInput;
		}
		set
		{
			SetSInput(value);
		}
	}

	public Image SSliderBackground
	{
		get
		{
			return sSliderBackground;
		}
		set
		{
			sSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Slider VSlider
	{
		get
		{
			return vSlider;
		}
		set
		{
			SetVSlider(value);
		}
	}

	public Spinner VInput
	{
		get
		{
			return vInput;
		}
		set
		{
			SetVInput(value);
		}
	}

	public Image VSliderBackground
	{
		get
		{
			return vSliderBackground;
		}
		set
		{
			vSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Shader DefaultShader
	{
		get
		{
			return defaultShader;
		}
		set
		{
			defaultShader = value;
			UpdateMaterial();
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
			((Component)this).gameObject.SetActive(inputMode == ColorPickerInputMode.HSV);
			UpdateView();
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			paletteMode = value;
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			HSlider = hSlider;
			HInput = hInput;
			HSliderBackground = hSliderBackground;
			SSlider = sSlider;
			SInput = sInput;
			SSliderBackground = sSliderBackground;
			VSlider = vSlider;
			VInput = vInput;
			VSliderBackground = vSliderBackground;
		}
	}

	protected virtual void SetHSlider(Slider value)
	{
		if ((Object)(object)hSlider != (Object)null)
		{
			((UnityEvent<float>)(object)hSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		hSlider = value;
		if ((Object)(object)hSlider != (Object)null)
		{
			((UnityEvent<float>)(object)hSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetHInput(Spinner value)
	{
		if ((Object)(object)hInput != (Object)null)
		{
			((UnityEvent<int>)hInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		hInput = value;
		if ((Object)(object)hInput != (Object)null)
		{
			((UnityEvent<int>)hInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
		}
	}

	protected virtual void SetVSlider(Slider value)
	{
		if ((Object)(object)vSlider != (Object)null)
		{
			((UnityEvent<float>)(object)vSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		vSlider = value;
		if ((Object)(object)vSlider != (Object)null)
		{
			((UnityEvent<float>)(object)vSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetVInput(Spinner value)
	{
		if ((Object)(object)vInput != (Object)null)
		{
			((UnityEvent<int>)vInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		vInput = value;
		if ((Object)(object)vInput != (Object)null)
		{
			((UnityEvent<int>)vInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
		}
	}

	protected virtual void SetSSlider(Slider value)
	{
		if ((Object)(object)sSlider != (Object)null)
		{
			((UnityEvent<float>)(object)sSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		sSlider = value;
		if ((Object)(object)sSlider != (Object)null)
		{
			((UnityEvent<float>)(object)sSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	protected virtual void SetSInput(Spinner value)
	{
		if ((Object)(object)sInput != (Object)null)
		{
			((UnityEvent<int>)sInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		sInput = value;
		if ((Object)(object)sInput != (Object)null)
		{
			((UnityEvent<int>)sInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
		}
	}

	protected virtual void OnEnable()
	{
		UpdateMaterial();
	}

	private void SpinnerValueChanged(int value)
	{
		ValueChanged();
	}

	private void SliderValueChanged(float value)
	{
		ValueChanged();
	}

	protected virtual void ValueChanged()
	{
		if (!inUpdateMode)
		{
			currentColorHSV = new ColorHSV(GetHue(), GetSaturation(), GetBrightness(), currentColorHSV.A);
			((UnityEvent<ColorHSV>)OnChangeHSV).Invoke(currentColorHSV);
		}
	}

	protected int GetHue()
	{
		if ((Object)(object)hSlider != (Object)null)
		{
			return (int)hSlider.value;
		}
		if ((Object)(object)hInput != (Object)null)
		{
			return hInput.Value;
		}
		return currentColorHSV.H;
	}

	protected int GetSaturation()
	{
		if ((Object)(object)sSlider != (Object)null)
		{
			return (int)sSlider.value;
		}
		if ((Object)(object)sInput != (Object)null)
		{
			return sInput.Value;
		}
		return currentColorHSV.S;
	}

	protected int GetBrightness()
	{
		if ((Object)(object)vSlider != (Object)null)
		{
			return (int)vSlider.value;
		}
		if ((Object)(object)vInput != (Object)null)
		{
			return vInput.Value;
		}
		return currentColorHSV.V;
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColorHSV = new ColorHSV(Color32.op_Implicit(color));
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		currentColorHSV = color;
		UpdateView();
	}

	protected virtual void UpdateView()
	{
		UpdateViewReal();
	}

	protected virtual void UpdateViewReal()
	{
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		inUpdateMode = true;
		if ((Object)(object)hSlider != (Object)null)
		{
			hSlider.value = currentColorHSV.H;
		}
		if ((Object)(object)hInput != (Object)null)
		{
			hInput.Value = currentColorHSV.H;
		}
		if ((Object)(object)sSlider != (Object)null)
		{
			sSlider.value = currentColorHSV.S;
		}
		if ((Object)(object)sInput != (Object)null)
		{
			sInput.Value = currentColorHSV.S;
		}
		if ((Object)(object)vSlider != (Object)null)
		{
			vSlider.value = currentColorHSV.V;
		}
		if ((Object)(object)vInput != (Object)null)
		{
			vInput.Value = currentColorHSV.V;
		}
		byte b = (byte)((float)currentColorHSV.H / 360f * 255f);
		byte b2 = (byte)currentColorHSV.S;
		byte b3 = (byte)currentColorHSV.V;
		if ((Object)(object)hSliderBackground != (Object)null)
		{
			((Graphic)hSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32((byte)0, byte.MaxValue, byte.MaxValue, byte.MaxValue)));
			((Graphic)hSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue)));
		}
		if ((Object)(object)sSliderBackground != (Object)null)
		{
			((Graphic)sSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32(b, (byte)0, (byte)Mathf.Max(80, (int)b3), byte.MaxValue)));
			((Graphic)sSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(b, byte.MaxValue, (byte)Mathf.Max(80, (int)b3), byte.MaxValue)));
		}
		if ((Object)(object)vSliderBackground != (Object)null)
		{
			((Graphic)vSliderBackground).material.SetColor("_ColorLeft", Color32.op_Implicit(new Color32(b, b2, (byte)0, byte.MaxValue)));
			((Graphic)vSliderBackground).material.SetColor("_ColorRight", Color32.op_Implicit(new Color32(b, b2, byte.MaxValue, byte.MaxValue)));
		}
		inUpdateMode = false;
	}

	protected virtual void UpdateMaterial()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		if (!((Object)(object)defaultShader == (Object)null))
		{
			if ((Object)(object)hSliderBackground != (Object)null)
			{
				((Graphic)hSliderBackground).material = new Material(defaultShader);
			}
			if ((Object)(object)sSliderBackground != (Object)null)
			{
				((Graphic)sSliderBackground).material = new Material(defaultShader);
			}
			if ((Object)(object)vSliderBackground != (Object)null)
			{
				((Graphic)vSliderBackground).material = new Material(defaultShader);
			}
			UpdateViewReal();
		}
	}

	protected virtual void OnDestroy()
	{
		hSlider = null;
		hInput = null;
		sSlider = null;
		sInput = null;
		vSlider = null;
		vInput = null;
	}
}
