using UnityEngine;
using UnityEngine.Events;

namespace UIWidgets;

[SerializeField]
public class SplitterResizeEvent : UnityEvent<Splitter>
{
}
