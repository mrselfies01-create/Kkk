namespace UIWidgets;

public enum SplitterType
{
	Horizontal,
	Vertical
}
