using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class TabIconDefaultButton : TabIconButton
{
	public override void SetData(TabIcons tab)
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		Name.text = tab.Name;
		if ((Object)(object)Icon != (Object)null)
		{
			Icon.sprite = tab.IconDefault;
			if (SetNativeSize)
			{
				((Graphic)Icon).SetNativeSize();
			}
			((Graphic)Icon).color = ((!((Object)(object)Icon.sprite == (Object)null)) ? Color.white : Color.clear);
		}
	}
}
