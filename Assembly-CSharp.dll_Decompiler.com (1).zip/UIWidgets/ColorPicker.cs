using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace UIWidgets;

public class ColorPicker : MonoBehaviour
{
	public const int ValueLimit = 80;

	[SerializeField]
	private ColorPickerRGBPalette rgbPalette;

	[SerializeField]
	private ColorPickerRGBBlock rgbBlock;

	[SerializeField]
	private ColorPickerHSVPalette hsvPalette;

	[SerializeField]
	private ColorPickerHSVBlock hsvBlock;

	[SerializeField]
	private ColorPickerABlock aBlock;

	[SerializeField]
	private ColorPickerColorBlock colorView;

	[SerializeField]
	private ColorPickerInputMode inputMode;

	[SerializeField]
	private ColorPickerPaletteMode paletteMode;

	[SerializeField]
	private Color32 color = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);

	public ColorRGBChangedEvent OnChange = new ColorRGBChangedEvent();

	private static List<ColorPickerPaletteMode> rgbPaletteModes = new List<ColorPickerPaletteMode>
	{
		ColorPickerPaletteMode.Red,
		ColorPickerPaletteMode.Green,
		ColorPickerPaletteMode.Blue
	};

	private static List<ColorPickerPaletteMode> hsvPaletteModes = new List<ColorPickerPaletteMode>
	{
		ColorPickerPaletteMode.Hue,
		ColorPickerPaletteMode.Saturation,
		ColorPickerPaletteMode.Value
	};

	public ColorPickerRGBPalette RGBPalette
	{
		get
		{
			return rgbPalette;
		}
		set
		{
			if ((Object)(object)rgbPalette != (Object)null)
			{
				((UnityEvent<Color32>)rgbPalette.OnChangeRGB).RemoveListener((UnityAction<Color32>)ColorRGBChanged);
			}
			rgbPalette = value;
			if ((Object)(object)rgbPalette != (Object)null)
			{
				((UnityEvent<Color32>)rgbPalette.OnChangeRGB).AddListener((UnityAction<Color32>)ColorRGBChanged);
			}
		}
	}

	public ColorPickerRGBBlock RGBBlock
	{
		get
		{
			return rgbBlock;
		}
		set
		{
			if ((Object)(object)rgbBlock != (Object)null)
			{
				((UnityEvent<Color32>)rgbBlock.OnChangeRGB).RemoveListener((UnityAction<Color32>)ColorRGBChanged);
			}
			rgbBlock = value;
			if ((Object)(object)rgbBlock != (Object)null)
			{
				((UnityEvent<Color32>)rgbBlock.OnChangeRGB).AddListener((UnityAction<Color32>)ColorRGBChanged);
			}
		}
	}

	public ColorPickerHSVPalette HSVPalette
	{
		get
		{
			return hsvPalette;
		}
		set
		{
			if ((Object)(object)hsvPalette != (Object)null)
			{
				((UnityEvent<ColorHSV>)hsvPalette.OnChangeHSV).RemoveListener((UnityAction<ColorHSV>)ColorHSVChanged);
			}
			hsvPalette = value;
			if ((Object)(object)hsvPalette != (Object)null)
			{
				((UnityEvent<ColorHSV>)hsvPalette.OnChangeHSV).AddListener((UnityAction<ColorHSV>)ColorHSVChanged);
			}
		}
	}

	public ColorPickerHSVBlock HSVBlock
	{
		get
		{
			return hsvBlock;
		}
		set
		{
			if ((Object)(object)hsvBlock != (Object)null)
			{
				((UnityEvent<ColorHSV>)hsvBlock.OnChangeHSV).RemoveListener((UnityAction<ColorHSV>)ColorHSVChanged);
			}
			hsvBlock = value;
			if ((Object)(object)hsvBlock != (Object)null)
			{
				((UnityEvent<ColorHSV>)hsvBlock.OnChangeHSV).AddListener((UnityAction<ColorHSV>)ColorHSVChanged);
			}
		}
	}

	public ColorPickerABlock ABlock
	{
		get
		{
			return aBlock;
		}
		set
		{
			if ((Object)(object)aBlock != (Object)null)
			{
				((UnityEvent<byte>)aBlock.OnChangeAlpha).RemoveListener((UnityAction<byte>)ColorAlphaChanged);
			}
			aBlock = value;
			if ((Object)(object)aBlock != (Object)null)
			{
				((UnityEvent<byte>)aBlock.OnChangeAlpha).AddListener((UnityAction<byte>)ColorAlphaChanged);
			}
		}
	}

	public ColorPickerColorBlock ColorView
	{
		get
		{
			return colorView;
		}
		set
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			colorView = value;
			if ((Object)(object)colorView != (Object)null)
			{
				colorView.SetColor(color);
			}
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
			if ((Object)(object)rgbPalette != (Object)null)
			{
				rgbPalette.InputMode = inputMode;
			}
			if ((Object)(object)hsvPalette != (Object)null)
			{
				hsvPalette.InputMode = inputMode;
			}
			if ((Object)(object)rgbBlock != (Object)null)
			{
				rgbBlock.InputMode = inputMode;
			}
			if ((Object)(object)hsvBlock != (Object)null)
			{
				hsvBlock.InputMode = inputMode;
			}
			if ((Object)(object)aBlock != (Object)null)
			{
				aBlock.InputMode = inputMode;
			}
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			paletteMode = value;
			if ((Object)(object)rgbPalette != (Object)null)
			{
				rgbPalette.PaletteMode = paletteMode;
			}
			if ((Object)(object)hsvPalette != (Object)null)
			{
				hsvPalette.PaletteMode = paletteMode;
			}
			if ((Object)(object)rgbBlock != (Object)null)
			{
				rgbBlock.PaletteMode = paletteMode;
			}
			if ((Object)(object)hsvBlock != (Object)null)
			{
				hsvBlock.PaletteMode = paletteMode;
			}
			if ((Object)(object)aBlock != (Object)null)
			{
				aBlock.PaletteMode = paletteMode;
			}
		}
	}

	public Color32 Color32
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return color;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			color = value;
			UpdateBlocks(color);
			((UnityEvent<Color32>)OnChange).Invoke(color);
		}
	}

	public Color Color
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return Color32.op_Implicit(Color32);
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			Color32 = Color32.op_Implicit(value);
		}
	}

	public void Start()
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)rgbPalette != (Object)null)
		{
			RGBPalette = rgbPalette;
			rgbPalette.Start();
		}
		if ((Object)(object)hsvPalette != (Object)null)
		{
			HSVPalette = hsvPalette;
			hsvPalette.Start();
		}
		if ((Object)(object)rgbBlock != (Object)null)
		{
			RGBBlock = rgbBlock;
			rgbBlock.Start();
		}
		if ((Object)(object)hsvBlock != (Object)null)
		{
			HSVBlock = hsvBlock;
			hsvBlock.Start();
		}
		if ((Object)(object)aBlock != (Object)null)
		{
			ABlock = aBlock;
			aBlock.Start();
		}
		InputMode = inputMode;
		PaletteMode = paletteMode;
		UpdateBlocks(color);
	}

	private void OnEnable()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		UpdateBlocks(color);
	}

	private void ColorRGBChanged(Color32 newColor)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		color = newColor;
		UpdateBlocks(color);
		((UnityEvent<Color32>)OnChange).Invoke(color);
	}

	private void ColorHSVChanged(ColorHSV newColor)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		color = newColor;
		UpdateBlocks(newColor);
		((UnityEvent<Color32>)OnChange).Invoke(color);
	}

	private void ColorAlphaChanged(byte alpha)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		color.a = alpha;
		if ((Object)(object)aBlock != (Object)null)
		{
			aBlock.SetColor(color);
		}
		if ((Object)(object)colorView != (Object)null)
		{
			colorView.SetColor(color);
		}
		((UnityEvent<Color32>)OnChange).Invoke(color);
	}

	private void UpdateBlocks(Color32 newColor)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)colorView != (Object)null)
		{
			colorView.SetColor(newColor);
		}
		if ((Object)(object)rgbPalette != (Object)null)
		{
			rgbPalette.SetColor(newColor);
		}
		if ((Object)(object)hsvPalette != (Object)null)
		{
			hsvPalette.SetColor(newColor);
		}
		if ((Object)(object)rgbBlock != (Object)null)
		{
			rgbBlock.SetColor(newColor);
		}
		if ((Object)(object)hsvBlock != (Object)null)
		{
			hsvBlock.SetColor(newColor);
		}
		if ((Object)(object)aBlock != (Object)null)
		{
			aBlock.SetColor(newColor);
		}
	}

	private void UpdateBlocks(ColorHSV newColor)
	{
		if ((Object)(object)colorView != (Object)null)
		{
			colorView.SetColor(newColor);
		}
		if ((Object)(object)rgbPalette != (Object)null)
		{
			rgbPalette.SetColor(newColor);
		}
		if ((Object)(object)hsvPalette != (Object)null)
		{
			hsvPalette.SetColor(newColor);
		}
		if ((Object)(object)hsvBlock != (Object)null)
		{
			hsvBlock.SetColor(newColor);
		}
		if ((Object)(object)rgbBlock != (Object)null)
		{
			rgbBlock.SetColor(newColor);
		}
		if ((Object)(object)aBlock != (Object)null)
		{
			aBlock.SetColor(newColor);
		}
	}

	public void ToggleInputMode()
	{
		InputMode = ((InputMode == ColorPickerInputMode.RGB) ? ColorPickerInputMode.HSV : ColorPickerInputMode.RGB);
	}

	public void TogglePaletteMode()
	{
		List<ColorPickerPaletteMode> list = new List<ColorPickerPaletteMode>();
		if ((Object)(object)rgbPalette != (Object)null)
		{
			list.AddRange(rgbPaletteModes);
		}
		if ((Object)(object)hsvPalette != (Object)null)
		{
			list.AddRange(hsvPaletteModes);
		}
		if (list.Count != 0)
		{
			int num = list.IndexOf(PaletteMode) + 1;
			if (num == list.Count)
			{
				num = 0;
			}
			PaletteMode = list[num];
		}
	}

	private void OnDestroy()
	{
		RGBPalette = null;
		HSVPalette = null;
		RGBBlock = null;
		HSVBlock = null;
		ABlock = null;
		ColorView = null;
	}
}
