using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerABlock : MonoBehaviour
{
	[SerializeField]
	private Slider aSlider;

	[SerializeField]
	private Spinner aInput;

	[SerializeField]
	private Image aSliderBackground;

	[SerializeField]
	private Shader defaultShader;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected bool inUpdateMode;

	protected Color32 currentColor;

	public Slider ASlider
	{
		get
		{
			return aSlider;
		}
		set
		{
			SetASlider(value);
		}
	}

	public Spinner AInput
	{
		get
		{
			return aInput;
		}
		set
		{
			SetAInput(value);
		}
	}

	public Image ASliderBackground
	{
		get
		{
			return aSliderBackground;
		}
		set
		{
			aSliderBackground = value;
			UpdateMaterial();
		}
	}

	public Shader DefaultShader
	{
		get
		{
			return defaultShader;
		}
		set
		{
			defaultShader = value;
			UpdateMaterial();
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			paletteMode = value;
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			ASlider = aSlider;
			AInput = aInput;
			ASliderBackground = aSliderBackground;
		}
	}

	protected virtual void SetASlider(Slider value)
	{
		if ((Object)(object)aSlider != (Object)null)
		{
			((UnityEvent<float>)(object)aSlider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		aSlider = value;
		if ((Object)(object)aSlider != (Object)null)
		{
			((UnityEvent<float>)(object)aSlider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
			UpdateView();
		}
	}

	protected virtual void SetAInput(Spinner value)
	{
		if ((Object)(object)aInput != (Object)null)
		{
			((UnityEvent<int>)aInput.onValueChangeInt).RemoveListener((UnityAction<int>)SpinnerValueChanged);
		}
		aInput = value;
		if ((Object)(object)aInput != (Object)null)
		{
			((UnityEvent<int>)aInput.onValueChangeInt).AddListener((UnityAction<int>)SpinnerValueChanged);
			UpdateView();
		}
	}

	protected virtual void OnEnable()
	{
		UpdateMaterial();
	}

	private void SpinnerValueChanged(int value)
	{
		ValueChanged();
	}

	private void SliderValueChanged(float value)
	{
		ValueChanged();
	}

	protected virtual void ValueChanged()
	{
		if (!inUpdateMode)
		{
			((UnityEvent<byte>)OnChangeAlpha).Invoke(GetAlpha());
		}
	}

	protected byte GetAlpha()
	{
		if ((Object)(object)aSlider != (Object)null)
		{
			return (byte)aSlider.value;
		}
		if ((Object)(object)aInput != (Object)null)
		{
			return (byte)aInput.Value;
		}
		return currentColor.a;
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	protected virtual void UpdateView()
	{
		inUpdateMode = true;
		if ((Object)(object)aSlider != (Object)null)
		{
			aSlider.value = (int)currentColor.a;
		}
		if ((Object)(object)aInput != (Object)null)
		{
			aInput.Value = currentColor.a;
		}
		inUpdateMode = false;
	}

	protected virtual void UpdateMaterial()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Expected O, but got Unknown
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)defaultShader == (Object)null) && !((Object)(object)aSliderBackground == (Object)null))
		{
			Material val = new Material(defaultShader);
			val.SetColor("_ColorLeft", Color.black);
			val.SetColor("_ColorRight", Color.white);
			((Graphic)aSliderBackground).material = val;
		}
	}

	protected virtual void OnDestroy()
	{
		aSlider = null;
		aInput = null;
	}
}
