using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ColorPickerRGBPalette : MonoBehaviour
{
	[SerializeField]
	private Image palette;

	private RectTransform paletteRect;

	private OnDragListener dragListener;

	[SerializeField]
	private Shader paletteShader;

	[SerializeField]
	private RectTransform paletteCursor;

	[SerializeField]
	private Slider slider;

	[SerializeField]
	private Image sliderBackground;

	[SerializeField]
	private Shader sliderShader;

	private ColorPickerInputMode inputMode;

	private ColorPickerPaletteMode paletteMode;

	public ColorRGBChangedEvent OnChangeRGB = new ColorRGBChangedEvent();

	public ColorHSVChangedEvent OnChangeHSV = new ColorHSVChangedEvent();

	public ColorAlphaChangedEvent OnChangeAlpha = new ColorAlphaChangedEvent();

	private bool isStarted;

	protected bool inUpdateMode;

	protected Color32 currentColor;

	public Image Palette
	{
		get
		{
			return palette;
		}
		set
		{
			SetPalette(value);
		}
	}

	public Shader PaletteShader
	{
		get
		{
			return paletteShader;
		}
		set
		{
			paletteShader = value;
			UpdateMaterial();
		}
	}

	public RectTransform PaletteCursor
	{
		get
		{
			return paletteCursor;
		}
		set
		{
			paletteCursor = value;
			if ((Object)(object)paletteCursor != (Object)null)
			{
				UpdateView();
			}
		}
	}

	public Slider Slider
	{
		get
		{
			return slider;
		}
		set
		{
			SetSlider(value);
		}
	}

	public Image SliderBackground
	{
		get
		{
			return sliderBackground;
		}
		set
		{
			sliderBackground = value;
			UpdateMaterial();
		}
	}

	public Shader SliderShader
	{
		get
		{
			return sliderShader;
		}
		set
		{
			sliderShader = value;
			UpdateMaterial();
		}
	}

	public ColorPickerInputMode InputMode
	{
		get
		{
			return inputMode;
		}
		set
		{
			inputMode = value;
		}
	}

	public ColorPickerPaletteMode PaletteMode
	{
		get
		{
			return paletteMode;
		}
		set
		{
			SetPaletteMode(value);
		}
	}

	public virtual void Start()
	{
		if (!isStarted)
		{
			isStarted = true;
			Palette = palette;
			Slider = slider;
			SliderBackground = sliderBackground;
		}
	}

	protected virtual void OnEnable()
	{
		UpdateMaterial();
	}

	protected virtual void SetPalette(Image value)
	{
		if ((Object)(object)dragListener != (Object)null)
		{
			((UnityEvent<PointerEventData>)dragListener.OnDragEvent).RemoveListener((UnityAction<PointerEventData>)OnDrag);
		}
		palette = value;
		if ((Object)(object)palette != (Object)null)
		{
			ref RectTransform reference = ref paletteRect;
			Transform transform = ((Component)palette).transform;
			reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			dragListener = ((Component)palette).GetComponent<OnDragListener>() ?? ((Component)palette).gameObject.AddComponent<OnDragListener>();
			((UnityEvent<PointerEventData>)dragListener.OnDragEvent).AddListener((UnityAction<PointerEventData>)OnDrag);
			UpdateMaterial();
		}
		else
		{
			paletteRect = null;
		}
	}

	protected virtual void SetPaletteMode(ColorPickerPaletteMode value)
	{
		paletteMode = value;
		bool flag = paletteMode == ColorPickerPaletteMode.Red || paletteMode == ColorPickerPaletteMode.Green || paletteMode == ColorPickerPaletteMode.Blue;
		((Component)this).gameObject.SetActive(flag);
		if (flag)
		{
			UpdateView();
		}
	}

	protected virtual void SetSlider(Slider value)
	{
		if ((Object)(object)slider != (Object)null)
		{
			((UnityEvent<float>)(object)slider.onValueChanged).RemoveListener((UnityAction<float>)SliderValueChanged);
		}
		slider = value;
		if ((Object)(object)slider != (Object)null)
		{
			((UnityEvent<float>)(object)slider.onValueChanged).AddListener((UnityAction<float>)SliderValueChanged);
		}
	}

	private void SliderValueChanged(float value)
	{
		ValueChanged();
	}

	protected virtual void ValueChanged()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (!inUpdateMode)
		{
			currentColor = GetColor();
			((UnityEvent<Color32>)OnChangeRGB).Invoke(currentColor);
		}
	}

	public void SetColor(Color32 color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	public void SetColor(ColorHSV color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		currentColor = color;
		UpdateView();
	}

	protected virtual void OnDrag(PointerEventData eventData)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = paletteRect.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		Vector2 val = default(Vector2);
		RectTransformUtility.ScreenPointToLocalPointInRectangle(paletteRect, eventData.position, eventData.pressEventCamera, ref val);
		val.x = Mathf.Clamp(val.x, 0f, size.x);
		val.y = Mathf.Clamp(val.y, 0f - size.y, 0f);
		((Transform)paletteCursor).localPosition = Vector2.op_Implicit(val);
		ValueChanged();
	}

	protected Color32 GetColor()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 cursorCoords = GetCursorCoords();
		byte b = (byte)slider.value;
		byte b2 = (byte)Mathf.RoundToInt(cursorCoords.x);
		byte b3 = (byte)Mathf.RoundToInt(cursorCoords.y);
		return (Color32)(paletteMode switch
		{
			ColorPickerPaletteMode.Red => new Color32(b, b3, b2, currentColor.a), 
			ColorPickerPaletteMode.Green => new Color32(b3, b, b2, currentColor.a), 
			ColorPickerPaletteMode.Blue => new Color32(b2, b3, b, currentColor.a), 
			_ => currentColor, 
		});
	}

	protected Vector2 GetCursorCoords()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = ((Transform)paletteCursor).localPosition;
		Rect rect = paletteRect.rect;
		Vector2 size = ((Rect)(ref rect)).size;
		float num = localPosition.x / size.x * 255f;
		float num2 = (localPosition.y / size.y + 1f) * 255f;
		return new Vector2(num, num2);
	}

	protected virtual void UpdateView()
	{
		UpdateViewReal();
	}

	protected virtual void UpdateViewReal()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		inUpdateMode = true;
		if ((Object)(object)slider != (Object)null)
		{
			slider.value = GetSliderValue();
		}
		if ((Object)(object)sliderBackground != (Object)null)
		{
			Color32[] sliderColors = GetSliderColors();
			((Graphic)sliderBackground).material.SetColor("_ColorBottom", Color32.op_Implicit(sliderColors[0]));
			((Graphic)sliderBackground).material.SetColor("_ColorTop", Color32.op_Implicit(sliderColors[1]));
		}
		if ((Object)(object)paletteCursor != (Object)null && (Object)(object)palette != (Object)null && (Object)(object)paletteRect != (Object)null)
		{
			Vector2 paletteCoords = GetPaletteCoords();
			Rect rect = paletteRect.rect;
			Vector2 size = ((Rect)(ref rect)).size;
			((Transform)paletteCursor).localPosition = new Vector3(paletteCoords.x / 255f * size.x, (0f - (1f - paletteCoords.y / 255f)) * size.y, 0f);
		}
		if ((Object)(object)palette != (Object)null)
		{
			Color[] paletteColors = GetPaletteColors();
			((Graphic)palette).material.SetColor("_ColorLeft", paletteColors[0]);
			((Graphic)palette).material.SetColor("_ColorRight", paletteColors[1]);
			((Graphic)palette).material.SetColor("_ColorBottom", paletteColors[2]);
			((Graphic)palette).material.SetColor("_ColorTop", paletteColors[3]);
		}
		inUpdateMode = false;
	}

	protected int GetSliderValue()
	{
		return paletteMode switch
		{
			ColorPickerPaletteMode.Red => currentColor.r, 
			ColorPickerPaletteMode.Green => currentColor.g, 
			ColorPickerPaletteMode.Blue => currentColor.b, 
			_ => 0, 
		};
	}

	protected Color32[] GetSliderColors()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		return paletteMode switch
		{
			ColorPickerPaletteMode.Red => (Color32[])(object)new Color32[2]
			{
				new Color32((byte)0, currentColor.g, currentColor.b, byte.MaxValue),
				new Color32(byte.MaxValue, currentColor.g, currentColor.b, byte.MaxValue)
			}, 
			ColorPickerPaletteMode.Green => (Color32[])(object)new Color32[2]
			{
				new Color32(currentColor.r, (byte)0, currentColor.b, byte.MaxValue),
				new Color32(currentColor.r, byte.MaxValue, currentColor.b, byte.MaxValue)
			}, 
			ColorPickerPaletteMode.Blue => (Color32[])(object)new Color32[2]
			{
				new Color32(currentColor.r, currentColor.g, (byte)0, byte.MaxValue),
				new Color32(currentColor.r, currentColor.g, byte.MaxValue, byte.MaxValue)
			}, 
			_ => (Color32[])(object)new Color32[2]
			{
				new Color32((byte)0, (byte)0, (byte)0, byte.MaxValue),
				new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue)
			}, 
		};
	}

	protected Vector2 GetPaletteCoords()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		return (Vector2)(paletteMode switch
		{
			ColorPickerPaletteMode.Red => new Vector2((float)(int)currentColor.b, (float)(int)currentColor.g), 
			ColorPickerPaletteMode.Green => new Vector2((float)(int)currentColor.b, (float)(int)currentColor.r), 
			ColorPickerPaletteMode.Blue => new Vector2((float)(int)currentColor.r, (float)(int)currentColor.g), 
			_ => new Vector2(0f, 0f), 
		});
	}

	protected Color[] GetPaletteColors()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		return paletteMode switch
		{
			ColorPickerPaletteMode.Red => (Color[])(object)new Color[4]
			{
				new Color((float)(int)currentColor.r / 255f / 2f, 0f, 0f, 1f),
				new Color((float)(int)currentColor.r / 255f / 2f, 0f, 1f, 1f),
				new Color((float)(int)currentColor.r / 255f / 2f, 0f, 0f, 1f),
				new Color((float)(int)currentColor.r / 255f / 2f, 1f, 0f, 1f)
			}, 
			ColorPickerPaletteMode.Green => (Color[])(object)new Color[4]
			{
				new Color(0f, (float)(int)currentColor.g / 255f / 2f, 0f, 1f),
				new Color(0f, (float)(int)currentColor.g / 255f / 2f, 1f, 1f),
				new Color(0f, (float)(int)currentColor.g / 255f / 2f, 0f, 1f),
				new Color(1f, (float)(int)currentColor.g / 255f / 2f, 0f, 1f)
			}, 
			ColorPickerPaletteMode.Blue => (Color[])(object)new Color[4]
			{
				new Color(0f, 0f, (float)(int)currentColor.b / 255f / 2f, 1f),
				new Color(1f, 0f, (float)(int)currentColor.b / 255f / 2f, 1f),
				new Color(0f, 0f, (float)(int)currentColor.b / 255f / 2f, 1f),
				new Color(0f, 1f, (float)(int)currentColor.b / 255f / 2f, 1f)
			}, 
			_ => (Color[])(object)new Color[4]
			{
				new Color(0f, 0f, 0f, 1f),
				new Color(1f, 1f, 1f, 1f),
				new Color(0f, 0f, 0f, 1f),
				new Color(1f, 1f, 1f, 1f)
			}, 
		};
	}

	protected virtual void UpdateMaterial()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected O, but got Unknown
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Expected O, but got Unknown
		if ((Object)(object)paletteShader != (Object)null && (Object)(object)palette != (Object)null)
		{
			((Graphic)palette).material = new Material(paletteShader);
		}
		if ((Object)(object)sliderShader != (Object)null && (Object)(object)sliderBackground != (Object)null)
		{
			((Graphic)sliderBackground).material = new Material(sliderShader);
		}
		UpdateViewReal();
	}

	protected virtual void OnDestroy()
	{
		dragListener = null;
		slider = null;
	}
}
