using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class OnChangeEventFloat : UnityEvent<float>
{
}
