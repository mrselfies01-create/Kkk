using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class Resizable : MonoBehaviour, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	[Serializable]
	public struct Directions
	{
		public bool Top;

		public bool Bottom;

		public bool Left;

		public bool Right;

		public Directions(bool top, bool bottom, bool left, bool right)
		{
			Top = top;
			Bottom = bottom;
			Left = left;
			Right = right;
		}
	}

	public struct Regions
	{
		public bool Top;

		public bool Bottom;

		public bool Left;

		public bool Right;

		public bool NWSE => (Top && Left) || (Bottom && Right);

		public bool NESW => (Top && Right) || (Bottom && Left);

		public bool NS => (Top && !Right) || (Bottom && !Left);

		public bool EW => (!Top && Right) || (!Bottom && Left);

		public bool Active => Top || Bottom || Left || Right;

		public void Reset()
		{
			Top = false;
			Bottom = false;
			Left = false;
			Right = false;
		}

		public override string ToString()
		{
			return $"Top: {Top}; Bottom: {Bottom}; Left: {Left}; Right: {Right}";
		}
	}

	[SerializeField]
	public bool UpdateRectTransform = true;

	[SerializeField]
	public bool UpdateLayoutElement = true;

	[SerializeField]
	[Tooltip("Maximum padding from border where resize active.")]
	public float ActiveRegion = 5f;

	[SerializeField]
	public Vector2 MinSize;

	[SerializeField]
	[Tooltip("Set 0 to unlimit.")]
	public Vector2 MaxSize;

	[SerializeField]
	public bool KeepAspectRatio;

	[SerializeField]
	public Directions ResizeDirections = new Directions(top: true, bottom: true, left: true, right: true);

	[SerializeField]
	public Camera CurrentCamera;

	[SerializeField]
	public Texture2D CursorEWTexture;

	[SerializeField]
	public Vector2 CursorEWHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D CursorNSTexture;

	[SerializeField]
	public Vector2 CursorNSHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D CursorNESWTexture;

	[SerializeField]
	public Vector2 CursorNESWHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D CursorNWSETexture;

	[SerializeField]
	public Vector2 CursorNWSEHotSpot = new Vector2(16f, 16f);

	[SerializeField]
	public Texture2D DefaultCursorTexture;

	[SerializeField]
	public Vector2 DefaultCursorHotSpot;

	public ResizableEvent OnStartResize = new ResizableEvent();

	public ResizableEvent OnEndResize = new ResizableEvent();

	private RectTransform rectTransform;

	private LayoutElement layoutElement;

	private Regions regions;

	private Regions dragRegions;

	private Canvas canvas;

	private RectTransform canvasRect;

	private bool processDrag;

	private static bool globalCursorSetted;

	private bool cursorSetted;

	public RectTransform RectTransform
	{
		get
		{
			if ((Object)(object)rectTransform == (Object)null)
			{
				ref RectTransform reference = ref rectTransform;
				Transform transform = ((Component)this).transform;
				reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			}
			return rectTransform;
		}
	}

	public LayoutElement LayoutElement
	{
		get
		{
			if ((Object)(object)layoutElement == (Object)null)
			{
				layoutElement = ((Component)this).GetComponent<LayoutElement>() ?? ((Component)this).gameObject.AddComponent<LayoutElement>();
			}
			return layoutElement;
		}
	}

	private void Start()
	{
		HorizontalOrVerticalLayoutGroup component = ((Component)this).GetComponent<HorizontalOrVerticalLayoutGroup>();
		if (Object.op_Implicit((Object)(object)component))
		{
			Utilites.UpdateLayout((LayoutGroup)(object)component);
		}
		Init();
	}

	public void OnInitializePotentialDrag(PointerEventData eventData)
	{
		Init();
	}

	public void Init()
	{
		ref RectTransform reference = ref canvasRect;
		Transform obj = Utilites.FindCanvas(((Component)this).transform);
		reference = (RectTransform)(object)((obj is RectTransform) ? obj : null);
		canvas = ((Component)canvasRect).GetComponent<Canvas>();
	}

	private void LateUpdate()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		globalCursorSetted = false;
		Vector2 val = default(Vector2);
		if ((!globalCursorSetted || cursorSetted) && !processDrag && Input.mousePresent && RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, Vector2.op_Implicit(Input.mousePosition), CurrentCamera, ref val))
		{
			Rect rect = RectTransform.rect;
			if (!((Rect)(ref rect)).Contains(val))
			{
				regions.Reset();
				UpdateCursor();
			}
			else
			{
				UpdateRegions(val);
				UpdateCursor();
			}
		}
	}

	private void UpdateRegions(Vector2 point)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		regions.Top = ResizeDirections.Top && CheckTop(point);
		regions.Bottom = ResizeDirections.Bottom && CheckBottom(point);
		regions.Left = ResizeDirections.Left && CheckLeft(point);
		regions.Right = ResizeDirections.Right && CheckRight(point);
	}

	private void UpdateCursor()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		if (regions.NWSE)
		{
			globalCursorSetted = true;
			cursorSetted = true;
			Cursor.SetCursor(CursorNWSETexture, CursorNWSEHotSpot, Utilites.GetCursorMode());
		}
		else if (regions.NESW)
		{
			globalCursorSetted = true;
			cursorSetted = true;
			Cursor.SetCursor(CursorNESWTexture, CursorNESWHotSpot, Utilites.GetCursorMode());
		}
		else if (regions.NS)
		{
			globalCursorSetted = true;
			cursorSetted = true;
			Cursor.SetCursor(CursorNSTexture, CursorNSHotSpot, Utilites.GetCursorMode());
		}
		else if (regions.EW)
		{
			globalCursorSetted = true;
			cursorSetted = true;
			Cursor.SetCursor(CursorEWTexture, CursorEWHotSpot, Utilites.GetCursorMode());
		}
		else if (cursorSetted)
		{
			globalCursorSetted = false;
			cursorSetted = false;
			Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
		}
	}

	private bool CheckTop(Vector2 point)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = RectTransform.rect;
		((Rect)(ref rect)).position = new Vector2(((Rect)(ref rect)).position.x, ((Rect)(ref rect)).position.y + ((Rect)(ref rect)).height - ActiveRegion);
		((Rect)(ref rect)).height = ActiveRegion;
		return ((Rect)(ref rect)).Contains(point);
	}

	private bool CheckBottom(Vector2 point)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = RectTransform.rect;
		((Rect)(ref rect)).height = ActiveRegion;
		return ((Rect)(ref rect)).Contains(point);
	}

	private bool CheckLeft(Vector2 point)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = RectTransform.rect;
		((Rect)(ref rect)).width = ActiveRegion;
		return ((Rect)(ref rect)).Contains(point);
	}

	private bool CheckRight(Vector2 point)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = RectTransform.rect;
		((Rect)(ref rect)).position = new Vector2(((Rect)(ref rect)).position.x + ((Rect)(ref rect)).width - ActiveRegion, ((Rect)(ref rect)).position.y);
		((Rect)(ref rect)).width = ActiveRegion;
		return ((Rect)(ref rect)).Contains(point);
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		processDrag = false;
		Vector2 point = default(Vector2);
		if (RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.pressPosition, eventData.pressEventCamera, ref point))
		{
			UpdateRegions(point);
			processDrag = regions.Active;
			dragRegions = regions;
			UpdateCursor();
			LayoutElement obj = LayoutElement;
			Rect rect = RectTransform.rect;
			obj.preferredHeight = ((Rect)(ref rect)).height;
			LayoutElement obj2 = LayoutElement;
			Rect rect2 = RectTransform.rect;
			obj2.preferredWidth = ((Rect)(ref rect2)).width;
			((UnityEvent<Resizable>)OnStartResize).Invoke(this);
		}
	}

	private void ResetCursor()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		globalCursorSetted = false;
		cursorSetted = false;
		Cursor.SetCursor(DefaultCursorTexture, DefaultCursorHotSpot, Utilites.GetCursorMode());
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		ResetCursor();
		processDrag = false;
		((UnityEvent<Resizable>)OnEndResize).Invoke(this);
	}

	public void OnDrag(PointerEventData eventData)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (processDrag)
		{
			if ((Object)(object)canvas == (Object)null)
			{
				throw new MissingComponentException(((Object)((Component)this).gameObject).name + " not in Canvas hierarchy.");
			}
			Vector2 val = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position, CurrentCamera, ref val);
			Vector2 val2 = default(Vector2);
			RectTransformUtility.ScreenPointToLocalPointInRectangle(RectTransform, eventData.position - eventData.delta, CurrentCamera, ref val2);
			Vector2 delta = val - val2;
			if (UpdateRectTransform)
			{
				PerformUpdateRectTransform(delta);
			}
			if (UpdateLayoutElement)
			{
				PerformUpdateLayoutElement(delta);
			}
		}
	}

	private void PerformUpdateRectTransform(Vector2 delta)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		Vector2 pivot = RectTransform.pivot;
		Rect rect = RectTransform.rect;
		Vector2 val = ((Rect)(ref rect)).size;
		Vector2 val2 = val;
		Vector2 val3 = default(Vector2);
		((Vector2)(ref val3))._002Ector(1f, 1f);
		if (dragRegions.Left || dragRegions.Right)
		{
			val3.x = (dragRegions.Right ? 1 : (-1));
			val.x = Mathf.Max(MinSize.x, val.x + val3.x * delta.x);
			if (MaxSize.x != 0f)
			{
				val.x = Mathf.Min(MaxSize.x, val.x);
			}
		}
		if (dragRegions.Top || dragRegions.Bottom)
		{
			val3.y = (dragRegions.Top ? 1 : (-1));
			val.y = Mathf.Max(MinSize.y, val.y + val3.y * delta.y);
			if (MaxSize.y != 0f)
			{
				val.y = Mathf.Min(MaxSize.y, val.y);
			}
		}
		if (KeepAspectRatio)
		{
			val = FixAspectRatio(val, val2);
		}
		Vector2 val4 = default(Vector2);
		((Vector2)(ref val4))._002Ector((!dragRegions.Right) ? (pivot.x - 1f) : pivot.x, (!dragRegions.Top) ? (pivot.y - 1f) : pivot.y);
		Vector2 val5 = val - val2;
		((Vector2)(ref val5))._002Ector(val5.x * val4.x, val5.y * val4.y);
		RectTransform obj = RectTransform;
		obj.anchoredPosition += val5;
		RectTransform.SetSizeWithCurrentAnchors((Axis)0, val.x);
		RectTransform.SetSizeWithCurrentAnchors((Axis)1, val.y);
	}

	protected Vector2 FixAspectRatio(Vector2 newSize, Vector2 baseSize)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		Vector2 result = newSize;
		float num = baseSize.x / baseSize.y;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(Mathf.Abs(newSize.x - baseSize.x), Mathf.Abs(newSize.y - baseSize.y));
		if (val.x >= val.y)
		{
			result.y = result.x / num;
		}
		else
		{
			result.x = result.y * num;
		}
		return result;
	}

	private void PerformUpdateLayoutElement(Vector2 delta)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(LayoutElement.preferredWidth, LayoutElement.preferredHeight);
		Vector2 baseSize = val;
		if (dragRegions.Left || dragRegions.Right)
		{
			int num = (dragRegions.Right ? 1 : (-1));
			float num2 = Mathf.Max(MinSize.x, LayoutElement.preferredWidth + (float)num * delta.x);
			if (MaxSize.x != 0f)
			{
				val.x = Mathf.Min(MaxSize.x, num2);
			}
		}
		if (dragRegions.Top || dragRegions.Bottom)
		{
			int num3 = (dragRegions.Top ? 1 : (-1));
			float num4 = Mathf.Max(MinSize.y, LayoutElement.preferredHeight + (float)num3 * delta.y);
			if (MaxSize.y != 0f)
			{
				val.y = Mathf.Min(MaxSize.y, num4);
			}
		}
		if (KeepAspectRatio)
		{
			val = FixAspectRatio(val, baseSize);
		}
		LayoutElement.preferredWidth = val.x;
		LayoutElement.preferredHeight = val.y;
	}
}
