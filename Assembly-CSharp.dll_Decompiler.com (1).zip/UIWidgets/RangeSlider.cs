using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/RangeSlider", 300)]
public class RangeSlider : RangeSliderBase<int>
{
	protected override float ValueToPosition(int value)
	{
		float num = FillSize() / (float)(limitMax - limitMin);
		return num * (float)(InBounds(value) - limitMin) + GetStartPoint();
	}

	protected override int PositionToValue(float position)
	{
		float num = FillSize() / (float)(limitMax - limitMin);
		float num2 = position / num + (float)base.LimitMin;
		if (WholeNumberOfSteps)
		{
			return InBounds(Mathf.RoundToInt(num2 / (float)step) * step);
		}
		return InBounds(Mathf.RoundToInt(num2));
	}

	protected override Vector2 MinPositionLimits()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(ValueToPosition(base.LimitMin), ValueToPosition(valueMax - step));
	}

	protected override Vector2 MaxPositionLimits()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(ValueToPosition(valueMin + step), ValueToPosition(limitMax));
	}

	protected override int InBounds(int value)
	{
		return Mathf.Clamp(value, limitMin, limitMax);
	}

	protected override int InBoundsMin(int value)
	{
		return Mathf.Clamp(value, limitMin, valueMax - step);
	}

	protected override int InBoundsMax(int value)
	{
		return Mathf.Clamp(value, valueMin + step, valueMax);
	}

	protected override void IncreaseMin()
	{
		base.ValueMin += step;
	}

	protected override void DecreaseMin()
	{
		base.ValueMin -= step;
	}

	protected override void IncreaseMax()
	{
		base.ValueMax += step;
	}

	protected override void DecreaseMax()
	{
		base.ValueMax -= step;
	}
}
