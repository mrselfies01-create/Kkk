using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewItemSelect : UnityEvent<ListViewItem>
{
}
