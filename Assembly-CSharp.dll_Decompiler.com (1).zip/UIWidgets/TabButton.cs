using UnityEngine.UI;

namespace UIWidgets;

public class TabButton : Button
{
}
