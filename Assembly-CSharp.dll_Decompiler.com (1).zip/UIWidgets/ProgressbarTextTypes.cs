namespace UIWidgets;

public enum ProgressbarTextTypes
{
	None,
	Percent,
	Range
}
