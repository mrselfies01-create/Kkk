using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(InputField))]
[AddComponentMenu("UI/Combobox", 220)]
public class Combobox : MonoBehaviour, ISubmitHandler, IEventSystemHandler
{
	[SerializeField]
	private ListView listView;

	[SerializeField]
	private Button toggleButton;

	[SerializeField]
	private bool editable = true;

	private InputField input;

	public ListViewEvent OnSelect = new ListViewEvent();

	private Transform _listCanvas;

	private Transform listParent;

	[NonSerialized]
	private bool isStartedCombobox;

	protected int? ModalKey;

	protected List<SelectListener> childrenDeselect = new List<SelectListener>();

	public ListView ListView
	{
		get
		{
			return listView;
		}
		set
		{
			SetListView(value);
		}
	}

	public Button ToggleButton
	{
		get
		{
			return toggleButton;
		}
		set
		{
			SetToggleButton(value);
		}
	}

	public bool Editable
	{
		get
		{
			return editable;
		}
		set
		{
			editable = value;
			((Selectable)input).interactable = editable;
		}
	}

	private Transform listCanvas
	{
		get
		{
			if ((Object)(object)_listCanvas == (Object)null)
			{
				_listCanvas = Utilites.FindCanvas(((Component)listView).transform.parent);
			}
			return _listCanvas;
		}
	}

	private void Awake()
	{
		Start();
	}

	public virtual void Start()
	{
		if (isStartedCombobox)
		{
			return;
		}
		isStartedCombobox = true;
		input = ((Component)this).GetComponent<InputField>();
		((UnityEvent<string>)(object)input.onEndEdit).AddListener((UnityAction<string>)InputItem);
		Editable = editable;
		SetToggleButton(toggleButton);
		SetListView(listView);
		if ((Object)(object)listView != (Object)null)
		{
			((UnityEvent<int, string>)listView.OnSelectString).RemoveListener((UnityAction<int, string>)SelectItem);
			((Component)listView).gameObject.SetActive(true);
			listView.Start();
			if (listView.SelectedIndex != -1)
			{
				input.text = listView.DataSource[listView.SelectedIndex];
			}
			((Component)listView).gameObject.SetActive(false);
			((UnityEvent<int, string>)listView.OnSelectString).AddListener((UnityAction<int, string>)SelectItem);
		}
	}

	protected virtual void SetListView(ListView value)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Expected O, but got Unknown
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Expected O, but got Unknown
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Expected O, but got Unknown
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Expected O, but got Unknown
		if ((Object)(object)listView != (Object)null)
		{
			listParent = null;
			((UnityEvent<int, string>)listView.OnSelectString).RemoveListener((UnityAction<int, string>)SelectItem);
			((UnityEvent<BaseEventData>)listView.OnFocusOut).RemoveListener((UnityAction<BaseEventData>)onFocusHideList);
			listView.onCancel.RemoveListener(new UnityAction(OnListViewCancel));
			listView.onItemCancel.RemoveListener(new UnityAction(OnListViewCancel));
			RemoveDeselectCallbacks();
		}
		listView = value;
		if ((Object)(object)listView != (Object)null)
		{
			listParent = ((Component)listView).transform.parent;
			((UnityEvent<int, string>)listView.OnSelectString).AddListener((UnityAction<int, string>)SelectItem);
			((UnityEvent<BaseEventData>)listView.OnFocusOut).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			listView.onCancel.AddListener(new UnityAction(OnListViewCancel));
			listView.onItemCancel.AddListener(new UnityAction(OnListViewCancel));
			AddDeselectCallbacks();
		}
	}

	protected virtual void SetToggleButton(Button value)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Expected O, but got Unknown
		if ((Object)(object)toggleButton != (Object)null)
		{
			((UnityEvent)toggleButton.onClick).RemoveListener(new UnityAction(ToggleList));
		}
		toggleButton = value;
		if ((Object)(object)toggleButton != (Object)null)
		{
			((UnityEvent)toggleButton.onClick).AddListener(new UnityAction(ToggleList));
		}
	}

	public virtual void Clear()
	{
		listView.DataSource.Clear();
		input.text = string.Empty;
	}

	public virtual void ToggleList()
	{
		if (!((Object)(object)listView == (Object)null))
		{
			if (((Component)listView).gameObject.activeSelf)
			{
				HideList();
			}
			else
			{
				ShowList();
			}
		}
	}

	public virtual void ShowList()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected O, but got Unknown
		if (!((Object)(object)listView == (Object)null))
		{
			if ((Object)(object)listCanvas != (Object)null)
			{
				ModalKey = ModalHelper.Open((MonoBehaviour)(object)this, (Sprite)null, (Color?)new Color(0f, 0f, 0f, 0f), new UnityAction(HideList));
				listParent = ((Component)listView).transform.parent;
				((Component)listView).transform.SetParent(listCanvas);
			}
			((Component)listView).gameObject.SetActive(true);
			if ((Object)(object)listView.Layout != (Object)null)
			{
				listView.Layout.UpdateLayout();
			}
			if (listView.SelectComponent())
			{
				SetChildDeselectListener(EventSystem.current.currentSelectedGameObject);
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(((Component)listView).gameObject);
			}
		}
	}

	public virtual void HideList()
	{
		int? modalKey = ModalKey;
		if (modalKey.HasValue)
		{
			int? modalKey2 = ModalKey;
			ModalHelper.Close(modalKey2.Value);
			ModalKey = null;
		}
		if (!((Object)(object)listView == (Object)null))
		{
			((Component)listView).gameObject.SetActive(false);
			if ((Object)(object)listCanvas != (Object)null)
			{
				((Component)listView).transform.SetParent(listParent);
			}
		}
	}

	protected void onFocusHideList(BaseEventData eventData)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)eventData.selectedObject == (Object)(object)((Component)this).gameObject)
		{
			return;
		}
		if (eventData is ListViewItemEventData listViewItemEventData)
		{
			if ((Object)(object)listViewItemEventData.NewSelectedObject != (Object)null)
			{
				SetChildDeselectListener(listViewItemEventData.NewSelectedObject);
			}
			return;
		}
		PointerEventData val = (PointerEventData)(object)((eventData is PointerEventData) ? eventData : null);
		if (val == null)
		{
			HideList();
			return;
		}
		RaycastResult pointerPressRaycast = val.pointerPressRaycast;
		GameObject gameObject = ((RaycastResult)(ref pointerPressRaycast)).gameObject;
		if (!((Object)(object)gameObject == (Object)null) && !((object)gameObject).Equals((object?)((Component)toggleButton).gameObject))
		{
			if (gameObject.transform.IsChildOf(((Component)listView).transform))
			{
				SetChildDeselectListener(gameObject);
			}
			else
			{
				HideList();
			}
		}
	}

	protected void SetChildDeselectListener(GameObject child)
	{
		SelectListener deselectListener = GetDeselectListener(child);
		if (!childrenDeselect.Contains(deselectListener))
		{
			((UnityEvent<BaseEventData>)deselectListener.onDeselect).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			childrenDeselect.Add(deselectListener);
		}
	}

	protected SelectListener GetDeselectListener(GameObject go)
	{
		return go.GetComponent<SelectListener>() ?? go.AddComponent<SelectListener>();
	}

	protected void AddDeselectCallbacks()
	{
		if (!((Object)(object)listView.ScrollRect == (Object)null) && !((Object)(object)listView.ScrollRect.verticalScrollbar == (Object)null))
		{
			GameObject gameObject = ((Component)listView.ScrollRect.verticalScrollbar).gameObject;
			SelectListener deselectListener = GetDeselectListener(gameObject);
			((UnityEvent<BaseEventData>)deselectListener.onDeselect).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			childrenDeselect.Add(deselectListener);
		}
	}

	protected void RemoveDeselectCallbacks()
	{
		childrenDeselect.ForEach(RemoveDeselectCallback);
		childrenDeselect.Clear();
	}

	protected void RemoveDeselectCallback(SelectListener listener)
	{
		if ((Object)(object)listener != (Object)null)
		{
			((UnityEvent<BaseEventData>)listener.onDeselect).RemoveListener((UnityAction<BaseEventData>)onFocusHideList);
		}
	}

	public virtual int Set(string item, bool allowDuplicate = true)
	{
		return listView.Set(item, allowDuplicate);
	}

	protected virtual void SelectItem(int index, string text)
	{
		input.text = text;
		HideList();
		if ((Object)(object)EventSystem.current != (Object)null && !EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)toggleButton).gameObject);
		}
		((UnityEvent<int, string>)OnSelect).Invoke(index, text);
	}

	protected virtual void InputItem(string item)
	{
		if (editable && !(item == string.Empty) && !listView.DataSource.Contains(item))
		{
			int index = listView.Add(item);
			listView.Select(index);
		}
	}

	protected virtual void OnDestroy()
	{
		ListView = null;
		ToggleButton = null;
		if ((Object)(object)input != (Object)null)
		{
			((UnityEvent<string>)(object)input.onEndEdit).RemoveListener((UnityAction<string>)InputItem);
		}
	}

	protected void OnListViewCancel()
	{
		HideList();
	}

	public virtual void OnSubmit(BaseEventData eventData)
	{
		ShowList();
	}
}
