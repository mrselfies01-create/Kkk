using UnityEngine.Events;

namespace UIWidgets;

public class SwitchEvent : UnityEvent<bool>
{
}
