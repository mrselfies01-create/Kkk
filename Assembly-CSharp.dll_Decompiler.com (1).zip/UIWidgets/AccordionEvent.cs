using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class AccordionEvent : UnityEvent<AccordionItem>
{
}
