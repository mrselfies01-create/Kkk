using UnityEngine;
using UnityEngine.UI;

namespace UIWidgets;

public class TreeViewComponent : TreeViewComponentBase<TreeViewItem>
{
	private TreeViewItem item;

	public TreeViewItem Item
	{
		get
		{
			return item;
		}
		set
		{
			if (item != null)
			{
				item.OnChange -= UpdateView;
			}
			item = value;
			if (item != null)
			{
				item.OnChange += UpdateView;
			}
			UpdateView();
		}
	}

	public override void SetData(TreeNode<TreeViewItem> newNode, int depth)
	{
		base.Node = newNode;
		base.SetData(base.Node, depth);
		Item = ((!(base.Node == null)) ? base.Node.Item : null);
	}

	protected virtual void UpdateView()
	{
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)Icon == (Object)null) && !((Object)(object)Text == (Object)null))
		{
			if (Item == null)
			{
				Icon.sprite = null;
				Text.text = string.Empty;
			}
			else
			{
				Icon.sprite = Item.Icon;
				Text.text = Item.LocalizedName ?? Item.Name;
			}
			if (SetNativeSize)
			{
				((Graphic)Icon).SetNativeSize();
			}
			((Graphic)Icon).color = ((!((Object)(object)Icon.sprite == (Object)null)) ? Color.white : Color.clear);
		}
	}

	public override void MovedToCache()
	{
		if ((Object)(object)Icon != (Object)null)
		{
			Icon.sprite = null;
		}
	}

	protected override void OnDestroy()
	{
		if (item != null)
		{
			item.OnChange -= UpdateView;
		}
		base.OnDestroy();
	}
}
