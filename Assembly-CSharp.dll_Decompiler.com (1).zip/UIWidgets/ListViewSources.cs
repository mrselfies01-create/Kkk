namespace UIWidgets;

public enum ListViewSources
{
	List,
	File
}
