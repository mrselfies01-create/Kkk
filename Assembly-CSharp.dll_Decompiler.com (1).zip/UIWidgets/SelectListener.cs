using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class SelectListener : MonoBehaviour, ISelectHandler, IDeselectHandler, IEventSystemHandler
{
	public SelectEvent onSelect = new SelectEvent();

	public SelectEvent onDeselect = new SelectEvent();

	public void OnSelect(BaseEventData eventData)
	{
		((UnityEvent<BaseEventData>)onSelect).Invoke(eventData);
	}

	public void OnDeselect(BaseEventData eventData)
	{
		((UnityEvent<BaseEventData>)onDeselect).Invoke(eventData);
	}
}
