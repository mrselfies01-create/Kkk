namespace UIWidgets;

public class ComboboxIconsItemComponent : ListViewIconsItemComponent
{
	public ComboboxIcons ComboboxIcons;

	public void Remove()
	{
		ComboboxIcons.ListView.Deselect(Index);
	}
}
