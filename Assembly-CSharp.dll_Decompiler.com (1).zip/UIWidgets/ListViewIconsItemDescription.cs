using System;
using UnityEngine;

namespace UIWidgets;

[Serializable]
public class ListViewIconsItemDescription
{
	[SerializeField]
	public Sprite Icon;

	[SerializeField]
	public string Name;

	[NonSerialized]
	public string LocalizedName;

	[SerializeField]
	public int Value;
}
