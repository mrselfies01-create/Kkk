using System;
using UnityEngine;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewGameObjectsEvent : UnityEvent<int, GameObject>
{
}
