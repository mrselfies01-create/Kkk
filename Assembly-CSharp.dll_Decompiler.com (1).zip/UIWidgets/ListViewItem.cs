using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

[RequireComponent(typeof(Image))]
public class ListViewItem : UIBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler, ISubmitHandler, ICancelHandler, ISelectHandler, IDeselectHandler, IMoveHandler, IComparable<ListViewItem>, IEventSystemHandler
{
	[HideInInspector]
	public int Index = -1;

	public UnityEvent onClick = new UnityEvent();

	public ListViewItemSelect onSubmit = new ListViewItemSelect();

	public ListViewItemSelect onCancel = new ListViewItemSelect();

	public ListViewItemSelect onSelect = new ListViewItemSelect();

	public ListViewItemSelect onDeselect = new ListViewItemSelect();

	public ListViewItemMove onMove = new ListViewItemMove();

	public PointerUnityEvent onPointerClick = new PointerUnityEvent();

	public PointerUnityEvent onPointerEnter = new PointerUnityEvent();

	public PointerUnityEvent onPointerExit = new PointerUnityEvent();

	[NonSerialized]
	public ImageAdvanced Background;

	protected override void Awake()
	{
		Background = ((Component)this).GetComponent<ImageAdvanced>();
	}

	public virtual void OnMove(AxisEventData eventData)
	{
		((UnityEvent<AxisEventData, ListViewItem>)onMove).Invoke(eventData, this);
	}

	public virtual void OnSubmit(BaseEventData eventData)
	{
		((UnityEvent<ListViewItem>)onSubmit).Invoke(this);
	}

	public virtual void OnCancel(BaseEventData eventData)
	{
		((UnityEvent<ListViewItem>)onCancel).Invoke(this);
	}

	public virtual void OnSelect(BaseEventData eventData)
	{
		Select();
		((UnityEvent<ListViewItem>)onSelect).Invoke(this);
	}

	public virtual void OnDeselect(BaseEventData eventData)
	{
		((UnityEvent<ListViewItem>)onDeselect).Invoke(this);
	}

	public virtual void OnPointerClick(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerClick).Invoke(eventData);
		onClick.Invoke();
		Select();
	}

	public virtual void OnPointerEnter(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerEnter).Invoke(eventData);
	}

	public virtual void OnPointerExit(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)onPointerExit).Invoke(eventData);
	}

	public virtual void Select()
	{
		if (!EventSystem.current.alreadySelecting)
		{
			ListViewItemEventData listViewItemEventData = new ListViewItemEventData(EventSystem.current);
			listViewItemEventData.NewSelectedObject = ((Component)this).gameObject;
			ListViewItemEventData listViewItemEventData2 = listViewItemEventData;
			EventSystem.current.SetSelectedGameObject(listViewItemEventData2.NewSelectedObject, (BaseEventData)(object)listViewItemEventData2);
		}
	}

	public int CompareTo(ListViewItem compareItem)
	{
		return ((Object)(object)compareItem == (Object)null) ? 1 : Index.CompareTo(compareItem.Index);
	}

	public virtual void MovedToCache()
	{
	}
}
