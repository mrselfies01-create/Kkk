using UnityEngine.EventSystems;

namespace UIWidgets;

public class ResizableHeaderDragCell : DragSupport<ResizableHeaderDragCell>
{
	public int Position = -1;

	public ResizableHeader ResizableHeader;

	public override bool CanDrag(PointerEventData eventData)
	{
		return !ResizableHeader.InActiveRegion && ResizableHeader.AllowReorder;
	}

	protected override void InitDrag(PointerEventData eventData)
	{
		ResizableHeader.ProcessCellReorder = true;
		base.Data = this;
	}

	public override void Dropped(bool success)
	{
		ResizableHeader.ProcessCellReorder = false;
		base.Dropped(success);
	}
}
