using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/ComboboxIcons", 230)]
public class ComboboxIcons : ComboboxCustom<ListViewIcons, ListViewIconsItemComponent, ListViewIconsItemDescription>
{
	protected override void SetData(ListViewIconsItemComponent component, ListViewIconsItemDescription item)
	{
		component.SetData(item);
	}
}
