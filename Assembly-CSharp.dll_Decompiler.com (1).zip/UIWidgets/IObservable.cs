namespace UIWidgets;

public interface IObservable
{
	event OnChange OnChange;
}
