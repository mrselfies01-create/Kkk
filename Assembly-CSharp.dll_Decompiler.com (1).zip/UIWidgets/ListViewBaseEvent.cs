using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ListViewBaseEvent : UnityEvent<int, ListViewItem>
{
}
