using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UIWidgets;

public class SlideBlockHandle : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IDragHandler, IEventSystemHandler
{
	public PointerUnityEvent BeginDragEvent = new PointerUnityEvent();

	public PointerUnityEvent EndDragEvent = new PointerUnityEvent();

	public PointerUnityEvent DragEvent = new PointerUnityEvent();

	public void OnBeginDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)BeginDragEvent).Invoke(eventData);
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)EndDragEvent).Invoke(eventData);
	}

	public void OnDrag(PointerEventData eventData)
	{
		((UnityEvent<PointerEventData>)DragEvent).Invoke(eventData);
	}
}
