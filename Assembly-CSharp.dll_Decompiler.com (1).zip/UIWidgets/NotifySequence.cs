namespace UIWidgets;

public enum NotifySequence
{
	None,
	First,
	Last
}
