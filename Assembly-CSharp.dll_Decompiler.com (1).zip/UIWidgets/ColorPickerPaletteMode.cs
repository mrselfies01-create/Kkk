namespace UIWidgets;

public enum ColorPickerPaletteMode
{
	None = -1,
	Red,
	Green,
	Blue,
	Hue,
	Saturation,
	Value
}
