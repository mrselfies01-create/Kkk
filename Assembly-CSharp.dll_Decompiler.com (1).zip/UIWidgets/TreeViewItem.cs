using System;
using System.ComponentModel;
using UnityEngine;

namespace UIWidgets;

[Serializable]
public class TreeViewItem : IObservable, INotifyPropertyChanged
{
	[SerializeField]
	private Sprite icon;

	[SerializeField]
	private string name;

	[NonSerialized]
	private string localizedName;

	[SerializeField]
	private int _value;

	[SerializeField]
	private object tag;

	public Sprite Icon
	{
		get
		{
			return icon;
		}
		set
		{
			icon = value;
			Changed("Icon");
		}
	}

	public string Name
	{
		get
		{
			return name;
		}
		set
		{
			name = value;
			Changed("Name");
		}
	}

	public string LocalizedName
	{
		get
		{
			return localizedName;
		}
		set
		{
			localizedName = value;
			Changed("LocalizedName");
		}
	}

	public int Value
	{
		get
		{
			return _value;
		}
		set
		{
			_value = value;
			Changed("Value");
		}
	}

	public object Tag
	{
		get
		{
			return tag;
		}
		set
		{
			tag = value;
			Changed("Tag");
		}
	}

	public event OnChange OnChange;

	public event PropertyChangedEventHandler PropertyChanged;

	public TreeViewItem(string itemName, Sprite itemIcon = null)
	{
		name = itemName;
		icon = itemIcon;
	}

	private void Changed(string propertyName = "")
	{
		if (this.OnChange != null)
		{
			this.OnChange();
		}
		if (this.PropertyChanged != null)
		{
			this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
