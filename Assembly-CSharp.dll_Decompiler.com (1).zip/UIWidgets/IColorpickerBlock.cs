using UnityEngine;

namespace UIWidgets;

public interface IColorpickerBlock
{
	ColorPickerInputMode InputMode { get; set; }

	ColorPickerPaletteMode PaletteMode { get; set; }

	ColorRGBChangedEvent OnChangeRGB { get; }

	ColorHSVChangedEvent OnChangeHSV { get; }

	ColorAlphaChangedEvent OnChangeAlpha { get; }

	void Start();

	void SetColor(Color32 color);

	void SetColor(ColorHSV color);
}
