using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class ResizableEvent : UnityEvent<Resizable>
{
}
