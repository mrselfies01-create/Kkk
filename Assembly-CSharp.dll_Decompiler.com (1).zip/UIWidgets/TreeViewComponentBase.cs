using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class TreeViewComponentBase<T> : ListViewItem
{
	public Image Icon;

	public Text Text;

	public TreeNodeToggle Toggle;

	public NodeToggleEvent ToggleEvent = new NodeToggleEvent();

	public LayoutElement Filler;

	public bool AnimateArrow;

	public float PaddingPerLevel = 30f;

	public bool SetNativeSize = true;

	protected IEnumerator AnimationCorutine;

	public TreeNode<T> Node { get; protected set; }

	protected override void Start()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		((UIBehaviour)this).Start();
		Toggle.OnClick.AddListener(new UnityAction(ToggleNode));
	}

	protected override void OnDestroy()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		if ((Object)(object)Toggle != (Object)null)
		{
			Toggle.OnClick.RemoveListener(new UnityAction(ToggleNode));
		}
		((UIBehaviour)this).OnDestroy();
	}

	protected virtual void ToggleNode()
	{
		if (AnimationCorutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(AnimationCorutine);
		}
		SetToggleRotation(Node.IsExpanded);
		((UnityEvent<int>)ToggleEvent).Invoke(Index);
		if (AnimateArrow)
		{
			AnimationCorutine = ((!Node.IsExpanded) ? OpenCorutine() : CloseCorutine());
			((MonoBehaviour)this).StartCoroutine(AnimationCorutine);
		}
	}

	protected virtual IEnumerator OpenCorutine()
	{
		Transform transform = ((Component)Toggle).transform;
		RectTransform rect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		yield return ((MonoBehaviour)this).StartCoroutine(Animations.RotateZ(rect, 0.2f, -90f, 0f));
	}

	protected virtual IEnumerator CloseCorutine()
	{
		Transform transform = ((Component)Toggle).transform;
		RectTransform rect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		yield return ((MonoBehaviour)this).StartCoroutine(Animations.RotateZ(rect, 0.2f, 0f, -90f));
	}

	protected virtual void SetToggleRotation(bool isExpanded)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)Toggle == (Object)null))
		{
			Transform transform = ((Component)Toggle).transform;
			RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			((Transform)val).rotation = Quaternion.Euler(0f, 0f, (float)(isExpanded ? (-90) : 0));
		}
	}

	public virtual void SetData(TreeNode<T> node, int depth)
	{
		if (node != null)
		{
			Node = node;
			SetToggleRotation(Node.IsExpanded);
		}
		if ((Object)(object)Filler != (Object)null)
		{
			Filler.preferredWidth = (float)depth * PaddingPerLevel;
		}
		if ((Object)(object)Toggle != (Object)null && (Object)(object)((Component)Toggle).gameObject != (Object)null)
		{
			bool flag = node.Nodes != null && node.Nodes.Count > 0;
			if (((Component)Toggle).gameObject.activeSelf != flag)
			{
				((Component)Toggle).gameObject.SetActive(flag);
			}
		}
	}
}
