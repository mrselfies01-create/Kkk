namespace UIWidgets;

public enum ListViewDirection
{
	Horizontal,
	Vertical
}
