using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class ComboboxCustom<TListViewCustom, TComponent, TItem> : MonoBehaviour, ISubmitHandler, IEventSystemHandler where TListViewCustom : ListViewCustom<TComponent, TItem> where TComponent : ListViewItem
{
	[Serializable]
	public class ComboboxCustomEvent : UnityEvent<int, TItem>
	{
		public ComboboxCustomEvent()
		{
			((UnityEvent<int, _003F>)(object)this)._002Ector();
		}
	}

	[SerializeField]
	private TListViewCustom listView;

	[SerializeField]
	private Button toggleButton;

	[SerializeField]
	private TComponent current;

	public ComboboxCustomEvent OnSelect = new ComboboxCustomEvent();

	private UnityAction<int> onSelectCallback;

	private Transform listCanvas;

	private Transform listParent;

	protected List<TComponent> components = new List<TComponent>();

	protected List<TComponent> componentsCache = new List<TComponent>();

	[NonSerialized]
	private bool isStartedComboboxCustom;

	protected int? ModalKey;

	protected List<SelectListener> childrenDeselect = new List<SelectListener>();

	protected List<int> currentIndicies;

	public TListViewCustom ListView
	{
		get
		{
			return listView;
		}
		set
		{
			SetListView(value);
		}
	}

	public Button ToggleButton
	{
		get
		{
			return toggleButton;
		}
		set
		{
			SetToggleButton(value);
		}
	}

	public TComponent Current
	{
		get
		{
			return current;
		}
		set
		{
			current = value;
		}
	}

	private void Awake()
	{
		Start();
	}

	public virtual void Start()
	{
		if (isStartedComboboxCustom)
		{
			return;
		}
		isStartedComboboxCustom = true;
		onSelectCallback = delegate(int index)
		{
			((UnityEvent<int, _003F>)(object)OnSelect).Invoke(index, listView.DataSource[index]);
		};
		SetToggleButton(toggleButton);
		SetListView(listView);
		if ((Object)(object)listView != (Object)null)
		{
			((Component)current).gameObject.SetActive(false);
			((UnityEvent<int>)listView.OnSelectObject).RemoveListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnDeselectObject).RemoveListener((UnityAction<int>)UpdateView);
			listCanvas = Utilites.FindCanvas(listParent);
			((Component)listView).gameObject.SetActive(true);
			listView.Start();
			if (listView.SelectedIndex == -1 && listView.DataSource.Count > 0 && !listView.Multiple)
			{
				listView.SelectedIndex = 0;
			}
			if (listView.SelectedIndex != -1)
			{
				UpdateView();
			}
			((Component)listView).gameObject.SetActive(false);
			((UnityEvent<int>)listView.OnSelectObject).AddListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnDeselectObject).AddListener((UnityAction<int>)UpdateView);
		}
	}

	protected virtual void SetToggleButton(Button value)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Expected O, but got Unknown
		if ((Object)(object)toggleButton != (Object)null)
		{
			((UnityEvent)toggleButton.onClick).RemoveListener(new UnityAction(ToggleList));
		}
		toggleButton = value;
		if ((Object)(object)toggleButton != (Object)null)
		{
			((UnityEvent)toggleButton.onClick).AddListener(new UnityAction(ToggleList));
		}
	}

	protected virtual void SetListView(TListViewCustom value)
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Expected O, but got Unknown
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Expected O, but got Unknown
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Expected O, but got Unknown
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Expected O, but got Unknown
		if ((Object)(object)listView != (Object)null)
		{
			listParent = null;
			((UnityEvent<int>)listView.OnSelectObject).RemoveListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnDeselectObject).RemoveListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnSelectObject).RemoveListener(onSelectCallback);
			((UnityEvent<BaseEventData>)listView.OnFocusOut).RemoveListener((UnityAction<BaseEventData>)onFocusHideList);
			listView.onCancel.RemoveListener(new UnityAction(OnListViewCancel));
			listView.onItemCancel.RemoveListener(new UnityAction(OnListViewCancel));
			RemoveDeselectCallbacks();
		}
		listView = value;
		if ((Object)(object)listView != (Object)null)
		{
			listParent = ((Component)listView).transform.parent;
			((UnityEvent<int>)listView.OnSelectObject).AddListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnDeselectObject).AddListener((UnityAction<int>)UpdateView);
			((UnityEvent<int>)listView.OnSelectObject).AddListener(onSelectCallback);
			((UnityEvent<BaseEventData>)listView.OnFocusOut).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			listView.onCancel.AddListener(new UnityAction(OnListViewCancel));
			listView.onItemCancel.AddListener(new UnityAction(OnListViewCancel));
			AddDeselectCallbacks();
		}
	}

	public virtual int Set(TItem item, bool allowDuplicate = true)
	{
		return listView.Set(item, allowDuplicate);
	}

	public virtual void Clear()
	{
		listView.Clear();
		UpdateView();
	}

	public virtual void ToggleList()
	{
		if (!((Object)(object)listView == (Object)null))
		{
			if (((Component)listView).gameObject.activeSelf)
			{
				HideList();
			}
			else
			{
				ShowList();
			}
		}
	}

	public virtual void ShowList()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected O, but got Unknown
		if (!((Object)(object)listView == (Object)null))
		{
			ModalKey = ModalHelper.Open((MonoBehaviour)(object)this, (Sprite)null, (Color?)new Color(0f, 0f, 0f, 0f), new UnityAction(HideList));
			if ((Object)(object)listCanvas != (Object)null)
			{
				listParent = ((Component)listView).transform.parent;
				((Component)listView).transform.SetParent(listCanvas);
			}
			((Component)listView).gameObject.SetActive(true);
			if ((Object)(object)listView.Layout != (Object)null)
			{
				listView.Layout.UpdateLayout();
			}
			if (listView.SelectComponent())
			{
				SetChildDeselectListener(EventSystem.current.currentSelectedGameObject);
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(((Component)listView).gameObject);
			}
		}
	}

	public virtual void HideList()
	{
		int? modalKey = ModalKey;
		if (modalKey.HasValue)
		{
			int? modalKey2 = ModalKey;
			ModalHelper.Close(modalKey2.Value);
			ModalKey = null;
		}
		if (!((Object)(object)listView == (Object)null))
		{
			((Component)listView).gameObject.SetActive(false);
			if ((Object)(object)listCanvas != (Object)null)
			{
				((Component)listView).transform.SetParent(listParent);
			}
		}
	}

	protected void onFocusHideList(BaseEventData eventData)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)eventData.selectedObject == (Object)(object)((Component)this).gameObject)
		{
			return;
		}
		if (eventData is ListViewItemEventData listViewItemEventData)
		{
			if ((Object)(object)listViewItemEventData.NewSelectedObject != (Object)null)
			{
				SetChildDeselectListener(listViewItemEventData.NewSelectedObject);
			}
			return;
		}
		PointerEventData val = (PointerEventData)(object)((eventData is PointerEventData) ? eventData : null);
		if (val == null)
		{
			HideList();
			return;
		}
		RaycastResult pointerPressRaycast = val.pointerPressRaycast;
		GameObject gameObject = ((RaycastResult)(ref pointerPressRaycast)).gameObject;
		if ((Object)(object)gameObject == (Object)null)
		{
			HideList();
		}
		else if (!((object)gameObject).Equals((object?)((Component)toggleButton).gameObject))
		{
			if (gameObject.transform.IsChildOf(((Component)listView).transform))
			{
				SetChildDeselectListener(gameObject);
			}
			else
			{
				HideList();
			}
		}
	}

	protected void SetChildDeselectListener(GameObject child)
	{
		SelectListener deselectListener = GetDeselectListener(child);
		if (!childrenDeselect.Contains(deselectListener))
		{
			((UnityEvent<BaseEventData>)deselectListener.onDeselect).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			childrenDeselect.Add(deselectListener);
		}
	}

	protected SelectListener GetDeselectListener(GameObject go)
	{
		return go.GetComponent<SelectListener>() ?? go.AddComponent<SelectListener>();
	}

	protected void AddDeselectCallbacks()
	{
		if (!((Object)(object)listView.ScrollRect == (Object)null) && !((Object)(object)listView.ScrollRect.verticalScrollbar == (Object)null))
		{
			GameObject gameObject = ((Component)listView.ScrollRect.verticalScrollbar).gameObject;
			SelectListener deselectListener = GetDeselectListener(gameObject);
			((UnityEvent<BaseEventData>)deselectListener.onDeselect).AddListener((UnityAction<BaseEventData>)onFocusHideList);
			childrenDeselect.Add(deselectListener);
		}
	}

	protected void RemoveDeselectCallbacks()
	{
		childrenDeselect.ForEach(RemoveDeselectCallback);
		childrenDeselect.Clear();
	}

	protected void RemoveDeselectCallback(SelectListener listener)
	{
		if ((Object)(object)listener != (Object)null)
		{
			((UnityEvent<BaseEventData>)listener.onDeselect).RemoveListener((UnityAction<BaseEventData>)onFocusHideList);
		}
	}

	private void UpdateView(int index)
	{
		UpdateView();
	}

	protected virtual void UpdateView()
	{
		TListViewCustom val = ListView;
		currentIndicies = val.SelectedIndicies;
		UpdateComponentsCount();
		components.ForEach(SetData);
		HideList();
		if ((Object)(object)EventSystem.current != (Object)null && !EventSystem.current.alreadySelecting)
		{
			EventSystem.current.SetSelectedGameObject(((Component)this).gameObject);
		}
	}

	protected virtual void SetData(TComponent component, int i)
	{
		component.Index = currentIndicies[i];
		TListViewCustom val = ListView;
		SetData(component, val.DataSource[currentIndicies[i]]);
	}

	protected virtual void SetData(TComponent component, TItem item)
	{
	}

	private void OnListViewCancel()
	{
		HideList();
	}

	protected virtual void AddComponent(int index)
	{
		TComponent val;
		if (componentsCache.Count > 0)
		{
			val = componentsCache[componentsCache.Count - 1];
			componentsCache.RemoveAt(componentsCache.Count - 1);
		}
		else
		{
			val = Object.Instantiate<TComponent>(current);
			((Component)val).transform.SetParent(((Component)current).transform.parent);
			Utilites.FixInstantiated((Component)(object)current, (Component)(object)val);
		}
		val.Index = -1;
		((Component)val).transform.SetAsLastSibling();
		((Component)val).gameObject.SetActive(true);
		components.Add(val);
	}

	protected virtual void DeactivateComponent(TComponent component)
	{
		if ((Object)(object)component != (Object)null)
		{
			component.MovedToCache();
			component.Index = -1;
			((Component)component).gameObject.SetActive(false);
		}
	}

	protected void UpdateComponentsCount()
	{
		components.RemoveAll(IsNullComponent);
		if (components.Count != currentIndicies.Count)
		{
			if (components.Count < currentIndicies.Count)
			{
				componentsCache.RemoveAll(IsNullComponent);
				Enumerable.Range(0, currentIndicies.Count - components.Count).ForEach(AddComponent);
				return;
			}
			IOrderedEnumerable<TComponent> orderedEnumerable = components.GetRange(currentIndicies.Count, components.Count - currentIndicies.Count).OrderByDescending(GetComponentIndex);
			orderedEnumerable.ForEach(DeactivateComponent);
			componentsCache.AddRange(orderedEnumerable);
			components.RemoveRange(currentIndicies.Count, components.Count - currentIndicies.Count);
		}
	}

	protected bool IsNullComponent(TComponent component)
	{
		return (Object)(object)component == (Object)null;
	}

	protected int GetComponentIndex(TComponent item)
	{
		return item.Index;
	}

	public virtual void OnSubmit(BaseEventData eventData)
	{
		ShowList();
	}

	[Obsolete("Use SetData() instead.")]
	protected virtual void UpdateCurrent()
	{
		HideList();
	}

	protected virtual void OnDestroy()
	{
		ListView = (TListViewCustom)null;
		ToggleButton = null;
	}
}
