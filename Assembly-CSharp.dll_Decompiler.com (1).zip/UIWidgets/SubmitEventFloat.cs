using System;
using UnityEngine.Events;

namespace UIWidgets;

[Serializable]
public class SubmitEventFloat : UnityEvent<float>
{
}
