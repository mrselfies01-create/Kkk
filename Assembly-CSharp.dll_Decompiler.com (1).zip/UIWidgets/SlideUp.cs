using System.Collections;
using UnityEngine;

namespace UIWidgets;

[RequireComponent(typeof(RectTransform))]
public class SlideUp : MonoBehaviour
{
	private RectTransform rect;

	private void Awake()
	{
		ref RectTransform reference = ref rect;
		Transform transform = ((Component)this).transform;
		reference = (RectTransform)(object)((transform is RectTransform) ? transform : null);
	}

	public void Run()
	{
		((MonoBehaviour)this).StartCoroutine(StartAnimation());
	}

	private IEnumerator StartAnimation()
	{
		yield return ((MonoBehaviour)this).StartCoroutine(AnimationCollapse());
		((Component)this).gameObject.SetActive(false);
	}

	private void OnDisable()
	{
		Notify.FreeSlide(rect);
	}

	private IEnumerator AnimationCollapse()
	{
		Rect val = rect.rect;
		float max_height = ((Rect)(ref val)).height;
		float speed = 200f;
		float time = max_height / speed;
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			float height = Mathf.Lerp(max_height, 0f, 1f - (end_time - Time.time) / time);
			rect.SetSizeWithCurrentAnchors((Axis)1, height);
			yield return null;
		}
		rect.SetSizeWithCurrentAnchors((Axis)1, max_height);
	}
}
