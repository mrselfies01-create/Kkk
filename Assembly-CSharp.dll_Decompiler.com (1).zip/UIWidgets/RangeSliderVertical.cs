using UnityEngine;

namespace UIWidgets;

[AddComponentMenu("UI/RangeSliderVertical", 300)]
public class RangeSliderVertical : RangeSlider
{
	protected override bool IsHorizontal()
	{
		return false;
	}
}
