namespace UIWidgets;

public interface ICollectionItemChanged
{
	event OnChange OnCollectionItemChange;
}
