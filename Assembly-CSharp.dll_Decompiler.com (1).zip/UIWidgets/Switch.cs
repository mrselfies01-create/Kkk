using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UIWidgets;

public class Switch : Selectable, ISubmitHandler, IPointerClickHandler, IEventSystemHandler
{
	[SerializeField]
	protected bool isOn;

	[SerializeField]
	protected SwitchDirection direction;

	[SerializeField]
	public RectTransform Mark;

	[SerializeField]
	public Image Background;

	[SerializeField]
	private Color backgroundOnColor = new Color(1f, 1f, 1f, 1f);

	[SerializeField]
	private Color backgroundOffColor = new Color(1f, 43f / 51f, 23f / 51f, 1f);

	[SerializeField]
	public float AnimationDuration = 0.3f;

	[SerializeField]
	public SwitchEvent OnValueChanged = new SwitchEvent();

	protected Coroutine CurrentCorutine;

	public bool IsOn
	{
		get
		{
			return isOn;
		}
		set
		{
			if (isOn != value)
			{
				isOn = value;
				Changed();
			}
		}
	}

	public SwitchDirection Direction
	{
		get
		{
			return direction;
		}
		set
		{
			direction = value;
			SetMarkPosition(animate: false);
		}
	}

	public Color BackgroundOnColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return backgroundOnColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			backgroundOnColor = value;
			SetBackgroundColor();
		}
	}

	public Color BackgroundOffColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return backgroundOffColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			backgroundOffColor = value;
			SetBackgroundColor();
		}
	}

	protected virtual void Changed()
	{
		SetMarkPosition();
		SetBackgroundColor();
		((UnityEvent<bool>)OnValueChanged).Invoke(IsOn);
	}

	protected virtual void SetMarkPosition(bool animate = true)
	{
		if (CurrentCorutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(CurrentCorutine);
		}
		if (animate)
		{
			((MonoBehaviour)this).StartCoroutine(AnimateSwitch(IsOn, AnimationDuration));
		}
		else
		{
			SetMarkPosition(GetPosition(IsOn));
		}
	}

	protected virtual IEnumerator AnimateSwitch(bool state, float time)
	{
		SetMarkPosition(GetPosition(!IsOn));
		float prev_position = GetPosition(!IsOn);
		float next_position = GetPosition(IsOn);
		float end_time = Time.time + time;
		while (Time.time <= end_time)
		{
			float distance = 1f - (end_time - Time.time) / time;
			float pos = Mathf.Lerp(prev_position, next_position, distance);
			SetMarkPosition(pos);
			yield return null;
		}
		SetMarkPosition(GetPosition(IsOn));
	}

	protected virtual void SetMarkPosition(float position)
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)Mark == (Object)null))
		{
			if (IsHorizontal())
			{
				Mark.anchorMin = new Vector2(position, Mark.anchorMin.y);
				Mark.anchorMax = new Vector2(position, Mark.anchorMax.y);
				Mark.pivot = new Vector2(position, Mark.pivot.y);
			}
			else
			{
				Mark.anchorMin = new Vector2(Mark.anchorMin.x, position);
				Mark.anchorMax = new Vector2(Mark.anchorMax.x, position);
				Mark.pivot = new Vector2(Mark.pivot.x, position);
			}
		}
	}

	protected bool IsHorizontal()
	{
		return Direction == SwitchDirection.LeftToRight || Direction == SwitchDirection.RightToLeft;
	}

	protected float GetPosition(bool state)
	{
		switch (Direction)
		{
		case SwitchDirection.LeftToRight:
		case SwitchDirection.BottomToTop:
			return (!state) ? 0f : 1f;
		case SwitchDirection.RightToLeft:
		case SwitchDirection.TopToBottom:
			return (!state) ? 1f : 0f;
		default:
			return 0f;
		}
	}

	protected virtual void SetBackgroundColor()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)Background == (Object)null))
		{
			((Graphic)Background).color = ((!IsOn) ? BackgroundOffColor : BackgroundOnColor);
		}
	}

	protected virtual void CallChanged()
	{
		if (((UIBehaviour)this).IsActive() && ((Selectable)this).IsInteractable())
		{
			IsOn = !IsOn;
		}
	}

	public virtual void OnSubmit(BaseEventData eventData)
	{
		CallChanged();
	}

	public virtual void OnPointerClick(PointerEventData eventData)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		if ((int)eventData.button == 0)
		{
			CallChanged();
		}
	}
}
