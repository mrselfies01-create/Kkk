using UnityEngine;
using UnityEngine.EventSystems;

namespace UIWidgets;

[RequireComponent(typeof(TreeViewComponent))]
public class TreeViewNodeDragSupport : DragSupport<TreeNode<TreeViewItem>>
{
	[SerializeField]
	public ListViewIconsItemComponent DragInfo;

	protected virtual void Start()
	{
		if ((Object)(object)DragInfo != (Object)null)
		{
			((Component)DragInfo).gameObject.SetActive(false);
		}
	}

	protected override void InitDrag(PointerEventData eventData)
	{
		base.Data = ((Component)this).GetComponent<TreeViewComponent>().Node;
		ShowDragInfo();
	}

	protected virtual void ShowDragInfo()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)DragInfo == (Object)null))
		{
			((Component)DragInfo).transform.SetParent((Transform)(object)base.DragPoint, false);
			((Component)DragInfo).transform.localPosition = new Vector3(-5f, 5f, 0f);
			DragInfo.SetData(new ListViewIconsItemDescription
			{
				Name = base.Data.Item.Name,
				LocalizedName = base.Data.Item.LocalizedName,
				Icon = base.Data.Item.Icon,
				Value = base.Data.Item.Value
			});
			((Component)DragInfo).gameObject.SetActive(true);
		}
	}

	protected virtual void HideDragInfo()
	{
		if (!((Object)(object)DragInfo == (Object)null))
		{
			((Component)DragInfo).gameObject.SetActive(false);
		}
	}

	public override void Dropped(bool success)
	{
		HideDragInfo();
		base.Dropped(success);
	}
}
