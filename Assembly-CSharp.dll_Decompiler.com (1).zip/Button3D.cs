using UnityEngine;
using UnityEngine.Events;

public class Button3D : MonoBehaviour
{
	public CameraMovement cameraController;

	private Camera cam;

	private MeshRenderer mr;

	public bool ToggleBehavior = true;

	public UnityEvent buttonPressed = new UnityEvent();

	private bool UITestPending;

	private Ray r;

	public bool pressed
	{
		get
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			if (((Renderer)mr).material.color == Color.black)
			{
				return false;
			}
			return true;
		}
		set
		{
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			if (value)
			{
				((Renderer)mr).material.color = new Color(0.3f, 0.3f, 0.3f);
			}
			else
			{
				((Renderer)mr).material.color = Color.black;
			}
		}
	}

	private void Start()
	{
		cam = ((Component)cameraController).GetComponentInChildren<Camera>();
		mr = ((Component)this).gameObject.GetComponent<MeshRenderer>();
		pressed = false;
	}

	private void Update()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		if (Input.GetMouseButtonDown(0))
		{
			val = Input.mousePosition;
			UITestPending = true;
		}
		else if (Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			if ((int)((Touch)(ref touch)).phase == 0)
			{
				Touch touch2 = Input.GetTouch(0);
				val = Vector2.op_Implicit(((Touch)(ref touch2)).position);
				UITestPending = true;
			}
		}
		r = cam.ScreenPointToRay(val);
	}

	private void FixedUpdate()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		if (!UITestPending)
		{
			return;
		}
		UITestPending = false;
		RaycastHit val = default(RaycastHit);
		Physics.Raycast(r, ref val);
		if (!Object.op_Implicit((Object)(object)((RaycastHit)(ref val)).collider) || !((Object)(object)((Component)((RaycastHit)(ref val)).collider).gameObject == (Object)(object)((Component)this).gameObject))
		{
			return;
		}
		buttonPressed.Invoke();
		if (ToggleBehavior)
		{
			if (((Renderer)mr).material.color == Color.black)
			{
				((Renderer)mr).material.color = new Color(0.3f, 0.3f, 0.3f);
			}
			else
			{
				((Renderer)mr).material.color = Color.black;
			}
		}
	}
}
