using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000101")]
public class CameraFilterPack_TV_80 : MonoBehaviour
{
	[Token(Token = "0x4000769")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400076A")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400076B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400076C")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x17000102")]
	private Material material
	{
		[Token(Token = "0x600065D")]
		[Address(RVA = "0x633DC8", Offset = "0x633DC8", VA = "0x633DC8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600065E")]
	[Address(RVA = "0x633E8C", Offset = "0x633E8C", VA = "0x633E8C")]
	private void Start()
	{
	}

	[Token(Token = "0x600065F")]
	[Address(RVA = "0x633F08", Offset = "0x633F08", VA = "0x633F08")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000660")]
	[Address(RVA = "0x634120", Offset = "0x634120", VA = "0x634120")]
	private void Update()
	{
	}

	[Token(Token = "0x6000661")]
	[Address(RVA = "0x634124", Offset = "0x634124", VA = "0x634124")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000662")]
	[Address(RVA = "0x6341D4", Offset = "0x6341D4", VA = "0x6341D4")]
	public CameraFilterPack_TV_80()
	{
	}
}
