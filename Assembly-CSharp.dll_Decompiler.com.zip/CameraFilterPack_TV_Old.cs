using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000110")]
public class CameraFilterPack_TV_Old : MonoBehaviour
{
	[Token(Token = "0x40007CA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007CB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007CC")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40007CD")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000111")]
	private Material material
	{
		[Token(Token = "0x60006B7")]
		[Address(RVA = "0x6381FC", Offset = "0x6381FC", VA = "0x6381FC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006B8")]
	[Address(RVA = "0x6382C0", Offset = "0x6382C0", VA = "0x6382C0")]
	private void Start()
	{
	}

	[Token(Token = "0x60006B9")]
	[Address(RVA = "0x63833C", Offset = "0x63833C", VA = "0x63833C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006BA")]
	[Address(RVA = "0x6384C0", Offset = "0x6384C0", VA = "0x6384C0")]
	private void Update()
	{
	}

	[Token(Token = "0x60006BB")]
	[Address(RVA = "0x6384C4", Offset = "0x6384C4", VA = "0x6384C4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006BC")]
	[Address(RVA = "0x638574", Offset = "0x638574", VA = "0x638574")]
	public CameraFilterPack_TV_Old()
	{
	}
}
