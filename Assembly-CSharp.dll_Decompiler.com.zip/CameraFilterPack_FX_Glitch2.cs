using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B2")]
public class CameraFilterPack_FX_Glitch2 : MonoBehaviour
{
	[Token(Token = "0x4000531")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000532")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000533")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000534")]
	[FieldOffset(Offset = "0x30")]
	public float Glitch;

	[Token(Token = "0x170000B3")]
	private Material material
	{
		[Token(Token = "0x6000460")]
		[Address(RVA = "0x699E98", Offset = "0x699E98", VA = "0x699E98")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000461")]
	[Address(RVA = "0x699F5C", Offset = "0x699F5C", VA = "0x699F5C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000462")]
	[Address(RVA = "0x699FD8", Offset = "0x699FD8", VA = "0x699FD8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000463")]
	[Address(RVA = "0x69A1F0", Offset = "0x69A1F0", VA = "0x69A1F0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000464")]
	[Address(RVA = "0x69A1F4", Offset = "0x69A1F4", VA = "0x69A1F4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000465")]
	[Address(RVA = "0x69A2A4", Offset = "0x69A2A4", VA = "0x69A2A4")]
	public CameraFilterPack_FX_Glitch2()
	{
	}
}
