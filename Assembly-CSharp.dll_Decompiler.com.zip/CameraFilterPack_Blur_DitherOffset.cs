using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000048")]
public class CameraFilterPack_Blur_DitherOffset : MonoBehaviour
{
	[Token(Token = "0x40002A9")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002AA")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002AB")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002AC")]
	[FieldOffset(Offset = "0x30")]
	public int Level;

	[Token(Token = "0x40002AD")]
	[FieldOffset(Offset = "0x34")]
	public Vector2 Distance;

	[Token(Token = "0x17000049")]
	private Material material
	{
		[Token(Token = "0x60001E1")]
		[Address(RVA = "0x665C58", Offset = "0x665C58", VA = "0x665C58")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001E2")]
	[Address(RVA = "0x665D1C", Offset = "0x665D1C", VA = "0x665D1C")]
	private void Start()
	{
	}

	[Token(Token = "0x60001E3")]
	[Address(RVA = "0x665D98", Offset = "0x665D98", VA = "0x665D98")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001E4")]
	[Address(RVA = "0x666014", Offset = "0x666014", VA = "0x666014")]
	private void Update()
	{
	}

	[Token(Token = "0x60001E5")]
	[Address(RVA = "0x666018", Offset = "0x666018", VA = "0x666018")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001E6")]
	[Address(RVA = "0x6660C8", Offset = "0x6660C8", VA = "0x6660C8")]
	public CameraFilterPack_Blur_DitherOffset()
	{
	}
}
