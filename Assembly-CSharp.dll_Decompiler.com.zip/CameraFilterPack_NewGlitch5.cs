using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E6")]
public class CameraFilterPack_NewGlitch5 : MonoBehaviour
{
	[Token(Token = "0x40006A2")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006A3")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006A4")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006A5")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x40006A6")]
	[FieldOffset(Offset = "0x34")]
	public float _Fade;

	[Token(Token = "0x40006A7")]
	[FieldOffset(Offset = "0x38")]
	public float _Parasite;

	[Token(Token = "0x40006A8")]
	[FieldOffset(Offset = "0x3C")]
	public float _ZoomX;

	[Token(Token = "0x40006A9")]
	[FieldOffset(Offset = "0x40")]
	public float _ZoomY;

	[Token(Token = "0x40006AA")]
	[FieldOffset(Offset = "0x44")]
	public float _PosX;

	[Token(Token = "0x40006AB")]
	[FieldOffset(Offset = "0x48")]
	public float _PosY;

	[Token(Token = "0x170000E7")]
	private Material material
	{
		[Token(Token = "0x60005B4")]
		[Address(RVA = "0x62B120", Offset = "0x62B120", VA = "0x62B120")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005B5")]
	[Address(RVA = "0x62B1E4", Offset = "0x62B1E4", VA = "0x62B1E4")]
	private void Start()
	{
	}

	[Token(Token = "0x60005B6")]
	[Address(RVA = "0x62B260", Offset = "0x62B260", VA = "0x62B260")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005B7")]
	[Address(RVA = "0x62B550", Offset = "0x62B550", VA = "0x62B550")]
	private void Update()
	{
	}

	[Token(Token = "0x60005B8")]
	[Address(RVA = "0x62B554", Offset = "0x62B554", VA = "0x62B554")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005B9")]
	[Address(RVA = "0x62B604", Offset = "0x62B604", VA = "0x62B604")]
	public CameraFilterPack_NewGlitch5()
	{
	}
}
