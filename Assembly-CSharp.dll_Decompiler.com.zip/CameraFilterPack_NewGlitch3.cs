using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E4")]
public class CameraFilterPack_NewGlitch3 : MonoBehaviour
{
	[Token(Token = "0x4000698")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000699")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400069A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400069B")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x400069C")]
	[FieldOffset(Offset = "0x34")]
	public float _RedFade;

	[Token(Token = "0x170000E5")]
	private Material material
	{
		[Token(Token = "0x60005A8")]
		[Address(RVA = "0x62A890", Offset = "0x62A890", VA = "0x62A890")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005A9")]
	[Address(RVA = "0x62A954", Offset = "0x62A954", VA = "0x62A954")]
	private void Start()
	{
	}

	[Token(Token = "0x60005AA")]
	[Address(RVA = "0x62A9D0", Offset = "0x62A9D0", VA = "0x62A9D0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005AB")]
	[Address(RVA = "0x62AC0C", Offset = "0x62AC0C", VA = "0x62AC0C")]
	private void Update()
	{
	}

	[Token(Token = "0x60005AC")]
	[Address(RVA = "0x62AC10", Offset = "0x62AC10", VA = "0x62AC10")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005AD")]
	[Address(RVA = "0x62ACC0", Offset = "0x62ACC0", VA = "0x62ACC0")]
	public CameraFilterPack_NewGlitch3()
	{
	}
}
