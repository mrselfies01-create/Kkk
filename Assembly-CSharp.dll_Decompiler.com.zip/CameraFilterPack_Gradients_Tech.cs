using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D5")]
public class CameraFilterPack_Gradients_Tech : MonoBehaviour
{
	[Token(Token = "0x4000625")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000626")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x4000627")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x4000628")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000629")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x400062A")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D6")]
	private Material material
	{
		[Token(Token = "0x6000532")]
		[Address(RVA = "0x6A44C8", Offset = "0x6A44C8", VA = "0x6A44C8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000533")]
	[Address(RVA = "0x6A458C", Offset = "0x6A458C", VA = "0x6A458C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000534")]
	[Address(RVA = "0x6A45DC", Offset = "0x6A45DC", VA = "0x6A45DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000535")]
	[Address(RVA = "0x6A4818", Offset = "0x6A4818", VA = "0x6A4818")]
	private void Update()
	{
	}

	[Token(Token = "0x6000536")]
	[Address(RVA = "0x6A481C", Offset = "0x6A481C", VA = "0x6A481C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000537")]
	[Address(RVA = "0x6A48CC", Offset = "0x6A48CC", VA = "0x6A48CC")]
	public CameraFilterPack_Gradients_Tech()
	{
	}
}
