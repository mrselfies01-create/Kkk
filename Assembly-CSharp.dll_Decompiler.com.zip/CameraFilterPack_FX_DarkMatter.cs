using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A9")]
public class CameraFilterPack_FX_DarkMatter : MonoBehaviour
{
	[Token(Token = "0x40004F3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004F4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004F5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004F6")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x40004F7")]
	[FieldOffset(Offset = "0x34")]
	public float Intensity;

	[Token(Token = "0x40004F8")]
	[FieldOffset(Offset = "0x38")]
	public float PosX;

	[Token(Token = "0x40004F9")]
	[FieldOffset(Offset = "0x3C")]
	public float PosY;

	[Token(Token = "0x40004FA")]
	[FieldOffset(Offset = "0x40")]
	public float Zoom;

	[Token(Token = "0x40004FB")]
	[FieldOffset(Offset = "0x44")]
	public float DarkIntensity;

	[Token(Token = "0x170000AA")]
	private Material material
	{
		[Token(Token = "0x600042A")]
		[Address(RVA = "0x697574", Offset = "0x697574", VA = "0x697574")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600042B")]
	[Address(RVA = "0x697638", Offset = "0x697638", VA = "0x697638")]
	private void Start()
	{
	}

	[Token(Token = "0x600042C")]
	[Address(RVA = "0x6976B4", Offset = "0x6976B4", VA = "0x6976B4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600042D")]
	[Address(RVA = "0x697980", Offset = "0x697980", VA = "0x697980")]
	private void Update()
	{
	}

	[Token(Token = "0x600042E")]
	[Address(RVA = "0x697984", Offset = "0x697984", VA = "0x697984")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600042F")]
	[Address(RVA = "0x697A34", Offset = "0x697A34", VA = "0x697A34")]
	public CameraFilterPack_FX_DarkMatter()
	{
	}
}
