using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003E")]
public class CameraFilterPack_Blend2Camera_Screen : MonoBehaviour
{
	[Token(Token = "0x400024F")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000250")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000251")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000252")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000253")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000254")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000255")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000256")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003F")]
	private Material material
	{
		[Token(Token = "0x6000199")]
		[Address(RVA = "0x661DD8", Offset = "0x661DD8", VA = "0x661DD8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600019A")]
	[Address(RVA = "0x661E9C", Offset = "0x661E9C", VA = "0x661E9C")]
	private void Start()
	{
	}

	[Token(Token = "0x600019B")]
	[Address(RVA = "0x661FB4", Offset = "0x661FB4", VA = "0x661FB4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600019C")]
	[Address(RVA = "0x662244", Offset = "0x662244", VA = "0x662244")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600019D")]
	[Address(RVA = "0x662330", Offset = "0x662330", VA = "0x662330")]
	private void Update()
	{
	}

	[Token(Token = "0x600019E")]
	[Address(RVA = "0x662334", Offset = "0x662334", VA = "0x662334")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600019F")]
	[Address(RVA = "0x662420", Offset = "0x662420", VA = "0x662420")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001A0")]
	[Address(RVA = "0x662518", Offset = "0x662518", VA = "0x662518")]
	public CameraFilterPack_Blend2Camera_Screen()
	{
	}
}
