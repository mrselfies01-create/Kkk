using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000032")]
public class CameraFilterPack_Blend2Camera_Hue : MonoBehaviour
{
	[Token(Token = "0x40001ED")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001EE")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001EF")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001F0")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001F1")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001F2")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001F3")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001F4")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000033")]
	private Material material
	{
		[Token(Token = "0x6000138")]
		[Address(RVA = "0x5C3750", Offset = "0x5C3750", VA = "0x5C3750")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000139")]
	[Address(RVA = "0x5C3814", Offset = "0x5C3814", VA = "0x5C3814")]
	private void Start()
	{
	}

	[Token(Token = "0x600013A")]
	[Address(RVA = "0x5C392C", Offset = "0x5C392C", VA = "0x5C392C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600013B")]
	[Address(RVA = "0x5C3BBC", Offset = "0x5C3BBC", VA = "0x5C3BBC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600013C")]
	[Address(RVA = "0x5C3CA8", Offset = "0x5C3CA8", VA = "0x5C3CA8")]
	private void Update()
	{
	}

	[Token(Token = "0x600013D")]
	[Address(RVA = "0x5C3CAC", Offset = "0x5C3CAC", VA = "0x5C3CAC")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600013E")]
	[Address(RVA = "0x5C3D98", Offset = "0x5C3D98", VA = "0x5C3D98")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600013F")]
	[Address(RVA = "0x5C3E90", Offset = "0x5C3E90", VA = "0x5C3E90")]
	public CameraFilterPack_Blend2Camera_Hue()
	{
	}
}
