using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AC")]
public class CameraFilterPack_FX_Dot_Circle : MonoBehaviour
{
	[Token(Token = "0x400050A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400050B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400050C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400050D")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000AD")]
	private Material material
	{
		[Token(Token = "0x600043C")]
		[Address(RVA = "0x69839C", Offset = "0x69839C", VA = "0x69839C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600043D")]
	[Address(RVA = "0x698460", Offset = "0x698460", VA = "0x698460")]
	private void Start()
	{
	}

	[Token(Token = "0x600043E")]
	[Address(RVA = "0x6984DC", Offset = "0x6984DC", VA = "0x6984DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600043F")]
	[Address(RVA = "0x6986F4", Offset = "0x6986F4", VA = "0x6986F4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000440")]
	[Address(RVA = "0x6986F8", Offset = "0x6986F8", VA = "0x6986F8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000441")]
	[Address(RVA = "0x6987A8", Offset = "0x6987A8", VA = "0x6987A8")]
	public CameraFilterPack_FX_Dot_Circle()
	{
	}
}
