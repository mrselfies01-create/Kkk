using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003B")]
public class CameraFilterPack_Blend2Camera_PhotoshopFilters : MonoBehaviour
{
	[Token(Token = "0x20001F0")]
	public enum filters
	{
		[Token(Token = "0x4000D30")]
		Darken,
		[Token(Token = "0x4000D31")]
		Multiply,
		[Token(Token = "0x4000D32")]
		ColorBurn,
		[Token(Token = "0x4000D33")]
		LinearBurn,
		[Token(Token = "0x4000D34")]
		DarkerColor,
		[Token(Token = "0x4000D35")]
		Lighten,
		[Token(Token = "0x4000D36")]
		Screen,
		[Token(Token = "0x4000D37")]
		ColorDodge,
		[Token(Token = "0x4000D38")]
		LinearDodge,
		[Token(Token = "0x4000D39")]
		LighterColor,
		[Token(Token = "0x4000D3A")]
		Overlay,
		[Token(Token = "0x4000D3B")]
		SoftLight,
		[Token(Token = "0x4000D3C")]
		HardLight,
		[Token(Token = "0x4000D3D")]
		VividLight,
		[Token(Token = "0x4000D3E")]
		LinearLight,
		[Token(Token = "0x4000D3F")]
		PinLight,
		[Token(Token = "0x4000D40")]
		HardMix,
		[Token(Token = "0x4000D41")]
		Difference,
		[Token(Token = "0x4000D42")]
		Exclusion,
		[Token(Token = "0x4000D43")]
		Subtract,
		[Token(Token = "0x4000D44")]
		Divide,
		[Token(Token = "0x4000D45")]
		Hue,
		[Token(Token = "0x4000D46")]
		Saturation,
		[Token(Token = "0x4000D47")]
		Color,
		[Token(Token = "0x4000D48")]
		Luminosity
	}

	[Token(Token = "0x4000235")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000236")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000237")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000238")]
	[FieldOffset(Offset = "0x30")]
	public filters filterchoice;

	[Token(Token = "0x4000239")]
	[FieldOffset(Offset = "0x34")]
	private filters filterchoicememo;

	[Token(Token = "0x400023A")]
	[FieldOffset(Offset = "0x38")]
	private float TimeX;

	[Token(Token = "0x400023B")]
	[FieldOffset(Offset = "0x40")]
	private Material SCMaterial;

	[Token(Token = "0x400023C")]
	[FieldOffset(Offset = "0x48")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400023D")]
	[FieldOffset(Offset = "0x4C")]
	public float BlendFX;

	[Token(Token = "0x400023E")]
	[FieldOffset(Offset = "0x50")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003C")]
	private Material material
	{
		[Token(Token = "0x6000180")]
		[Address(RVA = "0x660498", Offset = "0x660498", VA = "0x660498")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000181")]
	[Address(RVA = "0x66055C", Offset = "0x66055C", VA = "0x66055C")]
	private void ChangeFilters()
	{
	}

	[Token(Token = "0x6000182")]
	[Address(RVA = "0x6606E8", Offset = "0x6606E8", VA = "0x6606E8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000183")]
	[Address(RVA = "0x660810", Offset = "0x660810", VA = "0x660810")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000184")]
	[Address(RVA = "0x660AA0", Offset = "0x660AA0", VA = "0x660AA0")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000185")]
	[Address(RVA = "0x660C38", Offset = "0x660C38", VA = "0x660C38")]
	private void Update()
	{
	}

	[Token(Token = "0x6000186")]
	[Address(RVA = "0x660C3C", Offset = "0x660C3C", VA = "0x660C3C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000187")]
	[Address(RVA = "0x660D28", Offset = "0x660D28", VA = "0x660D28")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000188")]
	[Address(RVA = "0x660E20", Offset = "0x660E20", VA = "0x660E20")]
	public CameraFilterPack_Blend2Camera_PhotoshopFilters()
	{
	}
}
