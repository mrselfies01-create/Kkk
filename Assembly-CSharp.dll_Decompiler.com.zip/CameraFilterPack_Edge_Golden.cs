using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A0")]
public class CameraFilterPack_Edge_Golden : MonoBehaviour
{
	[Token(Token = "0x40004C6")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004C7")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004C8")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000A1")]
	private Material material
	{
		[Token(Token = "0x60003F4")]
		[Address(RVA = "0x695090", Offset = "0x695090", VA = "0x695090")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003F5")]
	[Address(RVA = "0x695154", Offset = "0x695154", VA = "0x695154")]
	private void Start()
	{
	}

	[Token(Token = "0x60003F6")]
	[Address(RVA = "0x6951D0", Offset = "0x6951D0", VA = "0x6951D0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003F7")]
	[Address(RVA = "0x6953B4", Offset = "0x6953B4", VA = "0x6953B4")]
	private void Update()
	{
	}

	[Token(Token = "0x60003F8")]
	[Address(RVA = "0x6953B8", Offset = "0x6953B8", VA = "0x6953B8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003F9")]
	[Address(RVA = "0x695468", Offset = "0x695468", VA = "0x695468")]
	public CameraFilterPack_Edge_Golden()
	{
	}
}
