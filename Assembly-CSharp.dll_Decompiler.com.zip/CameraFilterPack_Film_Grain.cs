using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C2")]
public class CameraFilterPack_Film_Grain : MonoBehaviour
{
	[Token(Token = "0x400057D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400057E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400057F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000580")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000C3")]
	private Material material
	{
		[Token(Token = "0x60004C0")]
		[Address(RVA = "0x69E19C", Offset = "0x69E19C", VA = "0x69E19C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004C1")]
	[Address(RVA = "0x69E260", Offset = "0x69E260", VA = "0x69E260")]
	private void Start()
	{
	}

	[Token(Token = "0x60004C2")]
	[Address(RVA = "0x69E2DC", Offset = "0x69E2DC", VA = "0x69E2DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004C3")]
	[Address(RVA = "0x69E4F4", Offset = "0x69E4F4", VA = "0x69E4F4")]
	private void Update()
	{
	}

	[Token(Token = "0x60004C4")]
	[Address(RVA = "0x69E4F8", Offset = "0x69E4F8", VA = "0x69E4F8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004C5")]
	[Address(RVA = "0x69E5A8", Offset = "0x69E5A8", VA = "0x69E5A8")]
	public CameraFilterPack_Film_Grain()
	{
	}
}
