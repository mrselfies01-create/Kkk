using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000EF")]
public class CameraFilterPack_Oculus_NightVision2 : MonoBehaviour
{
	[Token(Token = "0x40006F1")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40006F2")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40006F3")]
	[FieldOffset(Offset = "0x28")]
	public float FadeFX;

	[Token(Token = "0x40006F4")]
	[FieldOffset(Offset = "0x2C")]
	private float TimeX;

	[Token(Token = "0x40006F5")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40006F6")]
	[FieldOffset(Offset = "0x38")]
	private float[] Matrix9;

	[Token(Token = "0x170000F0")]
	private Material material
	{
		[Token(Token = "0x60005EC")]
		[Address(RVA = "0x62E37C", Offset = "0x62E37C", VA = "0x62E37C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005ED")]
	[Address(RVA = "0x62E440", Offset = "0x62E440", VA = "0x62E440")]
	private void ChangeFilters()
	{
	}

	[Token(Token = "0x60005EE")]
	[Address(RVA = "0x62E4B0", Offset = "0x62E4B0", VA = "0x62E4B0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005EF")]
	[Address(RVA = "0x62E504", Offset = "0x62E504", VA = "0x62E504")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005F0")]
	[Address(RVA = "0x62E9F4", Offset = "0x62E9F4", VA = "0x62E9F4")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60005F1")]
	[Address(RVA = "0x62E9F8", Offset = "0x62E9F8", VA = "0x62E9F8")]
	private void Update()
	{
	}

	[Token(Token = "0x60005F2")]
	[Address(RVA = "0x62E9FC", Offset = "0x62E9FC", VA = "0x62E9FC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005F3")]
	[Address(RVA = "0x62EAAC", Offset = "0x62EAAC", VA = "0x62EAAC")]
	public CameraFilterPack_Oculus_NightVision2()
	{
	}
}
