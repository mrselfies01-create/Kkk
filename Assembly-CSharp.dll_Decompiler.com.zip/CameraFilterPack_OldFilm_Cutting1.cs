using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F3")]
public class CameraFilterPack_OldFilm_Cutting1 : MonoBehaviour
{
	[Token(Token = "0x400070B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400070C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400070D")]
	[FieldOffset(Offset = "0x24")]
	public float Speed;

	[Token(Token = "0x400070E")]
	[FieldOffset(Offset = "0x28")]
	public float Luminosity;

	[Token(Token = "0x400070F")]
	[FieldOffset(Offset = "0x2C")]
	public float Vignette;

	[Token(Token = "0x4000710")]
	[FieldOffset(Offset = "0x30")]
	public float Negative;

	[Token(Token = "0x4000711")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000712")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000F4")]
	private Material material
	{
		[Token(Token = "0x6000608")]
		[Address(RVA = "0x62FBBC", Offset = "0x62FBBC", VA = "0x62FBBC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000609")]
	[Address(RVA = "0x62FC80", Offset = "0x62FC80", VA = "0x62FC80")]
	private void Start()
	{
	}

	[Token(Token = "0x600060A")]
	[Address(RVA = "0x62FD38", Offset = "0x62FD38", VA = "0x62FD38")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600060B")]
	[Address(RVA = "0x62FF54", Offset = "0x62FF54", VA = "0x62FF54")]
	private void Update()
	{
	}

	[Token(Token = "0x600060C")]
	[Address(RVA = "0x62FF58", Offset = "0x62FF58", VA = "0x62FF58")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600060D")]
	[Address(RVA = "0x630008", Offset = "0x630008", VA = "0x630008")]
	public CameraFilterPack_OldFilm_Cutting1()
	{
	}
}
