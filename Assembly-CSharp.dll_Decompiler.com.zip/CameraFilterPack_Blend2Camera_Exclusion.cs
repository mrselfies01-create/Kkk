using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002E")]
public class CameraFilterPack_Blend2Camera_Exclusion : MonoBehaviour
{
	[Token(Token = "0x40001C7")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001C8")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001C9")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001CA")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001CB")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001CC")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001CD")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001CE")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700002F")]
	private Material material
	{
		[Token(Token = "0x6000119")]
		[Address(RVA = "0x5C19D4", Offset = "0x5C19D4", VA = "0x5C19D4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600011A")]
	[Address(RVA = "0x5C1A98", Offset = "0x5C1A98", VA = "0x5C1A98")]
	private void Start()
	{
	}

	[Token(Token = "0x600011B")]
	[Address(RVA = "0x5C1BB0", Offset = "0x5C1BB0", VA = "0x5C1BB0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600011C")]
	[Address(RVA = "0x5C1E40", Offset = "0x5C1E40", VA = "0x5C1E40")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600011D")]
	[Address(RVA = "0x5C1F2C", Offset = "0x5C1F2C", VA = "0x5C1F2C")]
	private void Update()
	{
	}

	[Token(Token = "0x600011E")]
	[Address(RVA = "0x5C1F30", Offset = "0x5C1F30", VA = "0x5C1F30")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600011F")]
	[Address(RVA = "0x5C201C", Offset = "0x5C201C", VA = "0x5C201C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000120")]
	[Address(RVA = "0x5C2114", Offset = "0x5C2114", VA = "0x5C2114")]
	public CameraFilterPack_Blend2Camera_Exclusion()
	{
	}
}
