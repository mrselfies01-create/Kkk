using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C8")]
public class CameraFilterPack_Glasses_On_5 : MonoBehaviour
{
	[Token(Token = "0x40005C1")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005C2")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005C3")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40005C4")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x40005C5")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x40005C6")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x40005C7")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x40005C8")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x40005C9")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x40005CA")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x40005CB")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x40005CC")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x40005CD")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x40005CE")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C9")]
	private Material material
	{
		[Token(Token = "0x60004E4")]
		[Address(RVA = "0x6A031C", Offset = "0x6A031C", VA = "0x6A031C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004E5")]
	[Address(RVA = "0x6A03E0", Offset = "0x6A03E0", VA = "0x6A03E0")]
	private void Start()
	{
	}

	[Token(Token = "0x60004E6")]
	[Address(RVA = "0x6A0498", Offset = "0x6A0498", VA = "0x6A0498")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004E7")]
	[Address(RVA = "0x6A0790", Offset = "0x6A0790", VA = "0x6A0790")]
	private void Update()
	{
	}

	[Token(Token = "0x60004E8")]
	[Address(RVA = "0x6A0794", Offset = "0x6A0794", VA = "0x6A0794")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004E9")]
	[Address(RVA = "0x6A0844", Offset = "0x6A0844", VA = "0x6A0844")]
	public CameraFilterPack_Glasses_On_5()
	{
	}
}
