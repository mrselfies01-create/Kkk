using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000108")]
public class CameraFilterPack_TV_Chromatical : MonoBehaviour
{
	[Token(Token = "0x40007A0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007A1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007A2")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40007A3")]
	[FieldOffset(Offset = "0x28")]
	public float Intensity;

	[Token(Token = "0x40007A4")]
	[FieldOffset(Offset = "0x2C")]
	public float Speed;

	[Token(Token = "0x40007A5")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x17000109")]
	private Material material
	{
		[Token(Token = "0x6000687")]
		[Address(RVA = "0x635FD0", Offset = "0x635FD0", VA = "0x635FD0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000688")]
	[Address(RVA = "0x636094", Offset = "0x636094", VA = "0x636094")]
	private void Start()
	{
	}

	[Token(Token = "0x6000689")]
	[Address(RVA = "0x636110", Offset = "0x636110", VA = "0x636110")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600068A")]
	[Address(RVA = "0x636364", Offset = "0x636364", VA = "0x636364")]
	private void Update()
	{
	}

	[Token(Token = "0x600068B")]
	[Address(RVA = "0x636368", Offset = "0x636368", VA = "0x636368")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600068C")]
	[Address(RVA = "0x636418", Offset = "0x636418", VA = "0x636418")]
	public CameraFilterPack_TV_Chromatical()
	{
	}
}
