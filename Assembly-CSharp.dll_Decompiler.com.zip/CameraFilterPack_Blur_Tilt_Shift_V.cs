using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000054")]
public class CameraFilterPack_Blur_Tilt_Shift_V : MonoBehaviour
{
	[Token(Token = "0x40002F2")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002F3")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002F4")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002F5")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40002F6")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x40002F7")]
	[FieldOffset(Offset = "0x38")]
	public float Smooth;

	[Token(Token = "0x40002F8")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x40002F9")]
	[FieldOffset(Offset = "0x40")]
	public float Position;

	[Token(Token = "0x17000055")]
	private Material material
	{
		[Token(Token = "0x6000229")]
		[Address(RVA = "0x66969C", Offset = "0x66969C", VA = "0x66969C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600022A")]
	[Address(RVA = "0x669760", Offset = "0x669760", VA = "0x669760")]
	private void Start()
	{
	}

	[Token(Token = "0x600022B")]
	[Address(RVA = "0x6697DC", Offset = "0x6697DC", VA = "0x6697DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600022C")]
	[Address(RVA = "0x669B8C", Offset = "0x669B8C", VA = "0x669B8C")]
	private void Update()
	{
	}

	[Token(Token = "0x600022D")]
	[Address(RVA = "0x669B90", Offset = "0x669B90", VA = "0x669B90")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600022E")]
	[Address(RVA = "0x669C40", Offset = "0x669C40", VA = "0x669C40")]
	public CameraFilterPack_Blur_Tilt_Shift_V()
	{
	}
}
