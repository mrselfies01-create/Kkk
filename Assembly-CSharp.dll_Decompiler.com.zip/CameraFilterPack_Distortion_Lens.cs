using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007C")]
public class CameraFilterPack_Distortion_Lens : MonoBehaviour
{
	[Token(Token = "0x40003DB")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003DC")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003DD")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003DE")]
	[FieldOffset(Offset = "0x30")]
	public float CenterX;

	[Token(Token = "0x40003DF")]
	[FieldOffset(Offset = "0x34")]
	public float CenterY;

	[Token(Token = "0x40003E0")]
	[FieldOffset(Offset = "0x38")]
	public float Distortion;

	[Token(Token = "0x1700007D")]
	private Material material
	{
		[Token(Token = "0x600031B")]
		[Address(RVA = "0x674E14", Offset = "0x674E14", VA = "0x674E14")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600031C")]
	[Address(RVA = "0x674ED8", Offset = "0x674ED8", VA = "0x674ED8")]
	private void Start()
	{
	}

	[Token(Token = "0x600031D")]
	[Address(RVA = "0x674F54", Offset = "0x674F54", VA = "0x674F54")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600031E")]
	[Address(RVA = "0x6751A4", Offset = "0x6751A4", VA = "0x6751A4")]
	private void Update()
	{
	}

	[Token(Token = "0x600031F")]
	[Address(RVA = "0x6751A8", Offset = "0x6751A8", VA = "0x6751A8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000320")]
	[Address(RVA = "0x675258", Offset = "0x675258", VA = "0x675258")]
	public CameraFilterPack_Distortion_Lens()
	{
	}
}
