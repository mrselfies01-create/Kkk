using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000090")]
public class CameraFilterPack_Drawing_Manga3 : MonoBehaviour
{
	[Token(Token = "0x4000452")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000453")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000454")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000455")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x17000091")]
	private Material material
	{
		[Token(Token = "0x6000393")]
		[Address(RVA = "0x690834", Offset = "0x690834", VA = "0x690834")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000394")]
	[Address(RVA = "0x6908F8", Offset = "0x6908F8", VA = "0x6908F8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000395")]
	[Address(RVA = "0x690974", Offset = "0x690974", VA = "0x690974")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000396")]
	[Address(RVA = "0x690AF8", Offset = "0x690AF8", VA = "0x690AF8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000397")]
	[Address(RVA = "0x690AFC", Offset = "0x690AFC", VA = "0x690AFC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000398")]
	[Address(RVA = "0x690BAC", Offset = "0x690BAC", VA = "0x690BAC")]
	public CameraFilterPack_Drawing_Manga3()
	{
	}
}
