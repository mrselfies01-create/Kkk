using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C0")]
public class CameraFilterPack_FX_superDot : MonoBehaviour
{
	[Token(Token = "0x4000573")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000574")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000575")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000C1")]
	private Material material
	{
		[Token(Token = "0x60004B4")]
		[Address(RVA = "0x69D910", Offset = "0x69D910", VA = "0x69D910")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004B5")]
	[Address(RVA = "0x69D9D4", Offset = "0x69D9D4", VA = "0x69D9D4")]
	private void Start()
	{
	}

	[Token(Token = "0x60004B6")]
	[Address(RVA = "0x69DA50", Offset = "0x69DA50", VA = "0x69DA50")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004B7")]
	[Address(RVA = "0x69DC44", Offset = "0x69DC44", VA = "0x69DC44")]
	private void Update()
	{
	}

	[Token(Token = "0x60004B8")]
	[Address(RVA = "0x69DC48", Offset = "0x69DC48", VA = "0x69DC48")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004B9")]
	[Address(RVA = "0x69DCF8", Offset = "0x69DCF8", VA = "0x69DCF8")]
	public CameraFilterPack_FX_superDot()
	{
	}
}
