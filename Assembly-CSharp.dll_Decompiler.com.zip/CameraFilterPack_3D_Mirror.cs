using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000010")]
public class CameraFilterPack_3D_Mirror : MonoBehaviour
{
	[Token(Token = "0x4000086")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000087")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x4000088")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000089")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400008A")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x400008B")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x400008C")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x400008D")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x400008E")]
	[FieldOffset(Offset = "0x40")]
	public float Lightning;

	[Token(Token = "0x400008F")]
	[FieldOffset(Offset = "0x44")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x4000090")]
	[FieldOffset(Offset = "0x48")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x4000091")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x17000011")]
	private Material material
	{
		[Token(Token = "0x6000052")]
		[Address(RVA = "0x5B5FC8", Offset = "0x5B5FC8", VA = "0x5B5FC8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000053")]
	[Address(RVA = "0x5B608C", Offset = "0x5B608C", VA = "0x5B608C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000054")]
	[Address(RVA = "0x5B6108", Offset = "0x5B6108", VA = "0x5B6108")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000055")]
	[Address(RVA = "0x5B6498", Offset = "0x5B6498", VA = "0x5B6498")]
	private void Update()
	{
	}

	[Token(Token = "0x6000056")]
	[Address(RVA = "0x5B649C", Offset = "0x5B649C", VA = "0x5B649C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000057")]
	[Address(RVA = "0x5B654C", Offset = "0x5B654C", VA = "0x5B654C")]
	public CameraFilterPack_3D_Mirror()
	{
	}
}
