using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000012")]
public class CameraFilterPack_3D_Scan_Scene : MonoBehaviour
{
	[Token(Token = "0x40000A0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000A1")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x40000A2")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x40000A3")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40000A4")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x40000A5")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x40000A6")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x40000A7")]
	[FieldOffset(Offset = "0x3C")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x40000A8")]
	[FieldOffset(Offset = "0x40")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x40000A9")]
	[FieldOffset(Offset = "0x44")]
	public Color ScanColor;

	[Token(Token = "0x40000AA")]
	[FieldOffset(Offset = "0x54")]
	public float Fade;

	[Token(Token = "0x40000AB")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x40000AC")]
	[FieldOffset(Offset = "0x58")]
	private Texture2D Texture2;

	[Token(Token = "0x17000013")]
	private Material material
	{
		[Token(Token = "0x600005E")]
		[Address(RVA = "0x5B6BD4", Offset = "0x5B6BD4", VA = "0x5B6BD4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600005F")]
	[Address(RVA = "0x5B6C98", Offset = "0x5B6C98", VA = "0x5B6C98")]
	private void Start()
	{
	}

	[Token(Token = "0x6000060")]
	[Address(RVA = "0x5B6D14", Offset = "0x5B6D14", VA = "0x5B6D14")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000061")]
	[Address(RVA = "0x5B70A4", Offset = "0x5B70A4", VA = "0x5B70A4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000062")]
	[Address(RVA = "0x5B70A8", Offset = "0x5B70A8", VA = "0x5B70A8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000063")]
	[Address(RVA = "0x5B7158", Offset = "0x5B7158", VA = "0x5B7158")]
	public CameraFilterPack_3D_Scan_Scene()
	{
	}
}
