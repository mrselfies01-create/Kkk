using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000061")]
public class CameraFilterPack_Color_RGB : MonoBehaviour
{
	[Token(Token = "0x4000340")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000341")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000342")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000343")]
	[FieldOffset(Offset = "0x30")]
	public Color ColorRGB;

	[Token(Token = "0x17000062")]
	private Material material
	{
		[Token(Token = "0x6000277")]
		[Address(RVA = "0x66D0F8", Offset = "0x66D0F8", VA = "0x66D0F8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000278")]
	[Address(RVA = "0x66D1BC", Offset = "0x66D1BC", VA = "0x66D1BC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000279")]
	[Address(RVA = "0x66D238", Offset = "0x66D238", VA = "0x66D238")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600027A")]
	[Address(RVA = "0x66D454", Offset = "0x66D454", VA = "0x66D454")]
	private void Update()
	{
	}

	[Token(Token = "0x600027B")]
	[Address(RVA = "0x66D458", Offset = "0x66D458", VA = "0x66D458")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600027C")]
	[Address(RVA = "0x66D508", Offset = "0x66D508", VA = "0x66D508")]
	public CameraFilterPack_Color_RGB()
	{
	}
}
