using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000055")]
public class CameraFilterPack_Broken_Screen : MonoBehaviour
{
	[Token(Token = "0x40002FA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002FB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002FC")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40002FD")]
	[FieldOffset(Offset = "0x28")]
	public float Shadow;

	[Token(Token = "0x40002FE")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40002FF")]
	[FieldOffset(Offset = "0x38")]
	private Texture2D Texture2;

	[Token(Token = "0x17000056")]
	private Material material
	{
		[Token(Token = "0x600022F")]
		[Address(RVA = "0x669C6C", Offset = "0x669C6C", VA = "0x669C6C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000230")]
	[Address(RVA = "0x669D30", Offset = "0x669D30", VA = "0x669D30")]
	private void Start()
	{
	}

	[Token(Token = "0x6000231")]
	[Address(RVA = "0x669DE8", Offset = "0x669DE8", VA = "0x669DE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000232")]
	[Address(RVA = "0x669FB4", Offset = "0x669FB4", VA = "0x669FB4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000233")]
	[Address(RVA = "0x669FB8", Offset = "0x669FB8", VA = "0x669FB8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000234")]
	[Address(RVA = "0x66A068", Offset = "0x66A068", VA = "0x66A068")]
	public CameraFilterPack_Broken_Screen()
	{
	}
}
