using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000096")]
public class CameraFilterPack_Drawing_Manga_Flash_Color : MonoBehaviour
{
	[Token(Token = "0x4000473")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000474")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000475")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000476")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000477")]
	[FieldOffset(Offset = "0x34")]
	public Color Color;

	[Token(Token = "0x4000478")]
	[FieldOffset(Offset = "0x44")]
	public int Speed;

	[Token(Token = "0x4000479")]
	[FieldOffset(Offset = "0x48")]
	public float PosX;

	[Token(Token = "0x400047A")]
	[FieldOffset(Offset = "0x4C")]
	public float PosY;

	[Token(Token = "0x400047B")]
	[FieldOffset(Offset = "0x50")]
	public float Intensity;

	[Token(Token = "0x17000097")]
	private Material material
	{
		[Token(Token = "0x60003B7")]
		[Address(RVA = "0x692014", Offset = "0x692014", VA = "0x692014")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003B8")]
	[Address(RVA = "0x6920D8", Offset = "0x6920D8", VA = "0x6920D8")]
	private void Start()
	{
	}

	[Token(Token = "0x60003B9")]
	[Address(RVA = "0x692154", Offset = "0x692154", VA = "0x692154")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003BA")]
	[Address(RVA = "0x692428", Offset = "0x692428", VA = "0x692428")]
	private void Update()
	{
	}

	[Token(Token = "0x60003BB")]
	[Address(RVA = "0x69242C", Offset = "0x69242C", VA = "0x69242C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003BC")]
	[Address(RVA = "0x6924DC", Offset = "0x6924DC", VA = "0x6924DC")]
	public CameraFilterPack_Drawing_Manga_Flash_Color()
	{
	}
}
