using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CA")]
public class CameraFilterPack_Glitch_Mozaic : MonoBehaviour
{
	[Token(Token = "0x40005DD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005DE")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005DF")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40005E0")]
	[FieldOffset(Offset = "0x30")]
	public float Intensity;

	[Token(Token = "0x40005E1")]
	[FieldOffset(Offset = "0x34")]
	private float Value2;

	[Token(Token = "0x40005E2")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x40005E3")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x170000CB")]
	private Material material
	{
		[Token(Token = "0x60004F0")]
		[Address(RVA = "0x6A0F6C", Offset = "0x6A0F6C", VA = "0x6A0F6C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004F1")]
	[Address(RVA = "0x6A1030", Offset = "0x6A1030", VA = "0x6A1030")]
	private void Start()
	{
	}

	[Token(Token = "0x60004F2")]
	[Address(RVA = "0x6A10AC", Offset = "0x6A10AC", VA = "0x6A10AC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004F3")]
	[Address(RVA = "0x6A1330", Offset = "0x6A1330", VA = "0x6A1330")]
	private void Update()
	{
	}

	[Token(Token = "0x60004F4")]
	[Address(RVA = "0x6A1334", Offset = "0x6A1334", VA = "0x6A1334")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004F5")]
	[Address(RVA = "0x6A13E4", Offset = "0x6A13E4", VA = "0x6A13E4")]
	public CameraFilterPack_Glitch_Mozaic()
	{
	}
}
