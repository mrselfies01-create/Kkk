using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000050")]
public class CameraFilterPack_Blur_Regular : MonoBehaviour
{
	[Token(Token = "0x40002D7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002D8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002D9")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002DA")]
	[FieldOffset(Offset = "0x30")]
	public int Level;

	[Token(Token = "0x40002DB")]
	[FieldOffset(Offset = "0x34")]
	public Vector2 Distance;

	[Token(Token = "0x17000051")]
	private Material material
	{
		[Token(Token = "0x6000211")]
		[Address(RVA = "0x66818C", Offset = "0x66818C", VA = "0x66818C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000212")]
	[Address(RVA = "0x668250", Offset = "0x668250", VA = "0x668250")]
	private void Start()
	{
	}

	[Token(Token = "0x6000213")]
	[Address(RVA = "0x6682CC", Offset = "0x6682CC", VA = "0x6682CC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000214")]
	[Address(RVA = "0x668548", Offset = "0x668548", VA = "0x668548")]
	private void Update()
	{
	}

	[Token(Token = "0x6000215")]
	[Address(RVA = "0x66854C", Offset = "0x66854C", VA = "0x66854C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000216")]
	[Address(RVA = "0x6685FC", Offset = "0x6685FC", VA = "0x6685FC")]
	public CameraFilterPack_Blur_Regular()
	{
	}
}
