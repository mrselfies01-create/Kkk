using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000093")]
public class CameraFilterPack_Drawing_Manga_Color : MonoBehaviour
{
	[Token(Token = "0x400045E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400045F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000460")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000461")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x4000462")]
	[FieldOffset(Offset = "0x0")]
	public static float ChangeDotSize;

	[Token(Token = "0x17000094")]
	private Material material
	{
		[Token(Token = "0x60003A5")]
		[Address(RVA = "0x6912F0", Offset = "0x6912F0", VA = "0x6912F0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003A6")]
	[Address(RVA = "0x6913B4", Offset = "0x6913B4", VA = "0x6913B4")]
	private void Start()
	{
	}

	[Token(Token = "0x60003A7")]
	[Address(RVA = "0x691430", Offset = "0x691430", VA = "0x691430")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003A8")]
	[Address(RVA = "0x6915B4", Offset = "0x6915B4", VA = "0x6915B4")]
	private void Update()
	{
	}

	[Token(Token = "0x60003A9")]
	[Address(RVA = "0x6915B8", Offset = "0x6915B8", VA = "0x6915B8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003AA")]
	[Address(RVA = "0x691668", Offset = "0x691668", VA = "0x691668")]
	public CameraFilterPack_Drawing_Manga_Color()
	{
	}
}
