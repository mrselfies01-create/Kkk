using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200009B")]
public class CameraFilterPack_Drawing_Toon : MonoBehaviour
{
	[Token(Token = "0x40004A7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004A8")]
	[FieldOffset(Offset = "0x20")]
	private Material SCMaterial;

	[Token(Token = "0x40004A9")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x40004AA")]
	[FieldOffset(Offset = "0x2C")]
	public float Threshold;

	[Token(Token = "0x40004AB")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x1700009C")]
	private Material material
	{
		[Token(Token = "0x60003D5")]
		[Address(RVA = "0x693A7C", Offset = "0x693A7C", VA = "0x693A7C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003D6")]
	[Address(RVA = "0x693B40", Offset = "0x693B40", VA = "0x693B40")]
	private void Start()
	{
	}

	[Token(Token = "0x60003D7")]
	[Address(RVA = "0x693BBC", Offset = "0x693BBC", VA = "0x693BBC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003D8")]
	[Address(RVA = "0x693D64", Offset = "0x693D64", VA = "0x693D64")]
	private void Update()
	{
	}

	[Token(Token = "0x60003D9")]
	[Address(RVA = "0x693D68", Offset = "0x693D68", VA = "0x693D68")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003DA")]
	[Address(RVA = "0x693E18", Offset = "0x693E18", VA = "0x693E18")]
	public CameraFilterPack_Drawing_Toon()
	{
	}
}
