using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010A")]
public class CameraFilterPack_TV_CompressionFX : MonoBehaviour
{
	[Token(Token = "0x40007AD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007AE")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007AF")]
	[FieldOffset(Offset = "0x24")]
	public float Parasite;

	[Token(Token = "0x40007B0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700010B")]
	private Material material
	{
		[Token(Token = "0x6000693")]
		[Address(RVA = "0x6368BC", Offset = "0x6368BC", VA = "0x6368BC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000694")]
	[Address(RVA = "0x636980", Offset = "0x636980", VA = "0x636980")]
	private void Start()
	{
	}

	[Token(Token = "0x6000695")]
	[Address(RVA = "0x6369FC", Offset = "0x6369FC", VA = "0x6369FC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000696")]
	[Address(RVA = "0x636C14", Offset = "0x636C14", VA = "0x636C14")]
	private void Update()
	{
	}

	[Token(Token = "0x6000697")]
	[Address(RVA = "0x636C18", Offset = "0x636C18", VA = "0x636C18")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000698")]
	[Address(RVA = "0x636CC8", Offset = "0x636CC8", VA = "0x636CC8")]
	public CameraFilterPack_TV_CompressionFX()
	{
	}
}
