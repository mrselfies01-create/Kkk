using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004A")]
public class CameraFilterPack_Blur_Focus : MonoBehaviour
{
	[Token(Token = "0x40002B3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002B4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002B5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002B6")]
	[FieldOffset(Offset = "0x30")]
	public float CenterX;

	[Token(Token = "0x40002B7")]
	[FieldOffset(Offset = "0x34")]
	public float CenterY;

	[Token(Token = "0x40002B8")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x40002B9")]
	[FieldOffset(Offset = "0x3C")]
	public float _Eyes;

	[Token(Token = "0x1700004B")]
	private Material material
	{
		[Token(Token = "0x60001ED")]
		[Address(RVA = "0x666580", Offset = "0x666580", VA = "0x666580")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001EE")]
	[Address(RVA = "0x666644", Offset = "0x666644", VA = "0x666644")]
	private void Start()
	{
	}

	[Token(Token = "0x60001EF")]
	[Address(RVA = "0x6666C0", Offset = "0x6666C0", VA = "0x6666C0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001F0")]
	[Address(RVA = "0x6669D8", Offset = "0x6669D8", VA = "0x6669D8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001F1")]
	[Address(RVA = "0x6669DC", Offset = "0x6669DC", VA = "0x6669DC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001F2")]
	[Address(RVA = "0x666A8C", Offset = "0x666A8C", VA = "0x666A8C")]
	public CameraFilterPack_Blur_Focus()
	{
	}
}
