using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000063")]
public class CameraFilterPack_Color_Switching : MonoBehaviour
{
	[Token(Token = "0x4000348")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000349")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400034A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400034B")]
	[FieldOffset(Offset = "0x30")]
	public int Color;

	[Token(Token = "0x17000064")]
	private Material material
	{
		[Token(Token = "0x6000283")]
		[Address(RVA = "0x66D980", Offset = "0x66D980", VA = "0x66D980")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000284")]
	[Address(RVA = "0x66DA44", Offset = "0x66DA44", VA = "0x66DA44")]
	private void Start()
	{
	}

	[Token(Token = "0x6000285")]
	[Address(RVA = "0x66DAC0", Offset = "0x66DAC0", VA = "0x66DAC0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000286")]
	[Address(RVA = "0x66DCDC", Offset = "0x66DCDC", VA = "0x66DCDC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000287")]
	[Address(RVA = "0x66DCE0", Offset = "0x66DCE0", VA = "0x66DCE0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000288")]
	[Address(RVA = "0x66DD90", Offset = "0x66DD90", VA = "0x66DD90")]
	public CameraFilterPack_Color_Switching()
	{
	}
}
