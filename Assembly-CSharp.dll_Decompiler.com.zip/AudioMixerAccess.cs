using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Audio;

[Token(Token = "0x2000005")]
public class AudioMixerAccess : MonoBehaviour
{
	[Token(Token = "0x400000A")]
	[FieldOffset(Offset = "0x18")]
	public AudioMixer mixer;

	[Token(Token = "0x400000B")]
	[FieldOffset(Offset = "0x20")]
	private bool PitchEnabled;

	[Token(Token = "0x400000C")]
	[FieldOffset(Offset = "0x24")]
	private float curPitch;

	[Token(Token = "0x400000D")]
	[FieldOffset(Offset = "0x28")]
	public bool PitchShiftEnabled;

	[Token(Token = "0x17000001")]
	public bool PitchOn
	{
		[Token(Token = "0x600000A")]
		[Address(RVA = "0x5B05AC", Offset = "0x5B05AC", VA = "0x5B05AC")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x600000B")]
		[Address(RVA = "0x5B05B4", Offset = "0x5B05B4", VA = "0x5B05B4")]
		set
		{
		}
	}

	[Token(Token = "0x17000002")]
	public float Pitch
	{
		[Token(Token = "0x600000C")]
		[Address(RVA = "0x5B0640", Offset = "0x5B0640", VA = "0x5B0640")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600000D")]
		[Address(RVA = "0x5B06D4", Offset = "0x5B06D4", VA = "0x5B06D4")]
		set
		{
		}
	}

	[Token(Token = "0x17000003")]
	public float PitchShift
	{
		[Token(Token = "0x600000E")]
		[Address(RVA = "0x5B075C", Offset = "0x5B075C", VA = "0x5B075C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600000F")]
		[Address(RVA = "0x5B07F0", Offset = "0x5B07F0", VA = "0x5B07F0")]
		set
		{
		}
	}

	[Token(Token = "0x17000004")]
	public float EqLow
	{
		[Token(Token = "0x6000010")]
		[Address(RVA = "0x5B0878", Offset = "0x5B0878", VA = "0x5B0878")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000011")]
		[Address(RVA = "0x5B08F8", Offset = "0x5B08F8", VA = "0x5B08F8")]
		set
		{
		}
	}

	[Token(Token = "0x17000005")]
	public float EqMid
	{
		[Token(Token = "0x6000012")]
		[Address(RVA = "0x5B0964", Offset = "0x5B0964", VA = "0x5B0964")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000013")]
		[Address(RVA = "0x5B09E4", Offset = "0x5B09E4", VA = "0x5B09E4")]
		set
		{
		}
	}

	[Token(Token = "0x17000006")]
	public float EqUpper
	{
		[Token(Token = "0x6000014")]
		[Address(RVA = "0x5B0A50", Offset = "0x5B0A50", VA = "0x5B0A50")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000015")]
		[Address(RVA = "0x5B0AD0", Offset = "0x5B0AD0", VA = "0x5B0AD0")]
		set
		{
		}
	}

	[Token(Token = "0x17000007")]
	public float EqHi
	{
		[Token(Token = "0x6000016")]
		[Address(RVA = "0x5B0B3C", Offset = "0x5B0B3C", VA = "0x5B0B3C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000017")]
		[Address(RVA = "0x5B0BBC", Offset = "0x5B0BBC", VA = "0x5B0BBC")]
		set
		{
		}
	}

	[Token(Token = "0x6000018")]
	[Address(RVA = "0x5B0C28", Offset = "0x5B0C28", VA = "0x5B0C28")]
	public AudioMixerAccess()
	{
	}
}
