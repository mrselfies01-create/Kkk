using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000006")]
public class BetterToggle : MonoBehaviour
{
	[Token(Token = "0x400000E")]
	[FieldOffset(Offset = "0x18")]
	public Text offTextUp;

	[Token(Token = "0x400000F")]
	[FieldOffset(Offset = "0x20")]
	public Text offTextDn;

	[Token(Token = "0x4000010")]
	[FieldOffset(Offset = "0x28")]
	public Text onTextUp;

	[Token(Token = "0x4000011")]
	[FieldOffset(Offset = "0x30")]
	public Text onTextDn;

	[Token(Token = "0x4000012")]
	[FieldOffset(Offset = "0x38")]
	public Image onImg;

	[Token(Token = "0x4000013")]
	[FieldOffset(Offset = "0x40")]
	public Image offImg;

	[Token(Token = "0x4000014")]
	[FieldOffset(Offset = "0x48")]
	public Toggle tgl;

	[Token(Token = "0x6000019")]
	[Address(RVA = "0x5B0DD4", Offset = "0x5B0DD4", VA = "0x5B0DD4")]
	private void Start()
	{
	}

	[Token(Token = "0x600001A")]
	[Address(RVA = "0x5B0DD8", Offset = "0x5B0DD8", VA = "0x5B0DD8")]
	private void Update()
	{
	}

	[Token(Token = "0x600001B")]
	[Address(RVA = "0x5B0EB4", Offset = "0x5B0EB4", VA = "0x5B0EB4")]
	public BetterToggle()
	{
	}
}
