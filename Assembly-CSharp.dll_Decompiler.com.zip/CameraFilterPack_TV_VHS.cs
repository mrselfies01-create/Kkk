using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000117")]
public class CameraFilterPack_TV_VHS : MonoBehaviour
{
	[Token(Token = "0x40007F0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007F1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007F2")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007F3")]
	[FieldOffset(Offset = "0x30")]
	public float Cryptage;

	[Token(Token = "0x40007F4")]
	[FieldOffset(Offset = "0x34")]
	public float Parasite;

	[Token(Token = "0x40007F5")]
	[FieldOffset(Offset = "0x38")]
	public float Calibrage;

	[Token(Token = "0x40007F6")]
	[FieldOffset(Offset = "0x3C")]
	public float WhiteParasite;

	[Token(Token = "0x17000118")]
	private Material material
	{
		[Token(Token = "0x60006E1")]
		[Address(RVA = "0x639EAC", Offset = "0x639EAC", VA = "0x639EAC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006E2")]
	[Address(RVA = "0x639F70", Offset = "0x639F70", VA = "0x639F70")]
	private void Start()
	{
	}

	[Token(Token = "0x60006E3")]
	[Address(RVA = "0x639FEC", Offset = "0x639FEC", VA = "0x639FEC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006E4")]
	[Address(RVA = "0x63A270", Offset = "0x63A270", VA = "0x63A270")]
	private void Update()
	{
	}

	[Token(Token = "0x60006E5")]
	[Address(RVA = "0x63A274", Offset = "0x63A274", VA = "0x63A274")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006E6")]
	[Address(RVA = "0x63A324", Offset = "0x63A324", VA = "0x63A324")]
	public CameraFilterPack_TV_VHS()
	{
	}
}
