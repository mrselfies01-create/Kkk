using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000084")]
public class CameraFilterPack_Drawing_BluePrint : MonoBehaviour
{
	[Token(Token = "0x400040C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400040D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400040E")]
	[FieldOffset(Offset = "0x24")]
	public Color Pencil_Color;

	[Token(Token = "0x400040F")]
	[FieldOffset(Offset = "0x34")]
	public float Pencil_Size;

	[Token(Token = "0x4000410")]
	[FieldOffset(Offset = "0x38")]
	public float Pencil_Correction;

	[Token(Token = "0x4000411")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000412")]
	[FieldOffset(Offset = "0x40")]
	public float Speed_Animation;

	[Token(Token = "0x4000413")]
	[FieldOffset(Offset = "0x44")]
	public float Corner_Lose;

	[Token(Token = "0x4000414")]
	[FieldOffset(Offset = "0x48")]
	public float Fade_Paper_to_BackColor;

	[Token(Token = "0x4000415")]
	[FieldOffset(Offset = "0x4C")]
	public float Fade_With_Original;

	[Token(Token = "0x4000416")]
	[FieldOffset(Offset = "0x50")]
	public Color Back_Color;

	[Token(Token = "0x4000417")]
	[FieldOffset(Offset = "0x60")]
	private Material SCMaterial;

	[Token(Token = "0x4000418")]
	[FieldOffset(Offset = "0x68")]
	private Texture2D Texture2;

	[Token(Token = "0x17000085")]
	private Material material
	{
		[Token(Token = "0x600034B")]
		[Address(RVA = "0x677144", Offset = "0x677144", VA = "0x677144")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600034C")]
	[Address(RVA = "0x677208", Offset = "0x677208", VA = "0x677208")]
	private void Start()
	{
	}

	[Token(Token = "0x600034D")]
	[Address(RVA = "0x6772C0", Offset = "0x6772C0", VA = "0x6772C0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600034E")]
	[Address(RVA = "0x677590", Offset = "0x677590", VA = "0x677590")]
	private void Update()
	{
	}

	[Token(Token = "0x600034F")]
	[Address(RVA = "0x677594", Offset = "0x677594", VA = "0x677594")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000350")]
	[Address(RVA = "0x677644", Offset = "0x677644", VA = "0x677644")]
	public CameraFilterPack_Drawing_BluePrint()
	{
	}
}
