using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000120")]
public class CameraFilterPack_TV_WideScreenHorizontal : MonoBehaviour
{
	[Token(Token = "0x4000821")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000822")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000823")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000824")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000825")]
	[FieldOffset(Offset = "0x34")]
	public float Smooth;

	[Token(Token = "0x4000826")]
	[FieldOffset(Offset = "0x38")]
	private float StretchX;

	[Token(Token = "0x4000827")]
	[FieldOffset(Offset = "0x3C")]
	private float StretchY;

	[Token(Token = "0x17000121")]
	private Material material
	{
		[Token(Token = "0x6000717")]
		[Address(RVA = "0x63C450", Offset = "0x63C450", VA = "0x63C450")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000718")]
	[Address(RVA = "0x63C514", Offset = "0x63C514", VA = "0x63C514")]
	private void Start()
	{
	}

	[Token(Token = "0x6000719")]
	[Address(RVA = "0x63C590", Offset = "0x63C590", VA = "0x63C590")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600071A")]
	[Address(RVA = "0x63C814", Offset = "0x63C814", VA = "0x63C814")]
	private void Update()
	{
	}

	[Token(Token = "0x600071B")]
	[Address(RVA = "0x63C818", Offset = "0x63C818", VA = "0x63C818")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600071C")]
	[Address(RVA = "0x63C8C8", Offset = "0x63C8C8", VA = "0x63C8C8")]
	public CameraFilterPack_TV_WideScreenHorizontal()
	{
	}
}
