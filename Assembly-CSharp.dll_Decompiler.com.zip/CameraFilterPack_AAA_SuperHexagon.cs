using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001A")]
public class CameraFilterPack_AAA_SuperHexagon : MonoBehaviour
{
	[Token(Token = "0x400010A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400010B")]
	[FieldOffset(Offset = "0x20")]
	public float _AlphaHexa;

	[Token(Token = "0x400010C")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x400010D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400010E")]
	[FieldOffset(Offset = "0x30")]
	public float HexaSize;

	[Token(Token = "0x400010F")]
	[FieldOffset(Offset = "0x34")]
	public float _BorderSize;

	[Token(Token = "0x4000110")]
	[FieldOffset(Offset = "0x38")]
	public Color _BorderColor;

	[Token(Token = "0x4000111")]
	[FieldOffset(Offset = "0x48")]
	public Color _HexaColor;

	[Token(Token = "0x4000112")]
	[FieldOffset(Offset = "0x58")]
	public float _SpotSize;

	[Token(Token = "0x4000113")]
	[FieldOffset(Offset = "0x5C")]
	public Vector2 center;

	[Token(Token = "0x4000114")]
	[FieldOffset(Offset = "0x64")]
	public float Radius;

	[Token(Token = "0x1700001B")]
	private Material material
	{
		[Token(Token = "0x600008E")]
		[Address(RVA = "0x5B9BB0", Offset = "0x5B9BB0", VA = "0x5B9BB0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600008F")]
	[Address(RVA = "0x5B9C74", Offset = "0x5B9C74", VA = "0x5B9C74")]
	private void Start()
	{
	}

	[Token(Token = "0x6000090")]
	[Address(RVA = "0x5B9CF0", Offset = "0x5B9CF0", VA = "0x5B9CF0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000091")]
	[Address(RVA = "0x5BA030", Offset = "0x5BA030", VA = "0x5BA030")]
	private void Update()
	{
	}

	[Token(Token = "0x6000092")]
	[Address(RVA = "0x5BA034", Offset = "0x5BA034", VA = "0x5BA034")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000093")]
	[Address(RVA = "0x5BA0E4", Offset = "0x5BA0E4", VA = "0x5BA0E4")]
	public CameraFilterPack_AAA_SuperHexagon()
	{
	}
}
