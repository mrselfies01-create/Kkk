using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000104")]
public class CameraFilterPack_TV_ARCADE_Fast : MonoBehaviour
{
	[Token(Token = "0x4000778")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000779")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400077A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400077B")]
	[FieldOffset(Offset = "0x30")]
	public float Interferance_Size;

	[Token(Token = "0x400077C")]
	[FieldOffset(Offset = "0x34")]
	public float Interferance_Speed;

	[Token(Token = "0x400077D")]
	[FieldOffset(Offset = "0x38")]
	public float Contrast;

	[Token(Token = "0x400077E")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x400077F")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x17000105")]
	private Material material
	{
		[Token(Token = "0x600066F")]
		[Address(RVA = "0x634A9C", Offset = "0x634A9C", VA = "0x634A9C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000670")]
	[Address(RVA = "0x634B60", Offset = "0x634B60", VA = "0x634B60")]
	private void Start()
	{
	}

	[Token(Token = "0x6000671")]
	[Address(RVA = "0x634C18", Offset = "0x634C18", VA = "0x634C18")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000672")]
	[Address(RVA = "0x634EC0", Offset = "0x634EC0", VA = "0x634EC0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000673")]
	[Address(RVA = "0x634EC4", Offset = "0x634EC4", VA = "0x634EC4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000674")]
	[Address(RVA = "0x634F74", Offset = "0x634F74", VA = "0x634F74")]
	public CameraFilterPack_TV_ARCADE_Fast()
	{
	}
}
