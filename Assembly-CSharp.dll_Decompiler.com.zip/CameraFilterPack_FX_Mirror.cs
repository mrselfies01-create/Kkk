using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B9")]
public class CameraFilterPack_FX_Mirror : MonoBehaviour
{
	[Token(Token = "0x4000550")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000551")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000552")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000BA")]
	private Material material
	{
		[Token(Token = "0x600048A")]
		[Address(RVA = "0x69BB30", Offset = "0x69BB30", VA = "0x69BB30")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600048B")]
	[Address(RVA = "0x69BBF4", Offset = "0x69BBF4", VA = "0x69BBF4")]
	private void Start()
	{
	}

	[Token(Token = "0x600048C")]
	[Address(RVA = "0x69BC70", Offset = "0x69BC70", VA = "0x69BC70")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600048D")]
	[Address(RVA = "0x69BE64", Offset = "0x69BE64", VA = "0x69BE64")]
	private void Update()
	{
	}

	[Token(Token = "0x600048E")]
	[Address(RVA = "0x69BE68", Offset = "0x69BE68", VA = "0x69BE68")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600048F")]
	[Address(RVA = "0x69BF18", Offset = "0x69BF18", VA = "0x69BF18")]
	public CameraFilterPack_FX_Mirror()
	{
	}
}
