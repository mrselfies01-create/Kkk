using Il2CppDummyDll;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x200019E")]
public enum TweenEasing
{
	[Token(Token = "0x4000AEC")]
	Linear,
	[Token(Token = "0x4000AED")]
	Swing,
	[Token(Token = "0x4000AEE")]
	InQuad,
	[Token(Token = "0x4000AEF")]
	OutQuad,
	[Token(Token = "0x4000AF0")]
	InOutQuad,
	[Token(Token = "0x4000AF1")]
	InCubic,
	[Token(Token = "0x4000AF2")]
	OutCubic,
	[Token(Token = "0x4000AF3")]
	InOutCubic,
	[Token(Token = "0x4000AF4")]
	InQuart,
	[Token(Token = "0x4000AF5")]
	OutQuart,
	[Token(Token = "0x4000AF6")]
	InOutQuart,
	[Token(Token = "0x4000AF7")]
	InQuint,
	[Token(Token = "0x4000AF8")]
	OutQuint,
	[Token(Token = "0x4000AF9")]
	InOutQuint,
	[Token(Token = "0x4000AFA")]
	InSine,
	[Token(Token = "0x4000AFB")]
	OutSine,
	[Token(Token = "0x4000AFC")]
	InOutSine,
	[Token(Token = "0x4000AFD")]
	InExpo,
	[Token(Token = "0x4000AFE")]
	OutExpo,
	[Token(Token = "0x4000AFF")]
	InOutExpo,
	[Token(Token = "0x4000B00")]
	InCirc,
	[Token(Token = "0x4000B01")]
	OutCirc,
	[Token(Token = "0x4000B02")]
	InOutCirc,
	[Token(Token = "0x4000B03")]
	InElastic,
	[Token(Token = "0x4000B04")]
	OutElastic,
	[Token(Token = "0x4000B05")]
	InOutElastic,
	[Token(Token = "0x4000B06")]
	InBack,
	[Token(Token = "0x4000B07")]
	OutBack,
	[Token(Token = "0x4000B08")]
	InOutBack,
	[Token(Token = "0x4000B09")]
	InBounce,
	[Token(Token = "0x4000B0A")]
	OutBounce,
	[Token(Token = "0x4000B0B")]
	InOutBounce
}
