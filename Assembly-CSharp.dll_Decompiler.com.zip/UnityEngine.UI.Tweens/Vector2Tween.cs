using System;
using Il2CppDummyDll;
using UnityEngine.Events;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x20001A1")]
public struct Vector2Tween : IDisposable
{
	[Token(Token = "0x2000249")]
	public class Vector2TweenCallback : UnityEvent<Vector2>
	{
		[Token(Token = "0x6000DB3")]
		[Address(RVA = "0x790510", Offset = "0x790510", VA = "0x790510")]
		public Vector2TweenCallback()
		{
		}
	}

	[Token(Token = "0x200024A")]
	public class Vector2TweenFinishCallback : UnityEvent
	{
		[Token(Token = "0x6000DB4")]
		[Address(RVA = "0x790560", Offset = "0x790560", VA = "0x790560")]
		public Vector2TweenFinishCallback()
		{
		}
	}

	[Token(Token = "0x4000B0E")]
	[FieldOffset(Offset = "0x0")]
	private Vector2 m_StartVector2;

	[Token(Token = "0x4000B0F")]
	[FieldOffset(Offset = "0x8")]
	private Vector2 m_TargetVector2;

	[Token(Token = "0x4000B10")]
	[FieldOffset(Offset = "0x10")]
	private float m_Duration;

	[Token(Token = "0x4000B11")]
	[FieldOffset(Offset = "0x14")]
	private bool m_IgnoreTimeScale;

	[Token(Token = "0x4000B12")]
	[FieldOffset(Offset = "0x18")]
	private TweenEasing m_Easing;

	[Token(Token = "0x4000B13")]
	[FieldOffset(Offset = "0x20")]
	private Vector2TweenCallback m_Target;

	[Token(Token = "0x4000B14")]
	[FieldOffset(Offset = "0x28")]
	private Vector2TweenFinishCallback m_Finish;

	[Token(Token = "0x170001B3")]
	public Vector2 startVector2
	{
		[Token(Token = "0x6000A2F")]
		[Address(RVA = "0x29E29C", Offset = "0x29E29C", VA = "0x29E29C")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000A30")]
		[Address(RVA = "0x29E2A4", Offset = "0x29E2A4", VA = "0x29E2A4")]
		set
		{
		}
	}

	[Token(Token = "0x170001B4")]
	public Vector2 targetVector2
	{
		[Token(Token = "0x6000A31")]
		[Address(RVA = "0x29E2AC", Offset = "0x29E2AC", VA = "0x29E2AC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000A32")]
		[Address(RVA = "0x29E2B4", Offset = "0x29E2B4", VA = "0x29E2B4")]
		set
		{
		}
	}

	[Token(Token = "0x170001B5")]
	public float duration
	{
		[Token(Token = "0x6000A33")]
		[Address(RVA = "0x29E2BC", Offset = "0x29E2BC", VA = "0x29E2BC", Slot = "6")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A34")]
		[Address(RVA = "0x29E2C4", Offset = "0x29E2C4", VA = "0x29E2C4")]
		set
		{
		}
	}

	[Token(Token = "0x170001B6")]
	public bool ignoreTimeScale
	{
		[Token(Token = "0x6000A35")]
		[Address(RVA = "0x29E2CC", Offset = "0x29E2CC", VA = "0x29E2CC", Slot = "5")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000A36")]
		[Address(RVA = "0x29E2D4", Offset = "0x29E2D4", VA = "0x29E2D4")]
		set
		{
		}
	}

	[Token(Token = "0x170001B7")]
	public TweenEasing easing
	{
		[Token(Token = "0x6000A37")]
		[Address(RVA = "0x29E2E0", Offset = "0x29E2E0", VA = "0x29E2E0", Slot = "7")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000A38")]
		[Address(RVA = "0x29E2E8", Offset = "0x29E2E8", VA = "0x29E2E8")]
		set
		{
		}
	}

	[Token(Token = "0x6000A39")]
	[Address(RVA = "0x29E2F0", Offset = "0x29E2F0", VA = "0x29E2F0", Slot = "4")]
	public void TweenValue(float floatPercentage)
	{
	}

	[Token(Token = "0x6000A3A")]
	[Address(RVA = "0x29E2F8", Offset = "0x29E2F8", VA = "0x29E2F8")]
	public void AddOnChangedCallback(UnityAction<Vector2> callback)
	{
	}

	[Token(Token = "0x6000A3B")]
	[Address(RVA = "0x29E300", Offset = "0x29E300", VA = "0x29E300")]
	public void AddOnFinishCallback(UnityAction callback)
	{
	}

	[Token(Token = "0x6000A3C")]
	[Address(RVA = "0x29E308", Offset = "0x29E308", VA = "0x29E308")]
	public bool GetIgnoreTimescale()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A3D")]
	[Address(RVA = "0x29E310", Offset = "0x29E310", VA = "0x29E310")]
	public float GetDuration()
	{
		return default(float);
	}

	[Token(Token = "0x6000A3E")]
	[Address(RVA = "0x29E318", Offset = "0x29E318", VA = "0x29E318", Slot = "8")]
	public bool ValidTarget()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A3F")]
	[Address(RVA = "0x29E328", Offset = "0x29E328", VA = "0x29E328", Slot = "9")]
	public void Finished()
	{
	}
}
