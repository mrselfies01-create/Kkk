using System;
using Il2CppDummyDll;
using UnityEngine.Events;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x20001A2")]
public struct Vector3Tween : IDisposable
{
	[Token(Token = "0x200024B")]
	public class Vector3TweenCallback : UnityEvent<Vector3>
	{
		[Token(Token = "0x6000DB5")]
		[Address(RVA = "0x790568", Offset = "0x790568", VA = "0x790568")]
		public Vector3TweenCallback()
		{
		}
	}

	[Token(Token = "0x200024C")]
	public class Vector3TweenFinishCallback : UnityEvent
	{
		[Token(Token = "0x6000DB6")]
		[Address(RVA = "0x7905B8", Offset = "0x7905B8", VA = "0x7905B8")]
		public Vector3TweenFinishCallback()
		{
		}
	}

	[Token(Token = "0x4000B15")]
	[FieldOffset(Offset = "0x0")]
	private Vector3 m_StartVector3;

	[Token(Token = "0x4000B16")]
	[FieldOffset(Offset = "0xC")]
	private Vector3 m_TargetVector3;

	[Token(Token = "0x4000B17")]
	[FieldOffset(Offset = "0x18")]
	private float m_Duration;

	[Token(Token = "0x4000B18")]
	[FieldOffset(Offset = "0x1C")]
	private bool m_IgnoreTimeScale;

	[Token(Token = "0x4000B19")]
	[FieldOffset(Offset = "0x20")]
	private TweenEasing m_Easing;

	[Token(Token = "0x4000B1A")]
	[FieldOffset(Offset = "0x28")]
	private Vector3TweenCallback m_Target;

	[Token(Token = "0x4000B1B")]
	[FieldOffset(Offset = "0x30")]
	private Vector3TweenFinishCallback m_Finish;

	[Token(Token = "0x170001B8")]
	public Vector3 startVector3
	{
		[Token(Token = "0x6000A40")]
		[Address(RVA = "0x29E378", Offset = "0x29E378", VA = "0x29E378")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector3);
		}
		[Token(Token = "0x6000A41")]
		[Address(RVA = "0x29E384", Offset = "0x29E384", VA = "0x29E384")]
		set
		{
		}
	}

	[Token(Token = "0x170001B9")]
	public Vector3 targetVector3
	{
		[Token(Token = "0x6000A42")]
		[Address(RVA = "0x29E390", Offset = "0x29E390", VA = "0x29E390")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector3);
		}
		[Token(Token = "0x6000A43")]
		[Address(RVA = "0x29E39C", Offset = "0x29E39C", VA = "0x29E39C")]
		set
		{
		}
	}

	[Token(Token = "0x170001BA")]
	public float duration
	{
		[Token(Token = "0x6000A44")]
		[Address(RVA = "0x29E3A8", Offset = "0x29E3A8", VA = "0x29E3A8", Slot = "6")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A45")]
		[Address(RVA = "0x29E3B0", Offset = "0x29E3B0", VA = "0x29E3B0")]
		set
		{
		}
	}

	[Token(Token = "0x170001BB")]
	public bool ignoreTimeScale
	{
		[Token(Token = "0x6000A46")]
		[Address(RVA = "0x29E3B8", Offset = "0x29E3B8", VA = "0x29E3B8", Slot = "5")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000A47")]
		[Address(RVA = "0x29E3C0", Offset = "0x29E3C0", VA = "0x29E3C0")]
		set
		{
		}
	}

	[Token(Token = "0x170001BC")]
	public TweenEasing easing
	{
		[Token(Token = "0x6000A48")]
		[Address(RVA = "0x29E3CC", Offset = "0x29E3CC", VA = "0x29E3CC", Slot = "7")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000A49")]
		[Address(RVA = "0x29E3D4", Offset = "0x29E3D4", VA = "0x29E3D4")]
		set
		{
		}
	}

	[Token(Token = "0x6000A4A")]
	[Address(RVA = "0x29E3DC", Offset = "0x29E3DC", VA = "0x29E3DC", Slot = "4")]
	public void TweenValue(float floatPercentage)
	{
	}

	[Token(Token = "0x6000A4B")]
	[Address(RVA = "0x29E3E4", Offset = "0x29E3E4", VA = "0x29E3E4")]
	public void AddOnChangedCallback(UnityAction<Vector3> callback)
	{
	}

	[Token(Token = "0x6000A4C")]
	[Address(RVA = "0x29E3EC", Offset = "0x29E3EC", VA = "0x29E3EC")]
	public void AddOnFinishCallback(UnityAction callback)
	{
	}

	[Token(Token = "0x6000A4D")]
	[Address(RVA = "0x29E3F4", Offset = "0x29E3F4", VA = "0x29E3F4")]
	public bool GetIgnoreTimescale()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A4E")]
	[Address(RVA = "0x29E3FC", Offset = "0x29E3FC", VA = "0x29E3FC")]
	public float GetDuration()
	{
		return default(float);
	}

	[Token(Token = "0x6000A4F")]
	[Address(RVA = "0x29E404", Offset = "0x29E404", VA = "0x29E404", Slot = "8")]
	public bool ValidTarget()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A50")]
	[Address(RVA = "0x29E414", Offset = "0x29E414", VA = "0x29E414", Slot = "9")]
	public void Finished()
	{
	}
}
