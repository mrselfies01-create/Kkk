using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x20001A0")]
internal class TweenRunner<T> where T : struct, ITweenValue
{
	[Token(Token = "0x2000248")]
	private sealed class _003CStart_003Ed__2 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000F25")]
		[FieldOffset(Offset = "0x0")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000F26")]
		[FieldOffset(Offset = "0x0")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000F27")]
		[FieldOffset(Offset = "0x0")]
		public T tweenInfo;

		[Token(Token = "0x4000F28")]
		[FieldOffset(Offset = "0x0")]
		private float _003CelapsedTime_003E5__2;

		[Token(Token = "0x1700026E")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000DB0")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x1700026F")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000DB2")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000DAD")]
		public _003CStart_003Ed__2(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000DAE")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000DAF")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000DB1")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x4000B0C")]
	[FieldOffset(Offset = "0x0")]
	protected MonoBehaviour m_CoroutineContainer;

	[Token(Token = "0x4000B0D")]
	[FieldOffset(Offset = "0x0")]
	protected IEnumerator m_Tween;

	[Token(Token = "0x6000A2B")]
	private static IEnumerator Start(T tweenInfo)
	{
		return null;
	}

	[Token(Token = "0x6000A2C")]
	public void Init(MonoBehaviour coroutineContainer)
	{
	}

	[Token(Token = "0x6000A2D")]
	public void StartTween(T info)
	{
	}

	[Token(Token = "0x6000A2E")]
	public TweenRunner()
	{
	}
}
