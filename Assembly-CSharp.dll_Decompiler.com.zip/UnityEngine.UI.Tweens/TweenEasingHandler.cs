using Il2CppDummyDll;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x200019F")]
internal class TweenEasingHandler
{
	[Token(Token = "0x6000A29")]
	[Address(RVA = "0x3E2170", Offset = "0x3E2170", VA = "0x3E2170")]
	public static float Apply(TweenEasing e, float t, float b, float c, float d)
	{
		return default(float);
	}

	[Token(Token = "0x6000A2A")]
	[Address(RVA = "0x3E2C74", Offset = "0x3E2C74", VA = "0x3E2C74")]
	public TweenEasingHandler()
	{
	}
}
