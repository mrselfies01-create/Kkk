using System;
using Il2CppDummyDll;
using UnityEngine.Events;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x200019B")]
public struct ColorTween : IDisposable
{
	[Token(Token = "0x2000243")]
	public enum ColorTweenMode
	{
		[Token(Token = "0x4000F22")]
		All,
		[Token(Token = "0x4000F23")]
		RGB,
		[Token(Token = "0x4000F24")]
		Alpha
	}

	[Token(Token = "0x2000244")]
	public class ColorTweenCallback : UnityEvent<Color>
	{
		[Token(Token = "0x6000DA9")]
		[Address(RVA = "0x78C3AC", Offset = "0x78C3AC", VA = "0x78C3AC")]
		public ColorTweenCallback()
		{
		}
	}

	[Token(Token = "0x2000245")]
	public class ColorTweenFinishCallback : UnityEvent
	{
		[Token(Token = "0x6000DAA")]
		[Address(RVA = "0x78C3FC", Offset = "0x78C3FC", VA = "0x78C3FC")]
		public ColorTweenFinishCallback()
		{
		}
	}

	[Token(Token = "0x4000ADC")]
	[FieldOffset(Offset = "0x0")]
	private Color m_StartColor;

	[Token(Token = "0x4000ADD")]
	[FieldOffset(Offset = "0x10")]
	private Color m_TargetColor;

	[Token(Token = "0x4000ADE")]
	[FieldOffset(Offset = "0x20")]
	private float m_Duration;

	[Token(Token = "0x4000ADF")]
	[FieldOffset(Offset = "0x24")]
	private bool m_IgnoreTimeScale;

	[Token(Token = "0x4000AE0")]
	[FieldOffset(Offset = "0x28")]
	private TweenEasing m_Easing;

	[Token(Token = "0x4000AE1")]
	[FieldOffset(Offset = "0x2C")]
	private ColorTweenMode m_TweenMode;

	[Token(Token = "0x4000AE2")]
	[FieldOffset(Offset = "0x30")]
	private ColorTweenCallback m_Target;

	[Token(Token = "0x4000AE3")]
	[FieldOffset(Offset = "0x38")]
	private ColorTweenFinishCallback m_Finish;

	[Token(Token = "0x170001A5")]
	public Color startColor
	{
		[Token(Token = "0x60009FF")]
		[Address(RVA = "0x26E128", Offset = "0x26E128", VA = "0x26E128")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000A00")]
		[Address(RVA = "0x26E134", Offset = "0x26E134", VA = "0x26E134")]
		set
		{
		}
	}

	[Token(Token = "0x170001A6")]
	public Color targetColor
	{
		[Token(Token = "0x6000A01")]
		[Address(RVA = "0x26E140", Offset = "0x26E140", VA = "0x26E140")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000A02")]
		[Address(RVA = "0x26E14C", Offset = "0x26E14C", VA = "0x26E14C")]
		set
		{
		}
	}

	[Token(Token = "0x170001A7")]
	public float duration
	{
		[Token(Token = "0x6000A03")]
		[Address(RVA = "0x26E158", Offset = "0x26E158", VA = "0x26E158", Slot = "6")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A04")]
		[Address(RVA = "0x26E160", Offset = "0x26E160", VA = "0x26E160")]
		set
		{
		}
	}

	[Token(Token = "0x170001A8")]
	public bool ignoreTimeScale
	{
		[Token(Token = "0x6000A05")]
		[Address(RVA = "0x26E168", Offset = "0x26E168", VA = "0x26E168", Slot = "5")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000A06")]
		[Address(RVA = "0x26E170", Offset = "0x26E170", VA = "0x26E170")]
		set
		{
		}
	}

	[Token(Token = "0x170001A9")]
	public TweenEasing easing
	{
		[Token(Token = "0x6000A07")]
		[Address(RVA = "0x26E17C", Offset = "0x26E17C", VA = "0x26E17C", Slot = "7")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000A08")]
		[Address(RVA = "0x26E184", Offset = "0x26E184", VA = "0x26E184")]
		set
		{
		}
	}

	[Token(Token = "0x170001AA")]
	public ColorTweenMode tweenMode
	{
		[Token(Token = "0x6000A09")]
		[Address(RVA = "0x26E18C", Offset = "0x26E18C", VA = "0x26E18C")]
		get
		{
			return default(ColorTweenMode);
		}
		[Token(Token = "0x6000A0A")]
		[Address(RVA = "0x26E194", Offset = "0x26E194", VA = "0x26E194")]
		set
		{
		}
	}

	[Token(Token = "0x6000A0B")]
	[Address(RVA = "0x26E19C", Offset = "0x26E19C", VA = "0x26E19C", Slot = "4")]
	public void TweenValue(float floatPercentage)
	{
	}

	[Token(Token = "0x6000A0C")]
	[Address(RVA = "0x26E1A4", Offset = "0x26E1A4", VA = "0x26E1A4")]
	public void AddOnChangedCallback(UnityAction<Color> callback)
	{
	}

	[Token(Token = "0x6000A0D")]
	[Address(RVA = "0x26E1AC", Offset = "0x26E1AC", VA = "0x26E1AC")]
	public void AddOnFinishCallback(UnityAction callback)
	{
	}

	[Token(Token = "0x6000A0E")]
	[Address(RVA = "0x26E1B4", Offset = "0x26E1B4", VA = "0x26E1B4")]
	public bool GetIgnoreTimescale()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A0F")]
	[Address(RVA = "0x26E1BC", Offset = "0x26E1BC", VA = "0x26E1BC")]
	public float GetDuration()
	{
		return default(float);
	}

	[Token(Token = "0x6000A10")]
	[Address(RVA = "0x26E1C4", Offset = "0x26E1C4", VA = "0x26E1C4", Slot = "8")]
	public bool ValidTarget()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A11")]
	[Address(RVA = "0x26E1D4", Offset = "0x26E1D4", VA = "0x26E1D4", Slot = "9")]
	public void Finished()
	{
	}
}
