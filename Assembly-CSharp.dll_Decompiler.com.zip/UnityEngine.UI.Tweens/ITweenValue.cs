using Il2CppDummyDll;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x200019D")]
internal interface ITweenValue
{
	[Token(Token = "0x170001B0")]
	bool ignoreTimeScale
	{
		[Token(Token = "0x6000A24")]
		get;
	}

	[Token(Token = "0x170001B1")]
	float duration
	{
		[Token(Token = "0x6000A25")]
		get;
	}

	[Token(Token = "0x170001B2")]
	TweenEasing easing
	{
		[Token(Token = "0x6000A26")]
		get;
	}

	[Token(Token = "0x6000A23")]
	void TweenValue(float floatPercentage);

	[Token(Token = "0x6000A27")]
	bool ValidTarget();

	[Token(Token = "0x6000A28")]
	void Finished();
}
