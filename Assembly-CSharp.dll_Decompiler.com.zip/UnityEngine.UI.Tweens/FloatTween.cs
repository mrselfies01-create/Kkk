using System;
using Il2CppDummyDll;
using UnityEngine.Events;

namespace UnityEngine.UI.Tweens;

[Token(Token = "0x200019C")]
public struct FloatTween : IDisposable
{
	[Token(Token = "0x2000246")]
	public class FloatTweenCallback : UnityEvent<float>
	{
		[Token(Token = "0x6000DAB")]
		[Address(RVA = "0x78C988", Offset = "0x78C988", VA = "0x78C988")]
		public FloatTweenCallback()
		{
		}
	}

	[Token(Token = "0x2000247")]
	public class FloatFinishCallback : UnityEvent
	{
		[Token(Token = "0x6000DAC")]
		[Address(RVA = "0x78C980", Offset = "0x78C980", VA = "0x78C980")]
		public FloatFinishCallback()
		{
		}
	}

	[Token(Token = "0x4000AE4")]
	[FieldOffset(Offset = "0x0")]
	private float m_StartFloat;

	[Token(Token = "0x4000AE5")]
	[FieldOffset(Offset = "0x4")]
	private float m_TargetFloat;

	[Token(Token = "0x4000AE6")]
	[FieldOffset(Offset = "0x8")]
	private float m_Duration;

	[Token(Token = "0x4000AE7")]
	[FieldOffset(Offset = "0xC")]
	private bool m_IgnoreTimeScale;

	[Token(Token = "0x4000AE8")]
	[FieldOffset(Offset = "0x10")]
	private TweenEasing m_Easing;

	[Token(Token = "0x4000AE9")]
	[FieldOffset(Offset = "0x18")]
	private FloatTweenCallback m_Target;

	[Token(Token = "0x4000AEA")]
	[FieldOffset(Offset = "0x20")]
	private FloatFinishCallback m_Finish;

	[Token(Token = "0x170001AB")]
	public float startFloat
	{
		[Token(Token = "0x6000A12")]
		[Address(RVA = "0x26E224", Offset = "0x26E224", VA = "0x26E224")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A13")]
		[Address(RVA = "0x26E22C", Offset = "0x26E22C", VA = "0x26E22C")]
		set
		{
		}
	}

	[Token(Token = "0x170001AC")]
	public float targetFloat
	{
		[Token(Token = "0x6000A14")]
		[Address(RVA = "0x26E234", Offset = "0x26E234", VA = "0x26E234")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A15")]
		[Address(RVA = "0x26E23C", Offset = "0x26E23C", VA = "0x26E23C")]
		set
		{
		}
	}

	[Token(Token = "0x170001AD")]
	public float duration
	{
		[Token(Token = "0x6000A16")]
		[Address(RVA = "0x26E244", Offset = "0x26E244", VA = "0x26E244", Slot = "6")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A17")]
		[Address(RVA = "0x26E24C", Offset = "0x26E24C", VA = "0x26E24C")]
		set
		{
		}
	}

	[Token(Token = "0x170001AE")]
	public bool ignoreTimeScale
	{
		[Token(Token = "0x6000A18")]
		[Address(RVA = "0x26E254", Offset = "0x26E254", VA = "0x26E254", Slot = "5")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000A19")]
		[Address(RVA = "0x26E25C", Offset = "0x26E25C", VA = "0x26E25C")]
		set
		{
		}
	}

	[Token(Token = "0x170001AF")]
	public TweenEasing easing
	{
		[Token(Token = "0x6000A1A")]
		[Address(RVA = "0x26E268", Offset = "0x26E268", VA = "0x26E268", Slot = "7")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000A1B")]
		[Address(RVA = "0x26E270", Offset = "0x26E270", VA = "0x26E270")]
		set
		{
		}
	}

	[Token(Token = "0x6000A1C")]
	[Address(RVA = "0x26E278", Offset = "0x26E278", VA = "0x26E278", Slot = "4")]
	public void TweenValue(float floatPercentage)
	{
	}

	[Token(Token = "0x6000A1D")]
	[Address(RVA = "0x26E280", Offset = "0x26E280", VA = "0x26E280")]
	public void AddOnChangedCallback(UnityAction<float> callback)
	{
	}

	[Token(Token = "0x6000A1E")]
	[Address(RVA = "0x26E288", Offset = "0x26E288", VA = "0x26E288")]
	public void AddOnFinishCallback(UnityAction callback)
	{
	}

	[Token(Token = "0x6000A1F")]
	[Address(RVA = "0x26E290", Offset = "0x26E290", VA = "0x26E290")]
	public bool GetIgnoreTimescale()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A20")]
	[Address(RVA = "0x26E298", Offset = "0x26E298", VA = "0x26E298")]
	public float GetDuration()
	{
		return default(float);
	}

	[Token(Token = "0x6000A21")]
	[Address(RVA = "0x26E2A0", Offset = "0x26E2A0", VA = "0x26E2A0", Slot = "8")]
	public bool ValidTarget()
	{
		return default(bool);
	}

	[Token(Token = "0x6000A22")]
	[Address(RVA = "0x26E2B0", Offset = "0x26E2B0", VA = "0x26E2B0", Slot = "9")]
	public void Finished()
	{
	}
}
