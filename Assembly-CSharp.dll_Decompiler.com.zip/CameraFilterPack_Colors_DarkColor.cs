using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006A")]
public class CameraFilterPack_Colors_DarkColor : MonoBehaviour
{
	[Token(Token = "0x4000376")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000377")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000378")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000379")]
	[FieldOffset(Offset = "0x30")]
	public float Alpha;

	[Token(Token = "0x400037A")]
	[FieldOffset(Offset = "0x34")]
	private float Colors;

	[Token(Token = "0x400037B")]
	[FieldOffset(Offset = "0x38")]
	private float Green_Mod;

	[Token(Token = "0x400037C")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700006B")]
	private Material material
	{
		[Token(Token = "0x60002AF")]
		[Address(RVA = "0x6702AC", Offset = "0x6702AC", VA = "0x6702AC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002B0")]
	[Address(RVA = "0x670370", Offset = "0x670370", VA = "0x670370")]
	private void Start()
	{
	}

	[Token(Token = "0x60002B1")]
	[Address(RVA = "0x6703EC", Offset = "0x6703EC", VA = "0x6703EC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002B2")]
	[Address(RVA = "0x670670", Offset = "0x670670", VA = "0x670670")]
	private void Update()
	{
	}

	[Token(Token = "0x60002B3")]
	[Address(RVA = "0x670674", Offset = "0x670674", VA = "0x670674")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002B4")]
	[Address(RVA = "0x670724", Offset = "0x670724", VA = "0x670724")]
	public CameraFilterPack_Colors_DarkColor()
	{
	}
}
