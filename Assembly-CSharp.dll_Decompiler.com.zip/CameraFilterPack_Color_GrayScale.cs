using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005E")]
public class CameraFilterPack_Color_GrayScale : MonoBehaviour
{
	[Token(Token = "0x4000334")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000335")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000336")]
	[FieldOffset(Offset = "0x24")]
	public float _Fade;

	[Token(Token = "0x4000337")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700005F")]
	private Material material
	{
		[Token(Token = "0x6000265")]
		[Address(RVA = "0x66C498", Offset = "0x66C498", VA = "0x66C498")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000266")]
	[Address(RVA = "0x66C55C", Offset = "0x66C55C", VA = "0x66C55C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000267")]
	[Address(RVA = "0x66C5D8", Offset = "0x66C5D8", VA = "0x66C5D8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000268")]
	[Address(RVA = "0x66C7F0", Offset = "0x66C7F0", VA = "0x66C7F0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000269")]
	[Address(RVA = "0x66C7F4", Offset = "0x66C7F4", VA = "0x66C7F4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600026A")]
	[Address(RVA = "0x66C8A4", Offset = "0x66C8A4", VA = "0x66C8A4")]
	public CameraFilterPack_Color_GrayScale()
	{
	}
}
