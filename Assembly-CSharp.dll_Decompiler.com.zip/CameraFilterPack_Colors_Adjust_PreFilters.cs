using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000067")]
public class CameraFilterPack_Colors_Adjust_PreFilters : MonoBehaviour
{
	[Token(Token = "0x20001F1")]
	public enum filters
	{
		[Token(Token = "0x4000D4A")]
		Normal,
		[Token(Token = "0x4000D4B")]
		BlueLagoon,
		[Token(Token = "0x4000D4C")]
		BlueMoon,
		[Token(Token = "0x4000D4D")]
		RedWhite,
		[Token(Token = "0x4000D4E")]
		NashVille,
		[Token(Token = "0x4000D4F")]
		VintageYellow,
		[Token(Token = "0x4000D50")]
		GoldenPink,
		[Token(Token = "0x4000D51")]
		DarkPink,
		[Token(Token = "0x4000D52")]
		PopRocket,
		[Token(Token = "0x4000D53")]
		RedSoftLight,
		[Token(Token = "0x4000D54")]
		YellowSunSet,
		[Token(Token = "0x4000D55")]
		Walden,
		[Token(Token = "0x4000D56")]
		WhiteShine,
		[Token(Token = "0x4000D57")]
		Fluo,
		[Token(Token = "0x4000D58")]
		MarsSunRise,
		[Token(Token = "0x4000D59")]
		Amelie,
		[Token(Token = "0x4000D5A")]
		BlueJeans,
		[Token(Token = "0x4000D5B")]
		NightVision,
		[Token(Token = "0x4000D5C")]
		BlueParadise,
		[Token(Token = "0x4000D5D")]
		Blindness_Deuteranomaly,
		[Token(Token = "0x4000D5E")]
		Blindness_Protanopia,
		[Token(Token = "0x4000D5F")]
		Blindness_Protanomaly,
		[Token(Token = "0x4000D60")]
		Blindness_Deuteranopia,
		[Token(Token = "0x4000D61")]
		Blindness_Tritanomaly,
		[Token(Token = "0x4000D62")]
		Blindness_Achromatopsia,
		[Token(Token = "0x4000D63")]
		Blindness_Achromatomaly,
		[Token(Token = "0x4000D64")]
		Blindness_Tritanopia,
		[Token(Token = "0x4000D65")]
		BlackAndWhite_Blue,
		[Token(Token = "0x4000D66")]
		BlackAndWhite_Green,
		[Token(Token = "0x4000D67")]
		BlackAndWhite_Orange,
		[Token(Token = "0x4000D68")]
		BlackAndWhite_Red,
		[Token(Token = "0x4000D69")]
		BlackAndWhite_Yellow
	}

	[Token(Token = "0x4000368")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000369")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400036A")]
	[FieldOffset(Offset = "0x28")]
	public filters filterchoice;

	[Token(Token = "0x400036B")]
	[FieldOffset(Offset = "0x2C")]
	public float FadeFX;

	[Token(Token = "0x400036C")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400036D")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400036E")]
	[FieldOffset(Offset = "0x40")]
	private float[] Matrix9;

	[Token(Token = "0x17000068")]
	private Material material
	{
		[Token(Token = "0x600029B")]
		[Address(RVA = "0x66EC80", Offset = "0x66EC80", VA = "0x66EC80")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600029C")]
	[Address(RVA = "0x66ED44", Offset = "0x66ED44", VA = "0x66ED44")]
	private void ChangeFilters()
	{
	}

	[Token(Token = "0x600029D")]
	[Address(RVA = "0x66F500", Offset = "0x66F500", VA = "0x66F500")]
	private void Start()
	{
	}

	[Token(Token = "0x600029E")]
	[Address(RVA = "0x66F554", Offset = "0x66F554", VA = "0x66F554")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600029F")]
	[Address(RVA = "0x66FA44", Offset = "0x66FA44", VA = "0x66FA44")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60002A0")]
	[Address(RVA = "0x66FA48", Offset = "0x66FA48", VA = "0x66FA48")]
	private void Update()
	{
	}

	[Token(Token = "0x60002A1")]
	[Address(RVA = "0x66FA4C", Offset = "0x66FA4C", VA = "0x66FA4C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002A2")]
	[Address(RVA = "0x66FAFC", Offset = "0x66FAFC", VA = "0x66FAFC")]
	public CameraFilterPack_Colors_Adjust_PreFilters()
	{
	}
}
