using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004F")]
public class CameraFilterPack_Blur_Radial_Fast : MonoBehaviour
{
	[Token(Token = "0x40002D0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002D1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002D2")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002D3")]
	[FieldOffset(Offset = "0x30")]
	public float Intensity;

	[Token(Token = "0x40002D4")]
	[FieldOffset(Offset = "0x34")]
	public float MovX;

	[Token(Token = "0x40002D5")]
	[FieldOffset(Offset = "0x38")]
	public float MovY;

	[Token(Token = "0x40002D6")]
	[FieldOffset(Offset = "0x3C")]
	private float blurWidth;

	[Token(Token = "0x17000050")]
	private Material material
	{
		[Token(Token = "0x600020B")]
		[Address(RVA = "0x667CF8", Offset = "0x667CF8", VA = "0x667CF8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600020C")]
	[Address(RVA = "0x667DBC", Offset = "0x667DBC", VA = "0x667DBC")]
	private void Start()
	{
	}

	[Token(Token = "0x600020D")]
	[Address(RVA = "0x667E38", Offset = "0x667E38", VA = "0x667E38")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600020E")]
	[Address(RVA = "0x6680BC", Offset = "0x6680BC", VA = "0x6680BC")]
	private void Update()
	{
	}

	[Token(Token = "0x600020F")]
	[Address(RVA = "0x6680C0", Offset = "0x6680C0", VA = "0x6680C0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000210")]
	[Address(RVA = "0x668170", Offset = "0x668170", VA = "0x668170")]
	public CameraFilterPack_Blur_Radial_Fast()
	{
	}
}
