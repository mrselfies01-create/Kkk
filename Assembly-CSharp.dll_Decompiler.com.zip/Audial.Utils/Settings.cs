using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x2000165")]
public static class Settings
{
	[Token(Token = "0x4000A56")]
	[FieldOffset(Offset = "0x0")]
	public static float SampleRate;
}
