using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;

namespace Audial.Utils;

[Token(Token = "0x2000164")]
public class LFO
{
	[Token(Token = "0x20001FF")]
	private sealed class _003CRun_003Ed__7 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000DA2")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000DA3")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000DA4")]
		[FieldOffset(Offset = "0x20")]
		public LFO _003C_003E4__this;

		[Token(Token = "0x1700024C")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D62")]
			[Address(RVA = "0x78CD50", Offset = "0x78CD50", VA = "0x78CD50", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x1700024D")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D64")]
			[Address(RVA = "0x78CDB8", Offset = "0x78CDB8", VA = "0x78CDB8", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D5F")]
		[Address(RVA = "0x78CC24", Offset = "0x78CC24", VA = "0x78CC24")]
		public _003CRun_003Ed__7(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D60")]
		[Address(RVA = "0x78CC50", Offset = "0x78CC50", VA = "0x78CC50", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D61")]
		[Address(RVA = "0x78CC54", Offset = "0x78CC54", VA = "0x78CC54", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D63")]
		[Address(RVA = "0x78CD58", Offset = "0x78CD58", VA = "0x78CD58", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x4000A51")]
	[FieldOffset(Offset = "0x10")]
	private int tableLength;

	[Token(Token = "0x4000A52")]
	[FieldOffset(Offset = "0x0")]
	public static float[] waveTable;

	[Token(Token = "0x4000A53")]
	[FieldOffset(Offset = "0x14")]
	private float _index;

	[Token(Token = "0x4000A54")]
	[FieldOffset(Offset = "0x18")]
	private RunState runState;

	[Token(Token = "0x4000A55")]
	[FieldOffset(Offset = "0x1C")]
	private float _stepSize;

	[Token(Token = "0x1700016D")]
	public float Index
	{
		[Token(Token = "0x60008D2")]
		[Address(RVA = "0x38CD5C", Offset = "0x38CD5C", VA = "0x38CD5C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008D3")]
		[Address(RVA = "0x38CD64", Offset = "0x38CD64", VA = "0x38CD64")]
		set
		{
		}
	}

	[Token(Token = "0x1700016E")]
	public float StepSize
	{
		[Token(Token = "0x60008D8")]
		[Address(RVA = "0x38CE1C", Offset = "0x38CE1C", VA = "0x38CE1C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008D9")]
		[Address(RVA = "0x38CE24", Offset = "0x38CE24", VA = "0x38CE24")]
		set
		{
		}
	}

	[Token(Token = "0x60008D4")]
	[Address(RVA = "0x38CD8C", Offset = "0x38CD8C", VA = "0x38CD8C")]
	public IEnumerator Run()
	{
		return null;
	}

	[Token(Token = "0x60008D5")]
	[Address(RVA = "0x38CDFC", Offset = "0x38CDFC", VA = "0x38CDFC")]
	public void Pause()
	{
	}

	[Token(Token = "0x60008D6")]
	[Address(RVA = "0x38CE08", Offset = "0x38CE08", VA = "0x38CE08")]
	public void Resume()
	{
	}

	[Token(Token = "0x60008D7")]
	[Address(RVA = "0x38CE10", Offset = "0x38CE10", VA = "0x38CE10")]
	public void Stop()
	{
	}

	[Token(Token = "0x60008DA")]
	[Address(RVA = "0x3896F0", Offset = "0x3896F0", VA = "0x3896F0")]
	public void SetRate(float rate)
	{
	}

	[Token(Token = "0x60008DB")]
	[Address(RVA = "0x38CE2C", Offset = "0x38CE2C", VA = "0x38CE2C")]
	public int GetIndex()
	{
		return default(int);
	}

	[Token(Token = "0x60008DC")]
	[Address(RVA = "0x389A14", Offset = "0x389A14", VA = "0x389A14")]
	public float GetValue()
	{
		return default(float);
	}

	[Token(Token = "0x60008DD")]
	[Address(RVA = "0x389A98", Offset = "0x389A98", VA = "0x389A98")]
	public void MoveIndex()
	{
	}

	[Token(Token = "0x60008DE")]
	[Address(RVA = "0x38CECC", Offset = "0x38CECC", VA = "0x38CECC")]
	public float[] GetChunkValue(int chunkLength)
	{
		return null;
	}

	[Token(Token = "0x60008DF")]
	[Address(RVA = "0x389408", Offset = "0x389408", VA = "0x389408")]
	public LFO()
	{
	}

	[Token(Token = "0x60008E0")]
	[Address(RVA = "0x3895B4", Offset = "0x3895B4", VA = "0x3895B4")]
	public LFO(float speed)
	{
	}

	[Token(Token = "0x60008E1")]
	[Address(RVA = "0x38CF88", Offset = "0x38CF88", VA = "0x38CF88")]
	private void CreateWavetable()
	{
	}
}
