using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x2000163")]
internal enum RunState
{
	[Token(Token = "0x4000A4E")]
	Running,
	[Token(Token = "0x4000A4F")]
	Paused,
	[Token(Token = "0x4000A50")]
	Stopped
}
