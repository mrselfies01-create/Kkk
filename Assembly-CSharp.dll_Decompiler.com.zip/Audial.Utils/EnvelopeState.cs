using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x2000161")]
internal enum EnvelopeState
{
	[Token(Token = "0x4000A41")]
	Idle,
	[Token(Token = "0x4000A42")]
	Attack,
	[Token(Token = "0x4000A43")]
	Decay,
	[Token(Token = "0x4000A44")]
	Release
}
