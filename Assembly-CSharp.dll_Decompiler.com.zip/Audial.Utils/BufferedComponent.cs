using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x200015F")]
public class BufferedComponent
{
	[Token(Token = "0x4000A35")]
	[FieldOffset(Offset = "0x10")]
	public float[,] buffer;

	[Token(Token = "0x4000A36")]
	[FieldOffset(Offset = "0x18")]
	private float loopTime;

	[Token(Token = "0x4000A37")]
	[FieldOffset(Offset = "0x1C")]
	public float delayLength;

	[Token(Token = "0x4000A38")]
	[FieldOffset(Offset = "0x20")]
	public float decayLength;

	[Token(Token = "0x4000A39")]
	[FieldOffset(Offset = "0x24")]
	public int bufferLength;

	[Token(Token = "0x4000A3A")]
	[FieldOffset(Offset = "0x28")]
	public float gain;

	[Token(Token = "0x4000A3B")]
	[FieldOffset(Offset = "0x2C")]
	public int readIndex;

	[Token(Token = "0x4000A3C")]
	[FieldOffset(Offset = "0x30")]
	public int writeIndex;

	[Token(Token = "0x4000A3D")]
	[FieldOffset(Offset = "0x34")]
	public int channelCount;

	[Token(Token = "0x4000A3E")]
	[FieldOffset(Offset = "0x38")]
	private float sampleRate;

	[Token(Token = "0x4000A3F")]
	[FieldOffset(Offset = "0x3C")]
	private int _offset;

	[Token(Token = "0x17000169")]
	public float DelayLength
	{
		[Token(Token = "0x60008C0")]
		[Address(RVA = "0x5B1AF0", Offset = "0x5B1AF0", VA = "0x5B1AF0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008C1")]
		[Address(RVA = "0x5B1AF8", Offset = "0x5B1AF8", VA = "0x5B1AF8")]
		set
		{
		}
	}

	[Token(Token = "0x1700016A")]
	public int Offset
	{
		[Token(Token = "0x60008C8")]
		[Address(RVA = "0x5B1DCC", Offset = "0x5B1DCC", VA = "0x5B1DCC")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x60008C9")]
		[Address(RVA = "0x5B1B8C", Offset = "0x5B1B8C", VA = "0x5B1B8C")]
		set
		{
		}
	}

	[Token(Token = "0x60008C2")]
	[Address(RVA = "0x5AF3A4", Offset = "0x5AF3A4", VA = "0x5AF3A4")]
	public BufferedComponent(float delayLength, float gain)
	{
	}

	[Token(Token = "0x60008C3")]
	[Address(RVA = "0x5B1C1C", Offset = "0x5B1C1C", VA = "0x5B1C1C")]
	public void SetGainByDecayTime(float decayLength)
	{
	}

	[Token(Token = "0x60008C4")]
	[Address(RVA = "0x5AF4BC", Offset = "0x5AF4BC", VA = "0x5AF4BC")]
	public float ProcessSample(int channel, float sample)
	{
		return default(float);
	}

	[Token(Token = "0x60008C5")]
	[Address(RVA = "0x5B1CA0", Offset = "0x5B1CA0", VA = "0x5B1CA0")]
	public float ProcessSample(float sample)
	{
		return default(float);
	}

	[Token(Token = "0x60008C6")]
	[Address(RVA = "0x5B1D34", Offset = "0x5B1D34", VA = "0x5B1D34")]
	public void MoveIndex()
	{
	}

	[Token(Token = "0x60008C7")]
	[Address(RVA = "0x5B1D50", Offset = "0x5B1D50", VA = "0x5B1D50")]
	public void Reset()
	{
	}
}
