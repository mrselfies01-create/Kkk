using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x200015E")]
public class AllPassFilter : BufferedComponent
{
	[Token(Token = "0x60008BE")]
	[Address(RVA = "0x5AF3A0", Offset = "0x5AF3A0", VA = "0x5AF3A0")]
	public AllPassFilter(float delayLength, float gain)
	{
	}

	[Token(Token = "0x60008BF")]
	[Address(RVA = "0x5AF484", Offset = "0x5AF484", VA = "0x5AF484")]
	public new float ProcessSample(int channel, float sample)
	{
		return default(float);
	}
}
