using Il2CppDummyDll;

namespace Audial.Utils;

[Token(Token = "0x2000160")]
public class CombFilter : BufferedComponent
{
	[Token(Token = "0x60008CA")]
	[Address(RVA = "0x38567C", Offset = "0x38567C", VA = "0x38567C")]
	public CombFilter(float delayLength, float gain)
	{
	}

	[Token(Token = "0x60008CB")]
	[Address(RVA = "0x385684", Offset = "0x385684", VA = "0x385684")]
	public new float ProcessSample(int channel, float sample)
	{
		return default(float);
	}
}
