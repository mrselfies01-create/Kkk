using System;
using Il2CppDummyDll;

namespace Audial.Utils;

[Serializable]
[Token(Token = "0x2000162")]
public class Envelope
{
	[Token(Token = "0x4000A45")]
	[FieldOffset(Offset = "0x10")]
	private EnvelopeState envelopeState;

	[Token(Token = "0x4000A46")]
	[FieldOffset(Offset = "0x14")]
	private float env;

	[Token(Token = "0x4000A47")]
	[FieldOffset(Offset = "0x18")]
	private float _attack;

	[Token(Token = "0x4000A48")]
	[FieldOffset(Offset = "0x1C")]
	public float attackCoeff;

	[Token(Token = "0x4000A49")]
	[FieldOffset(Offset = "0x20")]
	private float _release;

	[Token(Token = "0x4000A4A")]
	[FieldOffset(Offset = "0x24")]
	private float releaseCoeff;

	[Token(Token = "0x4000A4B")]
	[FieldOffset(Offset = "0x28")]
	private float sustain;

	[Token(Token = "0x4000A4C")]
	[FieldOffset(Offset = "0x2C")]
	private float sampleRate;

	[Token(Token = "0x1700016B")]
	public float Attack
	{
		[Token(Token = "0x60008CC")]
		[Address(RVA = "0x387F8C", Offset = "0x387F8C", VA = "0x387F8C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008CD")]
		[Address(RVA = "0x387F94", Offset = "0x387F94", VA = "0x387F94")]
		set
		{
		}
	}

	[Token(Token = "0x1700016C")]
	public float Release
	{
		[Token(Token = "0x60008CE")]
		[Address(RVA = "0x38804C", Offset = "0x38804C", VA = "0x38804C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008CF")]
		[Address(RVA = "0x388054", Offset = "0x388054", VA = "0x388054")]
		set
		{
		}
	}

	[Token(Token = "0x60008D0")]
	[Address(RVA = "0x38810C", Offset = "0x38810C", VA = "0x38810C")]
	public Envelope(float attack, float release)
	{
	}

	[Token(Token = "0x60008D1")]
	[Address(RVA = "0x38815C", Offset = "0x38815C", VA = "0x38815C")]
	public float ProcessSample(float sample)
	{
		return default(float);
	}
}
