using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012D")]
public class CameraFilterPack_Vision_SniperScore : MonoBehaviour
{
	[Token(Token = "0x4000880")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000881")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000882")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000883")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x4000884")]
	[FieldOffset(Offset = "0x34")]
	public float Size;

	[Token(Token = "0x4000885")]
	[FieldOffset(Offset = "0x38")]
	public float Smooth;

	[Token(Token = "0x4000886")]
	[FieldOffset(Offset = "0x3C")]
	public float _Cible;

	[Token(Token = "0x4000887")]
	[FieldOffset(Offset = "0x40")]
	public float _Distortion;

	[Token(Token = "0x4000888")]
	[FieldOffset(Offset = "0x44")]
	public float _ExtraColor;

	[Token(Token = "0x4000889")]
	[FieldOffset(Offset = "0x48")]
	public float _ExtraLight;

	[Token(Token = "0x400088A")]
	[FieldOffset(Offset = "0x4C")]
	public Color _Tint;

	[Token(Token = "0x400088B")]
	[FieldOffset(Offset = "0x5C")]
	private float StretchX;

	[Token(Token = "0x400088C")]
	[FieldOffset(Offset = "0x60")]
	private float StretchY;

	[Token(Token = "0x400088D")]
	[FieldOffset(Offset = "0x64")]
	public float _PosX;

	[Token(Token = "0x400088E")]
	[FieldOffset(Offset = "0x68")]
	public float _PosY;

	[Token(Token = "0x1700012E")]
	private Material material
	{
		[Token(Token = "0x6000765")]
		[Address(RVA = "0x640184", Offset = "0x640184", VA = "0x640184")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000766")]
	[Address(RVA = "0x640248", Offset = "0x640248", VA = "0x640248")]
	private void Start()
	{
	}

	[Token(Token = "0x6000767")]
	[Address(RVA = "0x6402C4", Offset = "0x6402C4", VA = "0x6402C4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000768")]
	[Address(RVA = "0x640654", Offset = "0x640654", VA = "0x640654")]
	private void Update()
	{
	}

	[Token(Token = "0x6000769")]
	[Address(RVA = "0x640658", Offset = "0x640658", VA = "0x640658")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600076A")]
	[Address(RVA = "0x640708", Offset = "0x640708", VA = "0x640708")]
	public CameraFilterPack_Vision_SniperScore()
	{
	}
}
