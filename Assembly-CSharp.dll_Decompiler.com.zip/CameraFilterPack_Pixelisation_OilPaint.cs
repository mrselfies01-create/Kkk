using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F8")]
public class CameraFilterPack_Pixelisation_OilPaint : MonoBehaviour
{
	[Token(Token = "0x4000732")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000733")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000734")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000735")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000F9")]
	private Material material
	{
		[Token(Token = "0x6000626")]
		[Address(RVA = "0x631220", Offset = "0x631220", VA = "0x631220")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000627")]
	[Address(RVA = "0x6312E4", Offset = "0x6312E4", VA = "0x6312E4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000628")]
	[Address(RVA = "0x631360", Offset = "0x631360", VA = "0x631360")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000629")]
	[Address(RVA = "0x631578", Offset = "0x631578", VA = "0x631578")]
	private void Update()
	{
	}

	[Token(Token = "0x600062A")]
	[Address(RVA = "0x63157C", Offset = "0x63157C", VA = "0x63157C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600062B")]
	[Address(RVA = "0x63162C", Offset = "0x63162C", VA = "0x63162C")]
	public CameraFilterPack_Pixelisation_OilPaint()
	{
	}
}
