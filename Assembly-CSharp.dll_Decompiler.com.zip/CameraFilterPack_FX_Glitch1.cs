using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B1")]
public class CameraFilterPack_FX_Glitch1 : MonoBehaviour
{
	[Token(Token = "0x400052D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400052E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400052F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000530")]
	[FieldOffset(Offset = "0x30")]
	public float Glitch;

	[Token(Token = "0x170000B2")]
	private Material material
	{
		[Token(Token = "0x600045A")]
		[Address(RVA = "0x699A78", Offset = "0x699A78", VA = "0x699A78")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600045B")]
	[Address(RVA = "0x699B3C", Offset = "0x699B3C", VA = "0x699B3C")]
	private void Start()
	{
	}

	[Token(Token = "0x600045C")]
	[Address(RVA = "0x699BB8", Offset = "0x699BB8", VA = "0x699BB8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600045D")]
	[Address(RVA = "0x699DD0", Offset = "0x699DD0", VA = "0x699DD0")]
	private void Update()
	{
	}

	[Token(Token = "0x600045E")]
	[Address(RVA = "0x699DD4", Offset = "0x699DD4", VA = "0x699DD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600045F")]
	[Address(RVA = "0x699E84", Offset = "0x699E84", VA = "0x699E84")]
	public CameraFilterPack_FX_Glitch1()
	{
	}
}
