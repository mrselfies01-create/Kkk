using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000071")]
public class CameraFilterPack_Distortion_Aspiration : MonoBehaviour
{
	[Token(Token = "0x40003A0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003A1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003A2")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003A3")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x40003A4")]
	[FieldOffset(Offset = "0x34")]
	public float PosX;

	[Token(Token = "0x40003A5")]
	[FieldOffset(Offset = "0x38")]
	public float PosY;

	[Token(Token = "0x40003A6")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000072")]
	private Material material
	{
		[Token(Token = "0x60002D9")]
		[Address(RVA = "0x671F3C", Offset = "0x671F3C", VA = "0x671F3C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002DA")]
	[Address(RVA = "0x672000", Offset = "0x672000", VA = "0x672000")]
	private void Start()
	{
	}

	[Token(Token = "0x60002DB")]
	[Address(RVA = "0x67207C", Offset = "0x67207C", VA = "0x67207C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002DC")]
	[Address(RVA = "0x672308", Offset = "0x672308", VA = "0x672308")]
	private void Update()
	{
	}

	[Token(Token = "0x60002DD")]
	[Address(RVA = "0x67230C", Offset = "0x67230C", VA = "0x67230C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002DE")]
	[Address(RVA = "0x6723BC", Offset = "0x6723BC", VA = "0x6723BC")]
	public CameraFilterPack_Distortion_Aspiration()
	{
	}
}
