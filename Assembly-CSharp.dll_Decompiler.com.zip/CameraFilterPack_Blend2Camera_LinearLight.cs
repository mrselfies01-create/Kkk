using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000037")]
public class CameraFilterPack_Blend2Camera_LinearLight : MonoBehaviour
{
	[Token(Token = "0x4000215")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000216")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000217")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000218")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000219")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400021A")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400021B")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400021C")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000038")]
	private Material material
	{
		[Token(Token = "0x6000160")]
		[Address(RVA = "0x5C5D98", Offset = "0x5C5D98", VA = "0x5C5D98")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000161")]
	[Address(RVA = "0x5C5E5C", Offset = "0x5C5E5C", VA = "0x5C5E5C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000162")]
	[Address(RVA = "0x5C5F74", Offset = "0x5C5F74", VA = "0x5C5F74")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000163")]
	[Address(RVA = "0x5C6204", Offset = "0x5C6204", VA = "0x5C6204")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000164")]
	[Address(RVA = "0x5C62F0", Offset = "0x5C62F0", VA = "0x5C62F0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000165")]
	[Address(RVA = "0x5C62F4", Offset = "0x5C62F4", VA = "0x5C62F4")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000166")]
	[Address(RVA = "0x5C63E0", Offset = "0x5C63E0", VA = "0x5C63E0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000167")]
	[Address(RVA = "0x5C64D8", Offset = "0x5C64D8", VA = "0x5C64D8")]
	public CameraFilterPack_Blend2Camera_LinearLight()
	{
	}
}
