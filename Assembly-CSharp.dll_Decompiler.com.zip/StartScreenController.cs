using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000141")]
public class StartScreenController : MonoBehaviour
{
	[Token(Token = "0x20001FD")]
	private sealed class _003CdelayStartITC_003Ed__22 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D9A")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D9B")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D9C")]
		[FieldOffset(Offset = "0x20")]
		public float seconds;

		[Token(Token = "0x4000D9D")]
		[FieldOffset(Offset = "0x28")]
		public StartScreenController _003C_003E4__this;

		[Token(Token = "0x1700024A")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D5C")]
			[Address(RVA = "0x78F840", Offset = "0x78F840", VA = "0x78F840", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x1700024B")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D5E")]
			[Address(RVA = "0x78F8A8", Offset = "0x78F8A8", VA = "0x78F8A8", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D59")]
		[Address(RVA = "0x78F75C", Offset = "0x78F75C", VA = "0x78F75C")]
		public _003CdelayStartITC_003Ed__22(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D5A")]
		[Address(RVA = "0x78F788", Offset = "0x78F788", VA = "0x78F788", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D5B")]
		[Address(RVA = "0x78F78C", Offset = "0x78F78C", VA = "0x78F78C", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D5D")]
		[Address(RVA = "0x78F848", Offset = "0x78F848", VA = "0x78F848", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x4000985")]
	[FieldOffset(Offset = "0x18")]
	public float loadTimeCriticalPoint;

	[Token(Token = "0x4000986")]
	[FieldOffset(Offset = "0x1C")]
	public float curLoadTime;

	[Token(Token = "0x4000987")]
	[FieldOffset(Offset = "0x20")]
	public bool loading;

	[Token(Token = "0x4000988")]
	[FieldOffset(Offset = "0x28")]
	public Slider[] loadingSliders;

	[Token(Token = "0x4000989")]
	[FieldOffset(Offset = "0x30")]
	public AudioSource audio;

	[Token(Token = "0x400098A")]
	[FieldOffset(Offset = "0x38")]
	public bool touching;

	[Token(Token = "0x400098B")]
	[FieldOffset(Offset = "0x39")]
	public bool lastTouching;

	[Token(Token = "0x400098C")]
	[FieldOffset(Offset = "0x3C")]
	public float startFov;

	[Token(Token = "0x400098D")]
	[FieldOffset(Offset = "0x40")]
	public float endFov;

	[Token(Token = "0x400098E")]
	[FieldOffset(Offset = "0x48")]
	public Camera cam;

	[Token(Token = "0x400098F")]
	[FieldOffset(Offset = "0x50")]
	public RhythmVisualizatorPro visPro;

	[Token(Token = "0x4000990")]
	[FieldOffset(Offset = "0x58")]
	public Image panelBackground;

	[Token(Token = "0x4000991")]
	[FieldOffset(Offset = "0x60")]
	public GameObject[] hideOnVisualITC;

	[Token(Token = "0x4000992")]
	[FieldOffset(Offset = "0x68")]
	public GameObject[] showOnVisualITC;

	[Token(Token = "0x4000993")]
	[FieldOffset(Offset = "0x70")]
	public GameObject[] hideOnScreenSaver;

	[Token(Token = "0x4000994")]
	[FieldOffset(Offset = "0x78")]
	public GameObject[] showOnScreenSaver;

	[Token(Token = "0x4000995")]
	[FieldOffset(Offset = "0x80")]
	private bool inItc;

	[Token(Token = "0x4000996")]
	[FieldOffset(Offset = "0x81")]
	private bool inScreenSaver;

	[Token(Token = "0x4000997")]
	[FieldOffset(Offset = "0x84")]
	private Color backupCamColor;

	[Token(Token = "0x17000132")]
	public float FadeValue
	{
		[Token(Token = "0x60007E0")]
		[Address(RVA = "0x3DDE8C", Offset = "0x3DDE8C", VA = "0x3DDE8C")]
		set
		{
		}
	}

	[Token(Token = "0x60007E1")]
	[Address(RVA = "0x3DDF58", Offset = "0x3DDF58", VA = "0x3DDF58")]
	public void ToggleScreenSaver()
	{
	}

	[Token(Token = "0x60007E2")]
	[Address(RVA = "0x3DE094", Offset = "0x3DE094", VA = "0x3DE094")]
	public void StartScreenSaver()
	{
	}

	[Token(Token = "0x60007E3")]
	[Address(RVA = "0x3DE198", Offset = "0x3DE198", VA = "0x3DE198")]
	public IEnumerator delayStartITC(float seconds)
	{
		return null;
	}

	[Token(Token = "0x60007E4")]
	[Address(RVA = "0x3DE218", Offset = "0x3DE218", VA = "0x3DE218")]
	public void OnStartVisualITC()
	{
	}

	[Token(Token = "0x60007E5")]
	[Address(RVA = "0x3DE24C", Offset = "0x3DE24C", VA = "0x3DE24C")]
	public void StartVisualITC()
	{
	}

	[Token(Token = "0x60007E6")]
	[Address(RVA = "0x3DDF68", Offset = "0x3DDF68", VA = "0x3DDF68")]
	public void StopScreenSaver()
	{
	}

	[Token(Token = "0x60007E7")]
	[Address(RVA = "0x3DE320", Offset = "0x3DE320", VA = "0x3DE320")]
	public void StopVisualITC()
	{
	}

	[Token(Token = "0x60007E8")]
	[Address(RVA = "0x3DE3F0", Offset = "0x3DE3F0", VA = "0x3DE3F0")]
	private void Start()
	{
	}

	[Token(Token = "0x60007E9")]
	[Address(RVA = "0x3DE3F4", Offset = "0x3DE3F4", VA = "0x3DE3F4")]
	private void Update()
	{
	}

	[Token(Token = "0x60007EA")]
	[Address(RVA = "0x3DE4FC", Offset = "0x3DE4FC", VA = "0x3DE4FC")]
	public StartScreenController()
	{
	}
}
