using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001E")]
public class CameraFilterPack_Antialiasing_FXAA : MonoBehaviour
{
	[Token(Token = "0x400012C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400012D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400012E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700001F")]
	private Material material
	{
		[Token(Token = "0x60000A6")]
		[Address(RVA = "0x5BAEE4", Offset = "0x5BAEE4", VA = "0x5BAEE4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000A7")]
	[Address(RVA = "0x5BAFA8", Offset = "0x5BAFA8", VA = "0x5BAFA8")]
	private void Start()
	{
	}

	[Token(Token = "0x60000A8")]
	[Address(RVA = "0x5BB024", Offset = "0x5BB024", VA = "0x5BB024")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000A9")]
	[Address(RVA = "0x5BB208", Offset = "0x5BB208", VA = "0x5BB208")]
	private void Update()
	{
	}

	[Token(Token = "0x60000AA")]
	[Address(RVA = "0x5BB20C", Offset = "0x5BB20C", VA = "0x5BB20C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000AB")]
	[Address(RVA = "0x5BB2BC", Offset = "0x5BB2BC", VA = "0x5BB2BC")]
	public CameraFilterPack_Antialiasing_FXAA()
	{
	}
}
