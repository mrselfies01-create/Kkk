using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002C")]
public class CameraFilterPack_Blend2Camera_Difference : MonoBehaviour
{
	[Token(Token = "0x40001B7")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001B8")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001B9")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001BA")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001BB")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001BC")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001BD")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001BE")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700002D")]
	private Material material
	{
		[Token(Token = "0x6000109")]
		[Address(RVA = "0x5C0A84", Offset = "0x5C0A84", VA = "0x5C0A84")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600010A")]
	[Address(RVA = "0x5C0B48", Offset = "0x5C0B48", VA = "0x5C0B48")]
	private void Start()
	{
	}

	[Token(Token = "0x600010B")]
	[Address(RVA = "0x5C0C60", Offset = "0x5C0C60", VA = "0x5C0C60")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600010C")]
	[Address(RVA = "0x5C0EF0", Offset = "0x5C0EF0", VA = "0x5C0EF0")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600010D")]
	[Address(RVA = "0x5C0FDC", Offset = "0x5C0FDC", VA = "0x5C0FDC")]
	private void Update()
	{
	}

	[Token(Token = "0x600010E")]
	[Address(RVA = "0x5C0FE0", Offset = "0x5C0FE0", VA = "0x5C0FE0")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600010F")]
	[Address(RVA = "0x5C10CC", Offset = "0x5C10CC", VA = "0x5C10CC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000110")]
	[Address(RVA = "0x5C11C4", Offset = "0x5C11C4", VA = "0x5C11C4")]
	public CameraFilterPack_Blend2Camera_Difference()
	{
	}
}
