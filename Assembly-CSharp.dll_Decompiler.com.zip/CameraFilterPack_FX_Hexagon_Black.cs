using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B6")]
public class CameraFilterPack_FX_Hexagon_Black : MonoBehaviour
{
	[Token(Token = "0x4000542")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000543")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000544")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000545")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000B7")]
	private Material material
	{
		[Token(Token = "0x6000478")]
		[Address(RVA = "0x69AE84", Offset = "0x69AE84", VA = "0x69AE84")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000479")]
	[Address(RVA = "0x69AF48", Offset = "0x69AF48", VA = "0x69AF48")]
	private void Start()
	{
	}

	[Token(Token = "0x600047A")]
	[Address(RVA = "0x69AFC4", Offset = "0x69AFC4", VA = "0x69AFC4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600047B")]
	[Address(RVA = "0x69B1DC", Offset = "0x69B1DC", VA = "0x69B1DC")]
	private void Update()
	{
	}

	[Token(Token = "0x600047C")]
	[Address(RVA = "0x69B1E0", Offset = "0x69B1E0", VA = "0x69B1E0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600047D")]
	[Address(RVA = "0x69B290", Offset = "0x69B290", VA = "0x69B290")]
	public CameraFilterPack_FX_Hexagon_Black()
	{
	}
}
