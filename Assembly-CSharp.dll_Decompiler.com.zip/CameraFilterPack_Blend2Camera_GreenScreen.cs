using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002F")]
public class CameraFilterPack_Blend2Camera_GreenScreen : MonoBehaviour
{
	[Token(Token = "0x40001CF")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001D0")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001D1")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001D2")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001D3")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001D4")]
	[FieldOffset(Offset = "0x40")]
	public float BlendFX;

	[Token(Token = "0x40001D5")]
	[FieldOffset(Offset = "0x44")]
	public float Adjust;

	[Token(Token = "0x40001D6")]
	[FieldOffset(Offset = "0x48")]
	public float Precision;

	[Token(Token = "0x40001D7")]
	[FieldOffset(Offset = "0x4C")]
	public float Luminosity;

	[Token(Token = "0x40001D8")]
	[FieldOffset(Offset = "0x50")]
	public float Change_Red;

	[Token(Token = "0x40001D9")]
	[FieldOffset(Offset = "0x54")]
	public float Change_Green;

	[Token(Token = "0x40001DA")]
	[FieldOffset(Offset = "0x58")]
	public float Change_Blue;

	[Token(Token = "0x40001DB")]
	[FieldOffset(Offset = "0x60")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x40001DC")]
	[FieldOffset(Offset = "0x68")]
	private Vector2 ScreenSize;

	[Token(Token = "0x17000030")]
	private Material material
	{
		[Token(Token = "0x6000121")]
		[Address(RVA = "0x5C217C", Offset = "0x5C217C", VA = "0x5C217C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000122")]
	[Address(RVA = "0x5C2240", Offset = "0x5C2240", VA = "0x5C2240")]
	private void Start()
	{
	}

	[Token(Token = "0x6000123")]
	[Address(RVA = "0x5C2340", Offset = "0x5C2340", VA = "0x5C2340")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000124")]
	[Address(RVA = "0x5C25FC", Offset = "0x5C25FC", VA = "0x5C25FC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000125")]
	[Address(RVA = "0x5C263C", Offset = "0x5C263C", VA = "0x5C263C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000126")]
	[Address(RVA = "0x5C2660", Offset = "0x5C2660", VA = "0x5C2660")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000127")]
	[Address(RVA = "0x5C279C", Offset = "0x5C279C", VA = "0x5C279C")]
	public CameraFilterPack_Blend2Camera_GreenScreen()
	{
	}
}
