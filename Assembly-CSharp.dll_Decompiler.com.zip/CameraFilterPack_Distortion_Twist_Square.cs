using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000081")]
public class CameraFilterPack_Distortion_Twist_Square : MonoBehaviour
{
	[Token(Token = "0x40003FA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003FB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003FC")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003FD")]
	[FieldOffset(Offset = "0x30")]
	public float CenterX;

	[Token(Token = "0x40003FE")]
	[FieldOffset(Offset = "0x34")]
	public float CenterY;

	[Token(Token = "0x40003FF")]
	[FieldOffset(Offset = "0x38")]
	public float Distortion;

	[Token(Token = "0x4000400")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x17000082")]
	private Material material
	{
		[Token(Token = "0x6000339")]
		[Address(RVA = "0x676428", Offset = "0x676428", VA = "0x676428")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600033A")]
	[Address(RVA = "0x6764EC", Offset = "0x6764EC", VA = "0x6764EC")]
	private void Start()
	{
	}

	[Token(Token = "0x600033B")]
	[Address(RVA = "0x676568", Offset = "0x676568", VA = "0x676568")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600033C")]
	[Address(RVA = "0x6767DC", Offset = "0x6767DC", VA = "0x6767DC")]
	private void Update()
	{
	}

	[Token(Token = "0x600033D")]
	[Address(RVA = "0x6767E0", Offset = "0x6767E0", VA = "0x6767E0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600033E")]
	[Address(RVA = "0x676890", Offset = "0x676890", VA = "0x676890")]
	public CameraFilterPack_Distortion_Twist_Square()
	{
	}
}
