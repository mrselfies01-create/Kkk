using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CB")]
public class CameraFilterPack_Glow_Glow : MonoBehaviour
{
	[Token(Token = "0x40005E4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005E5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005E6")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40005E7")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40005E8")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x40005E9")]
	[FieldOffset(Offset = "0x38")]
	public float Threshold;

	[Token(Token = "0x40005EA")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x40005EB")]
	[FieldOffset(Offset = "0x40")]
	public float Precision;

	[Token(Token = "0x170000CC")]
	private Material material
	{
		[Token(Token = "0x60004F6")]
		[Address(RVA = "0x6A13FC", Offset = "0x6A13FC", VA = "0x6A13FC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004F7")]
	[Address(RVA = "0x6A14C0", Offset = "0x6A14C0", VA = "0x6A14C0")]
	private void Start()
	{
	}

	[Token(Token = "0x60004F8")]
	[Address(RVA = "0x6A153C", Offset = "0x6A153C", VA = "0x6A153C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004F9")]
	[Address(RVA = "0x6A198C", Offset = "0x6A198C", VA = "0x6A198C")]
	private void Update()
	{
	}

	[Token(Token = "0x60004FA")]
	[Address(RVA = "0x6A1990", Offset = "0x6A1990", VA = "0x6A1990")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004FB")]
	[Address(RVA = "0x6A1A40", Offset = "0x6A1A40", VA = "0x6A1A40")]
	public CameraFilterPack_Glow_Glow()
	{
	}
}
