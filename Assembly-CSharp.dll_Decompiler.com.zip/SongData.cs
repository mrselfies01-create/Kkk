using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000139")]
public class SongData : MonoBehaviour
{
	[Token(Token = "0x40008E4")]
	[FieldOffset(Offset = "0x18")]
	public string title;

	[Token(Token = "0x40008E5")]
	[FieldOffset(Offset = "0x20")]
	public string artist;

	[Token(Token = "0x40008E6")]
	[FieldOffset(Offset = "0x28")]
	public AudioClip songClip;

	[Token(Token = "0x60007AA")]
	[Address(RVA = "0x3DD18C", Offset = "0x3DD18C", VA = "0x3DD18C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60007AB")]
	[Address(RVA = "0x3DD1F0", Offset = "0x3DD1F0", VA = "0x3DD1F0")]
	public SongData()
	{
	}
}
