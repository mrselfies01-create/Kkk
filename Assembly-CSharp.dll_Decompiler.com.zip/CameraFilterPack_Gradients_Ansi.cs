using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CD")]
public class CameraFilterPack_Gradients_Ansi : MonoBehaviour
{
	[Token(Token = "0x40005F5")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005F6")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x40005F7")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x40005F8")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40005F9")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x40005FA")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000CE")]
	private Material material
	{
		[Token(Token = "0x6000502")]
		[Address(RVA = "0x6A2168", Offset = "0x6A2168", VA = "0x6A2168")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000503")]
	[Address(RVA = "0x6A222C", Offset = "0x6A222C", VA = "0x6A222C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000504")]
	[Address(RVA = "0x6A227C", Offset = "0x6A227C", VA = "0x6A227C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000505")]
	[Address(RVA = "0x6A24B8", Offset = "0x6A24B8", VA = "0x6A24B8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000506")]
	[Address(RVA = "0x6A24BC", Offset = "0x6A24BC", VA = "0x6A24BC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000507")]
	[Address(RVA = "0x6A256C", Offset = "0x6A256C", VA = "0x6A256C")]
	public CameraFilterPack_Gradients_Ansi()
	{
	}
}
