using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000167")]
public sealed class MinAttribute : PropertyAttribute
{
	[Token(Token = "0x4000A59")]
	[FieldOffset(Offset = "0x10")]
	public readonly float min;

	[Token(Token = "0x60008E4")]
	[Address(RVA = "0x38E8D4", Offset = "0x38E8D4", VA = "0x38E8D4")]
	public MinAttribute(float min)
	{
	}
}
