using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200018C")]
public abstract class PostProcessingComponentCommandBuffer<T> : PostProcessingComponent<T> where T : PostProcessingModel
{
	[Token(Token = "0x60009C0")]
	public abstract CameraEvent GetCameraEvent();

	[Token(Token = "0x60009C1")]
	public abstract string GetName();

	[Token(Token = "0x60009C2")]
	public abstract void PopulateCommandBuffer(CommandBuffer cb);

	[Token(Token = "0x60009C3")]
	protected PostProcessingComponentCommandBuffer()
	{
	}
}
