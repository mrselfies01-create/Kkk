using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000170")]
public sealed class DitheringComponent : PostProcessingComponentRenderTexture<DitheringModel>
{
	[Token(Token = "0x2000209")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DEE")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _DitheringTex;

		[Token(Token = "0x4000DEF")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _DitheringCoords;
	}

	[Token(Token = "0x4000A6C")]
	[FieldOffset(Offset = "0x20")]
	private Texture2D[] noiseTextures;

	[Token(Token = "0x4000A6D")]
	[FieldOffset(Offset = "0x28")]
	private int textureIndex;

	[Token(Token = "0x4000A6E")]
	private const int k_TextureCount = 64;

	[Token(Token = "0x17000177")]
	public override bool active
	{
		[Token(Token = "0x6000921")]
		[Address(RVA = "0x387B2C", Offset = "0x387B2C", VA = "0x387B2C", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000922")]
	[Address(RVA = "0x387B9C", Offset = "0x387B9C", VA = "0x387B9C", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000923")]
	[Address(RVA = "0x387BA4", Offset = "0x387BA4", VA = "0x387BA4")]
	private void LoadNoiseTextures()
	{
	}

	[Token(Token = "0x6000924")]
	[Address(RVA = "0x387CF8", Offset = "0x387CF8", VA = "0x387CF8", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x6000925")]
	[Address(RVA = "0x387ED4", Offset = "0x387ED4", VA = "0x387ED4")]
	public DitheringComponent()
	{
	}
}
