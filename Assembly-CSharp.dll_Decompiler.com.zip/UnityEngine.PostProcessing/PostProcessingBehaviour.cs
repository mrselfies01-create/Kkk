using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000189")]
public class PostProcessingBehaviour : MonoBehaviour
{
	[Token(Token = "0x4000A9C")]
	[FieldOffset(Offset = "0x18")]
	public PostProcessingProfile profile;

	[Token(Token = "0x4000A9D")]
	[FieldOffset(Offset = "0x20")]
	public Func<Vector2, Matrix4x4> jitteredMatrixFunc;

	[Token(Token = "0x4000A9E")]
	[FieldOffset(Offset = "0x28")]
	private Dictionary<Type, KeyValuePair<CameraEvent, CommandBuffer>> m_CommandBuffers;

	[Token(Token = "0x4000A9F")]
	[FieldOffset(Offset = "0x30")]
	private List<PostProcessingComponentBase> m_Components;

	[Token(Token = "0x4000AA0")]
	[FieldOffset(Offset = "0x38")]
	private Dictionary<PostProcessingComponentBase, bool> m_ComponentStates;

	[Token(Token = "0x4000AA1")]
	[FieldOffset(Offset = "0x40")]
	private MaterialFactory m_MaterialFactory;

	[Token(Token = "0x4000AA2")]
	[FieldOffset(Offset = "0x48")]
	private RenderTextureFactory m_RenderTextureFactory;

	[Token(Token = "0x4000AA3")]
	[FieldOffset(Offset = "0x50")]
	private PostProcessingContext m_Context;

	[Token(Token = "0x4000AA4")]
	[FieldOffset(Offset = "0x58")]
	private Camera m_Camera;

	[Token(Token = "0x4000AA5")]
	[FieldOffset(Offset = "0x60")]
	private PostProcessingProfile m_PreviousProfile;

	[Token(Token = "0x4000AA6")]
	[FieldOffset(Offset = "0x68")]
	private bool m_RenderingInSceneView;

	[Token(Token = "0x4000AA7")]
	[FieldOffset(Offset = "0x70")]
	private BuiltinDebugViewsComponent m_DebugViews;

	[Token(Token = "0x4000AA8")]
	[FieldOffset(Offset = "0x78")]
	private AmbientOcclusionComponent m_AmbientOcclusion;

	[Token(Token = "0x4000AA9")]
	[FieldOffset(Offset = "0x80")]
	private ScreenSpaceReflectionComponent m_ScreenSpaceReflection;

	[Token(Token = "0x4000AAA")]
	[FieldOffset(Offset = "0x88")]
	private FogComponent m_FogComponent;

	[Token(Token = "0x4000AAB")]
	[FieldOffset(Offset = "0x90")]
	private MotionBlurComponent m_MotionBlur;

	[Token(Token = "0x4000AAC")]
	[FieldOffset(Offset = "0x98")]
	private TaaComponent m_Taa;

	[Token(Token = "0x4000AAD")]
	[FieldOffset(Offset = "0xA0")]
	private EyeAdaptationComponent m_EyeAdaptation;

	[Token(Token = "0x4000AAE")]
	[FieldOffset(Offset = "0xA8")]
	private DepthOfFieldComponent m_DepthOfField;

	[Token(Token = "0x4000AAF")]
	[FieldOffset(Offset = "0xB0")]
	private BloomComponent m_Bloom;

	[Token(Token = "0x4000AB0")]
	[FieldOffset(Offset = "0xB8")]
	private ChromaticAberrationComponent m_ChromaticAberration;

	[Token(Token = "0x4000AB1")]
	[FieldOffset(Offset = "0xC0")]
	private ColorGradingComponent m_ColorGrading;

	[Token(Token = "0x4000AB2")]
	[FieldOffset(Offset = "0xC8")]
	private UserLutComponent m_UserLut;

	[Token(Token = "0x4000AB3")]
	[FieldOffset(Offset = "0xD0")]
	private GrainComponent m_Grain;

	[Token(Token = "0x4000AB4")]
	[FieldOffset(Offset = "0xD8")]
	private VignetteComponent m_Vignette;

	[Token(Token = "0x4000AB5")]
	[FieldOffset(Offset = "0xE0")]
	private DitheringComponent m_Dithering;

	[Token(Token = "0x4000AB6")]
	[FieldOffset(Offset = "0xE8")]
	private FxaaComponent m_Fxaa;

	[Token(Token = "0x4000AB7")]
	[FieldOffset(Offset = "0xF0")]
	private List<PostProcessingComponentBase> m_ComponentsToEnable;

	[Token(Token = "0x4000AB8")]
	[FieldOffset(Offset = "0xF8")]
	private List<PostProcessingComponentBase> m_ComponentsToDisable;

	[Token(Token = "0x60009A4")]
	[Address(RVA = "0x39547C", Offset = "0x39547C", VA = "0x39547C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60009A5")]
	[Address(RVA = "0x395A48", Offset = "0x395A48", VA = "0x395A48")]
	private void OnPreCull()
	{
	}

	[Token(Token = "0x60009A6")]
	[Address(RVA = "0x396320", Offset = "0x396320", VA = "0x396320")]
	private void OnPreRender()
	{
	}

	[Token(Token = "0x60009A7")]
	[Address(RVA = "0x396420", Offset = "0x396420", VA = "0x396420")]
	private void OnPostRender()
	{
	}

	[Token(Token = "0x60009A8")]
	[Address(RVA = "0x396534", Offset = "0x396534", VA = "0x396534")]
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
	}

	[Token(Token = "0x60009A9")]
	[Address(RVA = "0x396C18", Offset = "0x396C18", VA = "0x396C18")]
	private void OnGUI()
	{
	}

	[Token(Token = "0x60009AA")]
	[Address(RVA = "0x396DDC", Offset = "0x396DDC", VA = "0x396DDC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60009AB")]
	[Address(RVA = "0x396FB0", Offset = "0x396FB0", VA = "0x396FB0")]
	public void ResetTemporalEffects()
	{
	}

	[Token(Token = "0x60009AC")]
	[Address(RVA = "0x396070", Offset = "0x396070", VA = "0x396070")]
	private void CheckObservers()
	{
	}

	[Token(Token = "0x60009AD")]
	[Address(RVA = "0x395F50", Offset = "0x395F50", VA = "0x395F50")]
	private void DisableComponents()
	{
	}

	[Token(Token = "0x60009AE")]
	private CommandBuffer AddCommandBuffer<T>(CameraEvent evt, string name) where T : PostProcessingModel
	{
		return null;
	}

	[Token(Token = "0x60009AF")]
	private void RemoveCommandBuffer<T>() where T : PostProcessingModel
	{
	}

	[Token(Token = "0x60009B0")]
	private CommandBuffer GetCommandBuffer<T>(CameraEvent evt, string name) where T : PostProcessingModel
	{
		return null;
	}

	[Token(Token = "0x60009B1")]
	private void TryExecuteCommandBuffer<T>(PostProcessingComponentCommandBuffer<T> component) where T : PostProcessingModel
	{
	}

	[Token(Token = "0x60009B2")]
	private bool TryPrepareUberImageEffect<T>(PostProcessingComponentRenderTexture<T> component, Material material) where T : PostProcessingModel
	{
		return default(bool);
	}

	[Token(Token = "0x60009B3")]
	private T AddComponent<T>(T component) where T : PostProcessingComponentBase
	{
		return null;
	}

	[Token(Token = "0x60009B4")]
	[Address(RVA = "0x39700C", Offset = "0x39700C", VA = "0x39700C")]
	public PostProcessingBehaviour()
	{
	}
}
