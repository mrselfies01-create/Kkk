using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000179")]
public sealed class VignetteComponent : PostProcessingComponentRenderTexture<VignetteModel>
{
	[Token(Token = "0x2000216")]
	private static class Uniforms
	{
		[Token(Token = "0x4000E5F")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _Vignette_Color;

		[Token(Token = "0x4000E60")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Vignette_Center;

		[Token(Token = "0x4000E61")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _Vignette_Settings;

		[Token(Token = "0x4000E62")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _Vignette_Mask;

		[Token(Token = "0x4000E63")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _Vignette_Opacity;
	}

	[Token(Token = "0x17000183")]
	public override bool active
	{
		[Token(Token = "0x600095E")]
		[Address(RVA = "0x478554", Offset = "0x478554", VA = "0x478554", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x600095F")]
	[Address(RVA = "0x4785C4", Offset = "0x4785C4", VA = "0x4785C4", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x6000960")]
	[Address(RVA = "0x478890", Offset = "0x478890", VA = "0x478890")]
	public VignetteComponent()
	{
	}
}
