using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017C")]
public class BloomModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000220")]
	public struct BloomSettings
	{
		[Token(Token = "0x4000E8A")]
		[FieldOffset(Offset = "0x0")]
		public float intensity;

		[Token(Token = "0x4000E8B")]
		[FieldOffset(Offset = "0x4")]
		public float threshold;

		[Token(Token = "0x4000E8C")]
		[FieldOffset(Offset = "0x8")]
		public float softKnee;

		[Token(Token = "0x4000E8D")]
		[FieldOffset(Offset = "0xC")]
		public float radius;

		[Token(Token = "0x4000E8E")]
		[FieldOffset(Offset = "0x10")]
		public bool antiFlicker;

		[Token(Token = "0x17000255")]
		public float thresholdLinear
		{
			[Token(Token = "0x6000D90")]
			[Address(RVA = "0x29E530", Offset = "0x29E530", VA = "0x29E530")]
			get
			{
				return default(float);
			}
			[Token(Token = "0x6000D8F")]
			[Address(RVA = "0x29E528", Offset = "0x29E528", VA = "0x29E528")]
			set
			{
			}
		}

		[Token(Token = "0x17000256")]
		public static BloomSettings defaultSettings
		{
			[Token(Token = "0x6000D91")]
			[Address(RVA = "0x47B710", Offset = "0x47B710", VA = "0x47B710")]
			get
			{
				return default(BloomSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x2000221")]
	public struct LensDirtSettings
	{
		[Token(Token = "0x4000E8F")]
		[FieldOffset(Offset = "0x0")]
		public Texture texture;

		[Token(Token = "0x4000E90")]
		[FieldOffset(Offset = "0x8")]
		public float intensity;

		[Token(Token = "0x17000257")]
		public static LensDirtSettings defaultSettings
		{
			[Token(Token = "0x6000D92")]
			[Address(RVA = "0x47B72C", Offset = "0x47B72C", VA = "0x47B72C")]
			get
			{
				return default(LensDirtSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x2000222")]
	public struct Settings
	{
		[Token(Token = "0x4000E91")]
		[FieldOffset(Offset = "0x0")]
		public BloomSettings bloom;

		[Token(Token = "0x4000E92")]
		[FieldOffset(Offset = "0x18")]
		public LensDirtSettings lensDirt;

		[Token(Token = "0x17000258")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D93")]
			[Address(RVA = "0x47B738", Offset = "0x47B738", VA = "0x47B738")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A8D")]
	[FieldOffset(Offset = "0x18")]
	private Settings m_Settings;

	[Token(Token = "0x17000186")]
	public Settings settings
	{
		[Token(Token = "0x6000969")]
		[Address(RVA = "0x5B19B4", Offset = "0x5B19B4", VA = "0x5B19B4")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x600096A")]
		[Address(RVA = "0x5B19CC", Offset = "0x5B19CC", VA = "0x5B19CC")]
		set
		{
		}
	}

	[Token(Token = "0x600096B")]
	[Address(RVA = "0x5B19E4", Offset = "0x5B19E4", VA = "0x5B19E4", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600096C")]
	[Address(RVA = "0x5B1A2C", Offset = "0x5B1A2C", VA = "0x5B1A2C")]
	public BloomModel()
	{
	}
}
