using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000191")]
public sealed class ColorGradingCurve
{
	[Token(Token = "0x4000AD0")]
	[FieldOffset(Offset = "0x10")]
	public AnimationCurve curve;

	[Token(Token = "0x4000AD1")]
	[FieldOffset(Offset = "0x18")]
	private bool m_Loop;

	[Token(Token = "0x4000AD2")]
	[FieldOffset(Offset = "0x1C")]
	private float m_ZeroValue;

	[Token(Token = "0x4000AD3")]
	[FieldOffset(Offset = "0x20")]
	private float m_Range;

	[Token(Token = "0x4000AD4")]
	[FieldOffset(Offset = "0x28")]
	private AnimationCurve m_InternalLoopingCurve;

	[Token(Token = "0x60009D6")]
	[Address(RVA = "0x385270", Offset = "0x385270", VA = "0x385270")]
	public ColorGradingCurve(AnimationCurve curve, float zeroValue, bool loop, Vector2 bounds)
	{
	}

	[Token(Token = "0x60009D7")]
	[Address(RVA = "0x383FEC", Offset = "0x383FEC", VA = "0x383FEC")]
	public void Cache()
	{
	}

	[Token(Token = "0x60009D8")]
	[Address(RVA = "0x3841C8", Offset = "0x3841C8", VA = "0x3841C8")]
	public float Evaluate(float t)
	{
		return default(float);
	}
}
