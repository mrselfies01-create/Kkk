using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200018E")]
public class PostProcessingContext
{
	[Token(Token = "0x4000ABB")]
	[FieldOffset(Offset = "0x10")]
	public PostProcessingProfile profile;

	[Token(Token = "0x4000ABC")]
	[FieldOffset(Offset = "0x18")]
	public Camera camera;

	[Token(Token = "0x4000ABD")]
	[FieldOffset(Offset = "0x20")]
	public MaterialFactory materialFactory;

	[Token(Token = "0x4000ABE")]
	[FieldOffset(Offset = "0x28")]
	public RenderTextureFactory renderTextureFactory;

	[Token(Token = "0x4000ABF")]
	[FieldOffset(Offset = "0x30")]
	private bool _003Cinterrupted_003Ek__BackingField;

	[Token(Token = "0x17000198")]
	public bool interrupted
	{
		[Token(Token = "0x60009C6")]
		[Address(RVA = "0x3970B4", Offset = "0x3970B4", VA = "0x3970B4")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x60009C7")]
		[Address(RVA = "0x3970BC", Offset = "0x3970BC", VA = "0x3970BC")]
		private set
		{
		}
	}

	[Token(Token = "0x17000199")]
	public bool isGBufferAvailable
	{
		[Token(Token = "0x60009CA")]
		[Address(RVA = "0x389E58", Offset = "0x389E58", VA = "0x389E58")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x1700019A")]
	public bool isHdr
	{
		[Token(Token = "0x60009CB")]
		[Address(RVA = "0x38A370", Offset = "0x38A370", VA = "0x38A370")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x1700019B")]
	public int width
	{
		[Token(Token = "0x60009CC")]
		[Address(RVA = "0x38723C", Offset = "0x38723C", VA = "0x38723C")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x1700019C")]
	public int height
	{
		[Token(Token = "0x60009CD")]
		[Address(RVA = "0x387258", Offset = "0x387258", VA = "0x387258")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x1700019D")]
	public Rect viewport
	{
		[Token(Token = "0x60009CE")]
		[Address(RVA = "0x385180", Offset = "0x385180", VA = "0x385180")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Rect);
		}
	}

	[Token(Token = "0x60009C8")]
	[Address(RVA = "0x387494", Offset = "0x387494", VA = "0x387494")]
	public void Interrupt()
	{
	}

	[Token(Token = "0x60009C9")]
	[Address(RVA = "0x395F40", Offset = "0x395F40", VA = "0x395F40")]
	public PostProcessingContext Reset()
	{
		return null;
	}

	[Token(Token = "0x60009CF")]
	[Address(RVA = "0x395A40", Offset = "0x395A40", VA = "0x395A40")]
	public PostProcessingContext()
	{
	}
}
