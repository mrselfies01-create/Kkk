using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000187")]
public class UserLutModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000240")]
	public struct Settings
	{
		[Token(Token = "0x4000F13")]
		[FieldOffset(Offset = "0x0")]
		public Texture2D lut;

		[Token(Token = "0x4000F14")]
		[FieldOffset(Offset = "0x8")]
		public float contribution;

		[Token(Token = "0x1700026C")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA7")]
			[Address(RVA = "0x790504", Offset = "0x790504", VA = "0x790504")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A9A")]
	[FieldOffset(Offset = "0x18")]
	private Settings m_Settings;

	[Token(Token = "0x17000194")]
	public Settings settings
	{
		[Token(Token = "0x600099C")]
		[Address(RVA = "0x477EFC", Offset = "0x477EFC", VA = "0x477EFC")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x600099D")]
		[Address(RVA = "0x477F08", Offset = "0x477F08", VA = "0x477F08")]
		set
		{
		}
	}

	[Token(Token = "0x600099E")]
	[Address(RVA = "0x477F10", Offset = "0x477F10", VA = "0x477F10", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600099F")]
	[Address(RVA = "0x477F38", Offset = "0x477F38", VA = "0x477F38")]
	public UserLutModel()
	{
	}
}
