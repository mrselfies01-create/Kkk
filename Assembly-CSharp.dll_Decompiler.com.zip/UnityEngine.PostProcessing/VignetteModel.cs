using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000188")]
public class VignetteModel : PostProcessingModel
{
	[Token(Token = "0x2000241")]
	public enum Mode
	{
		[Token(Token = "0x4000F16")]
		Classic,
		[Token(Token = "0x4000F17")]
		Masked
	}

	[Serializable]
	[Token(Token = "0x2000242")]
	public struct Settings
	{
		[Token(Token = "0x4000F18")]
		[FieldOffset(Offset = "0x0")]
		public Mode mode;

		[Token(Token = "0x4000F19")]
		[FieldOffset(Offset = "0x4")]
		public Color color;

		[Token(Token = "0x4000F1A")]
		[FieldOffset(Offset = "0x14")]
		public Vector2 center;

		[Token(Token = "0x4000F1B")]
		[FieldOffset(Offset = "0x1C")]
		public float intensity;

		[Token(Token = "0x4000F1C")]
		[FieldOffset(Offset = "0x20")]
		public float smoothness;

		[Token(Token = "0x4000F1D")]
		[FieldOffset(Offset = "0x24")]
		public float roundness;

		[Token(Token = "0x4000F1E")]
		[FieldOffset(Offset = "0x28")]
		public Texture mask;

		[Token(Token = "0x4000F1F")]
		[FieldOffset(Offset = "0x30")]
		public float opacity;

		[Token(Token = "0x4000F20")]
		[FieldOffset(Offset = "0x34")]
		public bool rounded;

		[Token(Token = "0x1700026D")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA8")]
			[Address(RVA = "0x7906A4", Offset = "0x7906A4", VA = "0x7906A4")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A9B")]
	[FieldOffset(Offset = "0x18")]
	private Settings m_Settings;

	[Token(Token = "0x17000195")]
	public Settings settings
	{
		[Token(Token = "0x60009A0")]
		[Address(RVA = "0x4788E0", Offset = "0x4788E0", VA = "0x4788E0")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x60009A1")]
		[Address(RVA = "0x478900", Offset = "0x478900", VA = "0x478900")]
		set
		{
		}
	}

	[Token(Token = "0x60009A2")]
	[Address(RVA = "0x478920", Offset = "0x478920", VA = "0x478920", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x60009A3")]
	[Address(RVA = "0x478970", Offset = "0x478970", VA = "0x478970")]
	public VignetteModel()
	{
	}
}
