using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000168")]
public sealed class TrackballAttribute : PropertyAttribute
{
	[Token(Token = "0x4000A5A")]
	[FieldOffset(Offset = "0x10")]
	public readonly string method;

	[Token(Token = "0x60008E5")]
	[Address(RVA = "0x3E1DCC", Offset = "0x3E1DCC", VA = "0x3E1DCC")]
	public TrackballAttribute(string method)
	{
	}
}
