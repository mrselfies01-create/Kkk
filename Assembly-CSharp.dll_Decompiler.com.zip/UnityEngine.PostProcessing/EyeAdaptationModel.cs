using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000182")]
public class EyeAdaptationModel : PostProcessingModel
{
	[Token(Token = "0x2000235")]
	public enum EyeAdaptationType
	{
		[Token(Token = "0x4000EE8")]
		Progressive,
		[Token(Token = "0x4000EE9")]
		Fixed
	}

	[Serializable]
	[Token(Token = "0x2000236")]
	public struct Settings
	{
		[Token(Token = "0x4000EEA")]
		[FieldOffset(Offset = "0x0")]
		public float lowPercent;

		[Token(Token = "0x4000EEB")]
		[FieldOffset(Offset = "0x4")]
		public float highPercent;

		[Token(Token = "0x4000EEC")]
		[FieldOffset(Offset = "0x8")]
		public float minLuminance;

		[Token(Token = "0x4000EED")]
		[FieldOffset(Offset = "0xC")]
		public float maxLuminance;

		[Token(Token = "0x4000EEE")]
		[FieldOffset(Offset = "0x10")]
		public float keyValue;

		[Token(Token = "0x4000EEF")]
		[FieldOffset(Offset = "0x14")]
		public bool dynamicKeyValue;

		[Token(Token = "0x4000EF0")]
		[FieldOffset(Offset = "0x18")]
		public EyeAdaptationType adaptationType;

		[Token(Token = "0x4000EF1")]
		[FieldOffset(Offset = "0x1C")]
		public float speedUp;

		[Token(Token = "0x4000EF2")]
		[FieldOffset(Offset = "0x20")]
		public float speedDown;

		[Token(Token = "0x4000EF3")]
		[FieldOffset(Offset = "0x24")]
		public int logMin;

		[Token(Token = "0x4000EF4")]
		[FieldOffset(Offset = "0x28")]
		public int logMax;

		[Token(Token = "0x17000267")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA2")]
			[Address(RVA = "0x78C93C", Offset = "0x78C93C", VA = "0x78C93C")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A95")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x1700018F")]
	public Settings settings
	{
		[Token(Token = "0x6000988")]
		[Address(RVA = "0x38918C", Offset = "0x38918C", VA = "0x38918C")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000989")]
		[Address(RVA = "0x3891A4", Offset = "0x3891A4", VA = "0x3891A4")]
		set
		{
		}
	}

	[Token(Token = "0x600098A")]
	[Address(RVA = "0x3891C4", Offset = "0x3891C4", VA = "0x3891C4", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600098B")]
	[Address(RVA = "0x389208", Offset = "0x389208", VA = "0x389208")]
	public EyeAdaptationModel()
	{
	}
}
