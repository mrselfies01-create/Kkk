using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017A")]
public class AmbientOcclusionModel : PostProcessingModel
{
	[Token(Token = "0x2000217")]
	public enum SampleCount
	{
		[Token(Token = "0x4000E65")]
		Lowest = 3,
		[Token(Token = "0x4000E66")]
		Low = 6,
		[Token(Token = "0x4000E67")]
		Medium = 10,
		[Token(Token = "0x4000E68")]
		High = 16
	}

	[Serializable]
	[Token(Token = "0x2000218")]
	public struct Settings
	{
		[Token(Token = "0x4000E69")]
		[FieldOffset(Offset = "0x0")]
		public float intensity;

		[Token(Token = "0x4000E6A")]
		[FieldOffset(Offset = "0x4")]
		public float radius;

		[Token(Token = "0x4000E6B")]
		[FieldOffset(Offset = "0x8")]
		public SampleCount sampleCount;

		[Token(Token = "0x4000E6C")]
		[FieldOffset(Offset = "0xC")]
		public bool downsampling;

		[Token(Token = "0x4000E6D")]
		[FieldOffset(Offset = "0xD")]
		public bool forceForwardCompatibility;

		[Token(Token = "0x4000E6E")]
		[FieldOffset(Offset = "0xE")]
		public bool ambientOnly;

		[Token(Token = "0x4000E6F")]
		[FieldOffset(Offset = "0xF")]
		public bool highPrecision;

		[Token(Token = "0x17000251")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D89")]
			[Address(RVA = "0x47B25C", Offset = "0x47B25C", VA = "0x47B25C")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A8B")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000184")]
	public Settings settings
	{
		[Token(Token = "0x6000961")]
		[Address(RVA = "0x5B0354", Offset = "0x5B0354", VA = "0x5B0354")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000962")]
		[Address(RVA = "0x5B0364", Offset = "0x5B0364", VA = "0x5B0364")]
		set
		{
		}
	}

	[Token(Token = "0x6000963")]
	[Address(RVA = "0x5B0370", Offset = "0x5B0370", VA = "0x5B0370", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000964")]
	[Address(RVA = "0x5B039C", Offset = "0x5B039C", VA = "0x5B039C")]
	public AmbientOcclusionModel()
	{
	}
}
