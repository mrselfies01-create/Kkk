using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016D")]
public sealed class ChromaticAberrationComponent : PostProcessingComponentRenderTexture<ChromaticAberrationModel>
{
	[Token(Token = "0x2000206")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DCD")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _ChromaticAberration_Amount;

		[Token(Token = "0x4000DCE")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _ChromaticAberration_Spectrum;
	}

	[Token(Token = "0x4000A63")]
	[FieldOffset(Offset = "0x20")]
	private Texture2D m_SpectrumLut;

	[Token(Token = "0x17000174")]
	public override bool active
	{
		[Token(Token = "0x60008FD")]
		[Address(RVA = "0x641550", Offset = "0x641550", VA = "0x641550", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x60008FE")]
	[Address(RVA = "0x6415CC", Offset = "0x6415CC", VA = "0x6415CC", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x60008FF")]
	[Address(RVA = "0x6415F8", Offset = "0x6415F8", VA = "0x6415F8", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x6000900")]
	[Address(RVA = "0x6418B0", Offset = "0x6418B0", VA = "0x6418B0")]
	public ChromaticAberrationComponent()
	{
	}
}
