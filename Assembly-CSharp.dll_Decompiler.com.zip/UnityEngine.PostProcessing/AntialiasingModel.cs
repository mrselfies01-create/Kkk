using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017B")]
public class AntialiasingModel : PostProcessingModel
{
	[Token(Token = "0x2000219")]
	public enum Method
	{
		[Token(Token = "0x4000E71")]
		Fxaa,
		[Token(Token = "0x4000E72")]
		Taa
	}

	[Token(Token = "0x200021A")]
	public enum FxaaPreset
	{
		[Token(Token = "0x4000E74")]
		ExtremePerformance,
		[Token(Token = "0x4000E75")]
		Performance,
		[Token(Token = "0x4000E76")]
		Default,
		[Token(Token = "0x4000E77")]
		Quality,
		[Token(Token = "0x4000E78")]
		ExtremeQuality
	}

	[Serializable]
	[Token(Token = "0x200021B")]
	public struct FxaaQualitySettings
	{
		[Token(Token = "0x4000E79")]
		[FieldOffset(Offset = "0x0")]
		public float subpixelAliasingRemovalAmount;

		[Token(Token = "0x4000E7A")]
		[FieldOffset(Offset = "0x4")]
		public float edgeDetectionThreshold;

		[Token(Token = "0x4000E7B")]
		[FieldOffset(Offset = "0x8")]
		public float minimumRequiredLuminance;

		[Token(Token = "0x4000E7C")]
		[FieldOffset(Offset = "0x0")]
		public static FxaaQualitySettings[] presets;
	}

	[Serializable]
	[Token(Token = "0x200021C")]
	public struct FxaaConsoleSettings
	{
		[Token(Token = "0x4000E7D")]
		[FieldOffset(Offset = "0x0")]
		public float subpixelSpreadAmount;

		[Token(Token = "0x4000E7E")]
		[FieldOffset(Offset = "0x4")]
		public float edgeSharpnessAmount;

		[Token(Token = "0x4000E7F")]
		[FieldOffset(Offset = "0x8")]
		public float edgeDetectionThreshold;

		[Token(Token = "0x4000E80")]
		[FieldOffset(Offset = "0xC")]
		public float minimumRequiredLuminance;

		[Token(Token = "0x4000E81")]
		[FieldOffset(Offset = "0x0")]
		public static FxaaConsoleSettings[] presets;
	}

	[Serializable]
	[Token(Token = "0x200021D")]
	public struct FxaaSettings
	{
		[Token(Token = "0x4000E82")]
		[FieldOffset(Offset = "0x0")]
		public FxaaPreset preset;

		[Token(Token = "0x17000252")]
		public static FxaaSettings defaultSettings
		{
			[Token(Token = "0x6000D8C")]
			[Address(RVA = "0x47B458", Offset = "0x47B458", VA = "0x47B458")]
			get
			{
				return default(FxaaSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200021E")]
	public struct TaaSettings
	{
		[Token(Token = "0x4000E83")]
		[FieldOffset(Offset = "0x0")]
		public float jitterSpread;

		[Token(Token = "0x4000E84")]
		[FieldOffset(Offset = "0x4")]
		public float sharpen;

		[Token(Token = "0x4000E85")]
		[FieldOffset(Offset = "0x8")]
		public float stationaryBlending;

		[Token(Token = "0x4000E86")]
		[FieldOffset(Offset = "0xC")]
		public float motionBlending;

		[Token(Token = "0x17000253")]
		public static TaaSettings defaultSettings
		{
			[Token(Token = "0x6000D8D")]
			[Address(RVA = "0x47B47C", Offset = "0x47B47C", VA = "0x47B47C")]
			get
			{
				return default(TaaSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200021F")]
	public struct Settings
	{
		[Token(Token = "0x4000E87")]
		[FieldOffset(Offset = "0x0")]
		public Method method;

		[Token(Token = "0x4000E88")]
		[FieldOffset(Offset = "0x4")]
		public FxaaSettings fxaaSettings;

		[Token(Token = "0x4000E89")]
		[FieldOffset(Offset = "0x8")]
		public TaaSettings taaSettings;

		[Token(Token = "0x17000254")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D8E")]
			[Address(RVA = "0x47B460", Offset = "0x47B460", VA = "0x47B460")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A8C")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000185")]
	public Settings settings
	{
		[Token(Token = "0x6000965")]
		[Address(RVA = "0x5B04F8", Offset = "0x5B04F8", VA = "0x5B04F8")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000966")]
		[Address(RVA = "0x5B050C", Offset = "0x5B050C", VA = "0x5B050C")]
		set
		{
		}
	}

	[Token(Token = "0x6000967")]
	[Address(RVA = "0x5B0520", Offset = "0x5B0520", VA = "0x5B0520", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000968")]
	[Address(RVA = "0x5B0560", Offset = "0x5B0560", VA = "0x5B0560")]
	public AntialiasingModel()
	{
	}
}
