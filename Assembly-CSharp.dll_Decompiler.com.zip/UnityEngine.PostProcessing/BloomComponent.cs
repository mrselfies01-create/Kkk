using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016B")]
public sealed class BloomComponent : PostProcessingComponentRenderTexture<BloomModel>
{
	[Token(Token = "0x2000202")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DB3")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _AutoExposure;

		[Token(Token = "0x4000DB4")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Threshold;

		[Token(Token = "0x4000DB5")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _Curve;

		[Token(Token = "0x4000DB6")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _PrefilterOffs;

		[Token(Token = "0x4000DB7")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _SampleScale;

		[Token(Token = "0x4000DB8")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _BaseTex;

		[Token(Token = "0x4000DB9")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _BloomTex;

		[Token(Token = "0x4000DBA")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _Bloom_Settings;

		[Token(Token = "0x4000DBB")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _Bloom_DirtTex;

		[Token(Token = "0x4000DBC")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _Bloom_DirtIntensity;
	}

	[Token(Token = "0x4000A5E")]
	private const int k_MaxPyramidBlurLevel = 16;

	[Token(Token = "0x4000A5F")]
	[FieldOffset(Offset = "0x20")]
	private readonly RenderTexture[] m_BlurBuffer1;

	[Token(Token = "0x4000A60")]
	[FieldOffset(Offset = "0x28")]
	private readonly RenderTexture[] m_BlurBuffer2;

	[Token(Token = "0x17000172")]
	public override bool active
	{
		[Token(Token = "0x60008EF")]
		[Address(RVA = "0x5B0EE8", Offset = "0x5B0EE8", VA = "0x5B0EE8", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x60008F0")]
	[Address(RVA = "0x5B0F64", Offset = "0x5B0F64", VA = "0x5B0F64")]
	public void Prepare(RenderTexture source, Material uberMaterial, Texture autoExposure)
	{
	}

	[Token(Token = "0x60008F1")]
	[Address(RVA = "0x5B193C", Offset = "0x5B193C", VA = "0x5B193C")]
	public BloomComponent()
	{
	}
}
