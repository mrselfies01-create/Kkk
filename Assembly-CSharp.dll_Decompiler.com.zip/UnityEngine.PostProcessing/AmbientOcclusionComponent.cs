using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016A")]
public sealed class AmbientOcclusionComponent : PostProcessingComponentCommandBuffer<AmbientOcclusionModel>
{
	[Token(Token = "0x2000200")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DA5")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _Intensity;

		[Token(Token = "0x4000DA6")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Radius;

		[Token(Token = "0x4000DA7")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _FogParams;

		[Token(Token = "0x4000DA8")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _Downsample;

		[Token(Token = "0x4000DA9")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _SampleCount;

		[Token(Token = "0x4000DAA")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _OcclusionTexture1;

		[Token(Token = "0x4000DAB")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _OcclusionTexture2;

		[Token(Token = "0x4000DAC")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _OcclusionTexture;

		[Token(Token = "0x4000DAD")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _MainTex;

		[Token(Token = "0x4000DAE")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _TempRT;
	}

	[Token(Token = "0x2000201")]
	private enum OcclusionSource
	{
		[Token(Token = "0x4000DB0")]
		DepthTexture,
		[Token(Token = "0x4000DB1")]
		DepthNormalsTexture,
		[Token(Token = "0x4000DB2")]
		GBuffer
	}

	[Token(Token = "0x4000A5B")]
	private const string k_BlitShaderString = "Hidden/Post FX/Blit";

	[Token(Token = "0x4000A5C")]
	private const string k_ShaderString = "Hidden/Post FX/Ambient Occlusion";

	[Token(Token = "0x4000A5D")]
	[FieldOffset(Offset = "0x20")]
	private readonly RenderTargetIdentifier[] m_MRT;

	[Token(Token = "0x1700016F")]
	private OcclusionSource occlusionSource
	{
		[Token(Token = "0x60008E7")]
		[Address(RVA = "0x5AF5E8", Offset = "0x5AF5E8", VA = "0x5AF5E8")]
		get
		{
			return default(OcclusionSource);
		}
	}

	[Token(Token = "0x17000170")]
	private bool ambientOnlySupported
	{
		[Token(Token = "0x60008E8")]
		[Address(RVA = "0x5AF694", Offset = "0x5AF694", VA = "0x5AF694")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x17000171")]
	public override bool active
	{
		[Token(Token = "0x60008E9")]
		[Address(RVA = "0x5AF72C", Offset = "0x5AF72C", VA = "0x5AF72C", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x60008EA")]
	[Address(RVA = "0x5AF7A8", Offset = "0x5AF7A8", VA = "0x5AF7A8", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x60008EB")]
	[Address(RVA = "0x5AF7E4", Offset = "0x5AF7E4", VA = "0x5AF7E4", Slot = "11")]
	public override string GetName()
	{
		return null;
	}

	[Token(Token = "0x60008EC")]
	[Address(RVA = "0x5AF82C", Offset = "0x5AF82C", VA = "0x5AF82C", Slot = "10")]
	public override CameraEvent GetCameraEvent()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(CameraEvent);
	}

	[Token(Token = "0x60008ED")]
	[Address(RVA = "0x5AF898", Offset = "0x5AF898", VA = "0x5AF898", Slot = "12")]
	public override void PopulateCommandBuffer(CommandBuffer cb)
	{
	}

	[Token(Token = "0x60008EE")]
	[Address(RVA = "0x5B0248", Offset = "0x5B0248", VA = "0x5B0248")]
	public AmbientOcclusionComponent()
	{
	}
}
