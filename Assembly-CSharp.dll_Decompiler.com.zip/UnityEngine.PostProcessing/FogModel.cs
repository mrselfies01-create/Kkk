using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000183")]
public class FogModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000237")]
	public struct Settings
	{
		[Token(Token = "0x4000EF5")]
		[FieldOffset(Offset = "0x0")]
		public bool excludeSkybox;

		[Token(Token = "0x17000268")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA3")]
			[Address(RVA = "0x78CABC", Offset = "0x78CABC", VA = "0x78CABC")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A96")]
	[FieldOffset(Offset = "0x11")]
	private Settings m_Settings;

	[Token(Token = "0x17000190")]
	public Settings settings
	{
		[Token(Token = "0x600098C")]
		[Address(RVA = "0x38A3DC", Offset = "0x38A3DC", VA = "0x38A3DC")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x600098D")]
		[Address(RVA = "0x38A3E4", Offset = "0x38A3E4", VA = "0x38A3E4")]
		set
		{
		}
	}

	[Token(Token = "0x600098E")]
	[Address(RVA = "0x38A3EC", Offset = "0x38A3EC", VA = "0x38A3EC", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600098F")]
	[Address(RVA = "0x38A414", Offset = "0x38A414", VA = "0x38A414")]
	public FogModel()
	{
	}
}
