using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200018A")]
public abstract class PostProcessingComponentBase
{
	[Token(Token = "0x4000AB9")]
	[FieldOffset(Offset = "0x10")]
	public PostProcessingContext context;

	[Token(Token = "0x17000196")]
	public abstract bool active
	{
		[Token(Token = "0x60009B6")]
		get;
	}

	[Token(Token = "0x60009B5")]
	[Address(RVA = "0x39709C", Offset = "0x39709C", VA = "0x39709C", Slot = "4")]
	public virtual DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x60009B7")]
	[Address(RVA = "0x3970A4", Offset = "0x3970A4", VA = "0x3970A4", Slot = "6")]
	public virtual void OnEnable()
	{
	}

	[Token(Token = "0x60009B8")]
	[Address(RVA = "0x3970A8", Offset = "0x3970A8", VA = "0x3970A8", Slot = "7")]
	public virtual void OnDisable()
	{
	}

	[Token(Token = "0x60009B9")]
	public abstract PostProcessingModel GetModel();

	[Token(Token = "0x60009BA")]
	[Address(RVA = "0x3970AC", Offset = "0x3970AC", VA = "0x3970AC")]
	protected PostProcessingComponentBase()
	{
	}
}
