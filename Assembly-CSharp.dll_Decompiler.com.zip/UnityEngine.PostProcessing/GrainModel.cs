using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000184")]
public class GrainModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000238")]
	public struct Settings
	{
		[Token(Token = "0x4000EF6")]
		[FieldOffset(Offset = "0x0")]
		public bool colored;

		[Token(Token = "0x4000EF7")]
		[FieldOffset(Offset = "0x4")]
		public float intensity;

		[Token(Token = "0x4000EF8")]
		[FieldOffset(Offset = "0x8")]
		public float size;

		[Token(Token = "0x4000EF9")]
		[FieldOffset(Offset = "0xC")]
		public float luminanceContribution;

		[Token(Token = "0x17000269")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA4")]
			[Address(RVA = "0x78CC0C", Offset = "0x78CC0C", VA = "0x78CC0C")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A97")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000191")]
	public Settings settings
	{
		[Token(Token = "0x6000990")]
		[Address(RVA = "0x38BADC", Offset = "0x38BADC", VA = "0x38BADC")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000991")]
		[Address(RVA = "0x38BAEC", Offset = "0x38BAEC", VA = "0x38BAEC")]
		set
		{
		}
	}

	[Token(Token = "0x6000992")]
	[Address(RVA = "0x38BAF8", Offset = "0x38BAF8", VA = "0x38BAF8", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000993")]
	[Address(RVA = "0x38BB24", Offset = "0x38BB24", VA = "0x38BB24")]
	public GrainModel()
	{
	}
}
