using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000180")]
public class DepthOfFieldModel : PostProcessingModel
{
	[Token(Token = "0x2000232")]
	public enum KernelSize
	{
		[Token(Token = "0x4000EDE")]
		Small,
		[Token(Token = "0x4000EDF")]
		Medium,
		[Token(Token = "0x4000EE0")]
		Large,
		[Token(Token = "0x4000EE1")]
		VeryLarge
	}

	[Serializable]
	[Token(Token = "0x2000233")]
	public struct Settings
	{
		[Token(Token = "0x4000EE2")]
		[FieldOffset(Offset = "0x0")]
		public float focusDistance;

		[Token(Token = "0x4000EE3")]
		[FieldOffset(Offset = "0x4")]
		public float aperture;

		[Token(Token = "0x4000EE4")]
		[FieldOffset(Offset = "0x8")]
		public float focalLength;

		[Token(Token = "0x4000EE5")]
		[FieldOffset(Offset = "0xC")]
		public bool useCameraFov;

		[Token(Token = "0x4000EE6")]
		[FieldOffset(Offset = "0x10")]
		public KernelSize kernelSize;

		[Token(Token = "0x17000265")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA0")]
			[Address(RVA = "0x78C71C", Offset = "0x78C71C", VA = "0x78C71C")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A93")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x1700018D")]
	public Settings settings
	{
		[Token(Token = "0x6000980")]
		[Address(RVA = "0x387578", Offset = "0x387578", VA = "0x387578")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000981")]
		[Address(RVA = "0x38758C", Offset = "0x38758C", VA = "0x38758C")]
		set
		{
		}
	}

	[Token(Token = "0x6000982")]
	[Address(RVA = "0x3875A0", Offset = "0x3875A0", VA = "0x3875A0", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000983")]
	[Address(RVA = "0x3875E0", Offset = "0x3875E0", VA = "0x3875E0")]
	public DepthOfFieldModel()
	{
	}
}
