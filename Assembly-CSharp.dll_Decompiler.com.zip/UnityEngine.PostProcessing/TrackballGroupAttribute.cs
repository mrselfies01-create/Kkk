using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000169")]
public sealed class TrackballGroupAttribute : PropertyAttribute
{
	[Token(Token = "0x60008E6")]
	[Address(RVA = "0x3E1DF8", Offset = "0x3E1DF8", VA = "0x3E1DF8")]
	public TrackballGroupAttribute()
	{
	}
}
