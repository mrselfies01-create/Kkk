using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200018B")]
public abstract class PostProcessingComponent<T> : PostProcessingComponentBase where T : PostProcessingModel
{
	[Token(Token = "0x4000ABA")]
	[FieldOffset(Offset = "0x0")]
	private T _003Cmodel_003Ek__BackingField;

	[Token(Token = "0x17000197")]
	public T model
	{
		[Token(Token = "0x60009BB")]
		get
		{
			return null;
		}
		[Token(Token = "0x60009BC")]
		internal set
		{
		}
	}

	[Token(Token = "0x60009BD")]
	public virtual void Init(PostProcessingContext pcontext, T pmodel)
	{
	}

	[Token(Token = "0x60009BE")]
	public override PostProcessingModel GetModel()
	{
		return null;
	}

	[Token(Token = "0x60009BF")]
	protected PostProcessingComponent()
	{
	}
}
