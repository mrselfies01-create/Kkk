using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200018F")]
public abstract class PostProcessingModel
{
	[Token(Token = "0x4000AC0")]
	[FieldOffset(Offset = "0x10")]
	private bool m_Enabled;

	[Token(Token = "0x1700019E")]
	public bool enabled
	{
		[Token(Token = "0x60009D0")]
		[Address(RVA = "0x3970C8", Offset = "0x3970C8", VA = "0x3970C8")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x60009D1")]
		[Address(RVA = "0x3970D0", Offset = "0x3970D0", VA = "0x3970D0")]
		set
		{
		}
	}

	[Token(Token = "0x60009D2")]
	public abstract void Reset();

	[Token(Token = "0x60009D3")]
	[Address(RVA = "0x3970EC", Offset = "0x3970EC", VA = "0x3970EC", Slot = "5")]
	public virtual void OnValidate()
	{
	}

	[Token(Token = "0x60009D4")]
	[Address(RVA = "0x3853EC", Offset = "0x3853EC", VA = "0x3853EC")]
	protected PostProcessingModel()
	{
	}
}
