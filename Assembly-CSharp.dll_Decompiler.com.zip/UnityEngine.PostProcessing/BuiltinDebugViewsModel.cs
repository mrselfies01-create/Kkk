using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017D")]
public class BuiltinDebugViewsModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000223")]
	public struct DepthSettings
	{
		[Token(Token = "0x4000E93")]
		[FieldOffset(Offset = "0x0")]
		public float scale;

		[Token(Token = "0x17000259")]
		public static DepthSettings defaultSettings
		{
			[Token(Token = "0x6000D94")]
			[Address(RVA = "0x47BC3C", Offset = "0x47BC3C", VA = "0x47BC3C")]
			get
			{
				return default(DepthSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x2000224")]
	public struct MotionVectorsSettings
	{
		[Token(Token = "0x4000E94")]
		[FieldOffset(Offset = "0x0")]
		public float sourceOpacity;

		[Token(Token = "0x4000E95")]
		[FieldOffset(Offset = "0x4")]
		public float motionImageOpacity;

		[Token(Token = "0x4000E96")]
		[FieldOffset(Offset = "0x8")]
		public float motionImageAmplitude;

		[Token(Token = "0x4000E97")]
		[FieldOffset(Offset = "0xC")]
		public float motionVectorsOpacity;

		[Token(Token = "0x4000E98")]
		[FieldOffset(Offset = "0x10")]
		public int motionVectorsResolution;

		[Token(Token = "0x4000E99")]
		[FieldOffset(Offset = "0x14")]
		public float motionVectorsAmplitude;

		[Token(Token = "0x1700025A")]
		public static MotionVectorsSettings defaultSettings
		{
			[Token(Token = "0x6000D95")]
			[Address(RVA = "0x47BC44", Offset = "0x47BC44", VA = "0x47BC44")]
			get
			{
				return default(MotionVectorsSettings);
			}
		}
	}

	[Token(Token = "0x2000225")]
	public enum Mode
	{
		[Token(Token = "0x4000E9B")]
		None,
		[Token(Token = "0x4000E9C")]
		Depth,
		[Token(Token = "0x4000E9D")]
		Normals,
		[Token(Token = "0x4000E9E")]
		MotionVectors,
		[Token(Token = "0x4000E9F")]
		AmbientOcclusion,
		[Token(Token = "0x4000EA0")]
		EyeAdaptation,
		[Token(Token = "0x4000EA1")]
		FocusPlane,
		[Token(Token = "0x4000EA2")]
		PreGradingLog,
		[Token(Token = "0x4000EA3")]
		LogLut,
		[Token(Token = "0x4000EA4")]
		UserLut
	}

	[Serializable]
	[Token(Token = "0x2000226")]
	public struct Settings
	{
		[Token(Token = "0x4000EA5")]
		[FieldOffset(Offset = "0x0")]
		public Mode mode;

		[Token(Token = "0x4000EA6")]
		[FieldOffset(Offset = "0x4")]
		public DepthSettings depth;

		[Token(Token = "0x4000EA7")]
		[FieldOffset(Offset = "0x8")]
		public MotionVectorsSettings motionVectors;

		[Token(Token = "0x1700025B")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D96")]
			[Address(RVA = "0x47BC60", Offset = "0x47BC60", VA = "0x47BC60")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A8E")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000187")]
	public Settings settings
	{
		[Token(Token = "0x600096D")]
		[Address(RVA = "0x5B2948", Offset = "0x5B2948", VA = "0x5B2948")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x600096E")]
		[Address(RVA = "0x5B2958", Offset = "0x5B2958", VA = "0x5B2958")]
		set
		{
		}
	}

	[Token(Token = "0x17000188")]
	public bool willInterrupt
	{
		[Token(Token = "0x600096F")]
		[Address(RVA = "0x5B2968", Offset = "0x5B2968", VA = "0x5B2968")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000970")]
	[Address(RVA = "0x5B298C", Offset = "0x5B298C", VA = "0x5B298C", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000971")]
	[Address(RVA = "0x5AF888", Offset = "0x5AF888", VA = "0x5AF888")]
	public bool IsModeActive(Mode mode)
	{
		return default(bool);
	}

	[Token(Token = "0x6000972")]
	[Address(RVA = "0x5B29C8", Offset = "0x5B29C8", VA = "0x5B29C8")]
	public BuiltinDebugViewsModel()
	{
	}
}
