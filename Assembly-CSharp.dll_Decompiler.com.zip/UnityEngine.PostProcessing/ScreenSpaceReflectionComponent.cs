using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000176")]
public sealed class ScreenSpaceReflectionComponent : PostProcessingComponentCommandBuffer<ScreenSpaceReflectionModel>
{
	[Token(Token = "0x2000212")]
	private static class Uniforms
	{
		[Token(Token = "0x4000E2B")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _RayStepSize;

		[Token(Token = "0x4000E2C")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _AdditiveReflection;

		[Token(Token = "0x4000E2D")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _BilateralUpsampling;

		[Token(Token = "0x4000E2E")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _TreatBackfaceHitAsMiss;

		[Token(Token = "0x4000E2F")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _AllowBackwardsRays;

		[Token(Token = "0x4000E30")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _TraceBehindObjects;

		[Token(Token = "0x4000E31")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _MaxSteps;

		[Token(Token = "0x4000E32")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _FullResolutionFiltering;

		[Token(Token = "0x4000E33")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _HalfResolution;

		[Token(Token = "0x4000E34")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _HighlightSuppression;

		[Token(Token = "0x4000E35")]
		[FieldOffset(Offset = "0x28")]
		internal static readonly int _PixelsPerMeterAtOneMeter;

		[Token(Token = "0x4000E36")]
		[FieldOffset(Offset = "0x2C")]
		internal static readonly int _ScreenEdgeFading;

		[Token(Token = "0x4000E37")]
		[FieldOffset(Offset = "0x30")]
		internal static readonly int _ReflectionBlur;

		[Token(Token = "0x4000E38")]
		[FieldOffset(Offset = "0x34")]
		internal static readonly int _MaxRayTraceDistance;

		[Token(Token = "0x4000E39")]
		[FieldOffset(Offset = "0x38")]
		internal static readonly int _FadeDistance;

		[Token(Token = "0x4000E3A")]
		[FieldOffset(Offset = "0x3C")]
		internal static readonly int _LayerThickness;

		[Token(Token = "0x4000E3B")]
		[FieldOffset(Offset = "0x40")]
		internal static readonly int _SSRMultiplier;

		[Token(Token = "0x4000E3C")]
		[FieldOffset(Offset = "0x44")]
		internal static readonly int _FresnelFade;

		[Token(Token = "0x4000E3D")]
		[FieldOffset(Offset = "0x48")]
		internal static readonly int _FresnelFadePower;

		[Token(Token = "0x4000E3E")]
		[FieldOffset(Offset = "0x4C")]
		internal static readonly int _ReflectionBufferSize;

		[Token(Token = "0x4000E3F")]
		[FieldOffset(Offset = "0x50")]
		internal static readonly int _ScreenSize;

		[Token(Token = "0x4000E40")]
		[FieldOffset(Offset = "0x54")]
		internal static readonly int _InvScreenSize;

		[Token(Token = "0x4000E41")]
		[FieldOffset(Offset = "0x58")]
		internal static readonly int _ProjInfo;

		[Token(Token = "0x4000E42")]
		[FieldOffset(Offset = "0x5C")]
		internal static readonly int _CameraClipInfo;

		[Token(Token = "0x4000E43")]
		[FieldOffset(Offset = "0x60")]
		internal static readonly int _ProjectToPixelMatrix;

		[Token(Token = "0x4000E44")]
		[FieldOffset(Offset = "0x64")]
		internal static readonly int _WorldToCameraMatrix;

		[Token(Token = "0x4000E45")]
		[FieldOffset(Offset = "0x68")]
		internal static readonly int _CameraToWorldMatrix;

		[Token(Token = "0x4000E46")]
		[FieldOffset(Offset = "0x6C")]
		internal static readonly int _Axis;

		[Token(Token = "0x4000E47")]
		[FieldOffset(Offset = "0x70")]
		internal static readonly int _CurrentMipLevel;

		[Token(Token = "0x4000E48")]
		[FieldOffset(Offset = "0x74")]
		internal static readonly int _NormalAndRoughnessTexture;

		[Token(Token = "0x4000E49")]
		[FieldOffset(Offset = "0x78")]
		internal static readonly int _HitPointTexture;

		[Token(Token = "0x4000E4A")]
		[FieldOffset(Offset = "0x7C")]
		internal static readonly int _BlurTexture;

		[Token(Token = "0x4000E4B")]
		[FieldOffset(Offset = "0x80")]
		internal static readonly int _FilteredReflections;

		[Token(Token = "0x4000E4C")]
		[FieldOffset(Offset = "0x84")]
		internal static readonly int _FinalReflectionTexture;

		[Token(Token = "0x4000E4D")]
		[FieldOffset(Offset = "0x88")]
		internal static readonly int _TempTexture;
	}

	[Token(Token = "0x2000213")]
	private enum PassIndex
	{
		[Token(Token = "0x4000E4F")]
		RayTraceStep,
		[Token(Token = "0x4000E50")]
		CompositeFinal,
		[Token(Token = "0x4000E51")]
		Blur,
		[Token(Token = "0x4000E52")]
		CompositeSSR,
		[Token(Token = "0x4000E53")]
		MinMipGeneration,
		[Token(Token = "0x4000E54")]
		HitPointToReflections,
		[Token(Token = "0x4000E55")]
		BilateralKeyPack,
		[Token(Token = "0x4000E56")]
		BlitDepthAsCSZ,
		[Token(Token = "0x4000E57")]
		PoissonBlur
	}

	[Token(Token = "0x4000A7F")]
	[FieldOffset(Offset = "0x20")]
	private bool k_HighlightSuppression;

	[Token(Token = "0x4000A80")]
	[FieldOffset(Offset = "0x21")]
	private bool k_TraceBehindObjects;

	[Token(Token = "0x4000A81")]
	[FieldOffset(Offset = "0x22")]
	private bool k_TreatBackfaceHitAsMiss;

	[Token(Token = "0x4000A82")]
	[FieldOffset(Offset = "0x23")]
	private bool k_BilateralUpsample;

	[Token(Token = "0x4000A83")]
	[FieldOffset(Offset = "0x28")]
	private readonly int[] m_ReflectionTextures;

	[Token(Token = "0x1700017F")]
	public override bool active
	{
		[Token(Token = "0x6000947")]
		[Address(RVA = "0x3DAF90", Offset = "0x3DAF90", VA = "0x3DAF90", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000946")]
	[Address(RVA = "0x3DAF88", Offset = "0x3DAF88", VA = "0x3DAF88", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x6000948")]
	[Address(RVA = "0x3DB014", Offset = "0x3DB014", VA = "0x3DB014", Slot = "6")]
	public override void OnEnable()
	{
	}

	[Token(Token = "0x6000949")]
	[Address(RVA = "0x3DB13C", Offset = "0x3DB13C", VA = "0x3DB13C", Slot = "11")]
	public override string GetName()
	{
		return null;
	}

	[Token(Token = "0x600094A")]
	[Address(RVA = "0x3DB184", Offset = "0x3DB184", VA = "0x3DB184", Slot = "10")]
	public override CameraEvent GetCameraEvent()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(CameraEvent);
	}

	[Token(Token = "0x600094B")]
	[Address(RVA = "0x3DB18C", Offset = "0x3DB18C", VA = "0x3DB18C", Slot = "12")]
	public override void PopulateCommandBuffer(CommandBuffer cb)
	{
	}

	[Token(Token = "0x600094C")]
	[Address(RVA = "0x3DC31C", Offset = "0x3DC31C", VA = "0x3DC31C")]
	public ScreenSpaceReflectionComponent()
	{
	}
}
