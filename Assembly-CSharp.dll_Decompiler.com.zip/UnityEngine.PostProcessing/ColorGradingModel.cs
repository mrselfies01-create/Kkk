using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017F")]
public class ColorGradingModel : PostProcessingModel
{
	[Token(Token = "0x2000228")]
	public enum Tonemapper
	{
		[Token(Token = "0x4000EAB")]
		None,
		[Token(Token = "0x4000EAC")]
		ACES,
		[Token(Token = "0x4000EAD")]
		Neutral
	}

	[Serializable]
	[Token(Token = "0x2000229")]
	public struct TonemappingSettings
	{
		[Token(Token = "0x4000EAE")]
		[FieldOffset(Offset = "0x0")]
		public Tonemapper tonemapper;

		[Token(Token = "0x4000EAF")]
		[FieldOffset(Offset = "0x4")]
		public float neutralBlackIn;

		[Token(Token = "0x4000EB0")]
		[FieldOffset(Offset = "0x8")]
		public float neutralWhiteIn;

		[Token(Token = "0x4000EB1")]
		[FieldOffset(Offset = "0xC")]
		public float neutralBlackOut;

		[Token(Token = "0x4000EB2")]
		[FieldOffset(Offset = "0x10")]
		public float neutralWhiteOut;

		[Token(Token = "0x4000EB3")]
		[FieldOffset(Offset = "0x14")]
		public float neutralWhiteLevel;

		[Token(Token = "0x4000EB4")]
		[FieldOffset(Offset = "0x18")]
		public float neutralWhiteClip;

		[Token(Token = "0x1700025D")]
		public static TonemappingSettings defaultSettings
		{
			[Token(Token = "0x6000D98")]
			[Address(RVA = "0x78C384", Offset = "0x78C384", VA = "0x78C384")]
			get
			{
				return default(TonemappingSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200022A")]
	public struct BasicSettings
	{
		[Token(Token = "0x4000EB5")]
		[FieldOffset(Offset = "0x0")]
		public float postExposure;

		[Token(Token = "0x4000EB6")]
		[FieldOffset(Offset = "0x4")]
		public float temperature;

		[Token(Token = "0x4000EB7")]
		[FieldOffset(Offset = "0x8")]
		public float tint;

		[Token(Token = "0x4000EB8")]
		[FieldOffset(Offset = "0xC")]
		public float hueShift;

		[Token(Token = "0x4000EB9")]
		[FieldOffset(Offset = "0x10")]
		public float saturation;

		[Token(Token = "0x4000EBA")]
		[FieldOffset(Offset = "0x14")]
		public float contrast;

		[Token(Token = "0x1700025E")]
		public static BasicSettings defaultSettings
		{
			[Token(Token = "0x6000D99")]
			[Address(RVA = "0x78BB00", Offset = "0x78BB00", VA = "0x78BB00")]
			get
			{
				return default(BasicSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200022B")]
	public struct ChannelMixerSettings
	{
		[Token(Token = "0x4000EBB")]
		[FieldOffset(Offset = "0x0")]
		public Vector3 red;

		[Token(Token = "0x4000EBC")]
		[FieldOffset(Offset = "0xC")]
		public Vector3 green;

		[Token(Token = "0x4000EBD")]
		[FieldOffset(Offset = "0x18")]
		public Vector3 blue;

		[Token(Token = "0x4000EBE")]
		[FieldOffset(Offset = "0x24")]
		public int currentEditingChannel;

		[Token(Token = "0x1700025F")]
		public static ChannelMixerSettings defaultSettings
		{
			[Token(Token = "0x6000D9A")]
			[Address(RVA = "0x78BB10", Offset = "0x78BB10", VA = "0x78BB10")]
			get
			{
				return default(ChannelMixerSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200022C")]
	public struct LogWheelsSettings
	{
		[Token(Token = "0x4000EBF")]
		[FieldOffset(Offset = "0x0")]
		public Color slope;

		[Token(Token = "0x4000EC0")]
		[FieldOffset(Offset = "0x10")]
		public Color power;

		[Token(Token = "0x4000EC1")]
		[FieldOffset(Offset = "0x20")]
		public Color offset;

		[Token(Token = "0x17000260")]
		public static LogWheelsSettings defaultSettings
		{
			[Token(Token = "0x6000D9B")]
			[Address(RVA = "0x78BBA4", Offset = "0x78BBA4", VA = "0x78BBA4")]
			get
			{
				return default(LogWheelsSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x200022D")]
	public struct LinearWheelsSettings
	{
		[Token(Token = "0x4000EC2")]
		[FieldOffset(Offset = "0x0")]
		public Color lift;

		[Token(Token = "0x4000EC3")]
		[FieldOffset(Offset = "0x10")]
		public Color gamma;

		[Token(Token = "0x4000EC4")]
		[FieldOffset(Offset = "0x20")]
		public Color gain;

		[Token(Token = "0x17000261")]
		public static LinearWheelsSettings defaultSettings
		{
			[Token(Token = "0x6000D9C")]
			[Address(RVA = "0x78BC30", Offset = "0x78BC30", VA = "0x78BC30")]
			get
			{
				return default(LinearWheelsSettings);
			}
		}
	}

	[Token(Token = "0x200022E")]
	public enum ColorWheelMode
	{
		[Token(Token = "0x4000EC6")]
		Linear,
		[Token(Token = "0x4000EC7")]
		Log
	}

	[Serializable]
	[Token(Token = "0x200022F")]
	public struct ColorWheelsSettings
	{
		[Token(Token = "0x4000EC8")]
		[FieldOffset(Offset = "0x0")]
		public ColorWheelMode mode;

		[Token(Token = "0x4000EC9")]
		[FieldOffset(Offset = "0x4")]
		public LogWheelsSettings log;

		[Token(Token = "0x4000ECA")]
		[FieldOffset(Offset = "0x34")]
		public LinearWheelsSettings linear;

		[Token(Token = "0x17000262")]
		public static ColorWheelsSettings defaultSettings
		{
			[Token(Token = "0x6000D9D")]
			[Address(RVA = "0x78BB28", Offset = "0x78BB28", VA = "0x78BB28")]
			get
			{
				return default(ColorWheelsSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x2000230")]
	public struct CurvesSettings
	{
		[Token(Token = "0x4000ECB")]
		[FieldOffset(Offset = "0x0")]
		public ColorGradingCurve master;

		[Token(Token = "0x4000ECC")]
		[FieldOffset(Offset = "0x8")]
		public ColorGradingCurve red;

		[Token(Token = "0x4000ECD")]
		[FieldOffset(Offset = "0x10")]
		public ColorGradingCurve green;

		[Token(Token = "0x4000ECE")]
		[FieldOffset(Offset = "0x18")]
		public ColorGradingCurve blue;

		[Token(Token = "0x4000ECF")]
		[FieldOffset(Offset = "0x20")]
		public ColorGradingCurve hueVShue;

		[Token(Token = "0x4000ED0")]
		[FieldOffset(Offset = "0x28")]
		public ColorGradingCurve hueVSsat;

		[Token(Token = "0x4000ED1")]
		[FieldOffset(Offset = "0x30")]
		public ColorGradingCurve satVSsat;

		[Token(Token = "0x4000ED2")]
		[FieldOffset(Offset = "0x38")]
		public ColorGradingCurve lumVSsat;

		[Token(Token = "0x4000ED3")]
		[FieldOffset(Offset = "0x40")]
		public int e_CurrentEditingCurve;

		[Token(Token = "0x4000ED4")]
		[FieldOffset(Offset = "0x44")]
		public bool e_CurveY;

		[Token(Token = "0x4000ED5")]
		[FieldOffset(Offset = "0x45")]
		public bool e_CurveR;

		[Token(Token = "0x4000ED6")]
		[FieldOffset(Offset = "0x46")]
		public bool e_CurveG;

		[Token(Token = "0x4000ED7")]
		[FieldOffset(Offset = "0x47")]
		public bool e_CurveB;

		[Token(Token = "0x17000263")]
		public static CurvesSettings defaultSettings
		{
			[Token(Token = "0x6000D9E")]
			[Address(RVA = "0x78BCBC", Offset = "0x78BCBC", VA = "0x78BCBC")]
			get
			{
				return default(CurvesSettings);
			}
		}
	}

	[Serializable]
	[Token(Token = "0x2000231")]
	public struct Settings
	{
		[Token(Token = "0x4000ED8")]
		[FieldOffset(Offset = "0x0")]
		public TonemappingSettings tonemapping;

		[Token(Token = "0x4000ED9")]
		[FieldOffset(Offset = "0x1C")]
		public BasicSettings basic;

		[Token(Token = "0x4000EDA")]
		[FieldOffset(Offset = "0x34")]
		public ChannelMixerSettings channelMixer;

		[Token(Token = "0x4000EDB")]
		[FieldOffset(Offset = "0x5C")]
		public ColorWheelsSettings colorWheels;

		[Token(Token = "0x4000EDC")]
		[FieldOffset(Offset = "0xC0")]
		public CurvesSettings curves;

		[Token(Token = "0x17000264")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D9F")]
			[Address(RVA = "0x78C264", Offset = "0x78C264", VA = "0x78C264")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A90")]
	[FieldOffset(Offset = "0x18")]
	private Settings m_Settings;

	[Token(Token = "0x4000A91")]
	[FieldOffset(Offset = "0x120")]
	private bool _003CisDirty_003Ek__BackingField;

	[Token(Token = "0x4000A92")]
	[FieldOffset(Offset = "0x128")]
	private RenderTexture _003CbakedLut_003Ek__BackingField;

	[Token(Token = "0x1700018A")]
	public Settings settings
	{
		[Token(Token = "0x6000977")]
		[Address(RVA = "0x3852DC", Offset = "0x3852DC", VA = "0x3852DC")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000978")]
		[Address(RVA = "0x3852EC", Offset = "0x3852EC", VA = "0x3852EC")]
		set
		{
		}
	}

	[Token(Token = "0x1700018B")]
	public bool isDirty
	{
		[Token(Token = "0x6000979")]
		[Address(RVA = "0x385320", Offset = "0x385320", VA = "0x385320")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x600097A")]
		[Address(RVA = "0x385328", Offset = "0x385328", VA = "0x385328")]
		internal set
		{
		}
	}

	[Token(Token = "0x1700018C")]
	public RenderTexture bakedLut
	{
		[Token(Token = "0x600097B")]
		[Address(RVA = "0x385334", Offset = "0x385334", VA = "0x385334")]
		get
		{
			return null;
		}
		[Token(Token = "0x600097C")]
		[Address(RVA = "0x38533C", Offset = "0x38533C", VA = "0x38533C")]
		internal set
		{
		}
	}

	[Token(Token = "0x600097D")]
	[Address(RVA = "0x385344", Offset = "0x385344", VA = "0x385344", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600097E")]
	[Address(RVA = "0x385394", Offset = "0x385394", VA = "0x385394", Slot = "5")]
	public override void OnValidate()
	{
	}

	[Token(Token = "0x600097F")]
	[Address(RVA = "0x3853A0", Offset = "0x3853A0", VA = "0x3853A0")]
	public ColorGradingModel()
	{
	}
}
