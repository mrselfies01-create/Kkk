using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000174")]
public sealed class GrainComponent : PostProcessingComponentRenderTexture<GrainModel>
{
	[Token(Token = "0x200020D")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DFD")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _Grain_Params1;

		[Token(Token = "0x4000DFE")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Grain_Params2;

		[Token(Token = "0x4000DFF")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _GrainTex;

		[Token(Token = "0x4000E00")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _Phase;
	}

	[Token(Token = "0x4000A7B")]
	[FieldOffset(Offset = "0x20")]
	private RenderTexture m_GrainLookupRT;

	[Token(Token = "0x1700017B")]
	public override bool active
	{
		[Token(Token = "0x6000937")]
		[Address(RVA = "0x38B624", Offset = "0x38B624", VA = "0x38B624", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000938")]
	[Address(RVA = "0x38B6B0", Offset = "0x38B6B0", VA = "0x38B6B0", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000939")]
	[Address(RVA = "0x38B6D8", Offset = "0x38B6D8", VA = "0x38B6D8", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x600093A")]
	[Address(RVA = "0x38BA8C", Offset = "0x38BA8C", VA = "0x38BA8C")]
	public GrainComponent()
	{
	}
}
