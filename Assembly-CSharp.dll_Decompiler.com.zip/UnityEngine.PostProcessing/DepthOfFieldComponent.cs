using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016F")]
public sealed class DepthOfFieldComponent : PostProcessingComponentRenderTexture<DepthOfFieldModel>
{
	[Token(Token = "0x2000208")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DE3")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _DepthOfFieldTex;

		[Token(Token = "0x4000DE4")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _DepthOfFieldCoCTex;

		[Token(Token = "0x4000DE5")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _Distance;

		[Token(Token = "0x4000DE6")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _LensCoeff;

		[Token(Token = "0x4000DE7")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _MaxCoC;

		[Token(Token = "0x4000DE8")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _RcpMaxCoC;

		[Token(Token = "0x4000DE9")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _RcpAspect;

		[Token(Token = "0x4000DEA")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _MainTex;

		[Token(Token = "0x4000DEB")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _CoCTex;

		[Token(Token = "0x4000DEC")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _TaaParams;

		[Token(Token = "0x4000DED")]
		[FieldOffset(Offset = "0x28")]
		internal static readonly int _DepthOfFieldParams;
	}

	[Token(Token = "0x4000A69")]
	private const string k_ShaderString = "Hidden/Post FX/Depth Of Field";

	[Token(Token = "0x4000A6A")]
	[FieldOffset(Offset = "0x20")]
	private RenderTexture m_CoCHistory;

	[Token(Token = "0x4000A6B")]
	private const float k_FilmHeight = 0.024f;

	[Token(Token = "0x17000176")]
	public override bool active
	{
		[Token(Token = "0x6000918")]
		[Address(RVA = "0x386750", Offset = "0x386750", VA = "0x386750", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000919")]
	[Address(RVA = "0x3867C0", Offset = "0x3867C0", VA = "0x3867C0", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x600091A")]
	[Address(RVA = "0x3867C8", Offset = "0x3867C8", VA = "0x3867C8")]
	private float CalculateFocalLength()
	{
		return default(float);
	}

	[Token(Token = "0x600091B")]
	[Address(RVA = "0x386894", Offset = "0x386894", VA = "0x386894")]
	private float CalculateMaxCoCRadius(int screenHeight)
	{
		return default(float);
	}

	[Token(Token = "0x600091C")]
	[Address(RVA = "0x386940", Offset = "0x386940", VA = "0x386940")]
	private bool CheckHistory(int width, int height)
	{
		return default(bool);
	}

	[Token(Token = "0x600091D")]
	[Address(RVA = "0x386A20", Offset = "0x386A20", VA = "0x386A20")]
	private RenderTextureFormat SelectFormat(RenderTextureFormat primary, RenderTextureFormat secondary)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(RenderTextureFormat);
	}

	[Token(Token = "0x600091E")]
	[Address(RVA = "0x386A70", Offset = "0x386A70", VA = "0x386A70")]
	public void Prepare(RenderTexture source, Material uberMaterial, bool antialiasCoC, Vector2 taaJitter, float taaBlending)
	{
	}

	[Token(Token = "0x600091F")]
	[Address(RVA = "0x3874A0", Offset = "0x3874A0", VA = "0x3874A0", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000920")]
	[Address(RVA = "0x387528", Offset = "0x387528", VA = "0x387528")]
	public DepthOfFieldComponent()
	{
	}
}
