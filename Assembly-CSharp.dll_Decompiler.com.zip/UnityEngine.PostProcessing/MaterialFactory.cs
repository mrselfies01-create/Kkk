using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000193")]
public sealed class MaterialFactory : IDisposable
{
	[Token(Token = "0x4000AD7")]
	[FieldOffset(Offset = "0x10")]
	private Dictionary<string, Material> m_Materials;

	[Token(Token = "0x60009E1")]
	[Address(RVA = "0x38E1D0", Offset = "0x38E1D0", VA = "0x38E1D0")]
	public MaterialFactory()
	{
	}

	[Token(Token = "0x60009E2")]
	[Address(RVA = "0x384C4C", Offset = "0x384C4C", VA = "0x384C4C")]
	public Material Get(string shaderName)
	{
		return null;
	}

	[Token(Token = "0x60009E3")]
	[Address(RVA = "0x38E244", Offset = "0x38E244", VA = "0x38E244", Slot = "4")]
	public void Dispose()
	{
	}
}
