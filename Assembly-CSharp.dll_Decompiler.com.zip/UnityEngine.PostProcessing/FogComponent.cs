using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000172")]
public sealed class FogComponent : PostProcessingComponentCommandBuffer<FogModel>
{
	[Token(Token = "0x200020B")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DF6")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _FogColor;

		[Token(Token = "0x4000DF7")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Density;

		[Token(Token = "0x4000DF8")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _Start;

		[Token(Token = "0x4000DF9")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _End;

		[Token(Token = "0x4000DFA")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _TempRT;
	}

	[Token(Token = "0x4000A7A")]
	private const string k_ShaderString = "Hidden/Post FX/Fog";

	[Token(Token = "0x17000179")]
	public override bool active
	{
		[Token(Token = "0x600092E")]
		[Address(RVA = "0x389DCC", Offset = "0x389DCC", VA = "0x389DCC", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x600092F")]
	[Address(RVA = "0x389E84", Offset = "0x389E84", VA = "0x389E84", Slot = "11")]
	public override string GetName()
	{
		return null;
	}

	[Token(Token = "0x6000930")]
	[Address(RVA = "0x389ECC", Offset = "0x389ECC", VA = "0x389ECC", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x6000931")]
	[Address(RVA = "0x389ED4", Offset = "0x389ED4", VA = "0x389ED4", Slot = "10")]
	public override CameraEvent GetCameraEvent()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(CameraEvent);
	}

	[Token(Token = "0x6000932")]
	[Address(RVA = "0x389EDC", Offset = "0x389EDC", VA = "0x389EDC", Slot = "12")]
	public override void PopulateCommandBuffer(CommandBuffer cb)
	{
	}

	[Token(Token = "0x6000933")]
	[Address(RVA = "0x38A38C", Offset = "0x38A38C", VA = "0x38A38C")]
	public FogComponent()
	{
	}
}
