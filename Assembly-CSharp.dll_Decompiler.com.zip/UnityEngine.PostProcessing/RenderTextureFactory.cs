using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000194")]
public sealed class RenderTextureFactory : IDisposable
{
	[Token(Token = "0x4000AD8")]
	[FieldOffset(Offset = "0x10")]
	private HashSet<RenderTexture> m_TemporaryRTs;

	[Token(Token = "0x60009E4")]
	[Address(RVA = "0x3959CC", Offset = "0x3959CC", VA = "0x3959CC")]
	public RenderTextureFactory()
	{
	}

	[Token(Token = "0x60009E5")]
	[Address(RVA = "0x396A48", Offset = "0x396A48", VA = "0x396A48")]
	public RenderTexture Get(RenderTexture baseRenderTexture)
	{
		return null;
	}

	[Token(Token = "0x60009E6")]
	[Address(RVA = "0x387274", Offset = "0x387274", VA = "0x387274")]
	public RenderTexture Get(int width, int height, int depthBuffer = 0, RenderTextureFormat format = 2, RenderTextureReadWrite rw = 0, FilterMode filterMode = 1, TextureWrapMode wrapMode = 1, string name = "FactoryTempTexture")
	{
		return null;
	}

	[Token(Token = "0x60009E7")]
	[Address(RVA = "0x387368", Offset = "0x387368", VA = "0x387368")]
	public void Release(RenderTexture rt)
	{
	}

	[Token(Token = "0x60009E8")]
	[Address(RVA = "0x396B68", Offset = "0x396B68", VA = "0x396B68")]
	public void ReleaseAll()
	{
	}

	[Token(Token = "0x60009E9")]
	[Address(RVA = "0x396FAC", Offset = "0x396FAC", VA = "0x396FAC", Slot = "4")]
	public void Dispose()
	{
	}
}
