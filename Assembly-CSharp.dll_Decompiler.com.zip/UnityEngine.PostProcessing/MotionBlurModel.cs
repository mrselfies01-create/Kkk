using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000185")]
public class MotionBlurModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000239")]
	public struct Settings
	{
		[Token(Token = "0x4000EFA")]
		[FieldOffset(Offset = "0x0")]
		public float shutterAngle;

		[Token(Token = "0x4000EFB")]
		[FieldOffset(Offset = "0x4")]
		public int sampleCount;

		[Token(Token = "0x4000EFC")]
		[FieldOffset(Offset = "0x8")]
		public float frameBlending;

		[Token(Token = "0x1700026A")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA5")]
			[Address(RVA = "0x78EDCC", Offset = "0x78EDCC", VA = "0x78EDCC")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A98")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000192")]
	public Settings settings
	{
		[Token(Token = "0x6000994")]
		[Address(RVA = "0x390C50", Offset = "0x390C50", VA = "0x390C50")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000995")]
		[Address(RVA = "0x390C60", Offset = "0x390C60", VA = "0x390C60")]
		set
		{
		}
	}

	[Token(Token = "0x6000996")]
	[Address(RVA = "0x390C6C", Offset = "0x390C6C", VA = "0x390C6C", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000997")]
	[Address(RVA = "0x390C98", Offset = "0x390C98", VA = "0x390C98")]
	public MotionBlurModel()
	{
	}
}
