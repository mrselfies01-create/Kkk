using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000190")]
public class PostProcessingProfile : ScriptableObject
{
	[Token(Token = "0x4000AC1")]
	[FieldOffset(Offset = "0x18")]
	public BuiltinDebugViewsModel debugViews;

	[Token(Token = "0x4000AC2")]
	[FieldOffset(Offset = "0x20")]
	public FogModel fog;

	[Token(Token = "0x4000AC3")]
	[FieldOffset(Offset = "0x28")]
	public AntialiasingModel antialiasing;

	[Token(Token = "0x4000AC4")]
	[FieldOffset(Offset = "0x30")]
	public AmbientOcclusionModel ambientOcclusion;

	[Token(Token = "0x4000AC5")]
	[FieldOffset(Offset = "0x38")]
	public ScreenSpaceReflectionModel screenSpaceReflection;

	[Token(Token = "0x4000AC6")]
	[FieldOffset(Offset = "0x40")]
	public DepthOfFieldModel depthOfField;

	[Token(Token = "0x4000AC7")]
	[FieldOffset(Offset = "0x48")]
	public MotionBlurModel motionBlur;

	[Token(Token = "0x4000AC8")]
	[FieldOffset(Offset = "0x50")]
	public EyeAdaptationModel eyeAdaptation;

	[Token(Token = "0x4000AC9")]
	[FieldOffset(Offset = "0x58")]
	public BloomModel bloom;

	[Token(Token = "0x4000ACA")]
	[FieldOffset(Offset = "0x60")]
	public ColorGradingModel colorGrading;

	[Token(Token = "0x4000ACB")]
	[FieldOffset(Offset = "0x68")]
	public UserLutModel userLut;

	[Token(Token = "0x4000ACC")]
	[FieldOffset(Offset = "0x70")]
	public ChromaticAberrationModel chromaticAberration;

	[Token(Token = "0x4000ACD")]
	[FieldOffset(Offset = "0x78")]
	public GrainModel grain;

	[Token(Token = "0x4000ACE")]
	[FieldOffset(Offset = "0x80")]
	public VignetteModel vignette;

	[Token(Token = "0x4000ACF")]
	[FieldOffset(Offset = "0x88")]
	public DitheringModel dithering;

	[Token(Token = "0x60009D5")]
	[Address(RVA = "0x3970F0", Offset = "0x3970F0", VA = "0x3970F0")]
	public PostProcessingProfile()
	{
	}
}
