using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000177")]
public sealed class TaaComponent : PostProcessingComponentRenderTexture<AntialiasingModel>
{
	[Token(Token = "0x2000214")]
	private static class Uniforms
	{
		[Token(Token = "0x4000E58")]
		[FieldOffset(Offset = "0x0")]
		internal static int _Jitter;

		[Token(Token = "0x4000E59")]
		[FieldOffset(Offset = "0x4")]
		internal static int _SharpenParameters;

		[Token(Token = "0x4000E5A")]
		[FieldOffset(Offset = "0x8")]
		internal static int _FinalBlendParameters;

		[Token(Token = "0x4000E5B")]
		[FieldOffset(Offset = "0xC")]
		internal static int _HistoryTex;

		[Token(Token = "0x4000E5C")]
		[FieldOffset(Offset = "0x10")]
		internal static int _MainTex;
	}

	[Token(Token = "0x4000A84")]
	private const string k_ShaderString = "Hidden/Post FX/Temporal Anti-aliasing";

	[Token(Token = "0x4000A85")]
	private const int k_SampleCount = 8;

	[Token(Token = "0x4000A86")]
	[FieldOffset(Offset = "0x20")]
	private readonly RenderBuffer[] m_MRT;

	[Token(Token = "0x4000A87")]
	[FieldOffset(Offset = "0x28")]
	private int m_SampleIndex;

	[Token(Token = "0x4000A88")]
	[FieldOffset(Offset = "0x2C")]
	private bool m_ResetHistory;

	[Token(Token = "0x4000A89")]
	[FieldOffset(Offset = "0x30")]
	private RenderTexture m_HistoryTexture;

	[Token(Token = "0x4000A8A")]
	[FieldOffset(Offset = "0x38")]
	private Vector2 _003CjitterVector_003Ek__BackingField;

	[Token(Token = "0x17000180")]
	public override bool active
	{
		[Token(Token = "0x600094D")]
		[Address(RVA = "0x3DEF7C", Offset = "0x3DEF7C", VA = "0x3DEF7C", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x17000181")]
	public Vector2 jitterVector
	{
		[Token(Token = "0x600094F")]
		[Address(RVA = "0x3DF01C", Offset = "0x3DF01C", VA = "0x3DF01C")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000950")]
		[Address(RVA = "0x3DF024", Offset = "0x3DF024", VA = "0x3DF024")]
		private set
		{
		}
	}

	[Token(Token = "0x600094E")]
	[Address(RVA = "0x3DF014", Offset = "0x3DF014", VA = "0x3DF014", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x6000951")]
	[Address(RVA = "0x3DF02C", Offset = "0x3DF02C", VA = "0x3DF02C")]
	public void ResetHistory()
	{
	}

	[Token(Token = "0x6000952")]
	[Address(RVA = "0x3DF038", Offset = "0x3DF038", VA = "0x3DF038")]
	public void SetProjectionMatrix(Func<Vector2, Matrix4x4> jitteredFunc)
	{
	}

	[Token(Token = "0x6000953")]
	[Address(RVA = "0x3DF9B8", Offset = "0x3DF9B8", VA = "0x3DF9B8")]
	public void Render(RenderTexture source, RenderTexture destination)
	{
	}

	[Token(Token = "0x6000954")]
	[Address(RVA = "0x3DFE28", Offset = "0x3DFE28", VA = "0x3DFE28")]
	private float GetHaltonValue(int index, int radix)
	{
		return default(float);
	}

	[Token(Token = "0x6000955")]
	[Address(RVA = "0x3DF2E4", Offset = "0x3DF2E4", VA = "0x3DF2E4")]
	private Vector2 GenerateRandomOffset()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector2);
	}

	[Token(Token = "0x6000956")]
	[Address(RVA = "0x3DF378", Offset = "0x3DF378", VA = "0x3DF378")]
	private Matrix4x4 GetPerspectiveProjectionMatrix(Vector2 offset)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Matrix4x4);
	}

	[Token(Token = "0x6000957")]
	[Address(RVA = "0x3DF830", Offset = "0x3DF830", VA = "0x3DF830")]
	private Matrix4x4 GetOrthographicProjectionMatrix(Vector2 offset)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Matrix4x4);
	}

	[Token(Token = "0x6000958")]
	[Address(RVA = "0x3DFE6C", Offset = "0x3DFE6C", VA = "0x3DFE6C", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000959")]
	[Address(RVA = "0x3DFF00", Offset = "0x3DFF00", VA = "0x3DFF00")]
	public TaaComponent()
	{
	}
}
