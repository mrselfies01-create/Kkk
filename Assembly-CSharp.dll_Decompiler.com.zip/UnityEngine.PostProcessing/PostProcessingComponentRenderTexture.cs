using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200018D")]
public abstract class PostProcessingComponentRenderTexture<T> : PostProcessingComponent<T> where T : PostProcessingModel
{
	[Token(Token = "0x60009C4")]
	public virtual void Prepare(Material material)
	{
	}

	[Token(Token = "0x60009C5")]
	protected PostProcessingComponentRenderTexture()
	{
	}
}
