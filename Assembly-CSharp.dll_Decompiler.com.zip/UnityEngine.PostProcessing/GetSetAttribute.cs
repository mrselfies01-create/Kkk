using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000166")]
public sealed class GetSetAttribute : PropertyAttribute
{
	[Token(Token = "0x4000A57")]
	[FieldOffset(Offset = "0x10")]
	public readonly string name;

	[Token(Token = "0x4000A58")]
	[FieldOffset(Offset = "0x18")]
	public bool dirty;

	[Token(Token = "0x60008E3")]
	[Address(RVA = "0x38B274", Offset = "0x38B274", VA = "0x38B274")]
	public GetSetAttribute(string name)
	{
	}
}
