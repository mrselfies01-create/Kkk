using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000175")]
public sealed class MotionBlurComponent : PostProcessingComponentCommandBuffer<MotionBlurModel>
{
	[Token(Token = "0x200020E")]
	private static class Uniforms
	{
		[Token(Token = "0x4000E01")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _VelocityScale;

		[Token(Token = "0x4000E02")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _MaxBlurRadius;

		[Token(Token = "0x4000E03")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _RcpMaxBlurRadius;

		[Token(Token = "0x4000E04")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _VelocityTex;

		[Token(Token = "0x4000E05")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _MainTex;

		[Token(Token = "0x4000E06")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _Tile2RT;

		[Token(Token = "0x4000E07")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _Tile4RT;

		[Token(Token = "0x4000E08")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _Tile8RT;

		[Token(Token = "0x4000E09")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _TileMaxOffs;

		[Token(Token = "0x4000E0A")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _TileMaxLoop;

		[Token(Token = "0x4000E0B")]
		[FieldOffset(Offset = "0x28")]
		internal static readonly int _TileVRT;

		[Token(Token = "0x4000E0C")]
		[FieldOffset(Offset = "0x2C")]
		internal static readonly int _NeighborMaxTex;

		[Token(Token = "0x4000E0D")]
		[FieldOffset(Offset = "0x30")]
		internal static readonly int _LoopCount;

		[Token(Token = "0x4000E0E")]
		[FieldOffset(Offset = "0x34")]
		internal static readonly int _TempRT;

		[Token(Token = "0x4000E0F")]
		[FieldOffset(Offset = "0x38")]
		internal static readonly int _History1LumaTex;

		[Token(Token = "0x4000E10")]
		[FieldOffset(Offset = "0x3C")]
		internal static readonly int _History2LumaTex;

		[Token(Token = "0x4000E11")]
		[FieldOffset(Offset = "0x40")]
		internal static readonly int _History3LumaTex;

		[Token(Token = "0x4000E12")]
		[FieldOffset(Offset = "0x44")]
		internal static readonly int _History4LumaTex;

		[Token(Token = "0x4000E13")]
		[FieldOffset(Offset = "0x48")]
		internal static readonly int _History1ChromaTex;

		[Token(Token = "0x4000E14")]
		[FieldOffset(Offset = "0x4C")]
		internal static readonly int _History2ChromaTex;

		[Token(Token = "0x4000E15")]
		[FieldOffset(Offset = "0x50")]
		internal static readonly int _History3ChromaTex;

		[Token(Token = "0x4000E16")]
		[FieldOffset(Offset = "0x54")]
		internal static readonly int _History4ChromaTex;

		[Token(Token = "0x4000E17")]
		[FieldOffset(Offset = "0x58")]
		internal static readonly int _History1Weight;

		[Token(Token = "0x4000E18")]
		[FieldOffset(Offset = "0x5C")]
		internal static readonly int _History2Weight;

		[Token(Token = "0x4000E19")]
		[FieldOffset(Offset = "0x60")]
		internal static readonly int _History3Weight;

		[Token(Token = "0x4000E1A")]
		[FieldOffset(Offset = "0x64")]
		internal static readonly int _History4Weight;
	}

	[Token(Token = "0x200020F")]
	private enum Pass
	{
		[Token(Token = "0x4000E1C")]
		VelocitySetup,
		[Token(Token = "0x4000E1D")]
		TileMax1,
		[Token(Token = "0x4000E1E")]
		TileMax2,
		[Token(Token = "0x4000E1F")]
		TileMaxV,
		[Token(Token = "0x4000E20")]
		NeighborMax,
		[Token(Token = "0x4000E21")]
		Reconstruction,
		[Token(Token = "0x4000E22")]
		FrameCompression,
		[Token(Token = "0x4000E23")]
		FrameBlendingChroma,
		[Token(Token = "0x4000E24")]
		FrameBlendingRaw
	}

	[Token(Token = "0x2000210")]
	public class ReconstructionFilter
	{
		[Token(Token = "0x4000E25")]
		[FieldOffset(Offset = "0x10")]
		private RenderTextureFormat m_VectorRTFormat;

		[Token(Token = "0x4000E26")]
		[FieldOffset(Offset = "0x14")]
		private RenderTextureFormat m_PackedRTFormat;

		[Token(Token = "0x6000D7A")]
		[Address(RVA = "0x78E0D8", Offset = "0x78E0D8", VA = "0x78E0D8")]
		public ReconstructionFilter()
		{
		}

		[Token(Token = "0x6000D7B")]
		[Address(RVA = "0x78E11C", Offset = "0x78E11C", VA = "0x78E11C")]
		private void CheckTextureFormatSupport()
		{
		}

		[Token(Token = "0x6000D7C")]
		[Address(RVA = "0x78E14C", Offset = "0x78E14C", VA = "0x78E14C")]
		public bool IsSupported()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D7D")]
		[Address(RVA = "0x78E154", Offset = "0x78E154", VA = "0x78E154")]
		public void ProcessImage(PostProcessingContext context, CommandBuffer cb, ref MotionBlurModel.Settings settings, RenderTargetIdentifier source, RenderTargetIdentifier destination, Material material)
		{
		}
	}

	[Token(Token = "0x2000211")]
	public class FrameBlendingFilter
	{
		[Token(Token = "0x2000287")]
		private struct Frame
		{
			[Token(Token = "0x4000FB0")]
			[FieldOffset(Offset = "0x0")]
			public RenderTexture lumaTexture;

			[Token(Token = "0x4000FB1")]
			[FieldOffset(Offset = "0x8")]
			public RenderTexture chromaTexture;

			[Token(Token = "0x4000FB2")]
			[FieldOffset(Offset = "0x10")]
			private float m_Time;

			[Token(Token = "0x4000FB3")]
			[FieldOffset(Offset = "0x18")]
			private RenderTargetIdentifier[] m_MRT;

			[Token(Token = "0x6000DDF")]
			[Address(RVA = "0x2A645C", Offset = "0x2A645C", VA = "0x2A645C")]
			public float CalculateWeight(float strength, float currentTime)
			{
				return default(float);
			}

			[Token(Token = "0x6000DE0")]
			[Address(RVA = "0x2A6464", Offset = "0x2A6464", VA = "0x2A6464")]
			public void Release()
			{
			}

			[Token(Token = "0x6000DE1")]
			[Address(RVA = "0x2A646C", Offset = "0x2A646C", VA = "0x2A646C")]
			public void MakeRecord(CommandBuffer cb, RenderTargetIdentifier source, int width, int height, Material material)
			{
			}

			[Token(Token = "0x6000DE2")]
			[Address(RVA = "0x2A64A0", Offset = "0x2A64A0", VA = "0x2A64A0")]
			public void MakeRecordRaw(CommandBuffer cb, RenderTargetIdentifier source, int width, int height, RenderTextureFormat format)
			{
			}
		}

		[Token(Token = "0x4000E27")]
		[FieldOffset(Offset = "0x10")]
		private bool m_UseCompression;

		[Token(Token = "0x4000E28")]
		[FieldOffset(Offset = "0x14")]
		private RenderTextureFormat m_RawTextureFormat;

		[Token(Token = "0x4000E29")]
		[FieldOffset(Offset = "0x18")]
		private Frame[] m_FrameList;

		[Token(Token = "0x4000E2A")]
		[FieldOffset(Offset = "0x20")]
		private int m_LastFrameCount;

		[Token(Token = "0x6000D7E")]
		[Address(RVA = "0x78D1F0", Offset = "0x78D1F0", VA = "0x78D1F0")]
		public FrameBlendingFilter()
		{
		}

		[Token(Token = "0x6000D7F")]
		[Address(RVA = "0x78D370", Offset = "0x78D370", VA = "0x78D370")]
		public void Dispose()
		{
		}

		[Token(Token = "0x6000D80")]
		[Address(RVA = "0x78D4C4", Offset = "0x78D4C4", VA = "0x78D4C4")]
		public void PushFrame(CommandBuffer cb, RenderTargetIdentifier source, int width, int height, Material material)
		{
		}

		[Token(Token = "0x6000D81")]
		[Address(RVA = "0x78DA1C", Offset = "0x78DA1C", VA = "0x78DA1C")]
		public void BlendFrames(CommandBuffer cb, float strength, RenderTargetIdentifier source, RenderTargetIdentifier destination, Material material)
		{
		}

		[Token(Token = "0x6000D82")]
		[Address(RVA = "0x78D268", Offset = "0x78D268", VA = "0x78D268")]
		private static bool CheckSupportCompression()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D83")]
		[Address(RVA = "0x78D2A0", Offset = "0x78D2A0", VA = "0x78D2A0")]
		private static RenderTextureFormat GetPreferredRenderTextureFormat()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(RenderTextureFormat);
		}

		[Token(Token = "0x6000D84")]
		[Address(RVA = "0x78DF7C", Offset = "0x78DF7C", VA = "0x78DF7C")]
		private Frame GetFrameRelative(int offset)
		{
			return default(Frame);
		}
	}

	[Token(Token = "0x4000A7C")]
	[FieldOffset(Offset = "0x20")]
	private ReconstructionFilter m_ReconstructionFilter;

	[Token(Token = "0x4000A7D")]
	[FieldOffset(Offset = "0x28")]
	private FrameBlendingFilter m_FrameBlendingFilter;

	[Token(Token = "0x4000A7E")]
	[FieldOffset(Offset = "0x30")]
	private bool m_FirstFrame;

	[Token(Token = "0x1700017C")]
	public ReconstructionFilter reconstructionFilter
	{
		[Token(Token = "0x600093B")]
		[Address(RVA = "0x390390", Offset = "0x390390", VA = "0x390390")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x1700017D")]
	public FrameBlendingFilter frameBlendingFilter
	{
		[Token(Token = "0x600093C")]
		[Address(RVA = "0x3903FC", Offset = "0x3903FC", VA = "0x3903FC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x1700017E")]
	public override bool active
	{
		[Token(Token = "0x600093D")]
		[Address(RVA = "0x390468", Offset = "0x390468", VA = "0x390468", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x600093E")]
	[Address(RVA = "0x39052C", Offset = "0x39052C", VA = "0x39052C", Slot = "11")]
	public override string GetName()
	{
		return null;
	}

	[Token(Token = "0x600093F")]
	[Address(RVA = "0x390574", Offset = "0x390574", VA = "0x390574")]
	public void ResetHistory()
	{
	}

	[Token(Token = "0x6000940")]
	[Address(RVA = "0x3905A4", Offset = "0x3905A4", VA = "0x3905A4", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x6000941")]
	[Address(RVA = "0x3905AC", Offset = "0x3905AC", VA = "0x3905AC", Slot = "10")]
	public override CameraEvent GetCameraEvent()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(CameraEvent);
	}

	[Token(Token = "0x6000942")]
	[Address(RVA = "0x3905B4", Offset = "0x3905B4", VA = "0x3905B4", Slot = "6")]
	public override void OnEnable()
	{
	}

	[Token(Token = "0x6000943")]
	[Address(RVA = "0x3905C0", Offset = "0x3905C0", VA = "0x3905C0", Slot = "12")]
	public override void PopulateCommandBuffer(CommandBuffer cb)
	{
	}

	[Token(Token = "0x6000944")]
	[Address(RVA = "0x390BE4", Offset = "0x390BE4", VA = "0x390BE4", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000945")]
	[Address(RVA = "0x390BF8", Offset = "0x390BF8", VA = "0x390BF8")]
	public MotionBlurComponent()
	{
	}
}
