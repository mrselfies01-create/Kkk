using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000186")]
public class ScreenSpaceReflectionModel : PostProcessingModel
{
	[Token(Token = "0x200023A")]
	public enum SSRResolution
	{
		[Token(Token = "0x4000EFE")]
		High = 0,
		[Token(Token = "0x4000EFF")]
		Low = 2
	}

	[Token(Token = "0x200023B")]
	public enum SSRReflectionBlendType
	{
		[Token(Token = "0x4000F01")]
		PhysicallyBased,
		[Token(Token = "0x4000F02")]
		Additive
	}

	[Serializable]
	[Token(Token = "0x200023C")]
	public struct IntensitySettings
	{
		[Token(Token = "0x4000F03")]
		[FieldOffset(Offset = "0x0")]
		public float reflectionMultiplier;

		[Token(Token = "0x4000F04")]
		[FieldOffset(Offset = "0x4")]
		public float fadeDistance;

		[Token(Token = "0x4000F05")]
		[FieldOffset(Offset = "0x8")]
		public float fresnelFade;

		[Token(Token = "0x4000F06")]
		[FieldOffset(Offset = "0xC")]
		public float fresnelFadePower;
	}

	[Serializable]
	[Token(Token = "0x200023D")]
	public struct ReflectionSettings
	{
		[Token(Token = "0x4000F07")]
		[FieldOffset(Offset = "0x0")]
		public SSRReflectionBlendType blendType;

		[Token(Token = "0x4000F08")]
		[FieldOffset(Offset = "0x4")]
		public SSRResolution reflectionQuality;

		[Token(Token = "0x4000F09")]
		[FieldOffset(Offset = "0x8")]
		public float maxDistance;

		[Token(Token = "0x4000F0A")]
		[FieldOffset(Offset = "0xC")]
		public int iterationCount;

		[Token(Token = "0x4000F0B")]
		[FieldOffset(Offset = "0x10")]
		public int stepSize;

		[Token(Token = "0x4000F0C")]
		[FieldOffset(Offset = "0x14")]
		public float widthModifier;

		[Token(Token = "0x4000F0D")]
		[FieldOffset(Offset = "0x18")]
		public float reflectionBlur;

		[Token(Token = "0x4000F0E")]
		[FieldOffset(Offset = "0x1C")]
		public bool reflectBackfaces;
	}

	[Serializable]
	[Token(Token = "0x200023E")]
	public struct ScreenEdgeMask
	{
		[Token(Token = "0x4000F0F")]
		[FieldOffset(Offset = "0x0")]
		public float intensity;
	}

	[Serializable]
	[Token(Token = "0x200023F")]
	public struct Settings
	{
		[Token(Token = "0x4000F10")]
		[FieldOffset(Offset = "0x0")]
		public ReflectionSettings reflection;

		[Token(Token = "0x4000F11")]
		[FieldOffset(Offset = "0x20")]
		public IntensitySettings intensity;

		[Token(Token = "0x4000F12")]
		[FieldOffset(Offset = "0x30")]
		public ScreenEdgeMask screenEdgeMask;

		[Token(Token = "0x1700026B")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA6")]
			[Address(RVA = "0x78F708", Offset = "0x78F708", VA = "0x78F708")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A99")]
	[FieldOffset(Offset = "0x14")]
	private Settings m_Settings;

	[Token(Token = "0x17000193")]
	public Settings settings
	{
		[Token(Token = "0x6000998")]
		[Address(RVA = "0x3DC390", Offset = "0x3DC390", VA = "0x3DC390")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000999")]
		[Address(RVA = "0x3DC3B0", Offset = "0x3DC3B0", VA = "0x3DC3B0")]
		set
		{
		}
	}

	[Token(Token = "0x600099A")]
	[Address(RVA = "0x3DC3D0", Offset = "0x3DC3D0", VA = "0x3DC3D0", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x600099B")]
	[Address(RVA = "0x3DC420", Offset = "0x3DC420", VA = "0x3DC420")]
	public ScreenSpaceReflectionModel()
	{
	}
}
