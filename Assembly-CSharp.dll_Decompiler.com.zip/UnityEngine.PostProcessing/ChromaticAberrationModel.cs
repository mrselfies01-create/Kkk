using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x200017E")]
public class ChromaticAberrationModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000227")]
	public struct Settings
	{
		[Token(Token = "0x4000EA8")]
		[FieldOffset(Offset = "0x0")]
		public Texture2D spectralTexture;

		[Token(Token = "0x4000EA9")]
		[FieldOffset(Offset = "0x8")]
		public float intensity;

		[Token(Token = "0x1700025C")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000D97")]
			[Address(RVA = "0x47BE64", Offset = "0x47BE64", VA = "0x47BE64")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A8F")]
	[FieldOffset(Offset = "0x18")]
	private Settings m_Settings;

	[Token(Token = "0x17000189")]
	public Settings settings
	{
		[Token(Token = "0x6000973")]
		[Address(RVA = "0x641900", Offset = "0x641900", VA = "0x641900")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000974")]
		[Address(RVA = "0x64190C", Offset = "0x64190C", VA = "0x64190C")]
		set
		{
		}
	}

	[Token(Token = "0x6000975")]
	[Address(RVA = "0x641914", Offset = "0x641914", VA = "0x641914", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000976")]
	[Address(RVA = "0x64193C", Offset = "0x64193C", VA = "0x64193C")]
	public ChromaticAberrationModel()
	{
	}
}
