using Il2CppDummyDll;
using UnityEngine.Rendering;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016C")]
public sealed class BuiltinDebugViewsComponent : PostProcessingComponentCommandBuffer<BuiltinDebugViewsModel>
{
	[Token(Token = "0x2000203")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DBD")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _DepthScale;

		[Token(Token = "0x4000DBE")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _TempRT;

		[Token(Token = "0x4000DBF")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _Opacity;

		[Token(Token = "0x4000DC0")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _MainTex;

		[Token(Token = "0x4000DC1")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _TempRT2;

		[Token(Token = "0x4000DC2")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _Amplitude;

		[Token(Token = "0x4000DC3")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _Scale;
	}

	[Token(Token = "0x2000204")]
	private enum Pass
	{
		[Token(Token = "0x4000DC5")]
		Depth,
		[Token(Token = "0x4000DC6")]
		Normals,
		[Token(Token = "0x4000DC7")]
		MovecOpacity,
		[Token(Token = "0x4000DC8")]
		MovecImaging,
		[Token(Token = "0x4000DC9")]
		MovecArrows
	}

	[Token(Token = "0x2000205")]
	private class ArrowArray
	{
		[Token(Token = "0x4000DCA")]
		[FieldOffset(Offset = "0x10")]
		private Mesh _003Cmesh_003Ek__BackingField;

		[Token(Token = "0x4000DCB")]
		[FieldOffset(Offset = "0x18")]
		private int _003CcolumnCount_003Ek__BackingField;

		[Token(Token = "0x4000DCC")]
		[FieldOffset(Offset = "0x1C")]
		private int _003CrowCount_003Ek__BackingField;

		[Token(Token = "0x1700024E")]
		public Mesh mesh
		{
			[Token(Token = "0x6000D68")]
			[Address(RVA = "0x47B764", Offset = "0x47B764", VA = "0x47B764")]
			get
			{
				return null;
			}
			[Token(Token = "0x6000D69")]
			[Address(RVA = "0x47B76C", Offset = "0x47B76C", VA = "0x47B76C")]
			private set
			{
			}
		}

		[Token(Token = "0x1700024F")]
		public int columnCount
		{
			[Token(Token = "0x6000D6A")]
			[Address(RVA = "0x47B774", Offset = "0x47B774", VA = "0x47B774")]
			get
			{
				return default(int);
			}
			[Token(Token = "0x6000D6B")]
			[Address(RVA = "0x47B77C", Offset = "0x47B77C", VA = "0x47B77C")]
			private set
			{
			}
		}

		[Token(Token = "0x17000250")]
		public int rowCount
		{
			[Token(Token = "0x6000D6C")]
			[Address(RVA = "0x47B784", Offset = "0x47B784", VA = "0x47B784")]
			get
			{
				return default(int);
			}
			[Token(Token = "0x6000D6D")]
			[Address(RVA = "0x47B78C", Offset = "0x47B78C", VA = "0x47B78C")]
			private set
			{
			}
		}

		[Token(Token = "0x6000D6E")]
		[Address(RVA = "0x47B794", Offset = "0x47B794", VA = "0x47B794")]
		public void BuildMesh(int columns, int rows)
		{
		}

		[Token(Token = "0x6000D6F")]
		[Address(RVA = "0x47BAE4", Offset = "0x47BAE4", VA = "0x47BAE4")]
		public void Release()
		{
		}

		[Token(Token = "0x6000D70")]
		[Address(RVA = "0x47BB10", Offset = "0x47BB10", VA = "0x47BB10")]
		public ArrowArray()
		{
		}
	}

	[Token(Token = "0x4000A61")]
	private const string k_ShaderString = "Hidden/Post FX/Builtin Debug Views";

	[Token(Token = "0x4000A62")]
	[FieldOffset(Offset = "0x20")]
	private ArrowArray m_Arrows;

	[Token(Token = "0x17000173")]
	public override bool active
	{
		[Token(Token = "0x60008F2")]
		[Address(RVA = "0x5B1DD4", Offset = "0x5B1DD4", VA = "0x5B1DD4", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x60008F3")]
	[Address(RVA = "0x5B1E40", Offset = "0x5B1E40", VA = "0x5B1E40", Slot = "4")]
	public override DepthTextureMode GetCameraFlags()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(DepthTextureMode);
	}

	[Token(Token = "0x60008F4")]
	[Address(RVA = "0x5B1EB0", Offset = "0x5B1EB0", VA = "0x5B1EB0", Slot = "10")]
	public override CameraEvent GetCameraEvent()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(CameraEvent);
	}

	[Token(Token = "0x60008F5")]
	[Address(RVA = "0x5B1F10", Offset = "0x5B1F10", VA = "0x5B1F10", Slot = "11")]
	public override string GetName()
	{
		return null;
	}

	[Token(Token = "0x60008F6")]
	[Address(RVA = "0x5B1F58", Offset = "0x5B1F58", VA = "0x5B1F58", Slot = "12")]
	public override void PopulateCommandBuffer(CommandBuffer cb)
	{
	}

	[Token(Token = "0x60008F7")]
	[Address(RVA = "0x5B2068", Offset = "0x5B2068", VA = "0x5B2068")]
	private void DepthPass(CommandBuffer cb)
	{
	}

	[Token(Token = "0x60008F8")]
	[Address(RVA = "0x5B2180", Offset = "0x5B2180", VA = "0x5B2180")]
	private void DepthNormalsPass(CommandBuffer cb)
	{
	}

	[Token(Token = "0x60008F9")]
	[Address(RVA = "0x5B2244", Offset = "0x5B2244", VA = "0x5B2244")]
	private void MotionVectorsPass(CommandBuffer cb)
	{
	}

	[Token(Token = "0x60008FA")]
	[Address(RVA = "0x5B27D0", Offset = "0x5B27D0", VA = "0x5B27D0")]
	private void PrepareArrows()
	{
	}

	[Token(Token = "0x60008FB")]
	[Address(RVA = "0x5B28C8", Offset = "0x5B28C8", VA = "0x5B28C8", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x60008FC")]
	[Address(RVA = "0x5B28F8", Offset = "0x5B28F8", VA = "0x5B28F8")]
	public BuiltinDebugViewsComponent()
	{
	}
}
