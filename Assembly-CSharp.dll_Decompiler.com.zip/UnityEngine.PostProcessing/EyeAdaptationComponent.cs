using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000171")]
public sealed class EyeAdaptationComponent : PostProcessingComponentRenderTexture<EyeAdaptationModel>
{
	[Token(Token = "0x200020A")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DF0")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _Params;

		[Token(Token = "0x4000DF1")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _Speed;

		[Token(Token = "0x4000DF2")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _ScaleOffsetRes;

		[Token(Token = "0x4000DF3")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _ExposureCompensation;

		[Token(Token = "0x4000DF4")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _AutoExposure;

		[Token(Token = "0x4000DF5")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _DebugWidth;
	}

	[Token(Token = "0x4000A6F")]
	[FieldOffset(Offset = "0x20")]
	private ComputeShader m_EyeCompute;

	[Token(Token = "0x4000A70")]
	[FieldOffset(Offset = "0x28")]
	private ComputeBuffer m_HistogramBuffer;

	[Token(Token = "0x4000A71")]
	[FieldOffset(Offset = "0x30")]
	private readonly RenderTexture[] m_AutoExposurePool;

	[Token(Token = "0x4000A72")]
	[FieldOffset(Offset = "0x38")]
	private int m_AutoExposurePingPing;

	[Token(Token = "0x4000A73")]
	[FieldOffset(Offset = "0x40")]
	private RenderTexture m_CurrentAutoExposure;

	[Token(Token = "0x4000A74")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture m_DebugHistogram;

	[Token(Token = "0x4000A75")]
	[FieldOffset(Offset = "0x0")]
	private static uint[] s_EmptyHistogramBuffer;

	[Token(Token = "0x4000A76")]
	[FieldOffset(Offset = "0x50")]
	private bool m_FirstFrame;

	[Token(Token = "0x4000A77")]
	private const int k_HistogramBins = 64;

	[Token(Token = "0x4000A78")]
	private const int k_HistogramThreadX = 16;

	[Token(Token = "0x4000A79")]
	private const int k_HistogramThreadY = 16;

	[Token(Token = "0x17000178")]
	public override bool active
	{
		[Token(Token = "0x6000926")]
		[Address(RVA = "0x388398", Offset = "0x388398", VA = "0x388398", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000927")]
	[Address(RVA = "0x388414", Offset = "0x388414", VA = "0x388414")]
	public void ResetHistory()
	{
	}

	[Token(Token = "0x6000928")]
	[Address(RVA = "0x388420", Offset = "0x388420", VA = "0x388420", Slot = "6")]
	public override void OnEnable()
	{
	}

	[Token(Token = "0x6000929")]
	[Address(RVA = "0x38842C", Offset = "0x38842C", VA = "0x38842C", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x600092A")]
	[Address(RVA = "0x388524", Offset = "0x388524", VA = "0x388524")]
	private Vector4 GetHistogramScaleOffsetRes()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector4);
	}

	[Token(Token = "0x600092B")]
	[Address(RVA = "0x388648", Offset = "0x388648", VA = "0x388648")]
	public Texture Prepare(RenderTexture source, Material uberMaterial)
	{
		return null;
	}

	[Token(Token = "0x600092C")]
	[Address(RVA = "0x388FA0", Offset = "0x388FA0", VA = "0x388FA0")]
	public void OnGUI()
	{
	}

	[Token(Token = "0x600092D")]
	[Address(RVA = "0x38911C", Offset = "0x38911C", VA = "0x38911C")]
	public EyeAdaptationComponent()
	{
	}
}
