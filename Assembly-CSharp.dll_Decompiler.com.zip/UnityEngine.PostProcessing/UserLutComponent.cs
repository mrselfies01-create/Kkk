using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000178")]
public sealed class UserLutComponent : PostProcessingComponentRenderTexture<UserLutModel>
{
	[Token(Token = "0x2000215")]
	private static class Uniforms
	{
		[Token(Token = "0x4000E5D")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _UserLut;

		[Token(Token = "0x4000E5E")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _UserLut_Params;
	}

	[Token(Token = "0x17000182")]
	public override bool active
	{
		[Token(Token = "0x600095A")]
		[Address(RVA = "0x477B00", Offset = "0x477B00", VA = "0x477B00", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x600095B")]
	[Address(RVA = "0x477C30", Offset = "0x477C30", VA = "0x477C30", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x600095C")]
	[Address(RVA = "0x477D88", Offset = "0x477D88", VA = "0x477D88")]
	public void OnGUI()
	{
	}

	[Token(Token = "0x600095D")]
	[Address(RVA = "0x477EAC", Offset = "0x477EAC", VA = "0x477EAC")]
	public UserLutComponent()
	{
	}
}
