using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x200016E")]
public sealed class ColorGradingComponent : PostProcessingComponentRenderTexture<ColorGradingModel>
{
	[Token(Token = "0x2000207")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DCF")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _LutParams;

		[Token(Token = "0x4000DD0")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _NeutralTonemapperParams1;

		[Token(Token = "0x4000DD1")]
		[FieldOffset(Offset = "0x8")]
		internal static readonly int _NeutralTonemapperParams2;

		[Token(Token = "0x4000DD2")]
		[FieldOffset(Offset = "0xC")]
		internal static readonly int _HueShift;

		[Token(Token = "0x4000DD3")]
		[FieldOffset(Offset = "0x10")]
		internal static readonly int _Saturation;

		[Token(Token = "0x4000DD4")]
		[FieldOffset(Offset = "0x14")]
		internal static readonly int _Contrast;

		[Token(Token = "0x4000DD5")]
		[FieldOffset(Offset = "0x18")]
		internal static readonly int _Balance;

		[Token(Token = "0x4000DD6")]
		[FieldOffset(Offset = "0x1C")]
		internal static readonly int _Lift;

		[Token(Token = "0x4000DD7")]
		[FieldOffset(Offset = "0x20")]
		internal static readonly int _InvGamma;

		[Token(Token = "0x4000DD8")]
		[FieldOffset(Offset = "0x24")]
		internal static readonly int _Gain;

		[Token(Token = "0x4000DD9")]
		[FieldOffset(Offset = "0x28")]
		internal static readonly int _Slope;

		[Token(Token = "0x4000DDA")]
		[FieldOffset(Offset = "0x2C")]
		internal static readonly int _Power;

		[Token(Token = "0x4000DDB")]
		[FieldOffset(Offset = "0x30")]
		internal static readonly int _Offset;

		[Token(Token = "0x4000DDC")]
		[FieldOffset(Offset = "0x34")]
		internal static readonly int _ChannelMixerRed;

		[Token(Token = "0x4000DDD")]
		[FieldOffset(Offset = "0x38")]
		internal static readonly int _ChannelMixerGreen;

		[Token(Token = "0x4000DDE")]
		[FieldOffset(Offset = "0x3C")]
		internal static readonly int _ChannelMixerBlue;

		[Token(Token = "0x4000DDF")]
		[FieldOffset(Offset = "0x40")]
		internal static readonly int _Curves;

		[Token(Token = "0x4000DE0")]
		[FieldOffset(Offset = "0x44")]
		internal static readonly int _LogLut;

		[Token(Token = "0x4000DE1")]
		[FieldOffset(Offset = "0x48")]
		internal static readonly int _LogLut_Params;

		[Token(Token = "0x4000DE2")]
		[FieldOffset(Offset = "0x4C")]
		internal static readonly int _ExposureEV;
	}

	[Token(Token = "0x4000A64")]
	private const int k_InternalLogLutSize = 32;

	[Token(Token = "0x4000A65")]
	private const int k_CurvePrecision = 128;

	[Token(Token = "0x4000A66")]
	private const float k_CurveStep = 1f / 128f;

	[Token(Token = "0x4000A67")]
	[FieldOffset(Offset = "0x20")]
	private Texture2D m_GradingCurves;

	[Token(Token = "0x4000A68")]
	[FieldOffset(Offset = "0x28")]
	private Color[] m_pixels;

	[Token(Token = "0x17000175")]
	public override bool active
	{
		[Token(Token = "0x6000901")]
		[Address(RVA = "0x383230", Offset = "0x383230", VA = "0x383230", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000902")]
	[Address(RVA = "0x3832A0", Offset = "0x3832A0", VA = "0x3832A0")]
	private float StandardIlluminantY(float x)
	{
		return default(float);
	}

	[Token(Token = "0x6000903")]
	[Address(RVA = "0x3832CC", Offset = "0x3832CC", VA = "0x3832CC")]
	private Vector3 CIExyToLMS(float x, float y)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000904")]
	[Address(RVA = "0x38335C", Offset = "0x38335C", VA = "0x38335C")]
	private Vector3 CalculateColorBalance(float temperature, float tint)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000905")]
	[Address(RVA = "0x38347C", Offset = "0x38347C", VA = "0x38347C")]
	private static Color NormalizeColor(Color c)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Color);
	}

	[Token(Token = "0x6000906")]
	[Address(RVA = "0x383570", Offset = "0x383570", VA = "0x383570")]
	private static Vector3 ClampVector(Vector3 v, float min, float max)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000907")]
	[Address(RVA = "0x383648", Offset = "0x383648", VA = "0x383648")]
	public static Vector3 GetLiftValue(Color lift)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000908")]
	[Address(RVA = "0x3836AC", Offset = "0x3836AC", VA = "0x3836AC")]
	public static Vector3 GetGammaValue(Color gamma)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000909")]
	[Address(RVA = "0x383804", Offset = "0x383804", VA = "0x383804")]
	public static Vector3 GetGainValue(Color gain)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x600090A")]
	[Address(RVA = "0x38390C", Offset = "0x38390C", VA = "0x38390C")]
	public static void CalculateLiftGammaGain(Color lift, Color gamma, Color gain, out Vector3 outLift, out Vector3 outGamma, out Vector3 outGain)
	{
	}

	[Token(Token = "0x600090B")]
	[Address(RVA = "0x3839B4", Offset = "0x3839B4", VA = "0x3839B4")]
	public static Vector3 GetSlopeValue(Color slope)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x600090C")]
	[Address(RVA = "0x383A30", Offset = "0x383A30", VA = "0x383A30")]
	public static Vector3 GetPowerValue(Color power)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x600090D")]
	[Address(RVA = "0x383B70", Offset = "0x383B70", VA = "0x383B70")]
	public static Vector3 GetOffsetValue(Color offset)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x600090E")]
	[Address(RVA = "0x383BE4", Offset = "0x383BE4", VA = "0x383BE4")]
	public static void CalculateSlopePowerOffset(Color slope, Color power, Color offset, out Vector3 outSlope, out Vector3 outPower, out Vector3 outOffset)
	{
	}

	[Token(Token = "0x600090F")]
	[Address(RVA = "0x383C8C", Offset = "0x383C8C", VA = "0x383C8C")]
	private TextureFormat GetCurveFormat()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(TextureFormat);
	}

	[Token(Token = "0x6000910")]
	[Address(RVA = "0x383CC0", Offset = "0x383CC0", VA = "0x383CC0")]
	private Texture2D GetCurveTexture()
	{
		return null;
	}

	[Token(Token = "0x6000911")]
	[Address(RVA = "0x384254", Offset = "0x384254", VA = "0x384254")]
	private bool IsLogLutValid(RenderTexture lut)
	{
		return default(bool);
	}

	[Token(Token = "0x6000912")]
	[Address(RVA = "0x384300", Offset = "0x384300", VA = "0x384300")]
	private RenderTextureFormat GetLutFormat()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(RenderTextureFormat);
	}

	[Token(Token = "0x6000913")]
	[Address(RVA = "0x384330", Offset = "0x384330", VA = "0x384330")]
	private void GenerateLut()
	{
	}

	[Token(Token = "0x6000914")]
	[Address(RVA = "0x384E1C", Offset = "0x384E1C", VA = "0x384E1C", Slot = "10")]
	public override void Prepare(Material uberMaterial)
	{
	}

	[Token(Token = "0x6000915")]
	[Address(RVA = "0x385054", Offset = "0x385054", VA = "0x385054")]
	public void OnGUI()
	{
	}

	[Token(Token = "0x6000916")]
	[Address(RVA = "0x38519C", Offset = "0x38519C", VA = "0x38519C", Slot = "7")]
	public override void OnDisable()
	{
	}

	[Token(Token = "0x6000917")]
	[Address(RVA = "0x385208", Offset = "0x385208", VA = "0x385208")]
	public ColorGradingComponent()
	{
	}
}
