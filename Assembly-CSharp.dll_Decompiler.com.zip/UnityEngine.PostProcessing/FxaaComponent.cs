using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000173")]
public sealed class FxaaComponent : PostProcessingComponentRenderTexture<AntialiasingModel>
{
	[Token(Token = "0x200020C")]
	private static class Uniforms
	{
		[Token(Token = "0x4000DFB")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _QualitySettings;

		[Token(Token = "0x4000DFC")]
		[FieldOffset(Offset = "0x4")]
		internal static readonly int _ConsoleSettings;
	}

	[Token(Token = "0x1700017A")]
	public override bool active
	{
		[Token(Token = "0x6000934")]
		[Address(RVA = "0x38A98C", Offset = "0x38A98C", VA = "0x38A98C", Slot = "5")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000935")]
	[Address(RVA = "0x38AA04", Offset = "0x38AA04", VA = "0x38AA04")]
	public void Render(RenderTexture source, RenderTexture destination)
	{
	}

	[Token(Token = "0x6000936")]
	[Address(RVA = "0x38AC50", Offset = "0x38AC50", VA = "0x38AC50")]
	public FxaaComponent()
	{
	}
}
