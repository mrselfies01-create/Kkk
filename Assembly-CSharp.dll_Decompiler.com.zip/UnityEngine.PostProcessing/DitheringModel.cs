using System;
using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Serializable]
[Token(Token = "0x2000181")]
public class DitheringModel : PostProcessingModel
{
	[Serializable]
	[Token(Token = "0x2000234")]
	public struct Settings
	{
		[Token(Token = "0x17000266")]
		public static Settings defaultSettings
		{
			[Token(Token = "0x6000DA1")]
			[Address(RVA = "0x78C7CC", Offset = "0x78C7CC", VA = "0x78C7CC")]
			get
			{
				return default(Settings);
			}
		}
	}

	[Token(Token = "0x4000A94")]
	[FieldOffset(Offset = "0x11")]
	private Settings m_Settings;

	[Token(Token = "0x1700018E")]
	public Settings settings
	{
		[Token(Token = "0x6000984")]
		[Address(RVA = "0x387F24", Offset = "0x387F24", VA = "0x387F24")]
		get
		{
			return default(Settings);
		}
		[Token(Token = "0x6000985")]
		[Address(RVA = "0x387F2C", Offset = "0x387F2C", VA = "0x387F2C")]
		set
		{
		}
	}

	[Token(Token = "0x6000986")]
	[Address(RVA = "0x387F34", Offset = "0x387F34", VA = "0x387F34", Slot = "4")]
	public override void Reset()
	{
	}

	[Token(Token = "0x6000987")]
	[Address(RVA = "0x387F5C", Offset = "0x387F5C", VA = "0x387F5C")]
	public DitheringModel()
	{
	}
}
