using Il2CppDummyDll;

namespace UnityEngine.PostProcessing;

[Token(Token = "0x2000192")]
public static class GraphicsUtils
{
	[Token(Token = "0x4000AD5")]
	[FieldOffset(Offset = "0x0")]
	private static Texture2D s_WhiteTexture;

	[Token(Token = "0x4000AD6")]
	[FieldOffset(Offset = "0x8")]
	private static Mesh s_Quad;

	[Token(Token = "0x1700019F")]
	public static bool isLinearColorSpace
	{
		[Token(Token = "0x60009D9")]
		[Address(RVA = "0x38A350", Offset = "0x38A350", VA = "0x38A350")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x170001A0")]
	public static bool supportsDX11
	{
		[Token(Token = "0x60009DA")]
		[Address(RVA = "0x38BB58", Offset = "0x38BB58", VA = "0x38BB58")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x170001A1")]
	public static Texture2D whiteTexture
	{
		[Token(Token = "0x60009DB")]
		[Address(RVA = "0x38BB88", Offset = "0x38BB88", VA = "0x38BB88")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x170001A2")]
	public static Mesh quad
	{
		[Token(Token = "0x60009DC")]
		[Address(RVA = "0x38BCC0", Offset = "0x38BCC0", VA = "0x38BCC0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60009DD")]
	[Address(RVA = "0x38BEFC", Offset = "0x38BEFC", VA = "0x38BEFC")]
	public static void Blit(Material material, int pass)
	{
	}

	[Token(Token = "0x60009DE")]
	[Address(RVA = "0x38C000", Offset = "0x38C000", VA = "0x38C000")]
	public static void ClearAndBlit(Texture source, RenderTexture destination, Material material, int pass, bool clearColor = true, bool clearDepth = false)
	{
	}

	[Token(Token = "0x60009DF")]
	[Address(RVA = "0x384BAC", Offset = "0x384BAC", VA = "0x384BAC")]
	public static void Destroy(Object obj)
	{
	}

	[Token(Token = "0x60009E0")]
	[Address(RVA = "0x38C19C", Offset = "0x38C19C", VA = "0x38C19C")]
	public static void Dispose()
	{
	}
}
