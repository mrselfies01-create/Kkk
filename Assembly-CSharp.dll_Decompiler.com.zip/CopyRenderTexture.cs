using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;

[Token(Token = "0x2000131")]
public class CopyRenderTexture : MonoBehaviour
{
	[Token(Token = "0x20001F4")]
	private sealed class _003CUpdateTexture_003Ed__2 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D79")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D7A")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D7B")]
		[FieldOffset(Offset = "0x20")]
		public CopyRenderTexture _003C_003E4__this;

		[Token(Token = "0x17000240")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D3D")]
			[Address(RVA = "0x78C508", Offset = "0x78C508", VA = "0x78C508", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000241")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D3F")]
			[Address(RVA = "0x78C570", Offset = "0x78C570", VA = "0x78C570", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D3A")]
		[Address(RVA = "0x78C404", Offset = "0x78C404", VA = "0x78C404")]
		public _003CUpdateTexture_003Ed__2(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D3B")]
		[Address(RVA = "0x78C430", Offset = "0x78C430", VA = "0x78C430", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D3C")]
		[Address(RVA = "0x78C434", Offset = "0x78C434", VA = "0x78C434", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D3E")]
		[Address(RVA = "0x78C510", Offset = "0x78C510", VA = "0x78C510", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x40008A4")]
	[FieldOffset(Offset = "0x18")]
	public RenderTexture tex;

	[Token(Token = "0x600077D")]
	[Address(RVA = "0x3858F4", Offset = "0x3858F4", VA = "0x3858F4")]
	private void Start()
	{
	}

	[Token(Token = "0x600077E")]
	[Address(RVA = "0x385920", Offset = "0x385920", VA = "0x385920")]
	public IEnumerator UpdateTexture()
	{
		return null;
	}

	[Token(Token = "0x600077F")]
	[Address(RVA = "0x385990", Offset = "0x385990", VA = "0x385990")]
	private void Update()
	{
	}

	[Token(Token = "0x6000780")]
	[Address(RVA = "0x385994", Offset = "0x385994", VA = "0x385994")]
	public CopyRenderTexture()
	{
	}
}
