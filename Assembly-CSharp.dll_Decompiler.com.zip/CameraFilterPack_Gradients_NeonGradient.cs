using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D2")]
public class CameraFilterPack_Gradients_NeonGradient : MonoBehaviour
{
	[Token(Token = "0x4000613")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000614")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x4000615")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x4000616")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000617")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000618")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D3")]
	private Material material
	{
		[Token(Token = "0x6000520")]
		[Address(RVA = "0x6A3784", Offset = "0x6A3784", VA = "0x6A3784")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000521")]
	[Address(RVA = "0x6A3848", Offset = "0x6A3848", VA = "0x6A3848")]
	private void Start()
	{
	}

	[Token(Token = "0x6000522")]
	[Address(RVA = "0x6A3898", Offset = "0x6A3898", VA = "0x6A3898")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000523")]
	[Address(RVA = "0x6A3AD4", Offset = "0x6A3AD4", VA = "0x6A3AD4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000524")]
	[Address(RVA = "0x6A3AD8", Offset = "0x6A3AD8", VA = "0x6A3AD8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000525")]
	[Address(RVA = "0x6A3B88", Offset = "0x6A3B88", VA = "0x6A3B88")]
	public CameraFilterPack_Gradients_NeonGradient()
	{
	}
}
