using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D9")]
public class CameraFilterPack_Light_Water : MonoBehaviour
{
	[Token(Token = "0x4000639")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400063A")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400063B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400063C")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400063D")]
	[FieldOffset(Offset = "0x34")]
	public float Alpha;

	[Token(Token = "0x400063E")]
	[FieldOffset(Offset = "0x38")]
	public float Distance;

	[Token(Token = "0x400063F")]
	[FieldOffset(Offset = "0x3C")]
	public float Speed;

	[Token(Token = "0x170000DA")]
	private Material material
	{
		[Token(Token = "0x600054A")]
		[Address(RVA = "0x6A55E8", Offset = "0x6A55E8", VA = "0x6A55E8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600054B")]
	[Address(RVA = "0x6A56AC", Offset = "0x6A56AC", VA = "0x6A56AC")]
	private void Start()
	{
	}

	[Token(Token = "0x600054C")]
	[Address(RVA = "0x6A5728", Offset = "0x6A5728", VA = "0x6A5728")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600054D")]
	[Address(RVA = "0x6A5990", Offset = "0x6A5990", VA = "0x6A5990")]
	private void Update()
	{
	}

	[Token(Token = "0x600054E")]
	[Address(RVA = "0x6A5994", Offset = "0x6A5994", VA = "0x6A5994")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600054F")]
	[Address(RVA = "0x6A5A44", Offset = "0x6A5A44", VA = "0x6A5A44")]
	public CameraFilterPack_Light_Water()
	{
	}
}
