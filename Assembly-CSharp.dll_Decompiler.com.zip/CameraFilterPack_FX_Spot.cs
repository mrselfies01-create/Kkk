using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BE")]
public class CameraFilterPack_FX_Spot : MonoBehaviour
{
	[Token(Token = "0x400056A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400056B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400056C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400056D")]
	[FieldOffset(Offset = "0x30")]
	public Vector2 center;

	[Token(Token = "0x400056E")]
	[FieldOffset(Offset = "0x38")]
	public float Radius;

	[Token(Token = "0x170000BF")]
	private Material material
	{
		[Token(Token = "0x60004A8")]
		[Address(RVA = "0x69D074", Offset = "0x69D074", VA = "0x69D074")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004A9")]
	[Address(RVA = "0x69D138", Offset = "0x69D138", VA = "0x69D138")]
	private void Start()
	{
	}

	[Token(Token = "0x60004AA")]
	[Address(RVA = "0x69D1B4", Offset = "0x69D1B4", VA = "0x69D1B4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004AB")]
	[Address(RVA = "0x69D414", Offset = "0x69D414", VA = "0x69D414")]
	private void Update()
	{
	}

	[Token(Token = "0x60004AC")]
	[Address(RVA = "0x69D418", Offset = "0x69D418", VA = "0x69D418")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004AD")]
	[Address(RVA = "0x69D4C8", Offset = "0x69D4C8", VA = "0x69D4C8")]
	public CameraFilterPack_FX_Spot()
	{
	}
}
