using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012C")]
public class CameraFilterPack_Vision_Rainbow : MonoBehaviour
{
	[Token(Token = "0x4000878")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000879")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400087A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400087B")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x400087C")]
	[FieldOffset(Offset = "0x34")]
	public float PosX;

	[Token(Token = "0x400087D")]
	[FieldOffset(Offset = "0x38")]
	public float PosY;

	[Token(Token = "0x400087E")]
	[FieldOffset(Offset = "0x3C")]
	public float Colors;

	[Token(Token = "0x400087F")]
	[FieldOffset(Offset = "0x40")]
	public float Vision;

	[Token(Token = "0x1700012D")]
	private Material material
	{
		[Token(Token = "0x600075F")]
		[Address(RVA = "0x63FCC4", Offset = "0x63FCC4", VA = "0x63FCC4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000760")]
	[Address(RVA = "0x63FD88", Offset = "0x63FD88", VA = "0x63FD88")]
	private void Start()
	{
	}

	[Token(Token = "0x6000761")]
	[Address(RVA = "0x63FE04", Offset = "0x63FE04", VA = "0x63FE04")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000762")]
	[Address(RVA = "0x6400AC", Offset = "0x6400AC", VA = "0x6400AC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000763")]
	[Address(RVA = "0x6400B0", Offset = "0x6400B0", VA = "0x6400B0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000764")]
	[Address(RVA = "0x640160", Offset = "0x640160", VA = "0x640160")]
	public CameraFilterPack_Vision_Rainbow()
	{
	}
}
