using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000A")]
public class CameraFilterPack_3D_Computer : MonoBehaviour
{
	[Token(Token = "0x400003A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400003B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400003C")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x400003D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400003E")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x400003F")]
	[FieldOffset(Offset = "0x34")]
	public float LightIntensity;

	[Token(Token = "0x4000040")]
	[FieldOffset(Offset = "0x38")]
	public float MatrixSize;

	[Token(Token = "0x4000041")]
	[FieldOffset(Offset = "0x3C")]
	public float MatrixSpeed;

	[Token(Token = "0x4000042")]
	[FieldOffset(Offset = "0x40")]
	public float Fade;

	[Token(Token = "0x4000043")]
	[FieldOffset(Offset = "0x44")]
	public Color _MatrixColor;

	[Token(Token = "0x4000044")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x4000045")]
	[FieldOffset(Offset = "0x58")]
	private Texture2D Texture2;

	[Token(Token = "0x1700000B")]
	private Material material
	{
		[Token(Token = "0x600002E")]
		[Address(RVA = "0x5B3BA4", Offset = "0x5B3BA4", VA = "0x5B3BA4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600002F")]
	[Address(RVA = "0x5B3C68", Offset = "0x5B3C68", VA = "0x5B3C68")]
	private void Start()
	{
	}

	[Token(Token = "0x6000030")]
	[Address(RVA = "0x5B3D20", Offset = "0x5B3D20", VA = "0x5B3D20")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000031")]
	[Address(RVA = "0x5B40B8", Offset = "0x5B40B8", VA = "0x5B40B8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000032")]
	[Address(RVA = "0x5B40BC", Offset = "0x5B40BC", VA = "0x5B40BC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000033")]
	[Address(RVA = "0x5B416C", Offset = "0x5B416C", VA = "0x5B416C")]
	public CameraFilterPack_3D_Computer()
	{
	}
}
