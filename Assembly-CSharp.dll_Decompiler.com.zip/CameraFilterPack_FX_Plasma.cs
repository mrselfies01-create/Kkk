using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BA")]
public class CameraFilterPack_FX_Plasma : MonoBehaviour
{
	[Token(Token = "0x4000553")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000554")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000555")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000556")]
	[FieldOffset(Offset = "0x30")]
	private float Value;

	[Token(Token = "0x170000BB")]
	private Material material
	{
		[Token(Token = "0x6000490")]
		[Address(RVA = "0x69BF28", Offset = "0x69BF28", VA = "0x69BF28")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000491")]
	[Address(RVA = "0x69BFEC", Offset = "0x69BFEC", VA = "0x69BFEC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000492")]
	[Address(RVA = "0x69C068", Offset = "0x69C068", VA = "0x69C068")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000493")]
	[Address(RVA = "0x69C280", Offset = "0x69C280", VA = "0x69C280")]
	private void Update()
	{
	}

	[Token(Token = "0x6000494")]
	[Address(RVA = "0x69C284", Offset = "0x69C284", VA = "0x69C284")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000495")]
	[Address(RVA = "0x69C334", Offset = "0x69C334", VA = "0x69C334")]
	public CameraFilterPack_FX_Plasma()
	{
	}
}
