using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000087")]
public class CameraFilterPack_Drawing_Comics : MonoBehaviour
{
	[Token(Token = "0x4000424")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000425")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000426")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000427")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x17000088")]
	private Material material
	{
		[Token(Token = "0x600035D")]
		[Address(RVA = "0x677FA4", Offset = "0x677FA4", VA = "0x677FA4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600035E")]
	[Address(RVA = "0x678068", Offset = "0x678068", VA = "0x678068")]
	private void Start()
	{
	}

	[Token(Token = "0x600035F")]
	[Address(RVA = "0x6780E4", Offset = "0x6780E4", VA = "0x6780E4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000360")]
	[Address(RVA = "0x678268", Offset = "0x678268", VA = "0x678268")]
	private void Update()
	{
	}

	[Token(Token = "0x6000361")]
	[Address(RVA = "0x67826C", Offset = "0x67826C", VA = "0x67826C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000362")]
	[Address(RVA = "0x67831C", Offset = "0x67831C", VA = "0x67831C")]
	public CameraFilterPack_Drawing_Comics()
	{
	}
}
