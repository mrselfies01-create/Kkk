using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007A")]
public class CameraFilterPack_Distortion_Half_Sphere : MonoBehaviour
{
	[Token(Token = "0x40003D0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003D1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003D2")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003D3")]
	[FieldOffset(Offset = "0x30")]
	public float SphereSize;

	[Token(Token = "0x40003D4")]
	[FieldOffset(Offset = "0x34")]
	public float SpherePositionX;

	[Token(Token = "0x40003D5")]
	[FieldOffset(Offset = "0x38")]
	public float SpherePositionY;

	[Token(Token = "0x40003D6")]
	[FieldOffset(Offset = "0x3C")]
	public float Strength;

	[Token(Token = "0x1700007B")]
	private Material material
	{
		[Token(Token = "0x600030F")]
		[Address(RVA = "0x674568", Offset = "0x674568", VA = "0x674568")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000310")]
	[Address(RVA = "0x67462C", Offset = "0x67462C", VA = "0x67462C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000311")]
	[Address(RVA = "0x6746A8", Offset = "0x6746A8", VA = "0x6746A8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000312")]
	[Address(RVA = "0x67491C", Offset = "0x67491C", VA = "0x67491C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000313")]
	[Address(RVA = "0x674920", Offset = "0x674920", VA = "0x674920")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000314")]
	[Address(RVA = "0x6749D0", Offset = "0x6749D0", VA = "0x6749D0")]
	public CameraFilterPack_Distortion_Half_Sphere()
	{
	}
}
