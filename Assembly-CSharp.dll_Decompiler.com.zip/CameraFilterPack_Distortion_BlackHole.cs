using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000073")]
public class CameraFilterPack_Distortion_BlackHole : MonoBehaviour
{
	[Token(Token = "0x40003AC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003AD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003AE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003AF")]
	[FieldOffset(Offset = "0x30")]
	public float PositionX;

	[Token(Token = "0x40003B0")]
	[FieldOffset(Offset = "0x34")]
	public float PositionY;

	[Token(Token = "0x40003B1")]
	[FieldOffset(Offset = "0x38")]
	public float Size;

	[Token(Token = "0x40003B2")]
	[FieldOffset(Offset = "0x3C")]
	public float Distortion;

	[Token(Token = "0x17000074")]
	private Material material
	{
		[Token(Token = "0x60002E5")]
		[Address(RVA = "0x672824", Offset = "0x672824", VA = "0x672824")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002E6")]
	[Address(RVA = "0x6728E8", Offset = "0x6728E8", VA = "0x6728E8")]
	private void Start()
	{
	}

	[Token(Token = "0x60002E7")]
	[Address(RVA = "0x672964", Offset = "0x672964", VA = "0x672964")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002E8")]
	[Address(RVA = "0x672BD8", Offset = "0x672BD8", VA = "0x672BD8")]
	private void Update()
	{
	}

	[Token(Token = "0x60002E9")]
	[Address(RVA = "0x672BDC", Offset = "0x672BDC", VA = "0x672BDC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002EA")]
	[Address(RVA = "0x672C8C", Offset = "0x672C8C", VA = "0x672C8C")]
	public CameraFilterPack_Distortion_BlackHole()
	{
	}
}
