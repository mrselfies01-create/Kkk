using Il2CppDummyDll;

namespace UnityEngine.UI.Extensions;

[Token(Token = "0x20001A3")]
public class SoftMaskScript : MonoBehaviour
{
	[Token(Token = "0x4000B1C")]
	[FieldOffset(Offset = "0x18")]
	private Material mat;

	[Token(Token = "0x4000B1D")]
	[FieldOffset(Offset = "0x20")]
	private Canvas cachedCanvas;

	[Token(Token = "0x4000B1E")]
	[FieldOffset(Offset = "0x28")]
	private Transform cachedCanvasTransform;

	[Token(Token = "0x4000B1F")]
	[FieldOffset(Offset = "0x30")]
	private readonly Vector3[] m_WorldCorners;

	[Token(Token = "0x4000B20")]
	[FieldOffset(Offset = "0x38")]
	private readonly Vector3[] m_CanvasCorners;

	[Token(Token = "0x4000B21")]
	[FieldOffset(Offset = "0x40")]
	public RectTransform MaskArea;

	[Token(Token = "0x4000B22")]
	[FieldOffset(Offset = "0x48")]
	public Texture AlphaMask;

	[Token(Token = "0x4000B23")]
	[FieldOffset(Offset = "0x50")]
	public float CutOff;

	[Token(Token = "0x4000B24")]
	[FieldOffset(Offset = "0x54")]
	public bool HardBlend;

	[Token(Token = "0x4000B25")]
	[FieldOffset(Offset = "0x55")]
	public bool FlipAlphaMask;

	[Token(Token = "0x4000B26")]
	[FieldOffset(Offset = "0x56")]
	public bool DontClipMaskScalingRect;

	[Token(Token = "0x4000B27")]
	[FieldOffset(Offset = "0x58")]
	private Vector2 maskOffset;

	[Token(Token = "0x4000B28")]
	[FieldOffset(Offset = "0x60")]
	private Vector2 maskScale;

	[Token(Token = "0x6000A51")]
	[Address(RVA = "0x3DCA48", Offset = "0x3DCA48", VA = "0x3DCA48")]
	private void Start()
	{
	}

	[Token(Token = "0x6000A52")]
	[Address(RVA = "0x3DCD50", Offset = "0x3DCD50", VA = "0x3DCD50")]
	private void Update()
	{
	}

	[Token(Token = "0x6000A53")]
	[Address(RVA = "0x3DCDD8", Offset = "0x3DCDD8", VA = "0x3DCDD8")]
	private void SetMask()
	{
	}

	[Token(Token = "0x6000A54")]
	[Address(RVA = "0x3DCF7C", Offset = "0x3DCF7C", VA = "0x3DCF7C")]
	public Rect GetCanvasRect()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Rect);
	}

	[Token(Token = "0x6000A55")]
	[Address(RVA = "0x3DD0E4", Offset = "0x3DD0E4", VA = "0x3DD0E4")]
	public SoftMaskScript()
	{
	}
}
