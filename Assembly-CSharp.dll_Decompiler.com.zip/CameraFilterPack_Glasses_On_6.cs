using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C9")]
public class CameraFilterPack_Glasses_On_6 : MonoBehaviour
{
	[Token(Token = "0x40005CF")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005D0")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005D1")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40005D2")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x40005D3")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x40005D4")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x40005D5")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x40005D6")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x40005D7")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x40005D8")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x40005D9")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x40005DA")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x40005DB")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x40005DC")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000CA")]
	private Material material
	{
		[Token(Token = "0x60004EA")]
		[Address(RVA = "0x6A0948", Offset = "0x6A0948", VA = "0x6A0948")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004EB")]
	[Address(RVA = "0x6A0A0C", Offset = "0x6A0A0C", VA = "0x6A0A0C")]
	private void Start()
	{
	}

	[Token(Token = "0x60004EC")]
	[Address(RVA = "0x6A0AC4", Offset = "0x6A0AC4", VA = "0x6A0AC4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004ED")]
	[Address(RVA = "0x6A0DBC", Offset = "0x6A0DBC", VA = "0x6A0DBC")]
	private void Update()
	{
	}

	[Token(Token = "0x60004EE")]
	[Address(RVA = "0x6A0DC0", Offset = "0x6A0DC0", VA = "0x6A0DC0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004EF")]
	[Address(RVA = "0x6A0E70", Offset = "0x6A0E70", VA = "0x6A0E70")]
	public CameraFilterPack_Glasses_On_6()
	{
	}
}
