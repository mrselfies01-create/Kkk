using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000078")]
public class CameraFilterPack_Distortion_Flag : MonoBehaviour
{
	[Token(Token = "0x40003C7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003C8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003C9")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40003CA")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003CB")]
	[FieldOffset(Offset = "0x0")]
	public static float ChangeDistortion;

	[Token(Token = "0x17000079")]
	private Material material
	{
		[Token(Token = "0x6000303")]
		[Address(RVA = "0x673D38", Offset = "0x673D38", VA = "0x673D38")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000304")]
	[Address(RVA = "0x673DFC", Offset = "0x673DFC", VA = "0x673DFC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000305")]
	[Address(RVA = "0x673E78", Offset = "0x673E78", VA = "0x673E78")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000306")]
	[Address(RVA = "0x674080", Offset = "0x674080", VA = "0x674080")]
	private void Update()
	{
	}

	[Token(Token = "0x6000307")]
	[Address(RVA = "0x674084", Offset = "0x674084", VA = "0x674084")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000308")]
	[Address(RVA = "0x674134", Offset = "0x674134", VA = "0x674134")]
	public CameraFilterPack_Distortion_Flag()
	{
	}
}
