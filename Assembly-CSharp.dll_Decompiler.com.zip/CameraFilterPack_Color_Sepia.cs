using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000062")]
public class CameraFilterPack_Color_Sepia : MonoBehaviour
{
	[Token(Token = "0x4000344")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000345")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000346")]
	[FieldOffset(Offset = "0x24")]
	public float _Fade;

	[Token(Token = "0x4000347")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000063")]
	private Material material
	{
		[Token(Token = "0x600027D")]
		[Address(RVA = "0x66D564", Offset = "0x66D564", VA = "0x66D564")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600027E")]
	[Address(RVA = "0x66D628", Offset = "0x66D628", VA = "0x66D628")]
	private void Start()
	{
	}

	[Token(Token = "0x600027F")]
	[Address(RVA = "0x66D6A4", Offset = "0x66D6A4", VA = "0x66D6A4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000280")]
	[Address(RVA = "0x66D8BC", Offset = "0x66D8BC", VA = "0x66D8BC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000281")]
	[Address(RVA = "0x66D8C0", Offset = "0x66D8C0", VA = "0x66D8C0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000282")]
	[Address(RVA = "0x66D970", Offset = "0x66D970", VA = "0x66D970")]
	public CameraFilterPack_Color_Sepia()
	{
	}
}
