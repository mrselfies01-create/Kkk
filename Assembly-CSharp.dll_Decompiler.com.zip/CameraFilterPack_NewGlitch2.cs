using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E3")]
public class CameraFilterPack_NewGlitch2 : MonoBehaviour
{
	[Token(Token = "0x4000693")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000694")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000695")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000696")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x4000697")]
	[FieldOffset(Offset = "0x34")]
	public float _RedFade;

	[Token(Token = "0x170000E4")]
	private Material material
	{
		[Token(Token = "0x60005A2")]
		[Address(RVA = "0x62A448", Offset = "0x62A448", VA = "0x62A448")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005A3")]
	[Address(RVA = "0x62A50C", Offset = "0x62A50C", VA = "0x62A50C")]
	private void Start()
	{
	}

	[Token(Token = "0x60005A4")]
	[Address(RVA = "0x62A588", Offset = "0x62A588", VA = "0x62A588")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005A5")]
	[Address(RVA = "0x62A7C4", Offset = "0x62A7C4", VA = "0x62A7C4")]
	private void Update()
	{
	}

	[Token(Token = "0x60005A6")]
	[Address(RVA = "0x62A7C8", Offset = "0x62A7C8", VA = "0x62A7C8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005A7")]
	[Address(RVA = "0x62A878", Offset = "0x62A878", VA = "0x62A878")]
	public CameraFilterPack_NewGlitch2()
	{
	}
}
