using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000153")]
public class Gate : MonoBehaviour
{
	[Token(Token = "0x40009EA")]
	[FieldOffset(Offset = "0x18")]
	private Envelope envelope;

	[Token(Token = "0x40009EB")]
	[FieldOffset(Offset = "0x20")]
	private float sampleRate;

	[Token(Token = "0x40009EC")]
	[FieldOffset(Offset = "0x24")]
	private float _inputGain;

	[Token(Token = "0x40009ED")]
	[FieldOffset(Offset = "0x28")]
	private float _threshold;

	[Token(Token = "0x40009EE")]
	[FieldOffset(Offset = "0x2C")]
	private float _attack;

	[Token(Token = "0x40009EF")]
	[FieldOffset(Offset = "0x30")]
	public float _release;

	[Token(Token = "0x40009F0")]
	[FieldOffset(Offset = "0x34")]
	private float _outputGain;

	[Token(Token = "0x40009F1")]
	[FieldOffset(Offset = "0x38")]
	private float env;

	[Token(Token = "0x1700014C")]
	public float InputGain
	{
		[Token(Token = "0x6000861")]
		[Address(RVA = "0x38AD20", Offset = "0x38AD20", VA = "0x38AD20")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000862")]
		[Address(RVA = "0x38AD28", Offset = "0x38AD28", VA = "0x38AD28")]
		set
		{
		}
	}

	[Token(Token = "0x1700014D")]
	public float Threshold
	{
		[Token(Token = "0x6000863")]
		[Address(RVA = "0x38ADB8", Offset = "0x38ADB8", VA = "0x38ADB8")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000864")]
		[Address(RVA = "0x38ADC0", Offset = "0x38ADC0", VA = "0x38ADC0")]
		set
		{
		}
	}

	[Token(Token = "0x1700014E")]
	public float Attack
	{
		[Token(Token = "0x6000865")]
		[Address(RVA = "0x38AE50", Offset = "0x38AE50", VA = "0x38AE50")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000866")]
		[Address(RVA = "0x38AE58", Offset = "0x38AE58", VA = "0x38AE58")]
		set
		{
		}
	}

	[Token(Token = "0x1700014F")]
	public float Release
	{
		[Token(Token = "0x6000867")]
		[Address(RVA = "0x38AF04", Offset = "0x38AF04", VA = "0x38AF04")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000868")]
		[Address(RVA = "0x38AF0C", Offset = "0x38AF0C", VA = "0x38AF0C")]
		set
		{
		}
	}

	[Token(Token = "0x17000150")]
	public float OutputGain
	{
		[Token(Token = "0x6000869")]
		[Address(RVA = "0x38AFB8", Offset = "0x38AFB8", VA = "0x38AFB8")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600086A")]
		[Address(RVA = "0x38AFC0", Offset = "0x38AFC0", VA = "0x38AFC0")]
		set
		{
		}
	}

	[Token(Token = "0x6000860")]
	[Address(RVA = "0x38ACA0", Offset = "0x38ACA0", VA = "0x38ACA0")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600086B")]
	[Address(RVA = "0x38B050", Offset = "0x38B050", VA = "0x38B050")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x600086C")]
	[Address(RVA = "0x38B24C", Offset = "0x38B24C", VA = "0x38B24C")]
	public Gate()
	{
	}
}
