using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000156")]
public class Reverb : MonoBehaviour
{
	[Token(Token = "0x4000A00")]
	[FieldOffset(Offset = "0x18")]
	private float _reverbTime;

	[Token(Token = "0x4000A01")]
	[FieldOffset(Offset = "0x1C")]
	private float _reverbGain;

	[Token(Token = "0x4000A02")]
	[FieldOffset(Offset = "0x20")]
	private float _dryWet;

	[Token(Token = "0x4000A03")]
	[FieldOffset(Offset = "0x28")]
	private CombFilter[] combFilters;

	[Token(Token = "0x4000A04")]
	[FieldOffset(Offset = "0x30")]
	private AllPassFilter[] allPassFilters;

	[Token(Token = "0x17000157")]
	public float ReverbTime
	{
		[Token(Token = "0x6000881")]
		[Address(RVA = "0x397A1C", Offset = "0x397A1C", VA = "0x397A1C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000882")]
		[Address(RVA = "0x397A24", Offset = "0x397A24", VA = "0x397A24")]
		set
		{
		}
	}

	[Token(Token = "0x17000158")]
	public float ReverbGain
	{
		[Token(Token = "0x6000883")]
		[Address(RVA = "0x397B30", Offset = "0x397B30", VA = "0x397B30")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000884")]
		[Address(RVA = "0x397B38", Offset = "0x397B38", VA = "0x397B38")]
		set
		{
		}
	}

	[Token(Token = "0x17000159")]
	public float DryWet
	{
		[Token(Token = "0x6000885")]
		[Address(RVA = "0x397BBC", Offset = "0x397BBC", VA = "0x397BBC")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000886")]
		[Address(RVA = "0x397BC4", Offset = "0x397BC4", VA = "0x397BC4")]
		set
		{
		}
	}

	[Token(Token = "0x6000880")]
	[Address(RVA = "0x3976C0", Offset = "0x3976C0", VA = "0x3976C0")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000887")]
	[Address(RVA = "0x39774C", Offset = "0x39774C", VA = "0x39774C")]
	private void Initialize()
	{
	}

	[Token(Token = "0x6000888")]
	[Address(RVA = "0x397AAC", Offset = "0x397AAC", VA = "0x397AAC")]
	private void Callibrate()
	{
	}

	[Token(Token = "0x6000889")]
	[Address(RVA = "0x397C48", Offset = "0x397C48", VA = "0x397C48")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x600088A")]
	[Address(RVA = "0x397EC4", Offset = "0x397EC4", VA = "0x397EC4")]
	public Reverb()
	{
	}
}
