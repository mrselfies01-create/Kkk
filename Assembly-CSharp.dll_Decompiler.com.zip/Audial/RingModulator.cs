using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000157")]
public class RingModulator : MonoBehaviour
{
	[Token(Token = "0x4000A05")]
	[FieldOffset(Offset = "0x18")]
	private float output;

	[Token(Token = "0x4000A06")]
	[FieldOffset(Offset = "0x1C")]
	private float sampleRate;

	[Token(Token = "0x4000A07")]
	[FieldOffset(Offset = "0x20")]
	public LFO carrierLFO;

	[Token(Token = "0x4000A08")]
	[FieldOffset(Offset = "0x28")]
	private float _carrierFrequency;

	[Token(Token = "0x4000A09")]
	[FieldOffset(Offset = "0x2C")]
	private float _dryWet;

	[Token(Token = "0x1700015A")]
	public float CarrierFrequency
	{
		[Token(Token = "0x600088D")]
		[Address(RVA = "0x3DA99C", Offset = "0x3DA99C", VA = "0x3DA99C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600088E")]
		[Address(RVA = "0x3DA9A4", Offset = "0x3DA9A4", VA = "0x3DA9A4")]
		set
		{
		}
	}

	[Token(Token = "0x1700015B")]
	public float DryWet
	{
		[Token(Token = "0x600088F")]
		[Address(RVA = "0x3DAA44", Offset = "0x3DAA44", VA = "0x3DAA44")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000890")]
		[Address(RVA = "0x3DAA4C", Offset = "0x3DAA4C", VA = "0x3DAA4C")]
		set
		{
		}
	}

	[Token(Token = "0x600088B")]
	[Address(RVA = "0x3DA89C", Offset = "0x3DA89C", VA = "0x3DA89C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600088C")]
	[Address(RVA = "0x3DA928", Offset = "0x3DA928", VA = "0x3DA928")]
	private void ResetUtils()
	{
	}

	[Token(Token = "0x6000891")]
	[Address(RVA = "0x3DAAD0", Offset = "0x3DAAD0", VA = "0x3DAAD0")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000892")]
	[Address(RVA = "0x3DABFC", Offset = "0x3DABFC", VA = "0x3DABFC")]
	public RingModulator()
	{
	}
}
