using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200014E")]
public class Delay : MonoBehaviour
{
	[Token(Token = "0x40009C8")]
	[FieldOffset(Offset = "0x18")]
	private float sampleRate;

	[Token(Token = "0x40009C9")]
	[FieldOffset(Offset = "0x20")]
	private float[,] delayBuffer;

	[Token(Token = "0x40009CA")]
	[FieldOffset(Offset = "0x28")]
	private int index;

	[Token(Token = "0x40009CB")]
	[FieldOffset(Offset = "0x2C")]
	private float _BPM;

	[Token(Token = "0x40009CC")]
	[FieldOffset(Offset = "0x30")]
	private int _delayCount;

	[Token(Token = "0x40009CD")]
	[FieldOffset(Offset = "0x34")]
	private int _delayUnit;

	[Token(Token = "0x40009CE")]
	[FieldOffset(Offset = "0x38")]
	private float _dryWet;

	[Token(Token = "0x40009CF")]
	[FieldOffset(Offset = "0x3C")]
	private float _decayLength;

	[Token(Token = "0x40009D0")]
	[FieldOffset(Offset = "0x40")]
	private float _pan;

	[Token(Token = "0x40009D1")]
	[FieldOffset(Offset = "0x44")]
	public bool PingPong;

	[Token(Token = "0x40009D2")]
	[FieldOffset(Offset = "0x48")]
	private float delayLength;

	[Token(Token = "0x40009D3")]
	[FieldOffset(Offset = "0x4C")]
	private int delaySamples;

	[Token(Token = "0x40009D4")]
	[FieldOffset(Offset = "0x50")]
	private float output;

	[Token(Token = "0x17000138")]
	public float BPM
	{
		[Token(Token = "0x600082A")]
		[Address(RVA = "0x385E5C", Offset = "0x385E5C", VA = "0x385E5C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600082B")]
		[Address(RVA = "0x385E64", Offset = "0x385E64", VA = "0x385E64")]
		set
		{
		}
	}

	[Token(Token = "0x17000139")]
	public int DelayCount
	{
		[Token(Token = "0x600082C")]
		[Address(RVA = "0x385EF4", Offset = "0x385EF4", VA = "0x385EF4")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x600082D")]
		[Address(RVA = "0x385EFC", Offset = "0x385EFC", VA = "0x385EFC")]
		set
		{
		}
	}

	[Token(Token = "0x1700013A")]
	public int DelayUnit
	{
		[Token(Token = "0x600082E")]
		[Address(RVA = "0x385F84", Offset = "0x385F84", VA = "0x385F84")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x600082F")]
		[Address(RVA = "0x385F8C", Offset = "0x385F8C", VA = "0x385F8C")]
		set
		{
		}
	}

	[Token(Token = "0x1700013B")]
	public float DryWet
	{
		[Token(Token = "0x6000830")]
		[Address(RVA = "0x386014", Offset = "0x386014", VA = "0x386014")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000831")]
		[Address(RVA = "0x38601C", Offset = "0x38601C", VA = "0x38601C")]
		set
		{
		}
	}

	[Token(Token = "0x1700013C")]
	public float DecayLength
	{
		[Token(Token = "0x6000832")]
		[Address(RVA = "0x3860A0", Offset = "0x3860A0", VA = "0x3860A0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000833")]
		[Address(RVA = "0x3860A8", Offset = "0x3860A8", VA = "0x3860A8")]
		set
		{
		}
	}

	[Token(Token = "0x1700013D")]
	public float Pan
	{
		[Token(Token = "0x6000834")]
		[Address(RVA = "0x386130", Offset = "0x386130", VA = "0x386130")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000835")]
		[Address(RVA = "0x386138", Offset = "0x386138", VA = "0x386138")]
		set
		{
		}
	}

	[Token(Token = "0x6000829")]
	[Address(RVA = "0x385D84", Offset = "0x385D84", VA = "0x385D84")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000836")]
	[Address(RVA = "0x385DB4", Offset = "0x385DB4", VA = "0x385DB4")]
	private void ChangeDelay()
	{
	}

	[Token(Token = "0x6000837")]
	[Address(RVA = "0x3861BC", Offset = "0x3861BC", VA = "0x3861BC")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000838")]
	[Address(RVA = "0x3866C4", Offset = "0x3866C4", VA = "0x3866C4")]
	public Delay()
	{
	}
}
