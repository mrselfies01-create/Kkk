using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000150")]
public class Fader : MonoBehaviour
{
	[Token(Token = "0x40009D9")]
	[FieldOffset(Offset = "0x18")]
	private float _gain;

	[Token(Token = "0x40009DA")]
	[FieldOffset(Offset = "0x1C")]
	public bool Mute;

	[Token(Token = "0x40009DB")]
	[FieldOffset(Offset = "0x20")]
	private LFO lfo;

	[Token(Token = "0x17000142")]
	public float Gain
	{
		[Token(Token = "0x6000843")]
		[Address(RVA = "0x389268", Offset = "0x389268", VA = "0x389268")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000844")]
		[Address(RVA = "0x389270", Offset = "0x389270", VA = "0x389270")]
		set
		{
		}
	}

	[Token(Token = "0x6000845")]
	[Address(RVA = "0x3892F4", Offset = "0x3892F4", VA = "0x3892F4")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000846")]
	[Address(RVA = "0x38939C", Offset = "0x38939C", VA = "0x38939C")]
	public Fader()
	{
	}
}
