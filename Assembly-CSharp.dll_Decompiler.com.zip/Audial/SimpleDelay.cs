using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000159")]
public class SimpleDelay : MonoBehaviour
{
	[Token(Token = "0x4000A10")]
	[FieldOffset(Offset = "0x18")]
	private float sampleRate;

	[Token(Token = "0x4000A11")]
	[FieldOffset(Offset = "0x20")]
	private CombFilter combFilter;

	[Token(Token = "0x4000A12")]
	[FieldOffset(Offset = "0x28")]
	private int _delayLengthMS;

	[Token(Token = "0x4000A13")]
	[FieldOffset(Offset = "0x2C")]
	private int DelayLengthMSPrev;

	[Token(Token = "0x4000A14")]
	[FieldOffset(Offset = "0x30")]
	private float _dryWet;

	[Token(Token = "0x4000A15")]
	[FieldOffset(Offset = "0x34")]
	private float _decayLength;

	[Token(Token = "0x4000A16")]
	[FieldOffset(Offset = "0x38")]
	private float delayLength;

	[Token(Token = "0x4000A17")]
	[FieldOffset(Offset = "0x3C")]
	private int delaySamples;

	[Token(Token = "0x4000A18")]
	[FieldOffset(Offset = "0x40")]
	private float output;

	[Token(Token = "0x1700015F")]
	public int DelayLengthMS
	{
		[Token(Token = "0x600089C")]
		[Address(RVA = "0x3DC560", Offset = "0x3DC560", VA = "0x3DC560")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x600089D")]
		[Address(RVA = "0x3DC568", Offset = "0x3DC568", VA = "0x3DC568")]
		set
		{
		}
	}

	[Token(Token = "0x17000160")]
	public float DryWet
	{
		[Token(Token = "0x600089E")]
		[Address(RVA = "0x3DC5F0", Offset = "0x3DC5F0", VA = "0x3DC5F0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600089F")]
		[Address(RVA = "0x3DC5F8", Offset = "0x3DC5F8", VA = "0x3DC5F8")]
		set
		{
		}
	}

	[Token(Token = "0x17000161")]
	public float DecayLength
	{
		[Token(Token = "0x60008A0")]
		[Address(RVA = "0x3DC67C", Offset = "0x3DC67C", VA = "0x3DC67C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008A1")]
		[Address(RVA = "0x3DC684", Offset = "0x3DC684", VA = "0x3DC684")]
		set
		{
		}
	}

	[Token(Token = "0x600089B")]
	[Address(RVA = "0x3DC480", Offset = "0x3DC480", VA = "0x3DC480")]
	private void Awake()
	{
	}

	[Token(Token = "0x60008A2")]
	[Address(RVA = "0x3DC538", Offset = "0x3DC538", VA = "0x3DC538")]
	private void ChangeDelay()
	{
	}

	[Token(Token = "0x60008A3")]
	[Address(RVA = "0x3DC70C", Offset = "0x3DC70C", VA = "0x3DC70C")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x60008A4")]
	[Address(RVA = "0x3DC864", Offset = "0x3DC864", VA = "0x3DC864")]
	public SimpleDelay()
	{
	}
}
