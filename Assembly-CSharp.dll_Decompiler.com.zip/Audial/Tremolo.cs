using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200015D")]
public class Tremolo : MonoBehaviour
{
	[Token(Token = "0x4000A30")]
	[FieldOffset(Offset = "0x18")]
	private float output;

	[Token(Token = "0x4000A31")]
	[FieldOffset(Offset = "0x1C")]
	private float sampleRate;

	[Token(Token = "0x4000A32")]
	[FieldOffset(Offset = "0x20")]
	public LFO carrierLFO;

	[Token(Token = "0x4000A33")]
	[FieldOffset(Offset = "0x28")]
	private float _carrierFrequency;

	[Token(Token = "0x4000A34")]
	[FieldOffset(Offset = "0x2C")]
	private float _dryWet;

	[Token(Token = "0x17000167")]
	public float CarrierFrequency
	{
		[Token(Token = "0x60008B8")]
		[Address(RVA = "0x3E1F00", Offset = "0x3E1F00", VA = "0x3E1F00")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008B9")]
		[Address(RVA = "0x3E1F08", Offset = "0x3E1F08", VA = "0x3E1F08")]
		set
		{
		}
	}

	[Token(Token = "0x17000168")]
	public float DryWet
	{
		[Token(Token = "0x60008BA")]
		[Address(RVA = "0x3E1FA4", Offset = "0x3E1FA4", VA = "0x3E1FA4")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008BB")]
		[Address(RVA = "0x3E1FAC", Offset = "0x3E1FAC", VA = "0x3E1FAC")]
		set
		{
		}
	}

	[Token(Token = "0x60008B6")]
	[Address(RVA = "0x3E1E00", Offset = "0x3E1E00", VA = "0x3E1E00")]
	private void Awake()
	{
	}

	[Token(Token = "0x60008B7")]
	[Address(RVA = "0x3E1E8C", Offset = "0x3E1E8C", VA = "0x3E1E8C")]
	private void ResetUtils()
	{
	}

	[Token(Token = "0x60008BC")]
	[Address(RVA = "0x3E2030", Offset = "0x3E2030", VA = "0x3E2030")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x60008BD")]
	[Address(RVA = "0x3E215C", Offset = "0x3E215C", VA = "0x3E215C")]
	public Tremolo()
	{
	}
}
