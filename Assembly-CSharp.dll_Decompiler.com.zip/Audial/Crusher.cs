using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200014D")]
public class Crusher : MonoBehaviour
{
	[Token(Token = "0x40009C1")]
	[FieldOffset(Offset = "0x18")]
	private int _bitDepth;

	[Token(Token = "0x40009C2")]
	[FieldOffset(Offset = "0x20")]
	private long m;

	[Token(Token = "0x40009C3")]
	[FieldOffset(Offset = "0x28")]
	private float _sampleRate;

	[Token(Token = "0x40009C4")]
	[FieldOffset(Offset = "0x2C")]
	private float _dryWet;

	[Token(Token = "0x40009C5")]
	[FieldOffset(Offset = "0x30")]
	private float[] y;

	[Token(Token = "0x40009C6")]
	[FieldOffset(Offset = "0x38")]
	private float cnt;

	[Token(Token = "0x40009C7")]
	[FieldOffset(Offset = "0x40")]
	private LFO lfo;

	[Token(Token = "0x17000135")]
	public int BitDepth
	{
		[Token(Token = "0x600081F")]
		[Address(RVA = "0x38599C", Offset = "0x38599C", VA = "0x38599C")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000820")]
		[Address(RVA = "0x3859A4", Offset = "0x3859A4", VA = "0x3859A4")]
		set
		{
		}
	}

	[Token(Token = "0x17000136")]
	public float SampleRate
	{
		[Token(Token = "0x6000821")]
		[Address(RVA = "0x385A8C", Offset = "0x385A8C", VA = "0x385A8C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000822")]
		[Address(RVA = "0x385A94", Offset = "0x385A94", VA = "0x385A94")]
		set
		{
		}
	}

	[Token(Token = "0x17000137")]
	public float DryWet
	{
		[Token(Token = "0x6000823")]
		[Address(RVA = "0x385B28", Offset = "0x385B28", VA = "0x385B28")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000824")]
		[Address(RVA = "0x385B30", Offset = "0x385B30", VA = "0x385B30")]
		set
		{
		}
	}

	[Token(Token = "0x6000825")]
	[Address(RVA = "0x385BC0", Offset = "0x385BC0", VA = "0x385BC0")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000826")]
	[Address(RVA = "0x385A48", Offset = "0x385A48", VA = "0x385A48")]
	private void Callibrate()
	{
	}

	[Token(Token = "0x6000827")]
	[Address(RVA = "0x385C1C", Offset = "0x385C1C", VA = "0x385C1C")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000828")]
	[Address(RVA = "0x385D68", Offset = "0x385D68", VA = "0x385D68")]
	public Crusher()
	{
	}
}
