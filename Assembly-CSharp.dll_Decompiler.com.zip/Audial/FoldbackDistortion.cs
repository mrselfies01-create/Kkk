using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000152")]
public class FoldbackDistortion : MonoBehaviour
{
	[Token(Token = "0x40009E4")]
	[FieldOffset(Offset = "0x18")]
	private float _inputGain;

	[Token(Token = "0x40009E5")]
	[FieldOffset(Offset = "0x1C")]
	private float _softDistortAmount;

	[Token(Token = "0x40009E6")]
	[FieldOffset(Offset = "0x20")]
	private float softThreshold;

	[Token(Token = "0x40009E7")]
	[FieldOffset(Offset = "0x24")]
	private float _threshold;

	[Token(Token = "0x40009E8")]
	[FieldOffset(Offset = "0x28")]
	private float _distortAmount;

	[Token(Token = "0x40009E9")]
	[FieldOffset(Offset = "0x2C")]
	private float _outputGain;

	[Token(Token = "0x17000147")]
	public float InputGain
	{
		[Token(Token = "0x6000853")]
		[Address(RVA = "0x38A444", Offset = "0x38A444", VA = "0x38A444")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000854")]
		[Address(RVA = "0x38A44C", Offset = "0x38A44C", VA = "0x38A44C")]
		set
		{
		}
	}

	[Token(Token = "0x17000148")]
	public float SoftDistortAmount
	{
		[Token(Token = "0x6000855")]
		[Address(RVA = "0x38A4D0", Offset = "0x38A4D0", VA = "0x38A4D0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000856")]
		[Address(RVA = "0x38A4D8", Offset = "0x38A4D8", VA = "0x38A4D8")]
		set
		{
		}
	}

	[Token(Token = "0x17000149")]
	public float Threshold
	{
		[Token(Token = "0x6000857")]
		[Address(RVA = "0x38A55C", Offset = "0x38A55C", VA = "0x38A55C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000858")]
		[Address(RVA = "0x38A564", Offset = "0x38A564", VA = "0x38A564")]
		set
		{
		}
	}

	[Token(Token = "0x1700014A")]
	public float DistortAmount
	{
		[Token(Token = "0x6000859")]
		[Address(RVA = "0x38A5EC", Offset = "0x38A5EC", VA = "0x38A5EC")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600085A")]
		[Address(RVA = "0x38A5F4", Offset = "0x38A5F4", VA = "0x38A5F4")]
		set
		{
		}
	}

	[Token(Token = "0x1700014B")]
	public float OutputGain
	{
		[Token(Token = "0x600085B")]
		[Address(RVA = "0x38A678", Offset = "0x38A678", VA = "0x38A678")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600085C")]
		[Address(RVA = "0x38A680", Offset = "0x38A680", VA = "0x38A680")]
		set
		{
		}
	}

	[Token(Token = "0x600085D")]
	[Address(RVA = "0x38A704", Offset = "0x38A704", VA = "0x38A704")]
	private float foldBack(float sample, float threshold)
	{
		return default(float);
	}

	[Token(Token = "0x600085E")]
	[Address(RVA = "0x38A7D0", Offset = "0x38A7D0", VA = "0x38A7D0")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x600085F")]
	[Address(RVA = "0x38A968", Offset = "0x38A968", VA = "0x38A968")]
	public FoldbackDistortion()
	{
	}
}
