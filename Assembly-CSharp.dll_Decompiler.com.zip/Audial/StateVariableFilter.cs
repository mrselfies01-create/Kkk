using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200015B")]
public class StateVariableFilter : MonoBehaviour
{
	[Token(Token = "0x4000A21")]
	[FieldOffset(Offset = "0x18")]
	private float sampleFrequency;

	[Token(Token = "0x4000A22")]
	[FieldOffset(Offset = "0x1C")]
	private int passes;

	[Token(Token = "0x4000A23")]
	[FieldOffset(Offset = "0x20")]
	private float _frequency;

	[Token(Token = "0x4000A24")]
	[FieldOffset(Offset = "0x28")]
	private double freq;

	[Token(Token = "0x4000A25")]
	[FieldOffset(Offset = "0x30")]
	private float _resonance;

	[Token(Token = "0x4000A26")]
	[FieldOffset(Offset = "0x34")]
	private float _drive;

	[Token(Token = "0x4000A27")]
	[FieldOffset(Offset = "0x38")]
	public FilterState Filter;

	[Token(Token = "0x4000A28")]
	[FieldOffset(Offset = "0x3C")]
	private float _additiveGain;

	[Token(Token = "0x4000A29")]
	[FieldOffset(Offset = "0x40")]
	private double[] notch;

	[Token(Token = "0x4000A2A")]
	[FieldOffset(Offset = "0x48")]
	private double[] low;

	[Token(Token = "0x4000A2B")]
	[FieldOffset(Offset = "0x50")]
	private double[] high;

	[Token(Token = "0x4000A2C")]
	[FieldOffset(Offset = "0x58")]
	private double[] band;

	[Token(Token = "0x4000A2D")]
	[FieldOffset(Offset = "0x60")]
	private double[] output;

	[Token(Token = "0x4000A2E")]
	[FieldOffset(Offset = "0x68")]
	private double damp;

	[Token(Token = "0x17000162")]
	public float Frequency
	{
		[Token(Token = "0x60008A6")]
		[Address(RVA = "0x3DE6AC", Offset = "0x3DE6AC", VA = "0x3DE6AC")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008A7")]
		[Address(RVA = "0x3DE6B4", Offset = "0x3DE6B4", VA = "0x3DE6B4")]
		set
		{
		}
	}

	[Token(Token = "0x17000163")]
	public float Resonance
	{
		[Token(Token = "0x60008A8")]
		[Address(RVA = "0x3DE744", Offset = "0x3DE744", VA = "0x3DE744")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008A9")]
		[Address(RVA = "0x3DE74C", Offset = "0x3DE74C", VA = "0x3DE74C")]
		set
		{
		}
	}

	[Token(Token = "0x17000164")]
	public float Drive
	{
		[Token(Token = "0x60008AA")]
		[Address(RVA = "0x3DE7D4", Offset = "0x3DE7D4", VA = "0x3DE7D4")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008AB")]
		[Address(RVA = "0x3DE7DC", Offset = "0x3DE7DC", VA = "0x3DE7DC")]
		set
		{
		}
	}

	[Token(Token = "0x17000165")]
	public float AdditiveGain
	{
		[Token(Token = "0x60008AC")]
		[Address(RVA = "0x3DE864", Offset = "0x3DE864", VA = "0x3DE864")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008AD")]
		[Address(RVA = "0x3DE86C", Offset = "0x3DE86C", VA = "0x3DE86C")]
		set
		{
		}
	}

	[Token(Token = "0x60008A5")]
	[Address(RVA = "0x3DE510", Offset = "0x3DE510", VA = "0x3DE510")]
	private void Awake()
	{
	}

	[Token(Token = "0x60008AE")]
	[Address(RVA = "0x3DE548", Offset = "0x3DE548", VA = "0x3DE548")]
	private void UpdateFrequency()
	{
	}

	[Token(Token = "0x60008AF")]
	[Address(RVA = "0x3DE5EC", Offset = "0x3DE5EC", VA = "0x3DE5EC")]
	private void UpdateDamp()
	{
	}

	[Token(Token = "0x60008B0")]
	[Address(RVA = "0x3DE8F0", Offset = "0x3DE8F0", VA = "0x3DE8F0")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x60008B1")]
	[Address(RVA = "0x3DED70", Offset = "0x3DED70", VA = "0x3DED70")]
	public StateVariableFilter()
	{
	}
}
