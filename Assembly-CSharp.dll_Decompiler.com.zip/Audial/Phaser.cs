using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000155")]
public class Phaser : MonoBehaviour
{
	[Token(Token = "0x40009F3")]
	[FieldOffset(Offset = "0x18")]
	private float output;

	[Token(Token = "0x40009F4")]
	[FieldOffset(Offset = "0x1C")]
	private float sampleRate;

	[Token(Token = "0x40009F5")]
	[FieldOffset(Offset = "0x20")]
	public LFO lfo;

	[Token(Token = "0x40009F6")]
	[FieldOffset(Offset = "0x28")]
	public AllPassFilter[] allPassFilters;

	[Token(Token = "0x40009F7")]
	[FieldOffset(Offset = "0x30")]
	private float _rate;

	[Token(Token = "0x40009F8")]
	[FieldOffset(Offset = "0x34")]
	private float _width;

	[Token(Token = "0x40009F9")]
	[FieldOffset(Offset = "0x38")]
	private float _intensity;

	[Token(Token = "0x40009FA")]
	[FieldOffset(Offset = "0x3C")]
	private float _dryWet;

	[Token(Token = "0x40009FB")]
	[FieldOffset(Offset = "0x40")]
	private float _offset;

	[Token(Token = "0x40009FC")]
	[FieldOffset(Offset = "0x44")]
	private float fromMin;

	[Token(Token = "0x40009FD")]
	[FieldOffset(Offset = "0x48")]
	private float fromMax;

	[Token(Token = "0x40009FE")]
	[FieldOffset(Offset = "0x4C")]
	private float toMin;

	[Token(Token = "0x40009FF")]
	[FieldOffset(Offset = "0x50")]
	private float toMax;

	[Token(Token = "0x17000152")]
	public float Rate
	{
		[Token(Token = "0x6000874")]
		[Address(RVA = "0x393744", Offset = "0x393744", VA = "0x393744")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000875")]
		[Address(RVA = "0x39374C", Offset = "0x39374C", VA = "0x39374C")]
		set
		{
		}
	}

	[Token(Token = "0x17000153")]
	public float Width
	{
		[Token(Token = "0x6000876")]
		[Address(RVA = "0x3937F0", Offset = "0x3937F0", VA = "0x3937F0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000877")]
		[Address(RVA = "0x3937F8", Offset = "0x3937F8", VA = "0x3937F8")]
		set
		{
		}
	}

	[Token(Token = "0x17000154")]
	public float Intensity
	{
		[Token(Token = "0x6000878")]
		[Address(RVA = "0x393888", Offset = "0x393888", VA = "0x393888")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000879")]
		[Address(RVA = "0x393890", Offset = "0x393890", VA = "0x393890")]
		set
		{
		}
	}

	[Token(Token = "0x17000155")]
	public float DryWet
	{
		[Token(Token = "0x600087A")]
		[Address(RVA = "0x393918", Offset = "0x393918", VA = "0x393918")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600087B")]
		[Address(RVA = "0x393920", Offset = "0x393920", VA = "0x393920")]
		set
		{
		}
	}

	[Token(Token = "0x17000156")]
	private int Offset
	{
		[Token(Token = "0x600087C")]
		[Address(RVA = "0x3939A4", Offset = "0x3939A4", VA = "0x3939A4")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x600087D")]
		[Address(RVA = "0x3939B0", Offset = "0x3939B0", VA = "0x3939B0")]
		set
		{
		}
	}

	[Token(Token = "0x6000871")]
	[Address(RVA = "0x393460", Offset = "0x393460", VA = "0x393460")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000872")]
	[Address(RVA = "0x3934EC", Offset = "0x3934EC", VA = "0x3934EC")]
	private void ResetUtils()
	{
	}

	[Token(Token = "0x6000873")]
	[Address(RVA = "0x3936DC", Offset = "0x3936DC", VA = "0x3936DC")]
	private void SetIntensity(float i)
	{
	}

	[Token(Token = "0x600087E")]
	[Address(RVA = "0x3939BC", Offset = "0x3939BC", VA = "0x3939BC")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x600087F")]
	[Address(RVA = "0x393C4C", Offset = "0x393C4C", VA = "0x393C4C")]
	public Phaser()
	{
	}
}
