using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000158")]
public class Saturator : MonoBehaviour
{
	[Token(Token = "0x4000A0A")]
	[FieldOffset(Offset = "0x18")]
	private float _inputGain;

	[Token(Token = "0x4000A0B")]
	[FieldOffset(Offset = "0x1C")]
	private float _threshold;

	[Token(Token = "0x4000A0C")]
	[FieldOffset(Offset = "0x20")]
	public float _amount;

	[Token(Token = "0x4000A0D")]
	[FieldOffset(Offset = "0x24")]
	private float input;

	[Token(Token = "0x4000A0E")]
	[FieldOffset(Offset = "0x28")]
	private float sampleAbs;

	[Token(Token = "0x4000A0F")]
	[FieldOffset(Offset = "0x2C")]
	private float sampleSign;

	[Token(Token = "0x1700015C")]
	public float InputGain
	{
		[Token(Token = "0x6000893")]
		[Address(RVA = "0x3DAC10", Offset = "0x3DAC10", VA = "0x3DAC10")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000894")]
		[Address(RVA = "0x3DAC18", Offset = "0x3DAC18", VA = "0x3DAC18")]
		set
		{
		}
	}

	[Token(Token = "0x1700015D")]
	public float Threshold
	{
		[Token(Token = "0x6000895")]
		[Address(RVA = "0x3DAC9C", Offset = "0x3DAC9C", VA = "0x3DAC9C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000896")]
		[Address(RVA = "0x3DACA4", Offset = "0x3DACA4", VA = "0x3DACA4")]
		set
		{
		}
	}

	[Token(Token = "0x1700015E")]
	public float Amount
	{
		[Token(Token = "0x6000897")]
		[Address(RVA = "0x3DAD28", Offset = "0x3DAD28", VA = "0x3DAD28")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000898")]
		[Address(RVA = "0x3DAD30", Offset = "0x3DAD30", VA = "0x3DAD30")]
		set
		{
		}
	}

	[Token(Token = "0x6000899")]
	[Address(RVA = "0x3DADB4", Offset = "0x3DADB4", VA = "0x3DADB4")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x600089A")]
	[Address(RVA = "0x3DAF6C", Offset = "0x3DAF6C", VA = "0x3DAF6C")]
	public Saturator()
	{
	}
}
