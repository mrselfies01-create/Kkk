using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x2000154")]
public class PanControl : MonoBehaviour
{
	[Token(Token = "0x40009F2")]
	[FieldOffset(Offset = "0x18")]
	private float _panAmount;

	[Token(Token = "0x17000151")]
	public float PanAmount
	{
		[Token(Token = "0x600086D")]
		[Address(RVA = "0x393290", Offset = "0x393290", VA = "0x393290")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600086E")]
		[Address(RVA = "0x393298", Offset = "0x393298", VA = "0x393298")]
		set
		{
		}
	}

	[Token(Token = "0x600086F")]
	[Address(RVA = "0x39331C", Offset = "0x39331C", VA = "0x39331C")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000870")]
	[Address(RVA = "0x393458", Offset = "0x393458", VA = "0x393458")]
	public PanControl()
	{
	}
}
