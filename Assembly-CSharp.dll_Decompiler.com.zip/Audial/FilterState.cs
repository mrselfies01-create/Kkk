using Il2CppDummyDll;

namespace Audial;

[Token(Token = "0x200015A")]
public enum FilterState
{
	[Token(Token = "0x4000A1A")]
	Bypass,
	[Token(Token = "0x4000A1B")]
	LowPass,
	[Token(Token = "0x4000A1C")]
	LowShelf,
	[Token(Token = "0x4000A1D")]
	HighPass,
	[Token(Token = "0x4000A1E")]
	HighShelf,
	[Token(Token = "0x4000A1F")]
	BandPass,
	[Token(Token = "0x4000A20")]
	BandAdd
}
