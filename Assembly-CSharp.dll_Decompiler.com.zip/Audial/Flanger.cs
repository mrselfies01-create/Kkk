using System;
using Audial.Utils;
using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Serializable]
[Token(Token = "0x2000151")]
public class Flanger : MonoBehaviour
{
	[Token(Token = "0x40009DC")]
	[FieldOffset(Offset = "0x18")]
	private float sampleRate;

	[Token(Token = "0x40009DD")]
	[FieldOffset(Offset = "0x1C")]
	private float output;

	[Token(Token = "0x40009DE")]
	[FieldOffset(Offset = "0x20")]
	private LFO lfo;

	[Token(Token = "0x40009DF")]
	[FieldOffset(Offset = "0x28")]
	private CombFilter combFilter;

	[Token(Token = "0x40009E0")]
	[FieldOffset(Offset = "0x30")]
	private float _rate;

	[Token(Token = "0x40009E1")]
	[FieldOffset(Offset = "0x34")]
	private float _intensity;

	[Token(Token = "0x40009E2")]
	[FieldOffset(Offset = "0x38")]
	private float _dryWet;

	[Token(Token = "0x40009E3")]
	[FieldOffset(Offset = "0x3C")]
	private float _offset;

	[Token(Token = "0x17000143")]
	public float Rate
	{
		[Token(Token = "0x6000849")]
		[Address(RVA = "0x389644", Offset = "0x389644", VA = "0x389644")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600084A")]
		[Address(RVA = "0x38964C", Offset = "0x38964C", VA = "0x38964C")]
		set
		{
		}
	}

	[Token(Token = "0x17000144")]
	public float Intensity
	{
		[Token(Token = "0x600084B")]
		[Address(RVA = "0x3896F8", Offset = "0x3896F8", VA = "0x3896F8")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600084C")]
		[Address(RVA = "0x389700", Offset = "0x389700", VA = "0x389700")]
		set
		{
		}
	}

	[Token(Token = "0x17000145")]
	public float DryWet
	{
		[Token(Token = "0x600084D")]
		[Address(RVA = "0x38979C", Offset = "0x38979C", VA = "0x38979C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600084E")]
		[Address(RVA = "0x3897A4", Offset = "0x3897A4", VA = "0x3897A4")]
		set
		{
		}
	}

	[Token(Token = "0x17000146")]
	private int Offset
	{
		[Token(Token = "0x600084F")]
		[Address(RVA = "0x389828", Offset = "0x389828", VA = "0x389828")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000850")]
		[Address(RVA = "0x389834", Offset = "0x389834", VA = "0x389834")]
		set
		{
		}
	}

	[Token(Token = "0x6000847")]
	[Address(RVA = "0x389490", Offset = "0x389490", VA = "0x389490")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000848")]
	[Address(RVA = "0x38951C", Offset = "0x38951C", VA = "0x38951C")]
	private void ResetUtils()
	{
	}

	[Token(Token = "0x6000851")]
	[Address(RVA = "0x389840", Offset = "0x389840", VA = "0x389840")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000852")]
	[Address(RVA = "0x389B58", Offset = "0x389B58", VA = "0x389B58")]
	public Flanger()
	{
	}
}
