using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200014F")]
public class Distortion : MonoBehaviour
{
	[Token(Token = "0x40009D5")]
	[FieldOffset(Offset = "0x18")]
	private float _inputGain;

	[Token(Token = "0x40009D6")]
	[FieldOffset(Offset = "0x1C")]
	private float _threshold;

	[Token(Token = "0x40009D7")]
	[FieldOffset(Offset = "0x20")]
	private float _dryWet;

	[Token(Token = "0x40009D8")]
	[FieldOffset(Offset = "0x24")]
	private float _outputGain;

	[Token(Token = "0x1700013E")]
	public float InputGain
	{
		[Token(Token = "0x6000839")]
		[Address(RVA = "0x387718", Offset = "0x387718", VA = "0x387718")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600083A")]
		[Address(RVA = "0x387720", Offset = "0x387720", VA = "0x387720")]
		set
		{
		}
	}

	[Token(Token = "0x1700013F")]
	public float Threshold
	{
		[Token(Token = "0x600083B")]
		[Address(RVA = "0x3877A4", Offset = "0x3877A4", VA = "0x3877A4")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600083C")]
		[Address(RVA = "0x3877AC", Offset = "0x3877AC", VA = "0x3877AC")]
		set
		{
		}
	}

	[Token(Token = "0x17000140")]
	public float DryWet
	{
		[Token(Token = "0x600083D")]
		[Address(RVA = "0x387834", Offset = "0x387834", VA = "0x387834")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x600083E")]
		[Address(RVA = "0x38783C", Offset = "0x38783C", VA = "0x38783C")]
		set
		{
		}
	}

	[Token(Token = "0x17000141")]
	public float OutputGain
	{
		[Token(Token = "0x600083F")]
		[Address(RVA = "0x3878C0", Offset = "0x3878C0", VA = "0x3878C0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000840")]
		[Address(RVA = "0x3878C8", Offset = "0x3878C8", VA = "0x3878C8")]
		set
		{
		}
	}

	[Token(Token = "0x6000841")]
	[Address(RVA = "0x38794C", Offset = "0x38794C", VA = "0x38794C")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x6000842")]
	[Address(RVA = "0x387B18", Offset = "0x387B18", VA = "0x387B18")]
	public Distortion()
	{
	}
}
