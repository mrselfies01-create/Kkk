using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200015C")]
public class StereoWidener : MonoBehaviour
{
	[Token(Token = "0x4000A2F")]
	[FieldOffset(Offset = "0x18")]
	private float _width;

	[Token(Token = "0x17000166")]
	public float Width
	{
		[Token(Token = "0x60008B2")]
		[Address(RVA = "0x3DEE34", Offset = "0x3DEE34", VA = "0x3DEE34")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x60008B3")]
		[Address(RVA = "0x3DEE3C", Offset = "0x3DEE3C", VA = "0x3DEE3C")]
		set
		{
		}
	}

	[Token(Token = "0x60008B4")]
	[Address(RVA = "0x3DEEC0", Offset = "0x3DEEC0", VA = "0x3DEEC0")]
	private void OnAudioFilterRead(float[] data, int channels)
	{
	}

	[Token(Token = "0x60008B5")]
	[Address(RVA = "0x3DEF68", Offset = "0x3DEF68", VA = "0x3DEF68")]
	public StereoWidener()
	{
	}
}
