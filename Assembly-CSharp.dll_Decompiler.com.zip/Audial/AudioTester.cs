using Il2CppDummyDll;
using UnityEngine;

namespace Audial;

[Token(Token = "0x200014C")]
public class AudioTester : MonoBehaviour
{
	[Token(Token = "0x40009BF")]
	[FieldOffset(Offset = "0x18")]
	public bool hasAudioSource;

	[Token(Token = "0x40009C0")]
	[FieldOffset(Offset = "0x20")]
	public AudioSource audioSource;

	[Token(Token = "0x17000133")]
	public bool playAudio
	{
		[Token(Token = "0x600081C")]
		[Address(RVA = "0x5B0C40", Offset = "0x5B0C40", VA = "0x5B0C40")]
		set
		{
		}
	}

	[Token(Token = "0x17000134")]
	public bool stopAudio
	{
		[Token(Token = "0x600081D")]
		[Address(RVA = "0x5B0D3C", Offset = "0x5B0D3C", VA = "0x5B0D3C")]
		set
		{
		}
	}

	[Token(Token = "0x600081A")]
	[Address(RVA = "0x5B0C38", Offset = "0x5B0C38", VA = "0x5B0C38")]
	public void ClearBuffer()
	{
	}

	[Token(Token = "0x600081B")]
	[Address(RVA = "0x5B0C3C", Offset = "0x5B0C3C", VA = "0x5B0C3C")]
	public void SetRunEffectInEditMode()
	{
	}

	[Token(Token = "0x600081E")]
	[Address(RVA = "0x5B0DC4", Offset = "0x5B0DC4", VA = "0x5B0DC4")]
	public AudioTester()
	{
	}
}
