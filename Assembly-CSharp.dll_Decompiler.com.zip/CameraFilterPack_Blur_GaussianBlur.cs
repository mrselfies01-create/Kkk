using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004B")]
public class CameraFilterPack_Blur_GaussianBlur : MonoBehaviour
{
	[Token(Token = "0x40002BA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002BB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002BC")]
	[FieldOffset(Offset = "0x24")]
	public float Size;

	[Token(Token = "0x40002BD")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700004C")]
	private Material material
	{
		[Token(Token = "0x60001F3")]
		[Address(RVA = "0x666AA8", Offset = "0x666AA8", VA = "0x666AA8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001F4")]
	[Address(RVA = "0x666B6C", Offset = "0x666B6C", VA = "0x666B6C")]
	private void Start()
	{
	}

	[Token(Token = "0x60001F5")]
	[Address(RVA = "0x666BE8", Offset = "0x666BE8", VA = "0x666BE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001F6")]
	[Address(RVA = "0x666DF0", Offset = "0x666DF0", VA = "0x666DF0")]
	private void Update()
	{
	}

	[Token(Token = "0x60001F7")]
	[Address(RVA = "0x666DF4", Offset = "0x666DF4", VA = "0x666DF4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001F8")]
	[Address(RVA = "0x666EA4", Offset = "0x666EA4", VA = "0x666EA4")]
	public CameraFilterPack_Blur_GaussianBlur()
	{
	}
}
