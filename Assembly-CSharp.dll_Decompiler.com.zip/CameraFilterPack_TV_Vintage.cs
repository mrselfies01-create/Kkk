using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011D")]
public class CameraFilterPack_TV_Vintage : MonoBehaviour
{
	[Token(Token = "0x400080F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000810")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000811")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x4000812")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700011E")]
	private Material material
	{
		[Token(Token = "0x6000705")]
		[Address(RVA = "0x63B7A0", Offset = "0x63B7A0", VA = "0x63B7A0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000706")]
	[Address(RVA = "0x63B864", Offset = "0x63B864", VA = "0x63B864")]
	private void Start()
	{
	}

	[Token(Token = "0x6000707")]
	[Address(RVA = "0x63B8E0", Offset = "0x63B8E0", VA = "0x63B8E0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000708")]
	[Address(RVA = "0x63BA64", Offset = "0x63BA64", VA = "0x63BA64")]
	private void Update()
	{
	}

	[Token(Token = "0x6000709")]
	[Address(RVA = "0x63BA68", Offset = "0x63BA68", VA = "0x63BA68")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600070A")]
	[Address(RVA = "0x63BB18", Offset = "0x63BB18", VA = "0x63BB18")]
	public CameraFilterPack_TV_Vintage()
	{
	}
}
