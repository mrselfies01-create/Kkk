using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006B")]
public class CameraFilterPack_Colors_HSV : MonoBehaviour
{
	[Token(Token = "0x400037D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400037E")]
	[FieldOffset(Offset = "0x20")]
	public float _HueShift;

	[Token(Token = "0x400037F")]
	[FieldOffset(Offset = "0x24")]
	public float _Saturation;

	[Token(Token = "0x4000380")]
	[FieldOffset(Offset = "0x28")]
	public float _ValueBrightness;

	[Token(Token = "0x4000381")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x1700006C")]
	private Material material
	{
		[Token(Token = "0x60002B5")]
		[Address(RVA = "0x670740", Offset = "0x670740", VA = "0x670740")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002B6")]
	[Address(RVA = "0x670804", Offset = "0x670804", VA = "0x670804")]
	private void Start()
	{
	}

	[Token(Token = "0x60002B7")]
	[Address(RVA = "0x670844", Offset = "0x670844", VA = "0x670844")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002B8")]
	[Address(RVA = "0x6709B8", Offset = "0x6709B8", VA = "0x6709B8")]
	private void Update()
	{
	}

	[Token(Token = "0x60002B9")]
	[Address(RVA = "0x6709BC", Offset = "0x6709BC", VA = "0x6709BC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002BA")]
	[Address(RVA = "0x670A6C", Offset = "0x670A6C", VA = "0x670A6C")]
	public CameraFilterPack_Colors_HSV()
	{
	}
}
