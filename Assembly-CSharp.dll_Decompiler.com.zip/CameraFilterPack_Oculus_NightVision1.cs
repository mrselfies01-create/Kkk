using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000EE")]
public class CameraFilterPack_Oculus_NightVision1 : MonoBehaviour
{
	[Token(Token = "0x40006EB")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006EC")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006ED")]
	[FieldOffset(Offset = "0x24")]
	private float Distortion;

	[Token(Token = "0x40006EE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006EF")]
	[FieldOffset(Offset = "0x30")]
	public float Vignette;

	[Token(Token = "0x40006F0")]
	[FieldOffset(Offset = "0x34")]
	public float Linecount;

	[Token(Token = "0x170000EF")]
	private Material material
	{
		[Token(Token = "0x60005E6")]
		[Address(RVA = "0x62DF0C", Offset = "0x62DF0C", VA = "0x62DF0C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005E7")]
	[Address(RVA = "0x62DFD0", Offset = "0x62DFD0", VA = "0x62DFD0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005E8")]
	[Address(RVA = "0x62E04C", Offset = "0x62E04C", VA = "0x62E04C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005E9")]
	[Address(RVA = "0x62E2AC", Offset = "0x62E2AC", VA = "0x62E2AC")]
	private void Update()
	{
	}

	[Token(Token = "0x60005EA")]
	[Address(RVA = "0x62E2B0", Offset = "0x62E2B0", VA = "0x62E2B0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005EB")]
	[Address(RVA = "0x62E360", Offset = "0x62E360", VA = "0x62E360")]
	public CameraFilterPack_Oculus_NightVision1()
	{
	}
}
