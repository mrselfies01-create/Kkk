using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D6")]
public class CameraFilterPack_Gradients_Therma : MonoBehaviour
{
	[Token(Token = "0x400062B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400062C")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x400062D")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x400062E")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x400062F")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000630")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D7")]
	private Material material
	{
		[Token(Token = "0x6000538")]
		[Address(RVA = "0x6A4934", Offset = "0x6A4934", VA = "0x6A4934")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000539")]
	[Address(RVA = "0x6A49F8", Offset = "0x6A49F8", VA = "0x6A49F8")]
	private void Start()
	{
	}

	[Token(Token = "0x600053A")]
	[Address(RVA = "0x6A4A48", Offset = "0x6A4A48", VA = "0x6A4A48")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600053B")]
	[Address(RVA = "0x6A4C84", Offset = "0x6A4C84", VA = "0x6A4C84")]
	private void Update()
	{
	}

	[Token(Token = "0x600053C")]
	[Address(RVA = "0x6A4C88", Offset = "0x6A4C88", VA = "0x6A4C88")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600053D")]
	[Address(RVA = "0x6A4D38", Offset = "0x6A4D38", VA = "0x6A4D38")]
	public CameraFilterPack_Gradients_Therma()
	{
	}
}
