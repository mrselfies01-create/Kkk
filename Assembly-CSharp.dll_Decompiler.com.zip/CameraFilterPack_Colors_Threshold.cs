using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006F")]
public class CameraFilterPack_Colors_Threshold : MonoBehaviour
{
	[Token(Token = "0x4000398")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000399")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400039A")]
	[FieldOffset(Offset = "0x24")]
	public float Threshold;

	[Token(Token = "0x400039B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000070")]
	private Material material
	{
		[Token(Token = "0x60002CD")]
		[Address(RVA = "0x671858", Offset = "0x671858", VA = "0x671858")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002CE")]
	[Address(RVA = "0x67191C", Offset = "0x67191C", VA = "0x67191C")]
	private void Start()
	{
	}

	[Token(Token = "0x60002CF")]
	[Address(RVA = "0x671998", Offset = "0x671998", VA = "0x671998")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002D0")]
	[Address(RVA = "0x671B1C", Offset = "0x671B1C", VA = "0x671B1C")]
	private void Update()
	{
	}

	[Token(Token = "0x60002D1")]
	[Address(RVA = "0x671B20", Offset = "0x671B20", VA = "0x671B20")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002D2")]
	[Address(RVA = "0x671BD0", Offset = "0x671BD0", VA = "0x671BD0")]
	public CameraFilterPack_Colors_Threshold()
	{
	}
}
