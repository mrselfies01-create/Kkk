using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x200019A")]
public class VerticalLayoutGroupExtended : HorizontalOrVerticalLayoutGroupExtended
{
	[Token(Token = "0x60009FA")]
	[Address(RVA = "0x4784E8", Offset = "0x4784E8", VA = "0x4784E8", Slot = "28")]
	public override void CalculateLayoutInputHorizontal()
	{
	}

	[Token(Token = "0x60009FB")]
	[Address(RVA = "0x47851C", Offset = "0x47851C", VA = "0x47851C", Slot = "29")]
	public override void CalculateLayoutInputVertical()
	{
	}

	[Token(Token = "0x60009FC")]
	[Address(RVA = "0x47852C", Offset = "0x47852C", VA = "0x47852C", Slot = "37")]
	public override void SetLayoutHorizontal()
	{
	}

	[Token(Token = "0x60009FD")]
	[Address(RVA = "0x47853C", Offset = "0x47853C", VA = "0x47853C", Slot = "38")]
	public override void SetLayoutVertical()
	{
	}

	[Token(Token = "0x60009FE")]
	[Address(RVA = "0x47854C", Offset = "0x47854C", VA = "0x47854C")]
	public VerticalLayoutGroupExtended()
	{
	}
}
