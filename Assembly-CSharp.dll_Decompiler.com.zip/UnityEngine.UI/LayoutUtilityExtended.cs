using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x2000199")]
public static class LayoutUtilityExtended
{
	[Token(Token = "0x60009F8")]
	[Address(RVA = "0x38CBF4", Offset = "0x38CBF4", VA = "0x38CBF4")]
	public static RectOffset GetMargin(RectTransform rect)
	{
		return null;
	}

	[Token(Token = "0x60009F9")]
	[Address(RVA = "0x38D128", Offset = "0x38D128", VA = "0x38D128")]
	public static RectOffset GetMargin(RectTransform rect, RectOffset defaultValue)
	{
		return null;
	}
}
