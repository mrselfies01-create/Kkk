using System;
using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x2000198")]
public class LayoutElementExtended : LayoutElement, IDisposable
{
	[Token(Token = "0x4000ADB")]
	[FieldOffset(Offset = "0x38")]
	private RectOffset m_Margin;

	[Token(Token = "0x170001A4")]
	public virtual RectOffset margin
	{
		[Token(Token = "0x60009F3")]
		[Address(RVA = "0x38D0A4", Offset = "0x38D0A4", VA = "0x38D0A4", Slot = "46")]
		get
		{
			return null;
		}
		[Token(Token = "0x60009F4")]
		[Address(RVA = "0x38D0AC", Offset = "0x38D0AC", VA = "0x38D0AC", Slot = "47")]
		set
		{
		}
	}

	[Token(Token = "0x60009F5")]
	[Address(RVA = "0x38D0B8", Offset = "0x38D0B8", VA = "0x38D0B8", Slot = "29")]
	public override void CalculateLayoutInputHorizontal()
	{
	}

	[Token(Token = "0x60009F6")]
	[Address(RVA = "0x38D0BC", Offset = "0x38D0BC", VA = "0x38D0BC", Slot = "30")]
	public override void CalculateLayoutInputVertical()
	{
	}

	[Token(Token = "0x60009F7")]
	[Address(RVA = "0x38D0C0", Offset = "0x38D0C0", VA = "0x38D0C0")]
	public LayoutElementExtended()
	{
	}
}
