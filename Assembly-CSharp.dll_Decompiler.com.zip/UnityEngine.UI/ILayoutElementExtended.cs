using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x2000197")]
public interface ILayoutElementExtended
{
	[Token(Token = "0x170001A3")]
	RectOffset margin
	{
		[Token(Token = "0x60009F2")]
		get;
	}
}
