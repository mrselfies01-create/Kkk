using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x2000195")]
public class HorizontalLayoutGroupExtended : HorizontalOrVerticalLayoutGroupExtended
{
	[Token(Token = "0x60009EA")]
	[Address(RVA = "0x38C2CC", Offset = "0x38C2CC", VA = "0x38C2CC", Slot = "28")]
	public override void CalculateLayoutInputHorizontal()
	{
	}

	[Token(Token = "0x60009EB")]
	[Address(RVA = "0x38C57C", Offset = "0x38C57C", VA = "0x38C57C", Slot = "29")]
	public override void CalculateLayoutInputVertical()
	{
	}

	[Token(Token = "0x60009EC")]
	[Address(RVA = "0x38C588", Offset = "0x38C588", VA = "0x38C588", Slot = "37")]
	public override void SetLayoutHorizontal()
	{
	}

	[Token(Token = "0x60009ED")]
	[Address(RVA = "0x38CBD8", Offset = "0x38CBD8", VA = "0x38CBD8", Slot = "38")]
	public override void SetLayoutVertical()
	{
	}

	[Token(Token = "0x60009EE")]
	[Address(RVA = "0x38CBE4", Offset = "0x38CBE4", VA = "0x38CBE4")]
	public HorizontalLayoutGroupExtended()
	{
	}
}
