using Il2CppDummyDll;

namespace UnityEngine.UI;

[Token(Token = "0x2000196")]
public abstract class HorizontalOrVerticalLayoutGroupExtended : HorizontalOrVerticalLayoutGroup
{
	[Token(Token = "0x4000AD9")]
	[FieldOffset(Offset = "0x63")]
	private bool m_SubtractMarginHorizontal;

	[Token(Token = "0x4000ADA")]
	[FieldOffset(Offset = "0x64")]
	private bool m_SubtractMarginVertical;

	[Token(Token = "0x60009EF")]
	[Address(RVA = "0x38C2FC", Offset = "0x38C2FC", VA = "0x38C2FC")]
	protected void CalcAlongAxisExtended(int axis, bool isVertical)
	{
	}

	[Token(Token = "0x60009F0")]
	[Address(RVA = "0x38C594", Offset = "0x38C594", VA = "0x38C594")]
	protected void SetChildrenAlongAxisExtended(int axis, bool isVertical)
	{
	}

	[Token(Token = "0x60009F1")]
	[Address(RVA = "0x38CBEC", Offset = "0x38CBEC", VA = "0x38CBEC")]
	protected HorizontalOrVerticalLayoutGroupExtended()
	{
	}
}
