using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010E")]
public class CameraFilterPack_TV_MovieNoise : MonoBehaviour
{
	[Token(Token = "0x40007C2")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007C3")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007C4")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007C5")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x1700010F")]
	private Material material
	{
		[Token(Token = "0x60006AB")]
		[Address(RVA = "0x6379AC", Offset = "0x6379AC", VA = "0x6379AC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006AC")]
	[Address(RVA = "0x637A70", Offset = "0x637A70", VA = "0x637A70")]
	private void Start()
	{
	}

	[Token(Token = "0x60006AD")]
	[Address(RVA = "0x637AEC", Offset = "0x637AEC", VA = "0x637AEC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006AE")]
	[Address(RVA = "0x637D04", Offset = "0x637D04", VA = "0x637D04")]
	private void Update()
	{
	}

	[Token(Token = "0x60006AF")]
	[Address(RVA = "0x637D08", Offset = "0x637D08", VA = "0x637D08")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006B0")]
	[Address(RVA = "0x637DB8", Offset = "0x637DB8", VA = "0x637DB8")]
	public CameraFilterPack_TV_MovieNoise()
	{
	}
}
