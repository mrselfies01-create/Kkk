using System;
using Il2CppDummyDll;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001AF")]
public class AnimationTriggersExtended
{
	[Token(Token = "0x4000B3D")]
	[FieldOffset(Offset = "0x10")]
	private string m_NormalTrigger;

	[Token(Token = "0x4000B3E")]
	[FieldOffset(Offset = "0x18")]
	private string m_HighlightedTrigger;

	[Token(Token = "0x4000B3F")]
	[FieldOffset(Offset = "0x20")]
	private string m_PressedTrigger;

	[Token(Token = "0x4000B40")]
	[FieldOffset(Offset = "0x28")]
	private string m_ActiveTrigger;

	[Token(Token = "0x4000B41")]
	[FieldOffset(Offset = "0x30")]
	private string m_ActiveHighlightedTrigger;

	[Token(Token = "0x4000B42")]
	[FieldOffset(Offset = "0x38")]
	private string m_ActivePressedTrigger;

	[Token(Token = "0x4000B43")]
	[FieldOffset(Offset = "0x40")]
	private string m_DisabledTrigger;

	[Token(Token = "0x170001CB")]
	public string normalTrigger
	{
		[Token(Token = "0x6000A8D")]
		[Address(RVA = "0x5B03D0", Offset = "0x5B03D0", VA = "0x5B03D0")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A8E")]
		[Address(RVA = "0x5B03D8", Offset = "0x5B03D8", VA = "0x5B03D8")]
		set
		{
		}
	}

	[Token(Token = "0x170001CC")]
	public string highlightedTrigger
	{
		[Token(Token = "0x6000A8F")]
		[Address(RVA = "0x5B03E0", Offset = "0x5B03E0", VA = "0x5B03E0")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A90")]
		[Address(RVA = "0x5B03E8", Offset = "0x5B03E8", VA = "0x5B03E8")]
		set
		{
		}
	}

	[Token(Token = "0x170001CD")]
	public string pressedTrigger
	{
		[Token(Token = "0x6000A91")]
		[Address(RVA = "0x5B03F0", Offset = "0x5B03F0", VA = "0x5B03F0")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A92")]
		[Address(RVA = "0x5B03F8", Offset = "0x5B03F8", VA = "0x5B03F8")]
		set
		{
		}
	}

	[Token(Token = "0x170001CE")]
	public string activeTrigger
	{
		[Token(Token = "0x6000A93")]
		[Address(RVA = "0x5B0400", Offset = "0x5B0400", VA = "0x5B0400")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A94")]
		[Address(RVA = "0x5B0408", Offset = "0x5B0408", VA = "0x5B0408")]
		set
		{
		}
	}

	[Token(Token = "0x170001CF")]
	public string activeHighlightedTrigger
	{
		[Token(Token = "0x6000A95")]
		[Address(RVA = "0x5B0410", Offset = "0x5B0410", VA = "0x5B0410")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A96")]
		[Address(RVA = "0x5B0418", Offset = "0x5B0418", VA = "0x5B0418")]
		set
		{
		}
	}

	[Token(Token = "0x170001D0")]
	public string activePressedTrigger
	{
		[Token(Token = "0x6000A97")]
		[Address(RVA = "0x5B0420", Offset = "0x5B0420", VA = "0x5B0420")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A98")]
		[Address(RVA = "0x5B0428", Offset = "0x5B0428", VA = "0x5B0428")]
		set
		{
		}
	}

	[Token(Token = "0x170001D1")]
	public string disabledTrigger
	{
		[Token(Token = "0x6000A99")]
		[Address(RVA = "0x5B0430", Offset = "0x5B0430", VA = "0x5B0430")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000A9A")]
		[Address(RVA = "0x5B0438", Offset = "0x5B0438", VA = "0x5B0438")]
		set
		{
		}
	}

	[Token(Token = "0x6000A9B")]
	[Address(RVA = "0x5B0440", Offset = "0x5B0440", VA = "0x5B0440")]
	public AnimationTriggersExtended()
	{
	}
}
