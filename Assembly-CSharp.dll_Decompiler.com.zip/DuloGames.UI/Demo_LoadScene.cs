using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001A7")]
public class Demo_LoadScene : MonoBehaviour
{
	[Token(Token = "0x4000B2C")]
	[FieldOffset(Offset = "0x18")]
	public string scene;

	[Token(Token = "0x6000A5F")]
	[Address(RVA = "0x3866E8", Offset = "0x3866E8", VA = "0x3866E8")]
	public void LoadScene()
	{
	}

	[Token(Token = "0x6000A60")]
	[Address(RVA = "0x386748", Offset = "0x386748", VA = "0x386748")]
	public Demo_LoadScene()
	{
	}
}
