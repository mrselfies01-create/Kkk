using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001D9")]
public class UISelectField : Toggle
{
	[Token(Token = "0x200025E")]
	public enum Direction
	{
		[Token(Token = "0x4000F4E")]
		Auto,
		[Token(Token = "0x4000F4F")]
		Down,
		[Token(Token = "0x4000F50")]
		Up
	}

	[Token(Token = "0x200025F")]
	public enum VisualState
	{
		[Token(Token = "0x4000F52")]
		Normal,
		[Token(Token = "0x4000F53")]
		Highlighted,
		[Token(Token = "0x4000F54")]
		Pressed,
		[Token(Token = "0x4000F55")]
		Active,
		[Token(Token = "0x4000F56")]
		ActiveHighlighted,
		[Token(Token = "0x4000F57")]
		ActivePressed,
		[Token(Token = "0x4000F58")]
		Disabled
	}

	[Token(Token = "0x2000260")]
	public enum ListAnimationType
	{
		[Token(Token = "0x4000F5A")]
		None,
		[Token(Token = "0x4000F5B")]
		Fade,
		[Token(Token = "0x4000F5C")]
		Animation
	}

	[Token(Token = "0x2000261")]
	public enum OptionTextTransitionType
	{
		[Token(Token = "0x4000F5E")]
		None,
		[Token(Token = "0x4000F5F")]
		CrossFade
	}

	[Token(Token = "0x2000262")]
	public enum OptionTextEffectType
	{
		[Token(Token = "0x4000F61")]
		None,
		[Token(Token = "0x4000F62")]
		Shadow,
		[Token(Token = "0x4000F63")]
		Outline
	}

	[Serializable]
	[Token(Token = "0x2000263")]
	public class ChangeEvent : UnityEvent<int, string>
	{
		[Token(Token = "0x6000DCD")]
		[Address(RVA = "0x78FCE4", Offset = "0x78FCE4", VA = "0x78FCE4")]
		public ChangeEvent()
		{
		}
	}

	[Token(Token = "0x4000C09")]
	[FieldOffset(Offset = "0x118")]
	private string m_SelectedItem;

	[Token(Token = "0x4000C0A")]
	[FieldOffset(Offset = "0x120")]
	private Direction m_Direction;

	[Token(Token = "0x4000C0B")]
	[FieldOffset(Offset = "0x128")]
	private List<UISelectField_Option> m_OptionObjects;

	[Token(Token = "0x4000C0C")]
	[FieldOffset(Offset = "0x130")]
	private VisualState m_CurrentVisualState;

	[Token(Token = "0x4000C0D")]
	[FieldOffset(Offset = "0x134")]
	private bool m_PointerWasUsedOnOption;

	[Token(Token = "0x4000C0E")]
	[FieldOffset(Offset = "0x138")]
	private GameObject m_ListObject;

	[Token(Token = "0x4000C0F")]
	[FieldOffset(Offset = "0x140")]
	private CanvasGroup m_ListCanvasGroup;

	[Token(Token = "0x4000C10")]
	[FieldOffset(Offset = "0x148")]
	private Vector2 m_LastListSize;

	[Token(Token = "0x4000C11")]
	[FieldOffset(Offset = "0x150")]
	public UISelectField_Arrow arrow;

	[Token(Token = "0x4000C12")]
	[FieldOffset(Offset = "0x158")]
	public UISelectField_Label label;

	[Token(Token = "0x4000C13")]
	[FieldOffset(Offset = "0x160")]
	public List<string> options;

	[Token(Token = "0x4000C14")]
	[FieldOffset(Offset = "0x168")]
	public ColorBlockExtended colors;

	[Token(Token = "0x4000C15")]
	[FieldOffset(Offset = "0x1E0")]
	public SpriteStateExtended spriteState;

	[Token(Token = "0x4000C16")]
	[FieldOffset(Offset = "0x210")]
	public AnimationTriggersExtended animationTriggers;

	[Token(Token = "0x4000C17")]
	[FieldOffset(Offset = "0x218")]
	public Sprite listBackgroundSprite;

	[Token(Token = "0x4000C18")]
	[FieldOffset(Offset = "0x220")]
	public Type listBackgroundSpriteType;

	[Token(Token = "0x4000C19")]
	[FieldOffset(Offset = "0x224")]
	public Color listBackgroundColor;

	[Token(Token = "0x4000C1A")]
	[FieldOffset(Offset = "0x238")]
	public RectOffset listMargins;

	[Token(Token = "0x4000C1B")]
	[FieldOffset(Offset = "0x240")]
	public RectOffset listPadding;

	[Token(Token = "0x4000C1C")]
	[FieldOffset(Offset = "0x248")]
	public float listSpacing;

	[Token(Token = "0x4000C1D")]
	[FieldOffset(Offset = "0x24C")]
	public ListAnimationType listAnimationType;

	[Token(Token = "0x4000C1E")]
	[FieldOffset(Offset = "0x250")]
	public float listAnimationDuration;

	[Token(Token = "0x4000C1F")]
	[FieldOffset(Offset = "0x258")]
	public RuntimeAnimatorController listAnimatorController;

	[Token(Token = "0x4000C20")]
	[FieldOffset(Offset = "0x260")]
	public string listAnimationOpenTrigger;

	[Token(Token = "0x4000C21")]
	[FieldOffset(Offset = "0x268")]
	public string listAnimationCloseTrigger;

	[Token(Token = "0x4000C22")]
	[FieldOffset(Offset = "0x270")]
	public Font optionFont;

	[Token(Token = "0x4000C23")]
	[FieldOffset(Offset = "0x278")]
	public int optionFontSize;

	[Token(Token = "0x4000C24")]
	[FieldOffset(Offset = "0x27C")]
	public FontStyle optionFontStyle;

	[Token(Token = "0x4000C25")]
	[FieldOffset(Offset = "0x280")]
	public Color optionColor;

	[Token(Token = "0x4000C26")]
	[FieldOffset(Offset = "0x290")]
	public OptionTextTransitionType optionTextTransitionType;

	[Token(Token = "0x4000C27")]
	[FieldOffset(Offset = "0x294")]
	public ColorBlockExtended optionTextTransitionColors;

	[Token(Token = "0x4000C28")]
	[FieldOffset(Offset = "0x310")]
	public RectOffset optionPadding;

	[Token(Token = "0x4000C29")]
	[FieldOffset(Offset = "0x318")]
	public OptionTextEffectType optionTextEffectType;

	[Token(Token = "0x4000C2A")]
	[FieldOffset(Offset = "0x31C")]
	public Color optionTextEffectColor;

	[Token(Token = "0x4000C2B")]
	[FieldOffset(Offset = "0x32C")]
	public Vector2 optionTextEffectDistance;

	[Token(Token = "0x4000C2C")]
	[FieldOffset(Offset = "0x334")]
	public bool optionTextEffectUseGraphicAlpha;

	[Token(Token = "0x4000C2D")]
	[FieldOffset(Offset = "0x338")]
	public Sprite optionBackgroundSprite;

	[Token(Token = "0x4000C2E")]
	[FieldOffset(Offset = "0x340")]
	public Color optionBackgroundSpriteColor;

	[Token(Token = "0x4000C2F")]
	[FieldOffset(Offset = "0x350")]
	public Type optionBackgroundSpriteType;

	[Token(Token = "0x4000C30")]
	[FieldOffset(Offset = "0x354")]
	public Transition optionBackgroundTransitionType;

	[Token(Token = "0x4000C31")]
	[FieldOffset(Offset = "0x358")]
	public ColorBlockExtended optionBackgroundTransColors;

	[Token(Token = "0x4000C32")]
	[FieldOffset(Offset = "0x3D0")]
	public SpriteStateExtended optionBackgroundSpriteStates;

	[Token(Token = "0x4000C33")]
	[FieldOffset(Offset = "0x400")]
	public AnimationTriggersExtended optionBackgroundAnimationTriggers;

	[Token(Token = "0x4000C34")]
	[FieldOffset(Offset = "0x408")]
	public RuntimeAnimatorController optionBackgroundAnimatorController;

	[Token(Token = "0x4000C35")]
	[FieldOffset(Offset = "0x410")]
	public Sprite listSeparatorSprite;

	[Token(Token = "0x4000C36")]
	[FieldOffset(Offset = "0x418")]
	public Type listSeparatorType;

	[Token(Token = "0x4000C37")]
	[FieldOffset(Offset = "0x41C")]
	public Color listSeparatorColor;

	[Token(Token = "0x4000C38")]
	[FieldOffset(Offset = "0x42C")]
	public float listSeparatorHeight;

	[Token(Token = "0x4000C39")]
	[FieldOffset(Offset = "0x430")]
	public ChangeEvent onChange;

	[NonSerialized]
	[Token(Token = "0x4000C3A")]
	[FieldOffset(Offset = "0x438")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x170001FE")]
	public Direction direction
	{
		[Token(Token = "0x6000BB9")]
		[Address(RVA = "0x3EB594", Offset = "0x3EB594", VA = "0x3EB594")]
		get
		{
			return default(Direction);
		}
		[Token(Token = "0x6000BBA")]
		[Address(RVA = "0x3EB59C", Offset = "0x3EB59C", VA = "0x3EB59C")]
		set
		{
		}
	}

	[Token(Token = "0x170001FF")]
	public string value
	{
		[Token(Token = "0x6000BBB")]
		[Address(RVA = "0x3EB5A4", Offset = "0x3EB5A4", VA = "0x3EB5A4")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000BBC")]
		[Address(RVA = "0x3EB5AC", Offset = "0x3EB5AC", VA = "0x3EB5AC")]
		set
		{
		}
	}

	[Token(Token = "0x17000200")]
	public int selectedOptionIndex
	{
		[Token(Token = "0x6000BBD")]
		[Address(RVA = "0x3EB650", Offset = "0x3EB650", VA = "0x3EB650")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x17000201")]
	public bool IsOpen
	{
		[Token(Token = "0x6000BC5")]
		[Address(RVA = "0x3EBC88", Offset = "0x3EBC88", VA = "0x3EBC88")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000BBE")]
	[Address(RVA = "0x3EB730", Offset = "0x3EB730", VA = "0x3EB730")]
	protected UISelectField()
	{
	}

	[Token(Token = "0x6000BBF")]
	[Address(RVA = "0x3EBA1C", Offset = "0x3EBA1C", VA = "0x3EBA1C", Slot = "4")]
	protected override void Awake()
	{
	}

	[Token(Token = "0x6000BC0")]
	[Address(RVA = "0x3EBACC", Offset = "0x3EBACC", VA = "0x3EBACC", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000BC1")]
	[Address(RVA = "0x3EBAF4", Offset = "0x3EBAF4", VA = "0x3EBAF4", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000BC2")]
	[Address(RVA = "0x3EBB9C", Offset = "0x3EBB9C", VA = "0x3EBB9C", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000BC3")]
	[Address(RVA = "0x3EBC70", Offset = "0x3EBC70", VA = "0x3EBC70")]
	public void Open()
	{
	}

	[Token(Token = "0x6000BC4")]
	[Address(RVA = "0x3EBC7C", Offset = "0x3EBC7C", VA = "0x3EBC7C")]
	public void Close()
	{
	}

	[Token(Token = "0x6000BC6")]
	[Address(RVA = "0x3EB658", Offset = "0x3EB658", VA = "0x3EB658")]
	public int GetOptionIndex(string optionValue)
	{
		return default(int);
	}

	[Token(Token = "0x6000BC7")]
	[Address(RVA = "0x3EBC90", Offset = "0x3EBC90", VA = "0x3EBC90")]
	public void SelectOptionByIndex(int index)
	{
	}

	[Token(Token = "0x6000BC8")]
	[Address(RVA = "0x3EB5B0", Offset = "0x3EB5B0", VA = "0x3EB5B0")]
	public void SelectOption(string optionValue)
	{
	}

	[Token(Token = "0x6000BC9")]
	[Address(RVA = "0x3EBDB0", Offset = "0x3EBDB0", VA = "0x3EBDB0")]
	public void AddOption(string optionValue)
	{
	}

	[Token(Token = "0x6000BCA")]
	[Address(RVA = "0x3EBE24", Offset = "0x3EBE24", VA = "0x3EBE24")]
	public void AddOptionAtIndex(string optionValue, int index)
	{
	}

	[Token(Token = "0x6000BCB")]
	[Address(RVA = "0x3EBECC", Offset = "0x3EBECC", VA = "0x3EBECC")]
	public void RemoveOption(string optionValue)
	{
	}

	[Token(Token = "0x6000BCC")]
	[Address(RVA = "0x3EBFE0", Offset = "0x3EBFE0", VA = "0x3EBFE0")]
	public void RemoveOptionAtIndex(int index)
	{
	}

	[Token(Token = "0x6000BCD")]
	[Address(RVA = "0x3EBF6C", Offset = "0x3EBF6C", VA = "0x3EBF6C")]
	public void ValidateSelectedOption()
	{
	}

	[Token(Token = "0x6000BCE")]
	[Address(RVA = "0x3EC06C", Offset = "0x3EC06C", VA = "0x3EC06C")]
	public void OnOptionSelect(string option)
	{
	}

	[Token(Token = "0x6000BCF")]
	[Address(RVA = "0x3EC18C", Offset = "0x3EC18C", VA = "0x3EC18C")]
	public void OnOptionPointerUp(BaseEventData eventData)
	{
	}

	[Token(Token = "0x6000BD0")]
	[Address(RVA = "0x3EC198", Offset = "0x3EC198", VA = "0x3EC198", Slot = "51")]
	protected virtual void TriggerChangeEvent()
	{
	}

	[Token(Token = "0x6000BD1")]
	[Address(RVA = "0x3EC2B4", Offset = "0x3EC2B4", VA = "0x3EC2B4")]
	private void OnToggleValueChanged(bool state)
	{
	}

	[Token(Token = "0x6000BD2")]
	[Address(RVA = "0x3EC324", Offset = "0x3EC324", VA = "0x3EC324", Slot = "37")]
	public override void OnDeselect(BaseEventData eventData)
	{
	}

	[Token(Token = "0x6000BD3")]
	[Address(RVA = "0x3EC4C8", Offset = "0x3EC4C8", VA = "0x3EC4C8", Slot = "31")]
	public override void OnMove(AxisEventData eventData)
	{
	}

	[Token(Token = "0x6000BD4")]
	[Address(RVA = "0x3EC5A8", Offset = "0x3EC5A8", VA = "0x3EC5A8", Slot = "26")]
	protected override void DoStateTransition(SelectionState state, bool instant)
	{
	}

	[Token(Token = "0x6000BD5")]
	[Address(RVA = "0x3EC824", Offset = "0x3EC824", VA = "0x3EC824")]
	private void StartColorTween(Color color, float duration)
	{
	}

	[Token(Token = "0x6000BD6")]
	[Address(RVA = "0x3EC914", Offset = "0x3EC914", VA = "0x3EC914")]
	private void DoSpriteSwap(Sprite newSprite)
	{
	}

	[Token(Token = "0x6000BD7")]
	[Address(RVA = "0x3EC9FC", Offset = "0x3EC9FC", VA = "0x3EC9FC")]
	private void TriggerAnimation(string trigger)
	{
	}

	[Token(Token = "0x6000BD8")]
	[Address(RVA = "0x3ECE8C", Offset = "0x3ECE8C", VA = "0x3ECE8C", Slot = "52")]
	protected virtual void ToggleList(bool state)
	{
	}

	[Token(Token = "0x6000BD9")]
	[Address(RVA = "0x3ED034", Offset = "0x3ED034", VA = "0x3ED034")]
	protected void CreateList()
	{
	}

	[Token(Token = "0x6000BDA")]
	[Address(RVA = "0x3ED904", Offset = "0x3ED904", VA = "0x3ED904")]
	protected void CreateOption(int index, ToggleGroup toggleGroup)
	{
	}

	[Token(Token = "0x6000BDB")]
	[Address(RVA = "0x3EDF8C", Offset = "0x3EDF8C", VA = "0x3EDF8C")]
	protected void CreateSeparator(int index)
	{
	}

	[Token(Token = "0x6000BDC")]
	[Address(RVA = "0x3EE238", Offset = "0x3EE238", VA = "0x3EE238", Slot = "53")]
	protected virtual void ListCleanup()
	{
	}

	[Token(Token = "0x6000BDD")]
	[Address(RVA = "0x3EE2F8", Offset = "0x3EE2F8", VA = "0x3EE2F8", Slot = "54")]
	public virtual void PositionListForDirection(Direction direction)
	{
	}

	[Token(Token = "0x6000BDE")]
	[Address(RVA = "0x3EE5AC", Offset = "0x3EE5AC", VA = "0x3EE5AC", Slot = "55")]
	protected virtual void ListDimensionsChanged()
	{
	}

	[Token(Token = "0x6000BDF")]
	[Address(RVA = "0x3ED5C4", Offset = "0x3ED5C4", VA = "0x3ED5C4")]
	private void TweenListAlpha(float targetAlpha, float duration, bool ignoreTimeScale)
	{
	}

	[Token(Token = "0x6000BE0")]
	[Address(RVA = "0x3EE6DC", Offset = "0x3EE6DC", VA = "0x3EE6DC")]
	private void SetListAlpha(float alpha)
	{
	}

	[Token(Token = "0x6000BE1")]
	[Address(RVA = "0x3ED780", Offset = "0x3ED780", VA = "0x3ED780")]
	private void TriggerListAnimation(string trigger)
	{
	}

	[Token(Token = "0x6000BE2")]
	[Address(RVA = "0x3EE784", Offset = "0x3EE784", VA = "0x3EE784", Slot = "56")]
	protected virtual void OnListTweenFinished()
	{
	}

	[Token(Token = "0x6000BE3")]
	[Address(RVA = "0x3EE7A0", Offset = "0x3EE7A0", VA = "0x3EE7A0", Slot = "57")]
	protected virtual void OnListAnimationFinish(UISelectField_List.State state)
	{
	}
}
