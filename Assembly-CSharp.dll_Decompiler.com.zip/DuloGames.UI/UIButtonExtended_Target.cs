using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E0")]
public class UIButtonExtended_Target : MonoBehaviour
{
	[Serializable]
	[Token(Token = "0x200026B")]
	public struct SpriteState
	{
		[Token(Token = "0x4000F6F")]
		[FieldOffset(Offset = "0x0")]
		private Sprite m_HighlightedSprite;

		[Token(Token = "0x4000F70")]
		[FieldOffset(Offset = "0x8")]
		private Sprite m_PressedSprite;

		[Token(Token = "0x4000F71")]
		[FieldOffset(Offset = "0x10")]
		private Sprite m_DisabledSprite;

		[Token(Token = "0x17000274")]
		public Sprite highlightedSprite
		{
			[Token(Token = "0x6000DD2")]
			[Address(RVA = "0x2A6378", Offset = "0x2A6378", VA = "0x2A6378")]
			get
			{
				return null;
			}
			[Token(Token = "0x6000DD3")]
			[Address(RVA = "0x2A6380", Offset = "0x2A6380", VA = "0x2A6380")]
			set
			{
			}
		}

		[Token(Token = "0x17000275")]
		public Sprite pressedSprite
		{
			[Token(Token = "0x6000DD4")]
			[Address(RVA = "0x2A6388", Offset = "0x2A6388", VA = "0x2A6388")]
			get
			{
				return null;
			}
			[Token(Token = "0x6000DD5")]
			[Address(RVA = "0x2A6390", Offset = "0x2A6390", VA = "0x2A6390")]
			set
			{
			}
		}

		[Token(Token = "0x17000276")]
		public Sprite disabledSprite
		{
			[Token(Token = "0x6000DD6")]
			[Address(RVA = "0x2A6398", Offset = "0x2A6398", VA = "0x2A6398")]
			get
			{
				return null;
			}
			[Token(Token = "0x6000DD7")]
			[Address(RVA = "0x2A63A0", Offset = "0x2A63A0", VA = "0x2A63A0")]
			set
			{
			}
		}
	}

	[Token(Token = "0x4000C51")]
	[FieldOffset(Offset = "0x18")]
	private Transition m_Transition;

	[Token(Token = "0x4000C52")]
	[FieldOffset(Offset = "0x1C")]
	private ColorBlock m_Colors;

	[Token(Token = "0x4000C53")]
	[FieldOffset(Offset = "0x78")]
	private SpriteState m_SpriteState;

	[Token(Token = "0x4000C54")]
	[FieldOffset(Offset = "0x90")]
	private AnimationTriggers m_AnimationTriggers;

	[Token(Token = "0x4000C55")]
	[FieldOffset(Offset = "0x98")]
	private Graphic m_TargetGraphic;

	[Token(Token = "0x4000C56")]
	[FieldOffset(Offset = "0xA0")]
	private GameObject m_TargetGameObject;

	[Token(Token = "0x17000202")]
	public Transition transition
	{
		[Token(Token = "0x6000C13")]
		[Address(RVA = "0x3E31FC", Offset = "0x3E31FC", VA = "0x3E31FC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Transition);
		}
		[Token(Token = "0x6000C14")]
		[Address(RVA = "0x3E3204", Offset = "0x3E3204", VA = "0x3E3204")]
		set
		{
		}
	}

	[Token(Token = "0x17000203")]
	public ColorBlock colors
	{
		[Token(Token = "0x6000C15")]
		[Address(RVA = "0x3E320C", Offset = "0x3E320C", VA = "0x3E320C")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(ColorBlock);
		}
		[Token(Token = "0x6000C16")]
		[Address(RVA = "0x3E321C", Offset = "0x3E321C", VA = "0x3E321C")]
		set
		{
		}
	}

	[Token(Token = "0x17000204")]
	public SpriteState spriteState
	{
		[Token(Token = "0x6000C17")]
		[Address(RVA = "0x3E3238", Offset = "0x3E3238", VA = "0x3E3238")]
		get
		{
			return default(SpriteState);
		}
		[Token(Token = "0x6000C18")]
		[Address(RVA = "0x3E324C", Offset = "0x3E324C", VA = "0x3E324C")]
		set
		{
		}
	}

	[Token(Token = "0x17000205")]
	public AnimationTriggers animationTriggers
	{
		[Token(Token = "0x6000C19")]
		[Address(RVA = "0x3E3260", Offset = "0x3E3260", VA = "0x3E3260")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C1A")]
		[Address(RVA = "0x3E3268", Offset = "0x3E3268", VA = "0x3E3268")]
		set
		{
		}
	}

	[Token(Token = "0x17000206")]
	public Graphic targetGraphic
	{
		[Token(Token = "0x6000C1B")]
		[Address(RVA = "0x3E3270", Offset = "0x3E3270", VA = "0x3E3270")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C1C")]
		[Address(RVA = "0x3E3278", Offset = "0x3E3278", VA = "0x3E3278")]
		set
		{
		}
	}

	[Token(Token = "0x17000207")]
	public GameObject targetGameObject
	{
		[Token(Token = "0x6000C1D")]
		[Address(RVA = "0x3E3280", Offset = "0x3E3280", VA = "0x3E3280")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C1E")]
		[Address(RVA = "0x3E3288", Offset = "0x3E3288", VA = "0x3E3288")]
		set
		{
		}
	}

	[Token(Token = "0x17000208")]
	public Animator animator
	{
		[Token(Token = "0x6000C1F")]
		[Address(RVA = "0x3E3290", Offset = "0x3E3290", VA = "0x3E3290")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x17000209")]
	public UIButtonExtended button
	{
		[Token(Token = "0x6000C20")]
		[Address(RVA = "0x3E332C", Offset = "0x3E332C", VA = "0x3E332C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000C21")]
	[Address(RVA = "0x3E337C", Offset = "0x3E337C", VA = "0x3E337C")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000C22")]
	[Address(RVA = "0x3E3478", Offset = "0x3E3478", VA = "0x3E3478")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000C23")]
	[Address(RVA = "0x3E34A0", Offset = "0x3E34A0", VA = "0x3E34A0")]
	protected void OnDisable()
	{
	}

	[Token(Token = "0x6000C24")]
	[Address(RVA = "0x3E352C", Offset = "0x3E352C", VA = "0x3E352C")]
	protected void OnDestroy()
	{
	}

	[Token(Token = "0x6000C25")]
	[Address(RVA = "0x3E34A4", Offset = "0x3E34A4", VA = "0x3E34A4")]
	protected void InstantClearState()
	{
	}

	[Token(Token = "0x6000C26")]
	[Address(RVA = "0x3E348C", Offset = "0x3E348C", VA = "0x3E348C")]
	private void InternalEvaluateAndTransitionToNormalState(bool instant)
	{
	}

	[Token(Token = "0x6000C27")]
	[Address(RVA = "0x3E39DC", Offset = "0x3E39DC", VA = "0x3E39DC", Slot = "4")]
	protected virtual void OnStateChange(UIButtonExtended.VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000C28")]
	[Address(RVA = "0x3E3628", Offset = "0x3E3628", VA = "0x3E3628")]
	private void StartColorTween(Color targetColor, bool instant)
	{
	}

	[Token(Token = "0x6000C29")]
	[Address(RVA = "0x3E3720", Offset = "0x3E3720", VA = "0x3E3720")]
	private void DoSpriteSwap(Sprite newSprite)
	{
	}

	[Token(Token = "0x6000C2A")]
	[Address(RVA = "0x3E3808", Offset = "0x3E3808", VA = "0x3E3808")]
	private void TriggerAnimation(string triggername)
	{
	}

	[Token(Token = "0x6000C2B")]
	[Address(RVA = "0x3E3B20", Offset = "0x3E3B20", VA = "0x3E3B20")]
	public UIButtonExtended_Target()
	{
	}
}
