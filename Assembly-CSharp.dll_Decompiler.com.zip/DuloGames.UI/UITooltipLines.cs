using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001BA")]
public class UITooltipLines
{
	[Token(Token = "0x200024D")]
	public enum LineStyle
	{
		[Token(Token = "0x4000F2A")]
		Title,
		[Token(Token = "0x4000F2B")]
		Attribute,
		[Token(Token = "0x4000F2C")]
		Description
	}

	[Token(Token = "0x200024E")]
	public class Line
	{
		[Token(Token = "0x4000F2D")]
		[FieldOffset(Offset = "0x10")]
		public string left;

		[Token(Token = "0x4000F2E")]
		[FieldOffset(Offset = "0x18")]
		public string right;

		[Token(Token = "0x4000F2F")]
		[FieldOffset(Offset = "0x20")]
		public bool isComplete;

		[Token(Token = "0x4000F30")]
		[FieldOffset(Offset = "0x28")]
		public RectOffset padding;

		[Token(Token = "0x4000F31")]
		[FieldOffset(Offset = "0x30")]
		public LineStyle style;

		[Token(Token = "0x6000DB7")]
		[Address(RVA = "0x790314", Offset = "0x790314", VA = "0x790314")]
		public Line(string left, string right, bool isComplete, RectOffset padding, LineStyle style)
		{
		}
	}

	[Token(Token = "0x200024F")]
	public class Lines : List<Line>
	{
		[Token(Token = "0x6000DB8")]
		[Address(RVA = "0x790370", Offset = "0x790370", VA = "0x790370")]
		public Lines()
		{
		}
	}

	[Token(Token = "0x4000B86")]
	[FieldOffset(Offset = "0x10")]
	public Lines lineList;

	[Token(Token = "0x6000AC2")]
	[Address(RVA = "0x47618C", Offset = "0x47618C", VA = "0x47618C")]
	public void AddLine(string leftContent, string rightContent)
	{
	}

	[Token(Token = "0x6000AC3")]
	[Address(RVA = "0x475650", Offset = "0x475650", VA = "0x475650")]
	public void AddLine(string leftContent, string rightContent, RectOffset padding)
	{
	}

	[Token(Token = "0x6000AC4")]
	[Address(RVA = "0x476250", Offset = "0x476250", VA = "0x476250")]
	public void AddLine(string content)
	{
	}

	[Token(Token = "0x6000AC5")]
	[Address(RVA = "0x4753A4", Offset = "0x4753A4", VA = "0x4753A4")]
	public void AddLine(string content, RectOffset padding)
	{
	}

	[Token(Token = "0x6000AC6")]
	[Address(RVA = "0x4754F8", Offset = "0x4754F8", VA = "0x4754F8")]
	public void AddLine(string content, RectOffset padding, LineStyle style)
	{
	}

	[Token(Token = "0x6000AC7")]
	[Address(RVA = "0x47579C", Offset = "0x47579C", VA = "0x47579C")]
	public void AddLine(string leftContent, string rightContent, RectOffset padding, LineStyle style)
	{
	}

	[Token(Token = "0x6000AC8")]
	[Address(RVA = "0x4758CC", Offset = "0x4758CC", VA = "0x4758CC")]
	public void AddColumn(string content)
	{
	}

	[Token(Token = "0x6000AC9")]
	[Address(RVA = "0x47533C", Offset = "0x47533C", VA = "0x47533C")]
	public UITooltipLines()
	{
	}
}
