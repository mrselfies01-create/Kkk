using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001C6")]
public class NameAppendIndex : MonoBehaviour
{
	[Token(Token = "0x6000B6C")]
	[Address(RVA = "0x39249C", Offset = "0x39249C", VA = "0x39249C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000B6D")]
	[Address(RVA = "0x39281C", Offset = "0x39281C", VA = "0x39281C")]
	public NameAppendIndex()
	{
	}
}
