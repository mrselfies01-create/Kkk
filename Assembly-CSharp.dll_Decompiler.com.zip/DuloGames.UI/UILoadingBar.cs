using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001E5")]
public class UILoadingBar : MonoBehaviour
{
	[Serializable]
	[Token(Token = "0x2000272")]
	public class OnChangeEvent : UnityEvent<float>
	{
		[Token(Token = "0x6000DDB")]
		[Address(RVA = "0x78FC44", Offset = "0x78FC44", VA = "0x78FC44")]
		public OnChangeEvent()
		{
		}
	}

	[Token(Token = "0x2000273")]
	public enum Type
	{
		[Token(Token = "0x4000F81")]
		Normal,
		[Token(Token = "0x4000F82")]
		Masked
	}

	[Token(Token = "0x4000C82")]
	[FieldOffset(Offset = "0x18")]
	private float m_FillAmount;

	[Token(Token = "0x4000C83")]
	[FieldOffset(Offset = "0x1C")]
	private Type m_Type;

	[Token(Token = "0x4000C84")]
	[FieldOffset(Offset = "0x20")]
	private Image m_TargetImage;

	[Token(Token = "0x4000C85")]
	[FieldOffset(Offset = "0x28")]
	private RectTransform m_TargetTransform;

	[Token(Token = "0x4000C86")]
	[FieldOffset(Offset = "0x30")]
	private float m_TransformWidth;

	[Token(Token = "0x4000C87")]
	[FieldOffset(Offset = "0x38")]
	private Text m_TextComponent;

	[Token(Token = "0x4000C88")]
	[FieldOffset(Offset = "0x40")]
	private bool m_IsDemo;

	[Token(Token = "0x4000C89")]
	[FieldOffset(Offset = "0x44")]
	private float m_Duration;

	[Token(Token = "0x4000C8A")]
	[FieldOffset(Offset = "0x48")]
	private string m_LoadScene;

	[Token(Token = "0x4000C8B")]
	[FieldOffset(Offset = "0x50")]
	private OnChangeEvent m_OnChange;

	[NonSerialized]
	[Token(Token = "0x4000C8C")]
	[FieldOffset(Offset = "0x58")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x6000C78")]
	[Address(RVA = "0x3E8BA0", Offset = "0x3E8BA0", VA = "0x3E8BA0")]
	protected UILoadingBar()
	{
	}

	[Token(Token = "0x6000C79")]
	[Address(RVA = "0x3E8C70", Offset = "0x3E8C70", VA = "0x3E8C70")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000C7A")]
	[Address(RVA = "0x3E8F08", Offset = "0x3E8F08", VA = "0x3E8F08")]
	protected void SetFillAmount(float amount)
	{
	}

	[Token(Token = "0x6000C7B")]
	[Address(RVA = "0x3E8FC8", Offset = "0x3E8FC8", VA = "0x3E8FC8")]
	protected void FillAmountChanged()
	{
	}

	[Token(Token = "0x6000C7C")]
	[Address(RVA = "0x3E8D28", Offset = "0x3E8D28", VA = "0x3E8D28")]
	public void StartDemoTween()
	{
	}

	[Token(Token = "0x6000C7D")]
	[Address(RVA = "0x3E917C", Offset = "0x3E917C", VA = "0x3E917C")]
	protected void OnTweenFinished()
	{
	}
}
