using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E7")]
public class UIProgressBar : MonoBehaviour, IDisposable
{
	[Serializable]
	[Token(Token = "0x2000274")]
	public class ChangeEvent : UnityEvent<float>
	{
		[Token(Token = "0x6000DDC")]
		[Address(RVA = "0x78FC94", Offset = "0x78FC94", VA = "0x78FC94")]
		public ChangeEvent()
		{
		}
	}

	[Token(Token = "0x2000275")]
	public enum Type
	{
		[Token(Token = "0x4000F84")]
		Filled,
		[Token(Token = "0x4000F85")]
		Resize
	}

	[Token(Token = "0x2000276")]
	public enum FillSizing
	{
		[Token(Token = "0x4000F87")]
		Parent,
		[Token(Token = "0x4000F88")]
		Fixed
	}

	[Token(Token = "0x4000C93")]
	[FieldOffset(Offset = "0x18")]
	private Type m_Type;

	[Token(Token = "0x4000C94")]
	[FieldOffset(Offset = "0x20")]
	private Image m_TargetImage;

	[Token(Token = "0x4000C95")]
	[FieldOffset(Offset = "0x28")]
	private RectTransform m_TargetTransform;

	[Token(Token = "0x4000C96")]
	[FieldOffset(Offset = "0x30")]
	private FillSizing m_FillSizing;

	[Token(Token = "0x4000C97")]
	[FieldOffset(Offset = "0x34")]
	private float m_MinWidth;

	[Token(Token = "0x4000C98")]
	[FieldOffset(Offset = "0x38")]
	private float m_MaxWidth;

	[Token(Token = "0x4000C99")]
	[FieldOffset(Offset = "0x3C")]
	private float m_FillAmount;

	[Token(Token = "0x4000C9A")]
	[FieldOffset(Offset = "0x40")]
	private int m_Steps;

	[Token(Token = "0x4000C9B")]
	[FieldOffset(Offset = "0x48")]
	public ChangeEvent onChange;

	[Token(Token = "0x1700021C")]
	public Type type
	{
		[Token(Token = "0x6000C83")]
		[Address(RVA = "0x3EA104", Offset = "0x3EA104", VA = "0x3EA104")]
		get
		{
			return default(Type);
		}
		[Token(Token = "0x6000C84")]
		[Address(RVA = "0x3EA10C", Offset = "0x3EA10C", VA = "0x3EA10C")]
		set
		{
		}
	}

	[Token(Token = "0x1700021D")]
	public Image targetImage
	{
		[Token(Token = "0x6000C85")]
		[Address(RVA = "0x3EA114", Offset = "0x3EA114", VA = "0x3EA114")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C86")]
		[Address(RVA = "0x3EA11C", Offset = "0x3EA11C", VA = "0x3EA11C")]
		set
		{
		}
	}

	[Token(Token = "0x1700021E")]
	public RectTransform targetTransform
	{
		[Token(Token = "0x6000C87")]
		[Address(RVA = "0x3EA124", Offset = "0x3EA124", VA = "0x3EA124")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C88")]
		[Address(RVA = "0x3EA12C", Offset = "0x3EA12C", VA = "0x3EA12C")]
		set
		{
		}
	}

	[Token(Token = "0x1700021F")]
	public float minWidth
	{
		[Token(Token = "0x6000C89")]
		[Address(RVA = "0x3EA134", Offset = "0x3EA134", VA = "0x3EA134")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C8A")]
		[Address(RVA = "0x3EA13C", Offset = "0x3EA13C", VA = "0x3EA13C")]
		set
		{
		}
	}

	[Token(Token = "0x17000220")]
	public float maxWidth
	{
		[Token(Token = "0x6000C8B")]
		[Address(RVA = "0x3EA394", Offset = "0x3EA394", VA = "0x3EA394")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C8C")]
		[Address(RVA = "0x3EA39C", Offset = "0x3EA39C", VA = "0x3EA39C")]
		set
		{
		}
	}

	[Token(Token = "0x17000221")]
	public float fillAmount
	{
		[Token(Token = "0x6000C8D")]
		[Address(RVA = "0x3EA3A4", Offset = "0x3EA3A4", VA = "0x3EA3A4", Slot = "4")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C8E")]
		[Address(RVA = "0x3E1408", Offset = "0x3E1408", VA = "0x3E1408", Slot = "5")]
		set
		{
		}
	}

	[Token(Token = "0x17000222")]
	public int steps
	{
		[Token(Token = "0x6000C8F")]
		[Address(RVA = "0x3EA3AC", Offset = "0x3EA3AC", VA = "0x3EA3AC")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000C90")]
		[Address(RVA = "0x3EA3B4", Offset = "0x3EA3B4", VA = "0x3EA3B4")]
		set
		{
		}
	}

	[Token(Token = "0x17000223")]
	public int currentStep
	{
		[Token(Token = "0x6000C91")]
		[Address(RVA = "0x3EA3BC", Offset = "0x3EA3BC", VA = "0x3EA3BC")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000C92")]
		[Address(RVA = "0x3EA45C", Offset = "0x3EA45C", VA = "0x3EA45C")]
		set
		{
		}
	}

	[Token(Token = "0x6000C93")]
	[Address(RVA = "0x3EA144", Offset = "0x3EA144", VA = "0x3EA144")]
	public void UpdateBarFill()
	{
	}

	[Token(Token = "0x6000C94")]
	[Address(RVA = "0x3EA51C", Offset = "0x3EA51C", VA = "0x3EA51C")]
	public void AddFill()
	{
	}

	[Token(Token = "0x6000C95")]
	[Address(RVA = "0x3EA574", Offset = "0x3EA574", VA = "0x3EA574")]
	public void RemoveFill()
	{
	}

	[Token(Token = "0x6000C96")]
	[Address(RVA = "0x3EA5CC", Offset = "0x3EA5CC", VA = "0x3EA5CC")]
	public UIProgressBar()
	{
	}
}
