using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001CC")]
public class UIIgnoreRaycast : MonoBehaviour, IDisposable
{
	[Token(Token = "0x6000B82")]
	[Address(RVA = "0x3E72E0", Offset = "0x3E72E0", VA = "0x3E72E0", Slot = "4")]
	public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B83")]
	[Address(RVA = "0x3E72E8", Offset = "0x3E72E8", VA = "0x3E72E8")]
	public UIIgnoreRaycast()
	{
	}
}
