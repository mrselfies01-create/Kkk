using System;
using Il2CppDummyDll;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DC")]
public class UISelectField_List : Selectable
{
	[Token(Token = "0x2000265")]
	public enum State
	{
		[Token(Token = "0x4000F68")]
		Opened,
		[Token(Token = "0x4000F69")]
		Closed
	}

	[Serializable]
	[Token(Token = "0x2000266")]
	public class AnimationFinishEvent : UnityEvent<State>
	{
		[Token(Token = "0x6000DCE")]
		[Address(RVA = "0x78FD34", Offset = "0x78FD34", VA = "0x78FD34")]
		public AnimationFinishEvent()
		{
		}
	}

	[Token(Token = "0x4000C43")]
	[FieldOffset(Offset = "0xF0")]
	public AnimationFinishEvent onAnimationFinish;

	[Token(Token = "0x4000C44")]
	[FieldOffset(Offset = "0xF8")]
	public UnityEvent onDimensionsChange;

	[Token(Token = "0x4000C45")]
	[FieldOffset(Offset = "0x100")]
	private string m_AnimationOpenTrigger;

	[Token(Token = "0x4000C46")]
	[FieldOffset(Offset = "0x108")]
	private string m_AnimationCloseTrigger;

	[Token(Token = "0x4000C47")]
	[FieldOffset(Offset = "0x110")]
	private State m_State;

	[Token(Token = "0x6000BF1")]
	[Address(RVA = "0x469598", Offset = "0x469598", VA = "0x469598", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000BF2")]
	[Address(RVA = "0x4695F4", Offset = "0x4695F4", VA = "0x4695F4", Slot = "10")]
	protected override void OnRectTransformDimensionsChange()
	{
	}

	[Token(Token = "0x6000BF3")]
	[Address(RVA = "0x469630", Offset = "0x469630", VA = "0x469630")]
	public void SetTriggers(string openTrigger, string closeTrigger)
	{
	}

	[Token(Token = "0x6000BF4")]
	[Address(RVA = "0x469638", Offset = "0x469638", VA = "0x469638")]
	protected void Update()
	{
	}

	[Token(Token = "0x6000BF5")]
	[Address(RVA = "0x4697F8", Offset = "0x4697F8", VA = "0x4697F8")]
	public bool IsPressed()
	{
		return default(bool);
	}

	[Token(Token = "0x6000BF6")]
	[Address(RVA = "0x469800", Offset = "0x469800", VA = "0x469800")]
	public bool IsHighlighted(BaseEventData eventData)
	{
		return default(bool);
	}

	[Token(Token = "0x6000BF7")]
	[Address(RVA = "0x469808", Offset = "0x469808", VA = "0x469808")]
	public UISelectField_List()
	{
	}
}
