using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001E9")]
public class UITab : Toggle
{
	[Token(Token = "0x200027A")]
	public enum TextTransition
	{
		[Token(Token = "0x4000F94")]
		None,
		[Token(Token = "0x4000F95")]
		ColorTint
	}

	[Token(Token = "0x4000CB3")]
	[FieldOffset(Offset = "0x118")]
	private GameObject m_TargetContent;

	[Token(Token = "0x4000CB4")]
	[FieldOffset(Offset = "0x120")]
	private Image m_ImageTarget;

	[Token(Token = "0x4000CB5")]
	[FieldOffset(Offset = "0x128")]
	private Transition m_ImageTransition;

	[Token(Token = "0x4000CB6")]
	[FieldOffset(Offset = "0x12C")]
	private ColorBlockExtended m_ImageColors;

	[Token(Token = "0x4000CB7")]
	[FieldOffset(Offset = "0x1A8")]
	private SpriteStateExtended m_ImageSpriteState;

	[Token(Token = "0x4000CB8")]
	[FieldOffset(Offset = "0x1D8")]
	private AnimationTriggersExtended m_ImageAnimationTriggers;

	[Token(Token = "0x4000CB9")]
	[FieldOffset(Offset = "0x1E0")]
	private Text m_TextTarget;

	[Token(Token = "0x4000CBA")]
	[FieldOffset(Offset = "0x1E8")]
	private TextTransition m_TextTransition;

	[Token(Token = "0x4000CBB")]
	[FieldOffset(Offset = "0x1EC")]
	private ColorBlockExtended m_TextColors;

	[Token(Token = "0x4000CBC")]
	[FieldOffset(Offset = "0x264")]
	private SelectionState m_CurrentState;

	[NonSerialized]
	[Token(Token = "0x4000CBD")]
	[FieldOffset(Offset = "0x268")]
	private readonly TweenRunner<ColorTween> m_ColorTweenRunner;

	[Token(Token = "0x6000CAD")]
	[Address(RVA = "0x471140", Offset = "0x471140", VA = "0x471140")]
	protected UITab()
	{
	}

	[Token(Token = "0x6000CAE")]
	[Address(RVA = "0x471230", Offset = "0x471230", VA = "0x471230", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000CAF")]
	[Address(RVA = "0x4716AC", Offset = "0x4716AC", VA = "0x4716AC")]
	protected void OnToggleStateChanged(bool state)
	{
	}

	[Token(Token = "0x6000CB0")]
	[Address(RVA = "0x4716F8", Offset = "0x4716F8", VA = "0x4716F8")]
	private void EvaluateAndToggleContent()
	{
	}

	[Token(Token = "0x6000CB1")]
	[Address(RVA = "0x4712E4", Offset = "0x4712E4", VA = "0x4712E4")]
	private void InternalEvaluateAndTransitionState(bool instant)
	{
	}

	[Token(Token = "0x6000CB2")]
	[Address(RVA = "0x471790", Offset = "0x471790", VA = "0x471790", Slot = "26")]
	protected override void DoStateTransition(SelectionState state, bool instant)
	{
	}

	[Token(Token = "0x6000CB3")]
	[Address(RVA = "0x4719D8", Offset = "0x4719D8", VA = "0x4719D8")]
	private void StartColorTween(Graphic target, Color targetColor, float duration)
	{
	}

	[Token(Token = "0x6000CB4")]
	[Address(RVA = "0x471DD8", Offset = "0x471DD8", VA = "0x471DD8")]
	private void StartColorTweenText(Color targetColor, float duration)
	{
	}

	[Token(Token = "0x6000CB5")]
	[Address(RVA = "0x471FBC", Offset = "0x471FBC", VA = "0x471FBC")]
	private void SetTextColor(Color color)
	{
	}

	[Token(Token = "0x6000CB6")]
	[Address(RVA = "0x471B18", Offset = "0x471B18", VA = "0x471B18")]
	private void DoSpriteSwap(Image target, Sprite newSprite)
	{
	}

	[Token(Token = "0x6000CB7")]
	[Address(RVA = "0x471BBC", Offset = "0x471BBC", VA = "0x471BBC")]
	private void TriggerAnimation(GameObject target, string triggername)
	{
	}

	[Token(Token = "0x6000CB8")]
	[Address(RVA = "0x472090", Offset = "0x472090", VA = "0x472090")]
	public void Activate()
	{
	}
}
