using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001A9")]
public class UIStatsAdd : MonoBehaviour
{
	[Token(Token = "0x4000B2D")]
	[FieldOffset(Offset = "0x18")]
	private Text m_ValueText;

	[Token(Token = "0x6000A63")]
	[Address(RVA = "0x470FB4", Offset = "0x470FB4", VA = "0x470FB4")]
	public void OnButtonPress()
	{
	}

	[Token(Token = "0x6000A64")]
	[Address(RVA = "0x47108C", Offset = "0x47108C", VA = "0x47108C")]
	public UIStatsAdd()
	{
	}
}
