using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001C5")]
public class IconNameing : MonoBehaviour
{
	[Token(Token = "0x4000BD6")]
	[FieldOffset(Offset = "0x18")]
	private Image m_Image;

	[Token(Token = "0x6000B69")]
	[Address(RVA = "0x38CC68", Offset = "0x38CC68", VA = "0x38CC68")]
	private void Start()
	{
	}

	[Token(Token = "0x6000B6A")]
	[Address(RVA = "0x38CC6C", Offset = "0x38CC6C", VA = "0x38CC6C")]
	private void SetName()
	{
	}

	[Token(Token = "0x6000B6B")]
	[Address(RVA = "0x38CD54", Offset = "0x38CD54", VA = "0x38CD54")]
	public IconNameing()
	{
	}
}
