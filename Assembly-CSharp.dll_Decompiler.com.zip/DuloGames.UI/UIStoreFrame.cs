using Il2CppDummyDll;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001AA")]
public class UIStoreFrame : Toggle
{
	[Token(Token = "0x6000A65")]
	[Address(RVA = "0x471094", Offset = "0x471094", VA = "0x471094", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000A66")]
	[Address(RVA = "0x471138", Offset = "0x471138", VA = "0x471138")]
	public UIStoreFrame()
	{
	}
}
