using Il2CppDummyDll;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001A8")]
public class UILevelFrame : Toggle
{
	[Token(Token = "0x6000A61")]
	[Address(RVA = "0x3E8AF4", Offset = "0x3E8AF4", VA = "0x3E8AF4", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000A62")]
	[Address(RVA = "0x3E8B98", Offset = "0x3E8B98", VA = "0x3E8B98")]
	public UILevelFrame()
	{
	}
}
