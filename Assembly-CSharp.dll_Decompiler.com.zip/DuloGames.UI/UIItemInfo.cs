using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B3")]
public class UIItemInfo
{
	[Token(Token = "0x4000B61")]
	[FieldOffset(Offset = "0x10")]
	public int ID;

	[Token(Token = "0x4000B62")]
	[FieldOffset(Offset = "0x18")]
	public string Name;

	[Token(Token = "0x4000B63")]
	[FieldOffset(Offset = "0x20")]
	public Sprite Icon;

	[Token(Token = "0x4000B64")]
	[FieldOffset(Offset = "0x28")]
	public string Description;

	[Token(Token = "0x4000B65")]
	[FieldOffset(Offset = "0x30")]
	public UIEquipmentType EquipType;

	[Token(Token = "0x4000B66")]
	[FieldOffset(Offset = "0x34")]
	public int ItemType;

	[Token(Token = "0x4000B67")]
	[FieldOffset(Offset = "0x38")]
	public string Type;

	[Token(Token = "0x4000B68")]
	[FieldOffset(Offset = "0x40")]
	public string Subtype;

	[Token(Token = "0x4000B69")]
	[FieldOffset(Offset = "0x48")]
	public int Damage;

	[Token(Token = "0x4000B6A")]
	[FieldOffset(Offset = "0x4C")]
	public float AttackSpeed;

	[Token(Token = "0x4000B6B")]
	[FieldOffset(Offset = "0x50")]
	public int Block;

	[Token(Token = "0x4000B6C")]
	[FieldOffset(Offset = "0x54")]
	public int Armor;

	[Token(Token = "0x4000B6D")]
	[FieldOffset(Offset = "0x58")]
	public int Stamina;

	[Token(Token = "0x4000B6E")]
	[FieldOffset(Offset = "0x5C")]
	public int Strength;

	[Token(Token = "0x6000ABB")]
	[Address(RVA = "0x3E7334", Offset = "0x3E7334", VA = "0x3E7334")]
	public UIItemInfo()
	{
	}
}
