using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001D0")]
public class Test_Fill : MonoBehaviour
{
	[Token(Token = "0x4000BEA")]
	[FieldOffset(Offset = "0x18")]
	public Image imageComponent;

	[Token(Token = "0x4000BEB")]
	[FieldOffset(Offset = "0x20")]
	public float Duration;

	[Token(Token = "0x4000BEC")]
	[FieldOffset(Offset = "0x24")]
	public TweenEasing Easing;

	[NonSerialized]
	[Token(Token = "0x4000BED")]
	[FieldOffset(Offset = "0x28")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x6000B97")]
	[Address(RVA = "0x3E0508", Offset = "0x3E0508", VA = "0x3E0508")]
	protected Test_Fill()
	{
	}

	[Token(Token = "0x6000B98")]
	[Address(RVA = "0x3E059C", Offset = "0x3E059C", VA = "0x3E059C")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000B99")]
	[Address(RVA = "0x3E07F4", Offset = "0x3E07F4", VA = "0x3E07F4")]
	protected void SetFillAmount(float amount)
	{
	}

	[Token(Token = "0x6000B9A")]
	[Address(RVA = "0x3E089C", Offset = "0x3E089C", VA = "0x3E089C")]
	protected void OnTweenFinished()
	{
	}

	[Token(Token = "0x6000B9B")]
	[Address(RVA = "0x3E0640", Offset = "0x3E0640", VA = "0x3E0640")]
	protected void StartTween(float targetFloat, float duration)
	{
	}
}
