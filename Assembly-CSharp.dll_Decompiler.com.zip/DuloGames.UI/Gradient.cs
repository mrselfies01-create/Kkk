using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001AC")]
public class Gradient : BaseMeshEffect
{
	[Token(Token = "0x4000B37")]
	[FieldOffset(Offset = "0x20")]
	private Color topColor;

	[Token(Token = "0x4000B38")]
	[FieldOffset(Offset = "0x30")]
	private Color bottomColor;

	[Token(Token = "0x6000A70")]
	[Address(RVA = "0x38B2A0", Offset = "0x38B2A0", VA = "0x38B2A0", Slot = "20")]
	public override void ModifyMesh(VertexHelper vertexHelper)
	{
	}

	[Token(Token = "0x6000A71")]
	[Address(RVA = "0x38B370", Offset = "0x38B370", VA = "0x38B370")]
	public void ModifyVertices(List<UIVertex> vertexList)
	{
	}

	[Token(Token = "0x6000A72")]
	[Address(RVA = "0x38B5E0", Offset = "0x38B5E0", VA = "0x38B5E0")]
	public Gradient()
	{
	}
}
