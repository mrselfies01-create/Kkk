using Il2CppDummyDll;

namespace DuloGames.UI;

[Token(Token = "0x20001B6")]
public enum UISpellInfo_Flags
{
	[Token(Token = "0x4000B7C")]
	Passive = 1,
	[Token(Token = "0x4000B7D")]
	InstantCast = 2,
	[Token(Token = "0x4000B7E")]
	PowerCostInPct = 4
}
