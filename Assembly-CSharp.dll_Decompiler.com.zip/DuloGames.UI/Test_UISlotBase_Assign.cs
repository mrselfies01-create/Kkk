using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001D4")]
public class Test_UISlotBase_Assign : MonoBehaviour
{
	[Token(Token = "0x4000BFB")]
	[FieldOffset(Offset = "0x18")]
	public UISlotBase slot;

	[Token(Token = "0x4000BFC")]
	[FieldOffset(Offset = "0x20")]
	public Texture texture;

	[Token(Token = "0x4000BFD")]
	[FieldOffset(Offset = "0x28")]
	public Sprite sprite;

	[Token(Token = "0x6000BA9")]
	[Address(RVA = "0x3E1594", Offset = "0x3E1594", VA = "0x3E1594")]
	private void Start()
	{
	}

	[Token(Token = "0x6000BAA")]
	[Address(RVA = "0x3E16B8", Offset = "0x3E16B8", VA = "0x3E16B8")]
	public Test_UISlotBase_Assign()
	{
	}
}
