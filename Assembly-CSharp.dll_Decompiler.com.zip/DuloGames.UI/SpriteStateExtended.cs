using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B1")]
public struct SpriteStateExtended
{
	[Token(Token = "0x4000B4D")]
	[FieldOffset(Offset = "0x0")]
	private Sprite m_HighlightedSprite;

	[Token(Token = "0x4000B4E")]
	[FieldOffset(Offset = "0x8")]
	private Sprite m_PressedSprite;

	[Token(Token = "0x4000B4F")]
	[FieldOffset(Offset = "0x10")]
	private Sprite m_ActiveSprite;

	[Token(Token = "0x4000B50")]
	[FieldOffset(Offset = "0x18")]
	private Sprite m_ActiveHighlightedSprite;

	[Token(Token = "0x4000B51")]
	[FieldOffset(Offset = "0x20")]
	private Sprite m_ActivePressedSprite;

	[Token(Token = "0x4000B52")]
	[FieldOffset(Offset = "0x28")]
	private Sprite m_DisabledSprite;

	[Token(Token = "0x170001DC")]
	public Sprite highlightedSprite
	{
		[Token(Token = "0x6000AAF")]
		[Address(RVA = "0x29C8F4", Offset = "0x29C8F4", VA = "0x29C8F4")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000AB0")]
		[Address(RVA = "0x29C8FC", Offset = "0x29C8FC", VA = "0x29C8FC")]
		set
		{
		}
	}

	[Token(Token = "0x170001DD")]
	public Sprite pressedSprite
	{
		[Token(Token = "0x6000AB1")]
		[Address(RVA = "0x29C904", Offset = "0x29C904", VA = "0x29C904")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000AB2")]
		[Address(RVA = "0x29C90C", Offset = "0x29C90C", VA = "0x29C90C")]
		set
		{
		}
	}

	[Token(Token = "0x170001DE")]
	public Sprite activeSprite
	{
		[Token(Token = "0x6000AB3")]
		[Address(RVA = "0x29C914", Offset = "0x29C914", VA = "0x29C914")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000AB4")]
		[Address(RVA = "0x29C91C", Offset = "0x29C91C", VA = "0x29C91C")]
		set
		{
		}
	}

	[Token(Token = "0x170001DF")]
	public Sprite activeHighlightedSprite
	{
		[Token(Token = "0x6000AB5")]
		[Address(RVA = "0x29C924", Offset = "0x29C924", VA = "0x29C924")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000AB6")]
		[Address(RVA = "0x29C92C", Offset = "0x29C92C", VA = "0x29C92C")]
		set
		{
		}
	}

	[Token(Token = "0x170001E0")]
	public Sprite activePressedSprite
	{
		[Token(Token = "0x6000AB7")]
		[Address(RVA = "0x29C934", Offset = "0x29C934", VA = "0x29C934")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000AB8")]
		[Address(RVA = "0x29C93C", Offset = "0x29C93C", VA = "0x29C93C")]
		set
		{
		}
	}

	[Token(Token = "0x170001E1")]
	public Sprite disabledSprite
	{
		[Token(Token = "0x6000AB9")]
		[Address(RVA = "0x29C944", Offset = "0x29C944", VA = "0x29C944")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000ABA")]
		[Address(RVA = "0x29C94C", Offset = "0x29C94C", VA = "0x29C94C")]
		set
		{
		}
	}
}
