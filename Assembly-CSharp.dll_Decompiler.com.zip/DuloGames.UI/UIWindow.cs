using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001EC")]
public class UIWindow : MonoBehaviour, IDisposable, IContentHandler, IComparer<Contraction>
{
	[Token(Token = "0x200027F")]
	public enum Transition
	{
		[Token(Token = "0x4000FA6")]
		Instant,
		[Token(Token = "0x4000FA7")]
		Fade
	}

	[Token(Token = "0x2000280")]
	public enum VisualState
	{
		[Token(Token = "0x4000FA9")]
		Shown,
		[Token(Token = "0x4000FAA")]
		Hidden
	}

	[Token(Token = "0x2000281")]
	public enum EscapeKeyAction
	{
		[Token(Token = "0x4000FAC")]
		None,
		[Token(Token = "0x4000FAD")]
		Hide,
		[Token(Token = "0x4000FAE")]
		HideIfFocused,
		[Token(Token = "0x4000FAF")]
		Toggle
	}

	[Serializable]
	[Token(Token = "0x2000282")]
	public class TransitionBeginEvent : UnityEvent<UIWindow, VisualState, bool>
	{
		[Token(Token = "0x6000DDD")]
		[Address(RVA = "0x7903E0", Offset = "0x7903E0", VA = "0x7903E0")]
		public TransitionBeginEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x2000283")]
	public class TransitionCompleteEvent : UnityEvent<UIWindow, VisualState>
	{
		[Token(Token = "0x6000DDE")]
		[Address(RVA = "0x790430", Offset = "0x790430", VA = "0x790430")]
		public TransitionCompleteEvent()
		{
		}
	}

	[Token(Token = "0x4000CF2")]
	[FieldOffset(Offset = "0x0")]
	protected static UIWindow m_FucusedWindow;

	[Token(Token = "0x4000CF3")]
	[FieldOffset(Offset = "0x18")]
	private UIWindowID m_WindowId;

	[Token(Token = "0x4000CF4")]
	[FieldOffset(Offset = "0x1C")]
	private int m_CustomWindowId;

	[Token(Token = "0x4000CF5")]
	[FieldOffset(Offset = "0x20")]
	private VisualState m_StartingState;

	[Token(Token = "0x4000CF6")]
	[FieldOffset(Offset = "0x24")]
	private EscapeKeyAction m_EscapeKeyAction;

	[Token(Token = "0x4000CF7")]
	[FieldOffset(Offset = "0x28")]
	private Transition m_Transition;

	[Token(Token = "0x4000CF8")]
	[FieldOffset(Offset = "0x2C")]
	private TweenEasing m_TransitionEasing;

	[Token(Token = "0x4000CF9")]
	[FieldOffset(Offset = "0x30")]
	private float m_TransitionDuration;

	[Token(Token = "0x4000CFA")]
	[FieldOffset(Offset = "0x34")]
	protected bool m_IsFocused;

	[Token(Token = "0x4000CFB")]
	[FieldOffset(Offset = "0x38")]
	private VisualState m_CurrentVisualState;

	[Token(Token = "0x4000CFC")]
	[FieldOffset(Offset = "0x40")]
	private CanvasGroup m_CanvasGroup;

	[Token(Token = "0x4000CFD")]
	[FieldOffset(Offset = "0x48")]
	public TransitionBeginEvent onTransitionBegin;

	[Token(Token = "0x4000CFE")]
	[FieldOffset(Offset = "0x50")]
	public TransitionCompleteEvent onTransitionComplete;

	[NonSerialized]
	[Token(Token = "0x4000CFF")]
	[FieldOffset(Offset = "0x58")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x17000233")]
	public static UIWindow FocusedWindow
	{
		[Token(Token = "0x6000D04")]
		[Address(RVA = "0x476784", Offset = "0x476784", VA = "0x476784")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000D05")]
		[Address(RVA = "0x4767D4", Offset = "0x4767D4", VA = "0x4767D4")]
		private set
		{
		}
	}

	[Token(Token = "0x17000234")]
	public UIWindowID ID
	{
		[Token(Token = "0x6000D06")]
		[Address(RVA = "0x476828", Offset = "0x476828", VA = "0x476828")]
		get
		{
			return default(UIWindowID);
		}
		[Token(Token = "0x6000D07")]
		[Address(RVA = "0x476830", Offset = "0x476830", VA = "0x476830")]
		set
		{
		}
	}

	[Token(Token = "0x17000235")]
	public int CustomID
	{
		[Token(Token = "0x6000D08")]
		[Address(RVA = "0x476838", Offset = "0x476838", VA = "0x476838")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000D09")]
		[Address(RVA = "0x476840", Offset = "0x476840", VA = "0x476840")]
		set
		{
		}
	}

	[Token(Token = "0x17000236")]
	public EscapeKeyAction escapeKeyAction
	{
		[Token(Token = "0x6000D0A")]
		[Address(RVA = "0x476848", Offset = "0x476848", VA = "0x476848")]
		get
		{
			return default(EscapeKeyAction);
		}
		[Token(Token = "0x6000D0B")]
		[Address(RVA = "0x476850", Offset = "0x476850", VA = "0x476850")]
		set
		{
		}
	}

	[Token(Token = "0x17000237")]
	public Transition transition
	{
		[Token(Token = "0x6000D0C")]
		[Address(RVA = "0x476858", Offset = "0x476858", VA = "0x476858")]
		get
		{
			return default(Transition);
		}
		[Token(Token = "0x6000D0D")]
		[Address(RVA = "0x476860", Offset = "0x476860", VA = "0x476860")]
		set
		{
		}
	}

	[Token(Token = "0x17000238")]
	public TweenEasing transitionEasing
	{
		[Token(Token = "0x6000D0E")]
		[Address(RVA = "0x476868", Offset = "0x476868", VA = "0x476868")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000D0F")]
		[Address(RVA = "0x476870", Offset = "0x476870", VA = "0x476870")]
		set
		{
		}
	}

	[Token(Token = "0x17000239")]
	public float transitionDuration
	{
		[Token(Token = "0x6000D10")]
		[Address(RVA = "0x476878", Offset = "0x476878", VA = "0x476878")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000D11")]
		[Address(RVA = "0x476880", Offset = "0x476880", VA = "0x476880")]
		set
		{
		}
	}

	[Token(Token = "0x1700023A")]
	public bool IsVisible
	{
		[Token(Token = "0x6000D12")]
		[Address(RVA = "0x476888", Offset = "0x476888", VA = "0x476888")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x1700023B")]
	public bool IsOpen
	{
		[Token(Token = "0x6000D13")]
		[Address(RVA = "0x472E58", Offset = "0x472E58", VA = "0x472E58")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x1700023C")]
	public bool IsFocused
	{
		[Token(Token = "0x6000D14")]
		[Address(RVA = "0x476924", Offset = "0x476924", VA = "0x476924")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x1700023D")]
	public static int NextUnusedCustomID
	{
		[Token(Token = "0x6000D29")]
		[Address(RVA = "0x476BC8", Offset = "0x476BC8", VA = "0x476BC8")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x6000D15")]
	[Address(RVA = "0x47692C", Offset = "0x47692C", VA = "0x47692C")]
	protected UIWindow()
	{
	}

	[Token(Token = "0x6000D16")]
	[Address(RVA = "0x476A14", Offset = "0x476A14", VA = "0x476A14", Slot = "6")]
	protected virtual void Awake()
	{
	}

	[Token(Token = "0x6000D17")]
	[Address(RVA = "0x476AA4", Offset = "0x476AA4", VA = "0x476AA4", Slot = "7")]
	protected virtual void Start()
	{
	}

	[Token(Token = "0x6000D18")]
	[Address(RVA = "0x476CA8", Offset = "0x476CA8", VA = "0x476CA8", Slot = "8")]
	protected virtual bool IsActive()
	{
		return default(bool);
	}

	[Token(Token = "0x6000D19")]
	[Address(RVA = "0x476CF8", Offset = "0x476CF8", VA = "0x476CF8", Slot = "9")]
	public virtual void OnSelect(BaseEventData eventData)
	{
	}

	[Token(Token = "0x6000D1A")]
	[Address(RVA = "0x476D04", Offset = "0x476D04", VA = "0x476D04", Slot = "10")]
	public virtual void OnPointerDown(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000D1B")]
	[Address(RVA = "0x476D10", Offset = "0x476D10", VA = "0x476D10", Slot = "11")]
	public virtual void ApplyVisualState(VisualState state)
	{
	}

	[Token(Token = "0x6000D1C")]
	[Address(RVA = "0x476E40", Offset = "0x476E40", VA = "0x476E40", Slot = "12")]
	public virtual void Focus()
	{
	}

	[Token(Token = "0x6000D1D")]
	[Address(RVA = "0x476F28", Offset = "0x476F28", VA = "0x476F28")]
	public void BringToFront()
	{
	}

	[Token(Token = "0x6000D1E")]
	[Address(RVA = "0x477030", Offset = "0x477030", VA = "0x477030", Slot = "13")]
	public virtual void Toggle()
	{
	}

	[Token(Token = "0x6000D1F")]
	[Address(RVA = "0x477054", Offset = "0x477054", VA = "0x477054", Slot = "14")]
	public virtual void Show()
	{
	}

	[Token(Token = "0x6000D20")]
	[Address(RVA = "0x477068", Offset = "0x477068", VA = "0x477068", Slot = "15")]
	public virtual void Show(bool instant)
	{
	}

	[Token(Token = "0x6000D21")]
	[Address(RVA = "0x4770D8", Offset = "0x4770D8", VA = "0x4770D8", Slot = "16")]
	public virtual void Hide()
	{
	}

	[Token(Token = "0x6000D22")]
	[Address(RVA = "0x4770EC", Offset = "0x4770EC", VA = "0x4770EC", Slot = "17")]
	public virtual void Hide(bool instant)
	{
	}

	[Token(Token = "0x6000D23")]
	[Address(RVA = "0x477150", Offset = "0x477150", VA = "0x477150", Slot = "18")]
	protected virtual void EvaluateAndTransitionToVisualState(VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000D24")]
	[Address(RVA = "0x47728C", Offset = "0x47728C", VA = "0x47728C")]
	public void StartAlphaTween(float targetAlpha, float duration, bool ignoreTimeScale)
	{
	}

	[Token(Token = "0x6000D25")]
	[Address(RVA = "0x476D68", Offset = "0x476D68", VA = "0x476D68")]
	protected void SetCanvasAlpha(float alpha)
	{
	}

	[Token(Token = "0x6000D26")]
	[Address(RVA = "0x47744C", Offset = "0x47744C", VA = "0x47744C", Slot = "19")]
	protected virtual void OnTweenFinished()
	{
	}

	[Token(Token = "0x6000D27")]
	[Address(RVA = "0x4774B4", Offset = "0x4774B4", VA = "0x4774B4")]
	public static List<UIWindow> GetWindows()
	{
		return null;
	}

	[Token(Token = "0x6000D28")]
	[Address(RVA = "0x4775BC", Offset = "0x4775BC", VA = "0x4775BC")]
	public static int SortByCustomWindowID(UIWindow w1, UIWindow w2)
	{
		return default(int);
	}

	[Token(Token = "0x6000D2A")]
	[Address(RVA = "0x4775FC", Offset = "0x4775FC", VA = "0x4775FC")]
	public static UIWindow GetWindow(UIWindowID id)
	{
		return null;
	}

	[Token(Token = "0x6000D2B")]
	[Address(RVA = "0x47770C", Offset = "0x47770C", VA = "0x47770C")]
	public static UIWindow GetWindowByCustomID(int customId)
	{
		return null;
	}

	[Token(Token = "0x6000D2C")]
	[Address(RVA = "0x47781C", Offset = "0x47781C", VA = "0x47781C")]
	public static void FocusWindow(UIWindowID id)
	{
	}

	[Token(Token = "0x6000D2D")]
	[Address(RVA = "0x476E78", Offset = "0x476E78", VA = "0x476E78")]
	protected static void OnBeforeFocusWindow(UIWindow window)
	{
	}
}
