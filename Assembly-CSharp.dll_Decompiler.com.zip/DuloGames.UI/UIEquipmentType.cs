using Il2CppDummyDll;

namespace DuloGames.UI;

[Token(Token = "0x20001B2")]
public enum UIEquipmentType
{
	[Token(Token = "0x4000B54")]
	None,
	[Token(Token = "0x4000B55")]
	Weapon_MainHand,
	[Token(Token = "0x4000B56")]
	Weapon_OffHand,
	[Token(Token = "0x4000B57")]
	Head,
	[Token(Token = "0x4000B58")]
	Necklace,
	[Token(Token = "0x4000B59")]
	Shoulders,
	[Token(Token = "0x4000B5A")]
	Chest,
	[Token(Token = "0x4000B5B")]
	Bracers,
	[Token(Token = "0x4000B5C")]
	Gloves,
	[Token(Token = "0x4000B5D")]
	Belt,
	[Token(Token = "0x4000B5E")]
	Pants,
	[Token(Token = "0x4000B5F")]
	Boots,
	[Token(Token = "0x4000B60")]
	Trinket
}
