using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001BC")]
public class UIEquipReceiver : UIBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer
{
	[Token(Token = "0x2000250")]
	public enum HintState
	{
		[Token(Token = "0x4000F33")]
		Shown,
		[Token(Token = "0x4000F34")]
		Hidden
	}

	[Token(Token = "0x4000B8C")]
	[FieldOffset(Offset = "0x18")]
	private Transform m_SlotsContainer;

	[Token(Token = "0x4000B8D")]
	[FieldOffset(Offset = "0x20")]
	private Text m_HintText;

	[Token(Token = "0x4000B8E")]
	[FieldOffset(Offset = "0x28")]
	private bool m_Fading;

	[Token(Token = "0x4000B8F")]
	[FieldOffset(Offset = "0x2C")]
	private float m_FadeDuration;

	[Token(Token = "0x4000B90")]
	[FieldOffset(Offset = "0x30")]
	private HintState m_HintState;

	[Token(Token = "0x6000ACA")]
	[Address(RVA = "0x3E5288", Offset = "0x3E5288", VA = "0x3E5288", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000ACB")]
	[Address(RVA = "0x3E5390", Offset = "0x3E5390", VA = "0x3E5390")]
	public UIEquipSlot GetSlotByType(UIEquipmentType type)
	{
		return null;
	}

	[Token(Token = "0x6000ACC")]
	[Address(RVA = "0x3E5480", Offset = "0x3E5480", VA = "0x3E5480", Slot = "18")]
	public void OnPointerEnter(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000ACD")]
	[Address(RVA = "0x3E5698", Offset = "0x3E5698", VA = "0x3E5698")]
	private void HideHint()
	{
	}

	[Token(Token = "0x6000ACE")]
	[Address(RVA = "0x3E5718", Offset = "0x3E5718", VA = "0x3E5718", Slot = "19")]
	public void OnPointerExit(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000ACF")]
	[Address(RVA = "0x3E57A0", Offset = "0x3E57A0", VA = "0x3E57A0", Slot = "17")]
	public void OnDrop(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000AD0")]
	[Address(RVA = "0x3E55A0", Offset = "0x3E55A0", VA = "0x3E55A0")]
	private UISlotBase ExtractSlot(PointerEventData eventData)
	{
		return null;
	}

	[Token(Token = "0x6000AD1")]
	[Address(RVA = "0x3E595C", Offset = "0x3E595C", VA = "0x3E595C")]
	public UIEquipReceiver()
	{
	}
}
