using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001C8")]
public class UITextSetValue : MonoBehaviour
{
	[Token(Token = "0x4000BD8")]
	[FieldOffset(Offset = "0x18")]
	private Text m_Text;

	[Token(Token = "0x4000BD9")]
	[FieldOffset(Offset = "0x20")]
	public string floatFormat;

	[Token(Token = "0x6000B70")]
	[Address(RVA = "0x472BBC", Offset = "0x472BBC", VA = "0x472BBC")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000B71")]
	[Address(RVA = "0x472C24", Offset = "0x472C24", VA = "0x472C24")]
	public void SetFloat(float value)
	{
	}

	[Token(Token = "0x6000B72")]
	[Address(RVA = "0x472CD8", Offset = "0x472CD8", VA = "0x472CD8")]
	public UITextSetValue()
	{
	}
}
