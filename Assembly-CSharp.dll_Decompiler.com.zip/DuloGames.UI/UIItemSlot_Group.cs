using System;
using Il2CppDummyDll;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B4")]
public enum UIItemSlot_Group
{
	[Token(Token = "0x4000B70")]
	None,
	[Token(Token = "0x4000B71")]
	Inventory
}
