using Il2CppDummyDll;

namespace DuloGames.UI;

[Token(Token = "0x20001B7")]
public static class UISpellInfo_FlagsExtensions
{
	[Token(Token = "0x6000ABD")]
	[Address(RVA = "0x46FD90", Offset = "0x46FD90", VA = "0x46FD90")]
	public static bool Has(UISpellInfo_Flags type, UISpellInfo_Flags value)
	{
		return default(bool);
	}

	[Token(Token = "0x6000ABE")]
	[Address(RVA = "0x46FDE4", Offset = "0x46FDE4", VA = "0x46FDE4")]
	public static bool Is(UISpellInfo_Flags type, UISpellInfo_Flags value)
	{
		return default(bool);
	}

	[Token(Token = "0x6000ABF")]
	[Address(RVA = "0x46FE38", Offset = "0x46FE38", VA = "0x46FE38")]
	public static UISpellInfo_Flags Add(UISpellInfo_Flags type, UISpellInfo_Flags value)
	{
		return default(UISpellInfo_Flags);
	}

	[Token(Token = "0x6000AC0")]
	[Address(RVA = "0x46FE88", Offset = "0x46FE88", VA = "0x46FE88")]
	public static UISpellInfo_Flags Remove(UISpellInfo_Flags type, UISpellInfo_Flags value)
	{
		return default(UISpellInfo_Flags);
	}
}
