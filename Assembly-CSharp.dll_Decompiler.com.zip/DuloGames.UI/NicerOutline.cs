using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001AE")]
public class NicerOutline : BaseMeshEffect
{
	[Token(Token = "0x4000B3A")]
	[FieldOffset(Offset = "0x20")]
	private Color m_EffectColor;

	[Token(Token = "0x4000B3B")]
	[FieldOffset(Offset = "0x30")]
	private Vector2 m_EffectDistance;

	[Token(Token = "0x4000B3C")]
	[FieldOffset(Offset = "0x38")]
	private bool m_UseGraphicAlpha;

	[Token(Token = "0x170001C8")]
	public Color effectColor
	{
		[Token(Token = "0x6000A83")]
		[Address(RVA = "0x392824", Offset = "0x392824", VA = "0x392824")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000A84")]
		[Address(RVA = "0x392830", Offset = "0x392830", VA = "0x392830")]
		set
		{
		}
	}

	[Token(Token = "0x170001C9")]
	public Vector2 effectDistance
	{
		[Token(Token = "0x6000A85")]
		[Address(RVA = "0x392914", Offset = "0x392914", VA = "0x392914")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000A86")]
		[Address(RVA = "0x39291C", Offset = "0x39291C", VA = "0x39291C")]
		set
		{
		}
	}

	[Token(Token = "0x170001CA")]
	public bool useGraphicAlpha
	{
		[Token(Token = "0x6000A87")]
		[Address(RVA = "0x392A64", Offset = "0x392A64", VA = "0x392A64")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000A88")]
		[Address(RVA = "0x392A6C", Offset = "0x392A6C", VA = "0x392A6C")]
		set
		{
		}
	}

	[Token(Token = "0x6000A89")]
	[Address(RVA = "0x392B38", Offset = "0x392B38", VA = "0x392B38")]
	protected void ApplyShadow(List<UIVertex> verts, Color32 color, int start, int end, float x, float y)
	{
	}

	[Token(Token = "0x6000A8A")]
	[Address(RVA = "0x392D90", Offset = "0x392D90", VA = "0x392D90", Slot = "20")]
	public override void ModifyMesh(VertexHelper vertexHelper)
	{
	}

	[Token(Token = "0x6000A8B")]
	[Address(RVA = "0x392E60", Offset = "0x392E60", VA = "0x392E60")]
	public void ModifyVertices(List<UIVertex> verts)
	{
	}

	[Token(Token = "0x6000A8C")]
	[Address(RVA = "0x39314C", Offset = "0x39314C", VA = "0x39314C")]
	public NicerOutline()
	{
	}
}
