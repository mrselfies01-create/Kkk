using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001D3")]
public class Test_UIProgressBar : MonoBehaviour
{
	[Token(Token = "0x200025D")]
	public enum TextVariant
	{
		[Token(Token = "0x4000F4A")]
		Percent,
		[Token(Token = "0x4000F4B")]
		Value,
		[Token(Token = "0x4000F4C")]
		ValueMax
	}

	[Token(Token = "0x4000BF4")]
	[FieldOffset(Offset = "0x18")]
	public UIProgressBar bar;

	[Token(Token = "0x4000BF5")]
	[FieldOffset(Offset = "0x20")]
	public float Duration;

	[Token(Token = "0x4000BF6")]
	[FieldOffset(Offset = "0x24")]
	public TweenEasing Easing;

	[Token(Token = "0x4000BF7")]
	[FieldOffset(Offset = "0x28")]
	public Text m_Text;

	[Token(Token = "0x4000BF8")]
	[FieldOffset(Offset = "0x30")]
	public TextVariant m_TextVariant;

	[Token(Token = "0x4000BF9")]
	[FieldOffset(Offset = "0x34")]
	public int m_TextValue;

	[NonSerialized]
	[Token(Token = "0x4000BFA")]
	[FieldOffset(Offset = "0x38")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x6000BA4")]
	[Address(RVA = "0x3E0EC4", Offset = "0x3E0EC4", VA = "0x3E0EC4")]
	protected Test_UIProgressBar()
	{
	}

	[Token(Token = "0x6000BA5")]
	[Address(RVA = "0x3E0F60", Offset = "0x3E0F60", VA = "0x3E0F60")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000BA6")]
	[Address(RVA = "0x3E11B8", Offset = "0x3E11B8", VA = "0x3E11B8")]
	protected void SetFillAmount(float amount)
	{
	}

	[Token(Token = "0x6000BA7")]
	[Address(RVA = "0x3E14E8", Offset = "0x3E14E8", VA = "0x3E14E8")]
	protected void OnTweenFinished()
	{
	}

	[Token(Token = "0x6000BA8")]
	[Address(RVA = "0x3E1004", Offset = "0x3E1004", VA = "0x3E1004")]
	protected void StartTween(float targetFloat, float duration)
	{
	}
}
