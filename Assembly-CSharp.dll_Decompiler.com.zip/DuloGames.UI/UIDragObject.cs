using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace DuloGames.UI;

[Token(Token = "0x20001E1")]
public class UIDragObject : UIBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer
{
	[Serializable]
	[Token(Token = "0x200026C")]
	public class BeginDragEvent : UnityEvent<BaseEventData>
	{
		[Token(Token = "0x6000DD8")]
		[Address(RVA = "0x78FA14", Offset = "0x78FA14", VA = "0x78FA14")]
		public BeginDragEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x200026D")]
	public class EndDragEvent : UnityEvent<BaseEventData>
	{
		[Token(Token = "0x6000DD9")]
		[Address(RVA = "0x78FAB4", Offset = "0x78FAB4", VA = "0x78FAB4")]
		public EndDragEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x200026E")]
	public class DragEvent : UnityEvent<BaseEventData>
	{
		[Token(Token = "0x6000DDA")]
		[Address(RVA = "0x78FA64", Offset = "0x78FA64", VA = "0x78FA64")]
		public DragEvent()
		{
		}
	}

	[Token(Token = "0x4000C57")]
	[FieldOffset(Offset = "0x18")]
	private RectTransform m_Target;

	[Token(Token = "0x4000C58")]
	[FieldOffset(Offset = "0x20")]
	private bool m_Horizontal;

	[Token(Token = "0x4000C59")]
	[FieldOffset(Offset = "0x21")]
	private bool m_Vertical;

	[Token(Token = "0x4000C5A")]
	[FieldOffset(Offset = "0x22")]
	private bool m_Inertia;

	[Token(Token = "0x4000C5B")]
	[FieldOffset(Offset = "0x24")]
	private float m_DampeningRate;

	[Token(Token = "0x4000C5C")]
	[FieldOffset(Offset = "0x28")]
	private bool m_ConstrainWithinCanvas;

	[Token(Token = "0x4000C5D")]
	[FieldOffset(Offset = "0x29")]
	private bool m_ConstrainDrag;

	[Token(Token = "0x4000C5E")]
	[FieldOffset(Offset = "0x2A")]
	private bool m_ConstrainInertia;

	[Token(Token = "0x4000C5F")]
	[FieldOffset(Offset = "0x30")]
	private Canvas m_Canvas;

	[Token(Token = "0x4000C60")]
	[FieldOffset(Offset = "0x38")]
	private RectTransform m_CanvasRectTransform;

	[Token(Token = "0x4000C61")]
	[FieldOffset(Offset = "0x40")]
	private Vector2 m_PointerStartPosition;

	[Token(Token = "0x4000C62")]
	[FieldOffset(Offset = "0x48")]
	private Vector2 m_TargetStartPosition;

	[Token(Token = "0x4000C63")]
	[FieldOffset(Offset = "0x50")]
	private Vector2 m_Velocity;

	[Token(Token = "0x4000C64")]
	[FieldOffset(Offset = "0x58")]
	private bool m_Dragging;

	[Token(Token = "0x4000C65")]
	[FieldOffset(Offset = "0x5C")]
	private Vector2 m_LastPosition;

	[Token(Token = "0x4000C66")]
	[FieldOffset(Offset = "0x68")]
	public BeginDragEvent onBeginDrag;

	[Token(Token = "0x4000C67")]
	[FieldOffset(Offset = "0x70")]
	public EndDragEvent onEndDrag;

	[Token(Token = "0x4000C68")]
	[FieldOffset(Offset = "0x78")]
	public DragEvent onDrag;

	[Token(Token = "0x1700020A")]
	public RectTransform target
	{
		[Token(Token = "0x6000C2C")]
		[Address(RVA = "0x3E40D0", Offset = "0x3E40D0", VA = "0x3E40D0")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C2D")]
		[Address(RVA = "0x3E40D8", Offset = "0x3E40D8", VA = "0x3E40D8")]
		set
		{
		}
	}

	[Token(Token = "0x1700020B")]
	public bool horizontal
	{
		[Token(Token = "0x6000C2E")]
		[Address(RVA = "0x3E40E0", Offset = "0x3E40E0", VA = "0x3E40E0")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C2F")]
		[Address(RVA = "0x3E40E8", Offset = "0x3E40E8", VA = "0x3E40E8")]
		set
		{
		}
	}

	[Token(Token = "0x1700020C")]
	public bool vertical
	{
		[Token(Token = "0x6000C30")]
		[Address(RVA = "0x3E40F4", Offset = "0x3E40F4", VA = "0x3E40F4")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C31")]
		[Address(RVA = "0x3E40FC", Offset = "0x3E40FC", VA = "0x3E40FC")]
		set
		{
		}
	}

	[Token(Token = "0x1700020D")]
	public bool inertia
	{
		[Token(Token = "0x6000C32")]
		[Address(RVA = "0x3E4108", Offset = "0x3E4108", VA = "0x3E4108")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C33")]
		[Address(RVA = "0x3E4110", Offset = "0x3E4110", VA = "0x3E4110")]
		set
		{
		}
	}

	[Token(Token = "0x1700020E")]
	public float dampeningRate
	{
		[Token(Token = "0x6000C34")]
		[Address(RVA = "0x3E411C", Offset = "0x3E411C", VA = "0x3E411C")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C35")]
		[Address(RVA = "0x3E4124", Offset = "0x3E4124", VA = "0x3E4124")]
		set
		{
		}
	}

	[Token(Token = "0x1700020F")]
	public bool constrainWithinCanvas
	{
		[Token(Token = "0x6000C36")]
		[Address(RVA = "0x3E412C", Offset = "0x3E412C", VA = "0x3E412C")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C37")]
		[Address(RVA = "0x3E4134", Offset = "0x3E4134", VA = "0x3E4134")]
		set
		{
		}
	}

	[Token(Token = "0x6000C38")]
	[Address(RVA = "0x3E4140", Offset = "0x3E4140", VA = "0x3E4140", Slot = "4")]
	protected override void Awake()
	{
	}

	[Token(Token = "0x6000C39")]
	[Address(RVA = "0x3E4264", Offset = "0x3E4264", VA = "0x3E4264", Slot = "12")]
	protected override void OnTransformParentChanged()
	{
	}

	[Token(Token = "0x6000C3A")]
	[Address(RVA = "0x3E4388", Offset = "0x3E4388", VA = "0x3E4388", Slot = "9")]
	public override bool IsActive()
	{
		return default(bool);
	}

	[Token(Token = "0x6000C3B")]
	[Address(RVA = "0x3E4418", Offset = "0x3E4418", VA = "0x3E4418")]
	public void StopMovement()
	{
	}

	[Token(Token = "0x6000C3C")]
	[Address(RVA = "0x3E4484", Offset = "0x3E4484", VA = "0x3E4484", Slot = "17")]
	public void OnBeginDrag(PointerEventData data)
	{
	}

	[Token(Token = "0x6000C3D")]
	[Address(RVA = "0x3E45CC", Offset = "0x3E45CC", VA = "0x3E45CC", Slot = "19")]
	public void OnEndDrag(PointerEventData data)
	{
	}

	[Token(Token = "0x6000C3E")]
	[Address(RVA = "0x3E4658", Offset = "0x3E4658", VA = "0x3E4658", Slot = "18")]
	public void OnDrag(PointerEventData data)
	{
	}

	[Token(Token = "0x6000C3F")]
	[Address(RVA = "0x3E498C", Offset = "0x3E498C", VA = "0x3E498C", Slot = "20")]
	protected virtual void LateUpdate()
	{
	}

	[Token(Token = "0x6000C40")]
	[Address(RVA = "0x3E4F34", Offset = "0x3E4F34", VA = "0x3E4F34")]
	protected Vector3 Dampen(ref Vector2 velocity, float strength, float delta)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector3);
	}

	[Token(Token = "0x6000C41")]
	[Address(RVA = "0x3E5058", Offset = "0x3E5058", VA = "0x3E5058")]
	protected Vector2 ClampToScreen(Vector2 position)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector2);
	}

	[Token(Token = "0x6000C42")]
	[Address(RVA = "0x3E483C", Offset = "0x3E483C", VA = "0x3E483C")]
	protected Vector2 ClampToCanvas(Vector2 position)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector2);
	}

	[Token(Token = "0x6000C43")]
	[Address(RVA = "0x3E5180", Offset = "0x3E5180", VA = "0x3E5180")]
	public UIDragObject()
	{
	}
}
