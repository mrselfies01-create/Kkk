using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DE")]
public class UIBlackOverlay : MonoBehaviour
{
	[Token(Token = "0x4000C4D")]
	[FieldOffset(Offset = "0x18")]
	private Image m_Image;

	[Token(Token = "0x4000C4E")]
	[FieldOffset(Offset = "0x20")]
	private CanvasGroup m_CanvasGroup;

	[Token(Token = "0x4000C4F")]
	[FieldOffset(Offset = "0x28")]
	private int m_WindowsCount;

	[Token(Token = "0x6000C06")]
	[Address(RVA = "0x3E2C7C", Offset = "0x3E2C7C", VA = "0x3E2C7C")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000C07")]
	[Address(RVA = "0x3E2D08", Offset = "0x3E2D08", VA = "0x3E2D08")]
	protected void Start()
	{
	}

	[Token(Token = "0x6000C08")]
	[Address(RVA = "0x3E2D78", Offset = "0x3E2D78", VA = "0x3E2D78")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000C09")]
	[Address(RVA = "0x3E2DB0", Offset = "0x3E2DB0", VA = "0x3E2DB0")]
	public void Show()
	{
	}

	[Token(Token = "0x6000C0A")]
	[Address(RVA = "0x3E2D40", Offset = "0x3E2D40", VA = "0x3E2D40")]
	public void Hide()
	{
	}

	[Token(Token = "0x6000C0B")]
	[Address(RVA = "0x3E2E24", Offset = "0x3E2E24", VA = "0x3E2E24")]
	public bool IsActive()
	{
		return default(bool);
	}

	[Token(Token = "0x6000C0C")]
	[Address(RVA = "0x3E2E74", Offset = "0x3E2E74", VA = "0x3E2E74")]
	public bool IsVisible()
	{
		return default(bool);
	}

	[Token(Token = "0x6000C0D")]
	[Address(RVA = "0x3E2EAC", Offset = "0x3E2EAC", VA = "0x3E2EAC")]
	public void OnTransitionBegin(UIWindow window, UIWindow.VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000C0E")]
	[Address(RVA = "0x3E2DE8", Offset = "0x3E2DE8", VA = "0x3E2DE8")]
	public void SetAlpha(float alpha)
	{
	}

	[Token(Token = "0x6000C0F")]
	[Address(RVA = "0x3E3084", Offset = "0x3E3084", VA = "0x3E3084")]
	public UIBlackOverlay()
	{
	}
}
