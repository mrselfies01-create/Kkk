using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001C9")]
public class UIToggleWindowAndTab : MonoBehaviour
{
	[Token(Token = "0x4000BDA")]
	[FieldOffset(Offset = "0x18")]
	public UIWindow window;

	[Token(Token = "0x4000BDB")]
	[FieldOffset(Offset = "0x20")]
	public UITab tab;

	[Token(Token = "0x6000B73")]
	[Address(RVA = "0x472D30", Offset = "0x472D30", VA = "0x472D30")]
	public void Toggle()
	{
	}

	[Token(Token = "0x6000B74")]
	[Address(RVA = "0x472E68", Offset = "0x472E68", VA = "0x472E68")]
	public UIToggleWindowAndTab()
	{
	}
}
