using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001C3")]
public class UITalentSlot : UISlotBase
{
	[Token(Token = "0x4000BCD")]
	[FieldOffset(Offset = "0xEF")]
	private bool m_IsSpecialTalentSlot;

	[Token(Token = "0x4000BCE")]
	[FieldOffset(Offset = "0xF0")]
	private Transform m_SpecialBackground;

	[Token(Token = "0x4000BCF")]
	[FieldOffset(Offset = "0xF8")]
	private Text m_PointsText;

	[Token(Token = "0x4000BD0")]
	[FieldOffset(Offset = "0x100")]
	private Color m_pointsMinColor;

	[Token(Token = "0x4000BD1")]
	[FieldOffset(Offset = "0x110")]
	private Color m_pointsMaxColor;

	[Token(Token = "0x4000BD2")]
	[FieldOffset(Offset = "0x120")]
	private Color m_pointsActiveColor;

	[Token(Token = "0x4000BD3")]
	[FieldOffset(Offset = "0x130")]
	private UITalentInfo m_TalentInfo;

	[Token(Token = "0x4000BD4")]
	[FieldOffset(Offset = "0x138")]
	private UISpellInfo m_SpellInfo;

	[Token(Token = "0x4000BD5")]
	[FieldOffset(Offset = "0x140")]
	private int m_CurrentPoints;

	[Token(Token = "0x170001F1")]
	public bool IsSpecial
	{
		[Token(Token = "0x6000B58")]
		[Address(RVA = "0x47215C", Offset = "0x47215C", VA = "0x47215C")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B59")]
		[Address(RVA = "0x472164", Offset = "0x472164", VA = "0x472164")]
		set
		{
		}
	}

	[Token(Token = "0x6000B5A")]
	[Address(RVA = "0x472214", Offset = "0x472214", VA = "0x472214", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000B5B")]
	[Address(RVA = "0x472238", Offset = "0x472238", VA = "0x472238")]
	public UISpellInfo GetSpellInfo()
	{
		return null;
	}

	[Token(Token = "0x6000B5C")]
	[Address(RVA = "0x472240", Offset = "0x472240", VA = "0x472240")]
	public UITalentInfo GetTalentInfo()
	{
		return null;
	}

	[Token(Token = "0x6000B5D")]
	[Address(RVA = "0x472248", Offset = "0x472248", VA = "0x472248", Slot = "36")]
	public override bool IsAssigned()
	{
		return default(bool);
	}

	[Token(Token = "0x6000B5E")]
	[Address(RVA = "0x472170", Offset = "0x472170", VA = "0x472170")]
	public void UpdateSpecialBackground()
	{
	}

	[Token(Token = "0x6000B5F")]
	[Address(RVA = "0x472258", Offset = "0x472258", VA = "0x472258")]
	public bool Assign(UITalentInfo talentInfo, UISpellInfo spellInfo)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B60")]
	[Address(RVA = "0x4722AC", Offset = "0x4722AC", VA = "0x4722AC")]
	public void UpdatePointsLabel()
	{
	}

	[Token(Token = "0x6000B61")]
	[Address(RVA = "0x47295C", Offset = "0x47295C", VA = "0x47295C", Slot = "38")]
	public override void Unassign()
	{
	}

	[Token(Token = "0x6000B62")]
	[Address(RVA = "0x472980", Offset = "0x472980", VA = "0x472980", Slot = "31")]
	public override void OnPointerClick(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B63")]
	[Address(RVA = "0x472A1C", Offset = "0x472A1C", VA = "0x472A1C", Slot = "50")]
	public virtual void OnRightPointerClick(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B64")]
	[Address(RVA = "0x472A34", Offset = "0x472A34", VA = "0x472A34")]
	public void AddPoints(int points)
	{
	}

	[Token(Token = "0x6000B65")]
	[Address(RVA = "0x472AAC", Offset = "0x472AAC", VA = "0x472AAC", Slot = "28")]
	public override void OnTooltip(bool show)
	{
	}

	[Token(Token = "0x6000B66")]
	[Address(RVA = "0x472B54", Offset = "0x472B54", VA = "0x472B54")]
	public UITalentSlot()
	{
	}
}
