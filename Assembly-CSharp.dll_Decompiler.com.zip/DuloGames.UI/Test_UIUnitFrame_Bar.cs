using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001D7")]
public class Test_UIUnitFrame_Bar : MonoBehaviour
{
	[Token(Token = "0x4000C06")]
	[FieldOffset(Offset = "0x18")]
	public UIUnitFrame_Bar bar;

	[Token(Token = "0x4000C07")]
	[FieldOffset(Offset = "0x20")]
	public float duration;

	[NonSerialized]
	[Token(Token = "0x4000C08")]
	[FieldOffset(Offset = "0x28")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x6000BB2")]
	[Address(RVA = "0x3E1AAC", Offset = "0x3E1AAC", VA = "0x3E1AAC")]
	protected Test_UIUnitFrame_Bar()
	{
	}

	[Token(Token = "0x6000BB3")]
	[Address(RVA = "0x3E1B3C", Offset = "0x3E1B3C", VA = "0x3E1B3C")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000BB4")]
	[Address(RVA = "0x3E1CE8", Offset = "0x3E1CE8", VA = "0x3E1CE8")]
	protected void SetFillAmount(float amount)
	{
	}

	[Token(Token = "0x6000BB5")]
	[Address(RVA = "0x3E1B40", Offset = "0x3E1B40", VA = "0x3E1B40")]
	public void StartDemoTween()
	{
	}

	[Token(Token = "0x6000BB6")]
	[Address(RVA = "0x3E1DC8", Offset = "0x3E1DC8", VA = "0x3E1DC8")]
	protected void OnTweenFinished()
	{
	}
}
