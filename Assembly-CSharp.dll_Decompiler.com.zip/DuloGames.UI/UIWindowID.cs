using Il2CppDummyDll;

namespace DuloGames.UI;

[Token(Token = "0x20001BB")]
public enum UIWindowID
{
	[Token(Token = "0x4000B88")]
	None,
	[Token(Token = "0x4000B89")]
	Custom,
	[Token(Token = "0x4000B8A")]
	Settings,
	[Token(Token = "0x4000B8B")]
	GameMenu
}
