using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001EA")]
public class UIToggle_OnOff : MonoBehaviour, IDisposable, IContentHandler, IComparer<Contraction>
{
	[Token(Token = "0x4000CBE")]
	[FieldOffset(Offset = "0x18")]
	private Image m_Target;

	[Token(Token = "0x4000CBF")]
	[FieldOffset(Offset = "0x20")]
	private Sprite m_ActiveSprite;

	[Token(Token = "0x4000CC0")]
	[FieldOffset(Offset = "0x28")]
	private Image m_PressOverlay;

	[Token(Token = "0x4000CC1")]
	[FieldOffset(Offset = "0x30")]
	private Vector2 m_PressActivePos;

	[Token(Token = "0x4000CC2")]
	[FieldOffset(Offset = "0x38")]
	private Vector2 m_PressInactivePos;

	[Token(Token = "0x4000CC3")]
	[FieldOffset(Offset = "0x40")]
	private bool m_InstaOut;

	[Token(Token = "0x17000228")]
	public Toggle toggle
	{
		[Token(Token = "0x6000CB9")]
		[Address(RVA = "0x472E70", Offset = "0x472E70", VA = "0x472E70")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000CBA")]
	[Address(RVA = "0x472ED0", Offset = "0x472ED0", VA = "0x472ED0")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000CBB")]
	[Address(RVA = "0x4731E0", Offset = "0x4731E0", VA = "0x4731E0")]
	protected void OnDisable()
	{
	}

	[Token(Token = "0x6000CBC")]
	[Address(RVA = "0x4730B8", Offset = "0x4730B8", VA = "0x4730B8")]
	public void OnValueChanged(bool state)
	{
	}

	[Token(Token = "0x6000CBD")]
	[Address(RVA = "0x472FA0", Offset = "0x472FA0", VA = "0x472FA0")]
	private void DoTransition(bool pressed, bool instant)
	{
	}

	[Token(Token = "0x6000CBE")]
	[Address(RVA = "0x473288", Offset = "0x473288", VA = "0x473288", Slot = "6")]
	public virtual void OnPointerDown(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000CBF")]
	[Address(RVA = "0x4732B0", Offset = "0x4732B0", VA = "0x4732B0", Slot = "7")]
	public virtual void OnPointerUp(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000CC0")]
	[Address(RVA = "0x4732D8", Offset = "0x4732D8", VA = "0x4732D8")]
	public UIToggle_OnOff()
	{
	}
}
