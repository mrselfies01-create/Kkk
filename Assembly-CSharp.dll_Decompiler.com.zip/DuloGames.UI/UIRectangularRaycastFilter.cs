using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001CE")]
public class UIRectangularRaycastFilter : MonoBehaviour, IDisposable
{
	[Token(Token = "0x4000BE2")]
	[FieldOffset(Offset = "0x18")]
	private Vector2 m_Offset;

	[Token(Token = "0x4000BE3")]
	[FieldOffset(Offset = "0x20")]
	private RectOffset m_Borders;

	[Token(Token = "0x4000BE4")]
	[FieldOffset(Offset = "0x28")]
	private float m_ScaleX;

	[Token(Token = "0x4000BE5")]
	[FieldOffset(Offset = "0x2C")]
	private float m_ScaleY;

	[Token(Token = "0x170001F8")]
	public Vector2 offset
	{
		[Token(Token = "0x6000B87")]
		[Address(RVA = "0x3EA640", Offset = "0x3EA640", VA = "0x3EA640")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000B88")]
		[Address(RVA = "0x3EA648", Offset = "0x3EA648", VA = "0x3EA648")]
		set
		{
		}
	}

	[Token(Token = "0x170001F9")]
	public RectOffset borders
	{
		[Token(Token = "0x6000B89")]
		[Address(RVA = "0x3EA650", Offset = "0x3EA650", VA = "0x3EA650")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000B8A")]
		[Address(RVA = "0x3EA658", Offset = "0x3EA658", VA = "0x3EA658")]
		set
		{
		}
	}

	[Token(Token = "0x170001FA")]
	public float scaleX
	{
		[Token(Token = "0x6000B8B")]
		[Address(RVA = "0x3EA660", Offset = "0x3EA660", VA = "0x3EA660")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000B8C")]
		[Address(RVA = "0x3EA668", Offset = "0x3EA668", VA = "0x3EA668")]
		set
		{
		}
	}

	[Token(Token = "0x170001FB")]
	public float scaleY
	{
		[Token(Token = "0x6000B8D")]
		[Address(RVA = "0x3EA670", Offset = "0x3EA670", VA = "0x3EA670")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000B8E")]
		[Address(RVA = "0x3EA678", Offset = "0x3EA678", VA = "0x3EA678")]
		set
		{
		}
	}

	[Token(Token = "0x170001FC")]
	public Rect scaledRect
	{
		[Token(Token = "0x6000B8F")]
		[Address(RVA = "0x3EA680", Offset = "0x3EA680", VA = "0x3EA680")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Rect);
		}
	}

	[Token(Token = "0x6000B90")]
	[Address(RVA = "0x3EA98C", Offset = "0x3EA98C", VA = "0x3EA98C", Slot = "4")]
	public bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B91")]
	[Address(RVA = "0x3EAAB4", Offset = "0x3EAAB4", VA = "0x3EAAB4")]
	public UIRectangularRaycastFilter()
	{
	}
}
