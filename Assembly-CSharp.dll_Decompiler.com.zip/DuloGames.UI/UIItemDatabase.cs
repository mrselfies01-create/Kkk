using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001A4")]
public class UIItemDatabase : ScriptableObject
{
	[Token(Token = "0x4000B29")]
	[FieldOffset(Offset = "0x18")]
	public UIItemInfo[] items;

	[Token(Token = "0x6000A56")]
	[Address(RVA = "0x3E72F0", Offset = "0x3E72F0", VA = "0x3E72F0")]
	public UIItemInfo Get(int index)
	{
		return null;
	}

	[Token(Token = "0x6000A57")]
	[Address(RVA = "0x3E0B1C", Offset = "0x3E0B1C", VA = "0x3E0B1C")]
	public UIItemInfo GetByID(int ID)
	{
		return null;
	}

	[Token(Token = "0x6000A58")]
	[Address(RVA = "0x3E732C", Offset = "0x3E732C", VA = "0x3E732C")]
	public UIItemDatabase()
	{
	}
}
