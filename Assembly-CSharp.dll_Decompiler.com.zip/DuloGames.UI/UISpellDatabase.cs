using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001A5")]
public class UISpellDatabase : ScriptableObject
{
	[Token(Token = "0x4000B2A")]
	[FieldOffset(Offset = "0x18")]
	public UISpellInfo[] spells;

	[Token(Token = "0x6000A59")]
	[Address(RVA = "0x46FCDC", Offset = "0x46FCDC", VA = "0x46FCDC")]
	public UISpellInfo Get(int index)
	{
		return null;
	}

	[Token(Token = "0x6000A5A")]
	[Address(RVA = "0x46FD18", Offset = "0x46FD18", VA = "0x46FD18")]
	public UISpellInfo GetByID(int ID)
	{
		return null;
	}

	[Token(Token = "0x6000A5B")]
	[Address(RVA = "0x46FD80", Offset = "0x46FD80", VA = "0x46FD80")]
	public UISpellDatabase()
	{
	}
}
