using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Microsoft.Win32;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E3")]
public class UIHighlightTransition : MonoBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer, IRegistryApi
{
	[Token(Token = "0x200026F")]
	public enum VisualState
	{
		[Token(Token = "0x4000F73")]
		Normal,
		[Token(Token = "0x4000F74")]
		Highlighted,
		[Token(Token = "0x4000F75")]
		Selected
	}

	[Token(Token = "0x2000270")]
	public enum Transition
	{
		[Token(Token = "0x4000F77")]
		None,
		[Token(Token = "0x4000F78")]
		ColorTint,
		[Token(Token = "0x4000F79")]
		SpriteSwap,
		[Token(Token = "0x4000F7A")]
		Animation,
		[Token(Token = "0x4000F7B")]
		TextColor
	}

	[Token(Token = "0x4000C6B")]
	[FieldOffset(Offset = "0x18")]
	private Transition m_Transition;

	[Token(Token = "0x4000C6C")]
	[FieldOffset(Offset = "0x1C")]
	private Color m_NormalColor;

	[Token(Token = "0x4000C6D")]
	[FieldOffset(Offset = "0x2C")]
	private Color m_HighlightedColor;

	[Token(Token = "0x4000C6E")]
	[FieldOffset(Offset = "0x3C")]
	private Color m_SelectedColor;

	[Token(Token = "0x4000C6F")]
	[FieldOffset(Offset = "0x4C")]
	private float m_Duration;

	[Token(Token = "0x4000C70")]
	[FieldOffset(Offset = "0x50")]
	private float m_ColorMultiplier;

	[Token(Token = "0x4000C71")]
	[FieldOffset(Offset = "0x58")]
	private Sprite m_HighlightedSprite;

	[Token(Token = "0x4000C72")]
	[FieldOffset(Offset = "0x60")]
	private Sprite m_SelectedSprite;

	[Token(Token = "0x4000C73")]
	[FieldOffset(Offset = "0x68")]
	private string m_NormalTrigger;

	[Token(Token = "0x4000C74")]
	[FieldOffset(Offset = "0x70")]
	private string m_HighlightedTrigger;

	[Token(Token = "0x4000C75")]
	[FieldOffset(Offset = "0x78")]
	private string m_SelectedTrigger;

	[Token(Token = "0x4000C76")]
	[FieldOffset(Offset = "0x80")]
	private Graphic m_TargetGraphic;

	[Token(Token = "0x4000C77")]
	[FieldOffset(Offset = "0x88")]
	private GameObject m_TargetGameObject;

	[Token(Token = "0x4000C78")]
	[FieldOffset(Offset = "0x90")]
	private bool m_Highlighted;

	[Token(Token = "0x4000C79")]
	[FieldOffset(Offset = "0x91")]
	private bool m_Selected;

	[Token(Token = "0x17000212")]
	public Transition transition
	{
		[Token(Token = "0x6000C4C")]
		[Address(RVA = "0x3E69AC", Offset = "0x3E69AC", VA = "0x3E69AC")]
		get
		{
			return default(Transition);
		}
		[Token(Token = "0x6000C4D")]
		[Address(RVA = "0x3E69B4", Offset = "0x3E69B4", VA = "0x3E69B4")]
		set
		{
		}
	}

	[Token(Token = "0x17000213")]
	public Graphic targetGraphic
	{
		[Token(Token = "0x6000C4E")]
		[Address(RVA = "0x3E69BC", Offset = "0x3E69BC", VA = "0x3E69BC")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C4F")]
		[Address(RVA = "0x3E69C4", Offset = "0x3E69C4", VA = "0x3E69C4")]
		set
		{
		}
	}

	[Token(Token = "0x17000214")]
	public GameObject targetGameObject
	{
		[Token(Token = "0x6000C50")]
		[Address(RVA = "0x3E69CC", Offset = "0x3E69CC", VA = "0x3E69CC")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C51")]
		[Address(RVA = "0x3E69D4", Offset = "0x3E69D4", VA = "0x3E69D4")]
		set
		{
		}
	}

	[Token(Token = "0x17000215")]
	public Animator animator
	{
		[Token(Token = "0x6000C52")]
		[Address(RVA = "0x3E69DC", Offset = "0x3E69DC", VA = "0x3E69DC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000C53")]
	[Address(RVA = "0x3E6A78", Offset = "0x3E6A78", VA = "0x3E6A78")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000C54")]
	[Address(RVA = "0x3E6AA0", Offset = "0x3E6AA0", VA = "0x3E6AA0")]
	protected void OnDisable()
	{
	}

	[Token(Token = "0x6000C55")]
	[Address(RVA = "0x3E6AA4", Offset = "0x3E6AA4", VA = "0x3E6AA4")]
	protected void InstantClearState()
	{
	}

	[Token(Token = "0x6000C56")]
	[Address(RVA = "0x3E6A8C", Offset = "0x3E6A8C", VA = "0x3E6A8C")]
	private void InternalEvaluateAndTransitionToNormalState(bool instant)
	{
	}

	[Token(Token = "0x6000C57")]
	[Address(RVA = "0x3E702C", Offset = "0x3E702C", VA = "0x3E702C", Slot = "4")]
	public void OnSelect(BaseEventData eventData)
	{
	}

	[Token(Token = "0x6000C58")]
	[Address(RVA = "0x3E7048", Offset = "0x3E7048", VA = "0x3E7048", Slot = "5")]
	public void OnDeselect(BaseEventData eventData)
	{
	}

	[Token(Token = "0x6000C59")]
	[Address(RVA = "0x3E7070", Offset = "0x3E7070", VA = "0x3E7070", Slot = "6")]
	public void OnPointerEnter(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C5A")]
	[Address(RVA = "0x3E7098", Offset = "0x3E7098", VA = "0x3E7098", Slot = "7")]
	public void OnPointerExit(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C5B")]
	[Address(RVA = "0x3E70BC", Offset = "0x3E70BC", VA = "0x3E70BC", Slot = "8")]
	protected virtual void DoStateTransition(VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000C5C")]
	[Address(RVA = "0x3E6B40", Offset = "0x3E6B40", VA = "0x3E6B40")]
	private void StartColorTween(Color targetColor, bool instant)
	{
	}

	[Token(Token = "0x6000C5D")]
	[Address(RVA = "0x3E6C8C", Offset = "0x3E6C8C", VA = "0x3E6C8C")]
	private void DoSpriteSwap(Sprite newSprite)
	{
	}

	[Token(Token = "0x6000C5E")]
	[Address(RVA = "0x3E6D74", Offset = "0x3E6D74", VA = "0x3E6D74")]
	private void TriggerAnimation(string triggername)
	{
	}

	[Token(Token = "0x6000C5F")]
	[Address(RVA = "0x3E6F2C", Offset = "0x3E6F2C", VA = "0x3E6F2C")]
	private void SetTextColor(Color targetColor)
	{
	}

	[Token(Token = "0x6000C60")]
	[Address(RVA = "0x3E720C", Offset = "0x3E720C", VA = "0x3E720C")]
	public UIHighlightTransition()
	{
	}
}
