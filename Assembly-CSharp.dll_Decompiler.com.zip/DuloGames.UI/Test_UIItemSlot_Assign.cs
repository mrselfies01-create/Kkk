using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001D2")]
public class Test_UIItemSlot_Assign : MonoBehaviour
{
	[Token(Token = "0x4000BF1")]
	[FieldOffset(Offset = "0x18")]
	public UIItemSlot slot;

	[Token(Token = "0x4000BF2")]
	[FieldOffset(Offset = "0x20")]
	public UIItemDatabase itemDatabase;

	[Token(Token = "0x4000BF3")]
	[FieldOffset(Offset = "0x28")]
	public int assignItem;

	[Token(Token = "0x6000BA0")]
	[Address(RVA = "0x3E0C48", Offset = "0x3E0C48", VA = "0x3E0C48")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000BA1")]
	[Address(RVA = "0x3E0CD8", Offset = "0x3E0CD8", VA = "0x3E0CD8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000BA2")]
	[Address(RVA = "0x3E0DB4", Offset = "0x3E0DB4", VA = "0x3E0DB4")]
	private void Destruct()
	{
	}

	[Token(Token = "0x6000BA3")]
	[Address(RVA = "0x3E0EBC", Offset = "0x3E0EBC", VA = "0x3E0EBC")]
	public Test_UIItemSlot_Assign()
	{
	}
}
