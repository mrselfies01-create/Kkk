using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001ED")]
public class UIWindowManager : MonoBehaviour
{
	[Token(Token = "0x6000D2E")]
	[Address(RVA = "0x4778C4", Offset = "0x4778C4", VA = "0x4778C4", Slot = "4")]
	protected virtual void Update()
	{
	}

	[Token(Token = "0x6000D2F")]
	[Address(RVA = "0x477AF8", Offset = "0x477AF8", VA = "0x477AF8")]
	public UIWindowManager()
	{
	}
}
