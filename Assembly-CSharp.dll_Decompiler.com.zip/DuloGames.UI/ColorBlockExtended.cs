using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B0")]
public struct ColorBlockExtended
{
	[Token(Token = "0x4000B44")]
	[FieldOffset(Offset = "0x0")]
	private Color m_NormalColor;

	[Token(Token = "0x4000B45")]
	[FieldOffset(Offset = "0x10")]
	private Color m_HighlightedColor;

	[Token(Token = "0x4000B46")]
	[FieldOffset(Offset = "0x20")]
	private Color m_PressedColor;

	[Token(Token = "0x4000B47")]
	[FieldOffset(Offset = "0x30")]
	private Color m_ActiveColor;

	[Token(Token = "0x4000B48")]
	[FieldOffset(Offset = "0x40")]
	private Color m_ActiveHighlightedColor;

	[Token(Token = "0x4000B49")]
	[FieldOffset(Offset = "0x50")]
	private Color m_ActivePressedColor;

	[Token(Token = "0x4000B4A")]
	[FieldOffset(Offset = "0x60")]
	private Color m_DisabledColor;

	[Token(Token = "0x4000B4B")]
	[FieldOffset(Offset = "0x70")]
	private float m_ColorMultiplier;

	[Token(Token = "0x4000B4C")]
	[FieldOffset(Offset = "0x74")]
	private float m_FadeDuration;

	[Token(Token = "0x170001D2")]
	public static ColorBlockExtended defaultColorBlock
	{
		[Token(Token = "0x6000A9C")]
		[Address(RVA = "0x64196C", Offset = "0x64196C", VA = "0x64196C")]
		get
		{
			return default(ColorBlockExtended);
		}
	}

	[Token(Token = "0x170001D3")]
	public Color normalColor
	{
		[Token(Token = "0x6000A9D")]
		[Address(RVA = "0x2A43AC", Offset = "0x2A43AC", VA = "0x2A43AC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000A9E")]
		[Address(RVA = "0x2A43B8", Offset = "0x2A43B8", VA = "0x2A43B8")]
		set
		{
		}
	}

	[Token(Token = "0x170001D4")]
	public Color highlightedColor
	{
		[Token(Token = "0x6000A9F")]
		[Address(RVA = "0x2A43C4", Offset = "0x2A43C4", VA = "0x2A43C4")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AA0")]
		[Address(RVA = "0x2A43D0", Offset = "0x2A43D0", VA = "0x2A43D0")]
		set
		{
		}
	}

	[Token(Token = "0x170001D5")]
	public Color pressedColor
	{
		[Token(Token = "0x6000AA1")]
		[Address(RVA = "0x2A43DC", Offset = "0x2A43DC", VA = "0x2A43DC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AA2")]
		[Address(RVA = "0x2A43E8", Offset = "0x2A43E8", VA = "0x2A43E8")]
		set
		{
		}
	}

	[Token(Token = "0x170001D6")]
	public Color disabledColor
	{
		[Token(Token = "0x6000AA3")]
		[Address(RVA = "0x2A43F4", Offset = "0x2A43F4", VA = "0x2A43F4")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AA4")]
		[Address(RVA = "0x2A4400", Offset = "0x2A4400", VA = "0x2A4400")]
		set
		{
		}
	}

	[Token(Token = "0x170001D7")]
	public Color activeColor
	{
		[Token(Token = "0x6000AA5")]
		[Address(RVA = "0x2A440C", Offset = "0x2A440C", VA = "0x2A440C")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AA6")]
		[Address(RVA = "0x2A4418", Offset = "0x2A4418", VA = "0x2A4418")]
		set
		{
		}
	}

	[Token(Token = "0x170001D8")]
	public Color activeHighlightedColor
	{
		[Token(Token = "0x6000AA7")]
		[Address(RVA = "0x2A4424", Offset = "0x2A4424", VA = "0x2A4424")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AA8")]
		[Address(RVA = "0x2A4430", Offset = "0x2A4430", VA = "0x2A4430")]
		set
		{
		}
	}

	[Token(Token = "0x170001D9")]
	public Color activePressedColor
	{
		[Token(Token = "0x6000AA9")]
		[Address(RVA = "0x2A443C", Offset = "0x2A443C", VA = "0x2A443C")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Color);
		}
		[Token(Token = "0x6000AAA")]
		[Address(RVA = "0x2A4448", Offset = "0x2A4448", VA = "0x2A4448")]
		set
		{
		}
	}

	[Token(Token = "0x170001DA")]
	public float colorMultiplier
	{
		[Token(Token = "0x6000AAB")]
		[Address(RVA = "0x2A4454", Offset = "0x2A4454", VA = "0x2A4454")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000AAC")]
		[Address(RVA = "0x2A445C", Offset = "0x2A445C", VA = "0x2A445C")]
		set
		{
		}
	}

	[Token(Token = "0x170001DB")]
	public float fadeDuration
	{
		[Token(Token = "0x6000AAD")]
		[Address(RVA = "0x2A4464", Offset = "0x2A4464", VA = "0x2A4464")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000AAE")]
		[Address(RVA = "0x2A446C", Offset = "0x2A446C", VA = "0x2A446C")]
		set
		{
		}
	}
}
