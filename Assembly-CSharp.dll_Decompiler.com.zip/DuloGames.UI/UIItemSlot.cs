using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;

namespace DuloGames.UI;

[Token(Token = "0x20001BE")]
public class UIItemSlot : UISlotBase
{
	[Serializable]
	[Token(Token = "0x2000253")]
	public class OnAssignEvent : UnityEvent<UIItemSlot>
	{
		[Token(Token = "0x6000DBB")]
		[Address(RVA = "0x78FBA4", Offset = "0x78FBA4", VA = "0x78FBA4")]
		public OnAssignEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x2000254")]
	public class OnUnassignEvent : UnityEvent<UIItemSlot>
	{
		[Token(Token = "0x6000DBC")]
		[Address(RVA = "0x78FBF4", Offset = "0x78FBF4", VA = "0x78FBF4")]
		public OnUnassignEvent()
		{
		}
	}

	[Token(Token = "0x4000B95")]
	[FieldOffset(Offset = "0xF0")]
	private UIItemSlot_Group m_SlotGroup;

	[Token(Token = "0x4000B96")]
	[FieldOffset(Offset = "0xF4")]
	private int m_ID;

	[Token(Token = "0x4000B97")]
	[FieldOffset(Offset = "0xF8")]
	private UIItemInfo m_ItemInfo;

	[Token(Token = "0x4000B98")]
	[FieldOffset(Offset = "0x100")]
	public OnAssignEvent onAssign;

	[Token(Token = "0x4000B99")]
	[FieldOffset(Offset = "0x108")]
	public OnUnassignEvent onUnassign;

	[Token(Token = "0x170001E3")]
	public UIItemSlot_Group slotGroup
	{
		[Token(Token = "0x6000AE2")]
		[Address(RVA = "0x3E733C", Offset = "0x3E733C", VA = "0x3E733C")]
		get
		{
			return default(UIItemSlot_Group);
		}
		[Token(Token = "0x6000AE3")]
		[Address(RVA = "0x3E7344", Offset = "0x3E7344", VA = "0x3E7344")]
		set
		{
		}
	}

	[Token(Token = "0x170001E4")]
	public int ID
	{
		[Token(Token = "0x6000AE4")]
		[Address(RVA = "0x3E734C", Offset = "0x3E734C", VA = "0x3E734C")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000AE5")]
		[Address(RVA = "0x3E7354", Offset = "0x3E7354", VA = "0x3E7354")]
		set
		{
		}
	}

	[Token(Token = "0x6000AE6")]
	[Address(RVA = "0x3E735C", Offset = "0x3E735C", VA = "0x3E735C")]
	public UIItemInfo GetItemInfo()
	{
		return null;
	}

	[Token(Token = "0x6000AE7")]
	[Address(RVA = "0x3E7364", Offset = "0x3E7364", VA = "0x3E7364", Slot = "36")]
	public override bool IsAssigned()
	{
		return default(bool);
	}

	[Token(Token = "0x6000AE8")]
	[Address(RVA = "0x3E0E1C", Offset = "0x3E0E1C", VA = "0x3E0E1C")]
	public bool Assign(UIItemInfo itemInfo)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AE9")]
	[Address(RVA = "0x3E7374", Offset = "0x3E7374", VA = "0x3E7374", Slot = "37")]
	public override bool Assign(Object source)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AEA")]
	[Address(RVA = "0x3E7474", Offset = "0x3E7474", VA = "0x3E7474", Slot = "38")]
	public override void Unassign()
	{
	}

	[Token(Token = "0x6000AEB")]
	[Address(RVA = "0x3E74E8", Offset = "0x3E74E8", VA = "0x3E74E8", Slot = "44")]
	public override bool CanSwapWith(Object target)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AEC")]
	[Address(RVA = "0x3E75EC", Offset = "0x3E75EC", VA = "0x3E75EC", Slot = "45")]
	public override bool PerformSlotSwap(Object sourceObject)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AED")]
	[Address(RVA = "0x3E5E74", Offset = "0x3E5E74", VA = "0x3E5E74")]
	public static void PrepareTooltip(UIItemInfo itemInfo)
	{
	}

	[Token(Token = "0x6000AEE")]
	[Address(RVA = "0x3E7708", Offset = "0x3E7708", VA = "0x3E7708", Slot = "28")]
	public override void OnTooltip(bool show)
	{
	}

	[Token(Token = "0x6000AEF")]
	[Address(RVA = "0x3E77BC", Offset = "0x3E77BC", VA = "0x3E77BC")]
	public static List<UIItemSlot> GetSlots()
	{
		return null;
	}

	[Token(Token = "0x6000AF0")]
	[Address(RVA = "0x3E78C4", Offset = "0x3E78C4", VA = "0x3E78C4")]
	public static List<UIItemSlot> GetSlotsWithID(int ID)
	{
		return null;
	}

	[Token(Token = "0x6000AF1")]
	[Address(RVA = "0x3E79DC", Offset = "0x3E79DC", VA = "0x3E79DC")]
	public static List<UIItemSlot> GetSlotsInGroup(UIItemSlot_Group group)
	{
		return null;
	}

	[Token(Token = "0x6000AF2")]
	[Address(RVA = "0x3E7AF4", Offset = "0x3E7AF4", VA = "0x3E7AF4")]
	public static UIItemSlot GetSlot(int ID, UIItemSlot_Group group)
	{
		return null;
	}

	[Token(Token = "0x6000AF3")]
	[Address(RVA = "0x3E7BE0", Offset = "0x3E7BE0", VA = "0x3E7BE0")]
	public UIItemSlot()
	{
	}
}
