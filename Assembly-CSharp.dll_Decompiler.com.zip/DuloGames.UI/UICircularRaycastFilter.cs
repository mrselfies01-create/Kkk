using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001CB")]
public class UICircularRaycastFilter : MonoBehaviour, IDisposable
{
	[Token(Token = "0x4000BDC")]
	[FieldOffset(Offset = "0x18")]
	private bool m_RadiusInPercents;

	[Token(Token = "0x4000BDD")]
	[FieldOffset(Offset = "0x1C")]
	private float m_Radius;

	[Token(Token = "0x4000BDE")]
	[FieldOffset(Offset = "0x20")]
	private Vector2 m_Offset;

	[Token(Token = "0x170001F2")]
	public bool radiusInPercents
	{
		[Token(Token = "0x6000B77")]
		[Address(RVA = "0x3E3BB8", Offset = "0x3E3BB8", VA = "0x3E3BB8")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B78")]
		[Address(RVA = "0x3E3BC0", Offset = "0x3E3BC0", VA = "0x3E3BC0")]
		set
		{
		}
	}

	[Token(Token = "0x170001F3")]
	public float radius
	{
		[Token(Token = "0x6000B79")]
		[Address(RVA = "0x3E3BCC", Offset = "0x3E3BCC", VA = "0x3E3BCC")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000B7A")]
		[Address(RVA = "0x3E3BD4", Offset = "0x3E3BD4", VA = "0x3E3BD4")]
		set
		{
		}
	}

	[Token(Token = "0x170001F4")]
	public Vector2 offset
	{
		[Token(Token = "0x6000B7B")]
		[Address(RVA = "0x3E3BDC", Offset = "0x3E3BDC", VA = "0x3E3BDC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000B7C")]
		[Address(RVA = "0x3E3BE4", Offset = "0x3E3BE4", VA = "0x3E3BE4")]
		set
		{
		}
	}

	[Token(Token = "0x170001F5")]
	public Vector2 center
	{
		[Token(Token = "0x6000B7D")]
		[Address(RVA = "0x3E3BEC", Offset = "0x3E3BEC", VA = "0x3E3BEC")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
	}

	[Token(Token = "0x170001F6")]
	private float rectMaxRadius
	{
		[Token(Token = "0x6000B7E")]
		[Address(RVA = "0x3E3CCC", Offset = "0x3E3CCC", VA = "0x3E3CCC")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001F7")]
	public float operationalRadius
	{
		[Token(Token = "0x6000B7F")]
		[Address(RVA = "0x3E3D9C", Offset = "0x3E3D9C", VA = "0x3E3D9C")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x6000B80")]
	[Address(RVA = "0x3E3DE4", Offset = "0x3E3DE4", VA = "0x3E3DE4", Slot = "4")]
	public bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B81")]
	[Address(RVA = "0x3E404C", Offset = "0x3E404C", VA = "0x3E404C")]
	public UICircularRaycastFilter()
	{
	}
}
