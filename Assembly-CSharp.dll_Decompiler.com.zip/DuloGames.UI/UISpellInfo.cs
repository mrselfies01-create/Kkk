using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B5")]
public class UISpellInfo
{
	[Token(Token = "0x4000B72")]
	[FieldOffset(Offset = "0x10")]
	public int ID;

	[Token(Token = "0x4000B73")]
	[FieldOffset(Offset = "0x18")]
	public string Name;

	[Token(Token = "0x4000B74")]
	[FieldOffset(Offset = "0x20")]
	public Sprite Icon;

	[Token(Token = "0x4000B75")]
	[FieldOffset(Offset = "0x28")]
	public string Description;

	[Token(Token = "0x4000B76")]
	[FieldOffset(Offset = "0x30")]
	public float Range;

	[Token(Token = "0x4000B77")]
	[FieldOffset(Offset = "0x34")]
	public float Cooldown;

	[Token(Token = "0x4000B78")]
	[FieldOffset(Offset = "0x38")]
	public float CastTime;

	[Token(Token = "0x4000B79")]
	[FieldOffset(Offset = "0x3C")]
	public float PowerCost;

	[Token(Token = "0x4000B7A")]
	[FieldOffset(Offset = "0x40")]
	public UISpellInfo_Flags Flags;

	[Token(Token = "0x6000ABC")]
	[Address(RVA = "0x46FD88", Offset = "0x46FD88", VA = "0x46FD88")]
	public UISpellInfo()
	{
	}
}
