using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001EB")]
public class UITooltip : MonoBehaviour
{
	[Token(Token = "0x200027B")]
	public enum Transition
	{
		[Token(Token = "0x4000F97")]
		None,
		[Token(Token = "0x4000F98")]
		Fade
	}

	[Token(Token = "0x200027C")]
	public enum VisualState
	{
		[Token(Token = "0x4000F9A")]
		Shown,
		[Token(Token = "0x4000F9B")]
		Hidden
	}

	[Token(Token = "0x200027D")]
	public enum Corner
	{
		[Token(Token = "0x4000F9D")]
		BottomLeft,
		[Token(Token = "0x4000F9E")]
		TopLeft,
		[Token(Token = "0x4000F9F")]
		TopRight,
		[Token(Token = "0x4000FA0")]
		BottomRight
	}

	[Token(Token = "0x200027E")]
	public enum TextEffectType
	{
		[Token(Token = "0x4000FA2")]
		None,
		[Token(Token = "0x4000FA3")]
		Shadow,
		[Token(Token = "0x4000FA4")]
		Outline
	}

	[Token(Token = "0x4000CC4")]
	[FieldOffset(Offset = "0x0")]
	private static UITooltip mInstance;

	[Token(Token = "0x4000CC5")]
	public const FitMode DefaultHorizontalFitMode = 0;

	[Token(Token = "0x4000CC6")]
	[FieldOffset(Offset = "0x18")]
	private float m_DefaultWidth;

	[Token(Token = "0x4000CC7")]
	[FieldOffset(Offset = "0x1C")]
	private bool m_followMouse;

	[Token(Token = "0x4000CC8")]
	[FieldOffset(Offset = "0x20")]
	private Vector2 m_Offset;

	[Token(Token = "0x4000CC9")]
	[FieldOffset(Offset = "0x28")]
	private Vector2 m_AnchoredOffset;

	[Token(Token = "0x4000CCA")]
	[FieldOffset(Offset = "0x30")]
	private Graphic m_AnchorGraphic;

	[Token(Token = "0x4000CCB")]
	[FieldOffset(Offset = "0x38")]
	private Vector2 m_AnchorGraphicOffset;

	[Token(Token = "0x4000CCC")]
	[FieldOffset(Offset = "0x40")]
	private Transition m_Transition;

	[Token(Token = "0x4000CCD")]
	[FieldOffset(Offset = "0x44")]
	private TweenEasing m_TransitionEasing;

	[Token(Token = "0x4000CCE")]
	[FieldOffset(Offset = "0x48")]
	private float m_TransitionDuration;

	[Token(Token = "0x4000CCF")]
	[FieldOffset(Offset = "0x50")]
	private Font m_TitleFont;

	[Token(Token = "0x4000CD0")]
	[FieldOffset(Offset = "0x58")]
	private FontStyle m_TitleFontStyle;

	[Token(Token = "0x4000CD1")]
	[FieldOffset(Offset = "0x5C")]
	private int m_TitleFontSize;

	[Token(Token = "0x4000CD2")]
	[FieldOffset(Offset = "0x60")]
	private float m_TitleFontLineSpacing;

	[Token(Token = "0x4000CD3")]
	[FieldOffset(Offset = "0x64")]
	private Color m_TitleFontColor;

	[Token(Token = "0x4000CD4")]
	[FieldOffset(Offset = "0x74")]
	private TextEffectType m_TitleTextEffect;

	[Token(Token = "0x4000CD5")]
	[FieldOffset(Offset = "0x78")]
	private Color m_TitleTextEffectColor;

	[Token(Token = "0x4000CD6")]
	[FieldOffset(Offset = "0x88")]
	private Vector2 m_TitleTextEffectDistance;

	[Token(Token = "0x4000CD7")]
	[FieldOffset(Offset = "0x90")]
	private bool m_TitleTextEffectUseGraphicAlpha;

	[Token(Token = "0x4000CD8")]
	[FieldOffset(Offset = "0x98")]
	private Font m_DescriptionFont;

	[Token(Token = "0x4000CD9")]
	[FieldOffset(Offset = "0xA0")]
	private FontStyle m_DescriptionFontStyle;

	[Token(Token = "0x4000CDA")]
	[FieldOffset(Offset = "0xA4")]
	private int m_DescriptionFontSize;

	[Token(Token = "0x4000CDB")]
	[FieldOffset(Offset = "0xA8")]
	private float m_DescriptionFontLineSpacing;

	[Token(Token = "0x4000CDC")]
	[FieldOffset(Offset = "0xAC")]
	private Color m_DescriptionFontColor;

	[Token(Token = "0x4000CDD")]
	[FieldOffset(Offset = "0xBC")]
	private TextEffectType m_DescriptionTextEffect;

	[Token(Token = "0x4000CDE")]
	[FieldOffset(Offset = "0xC0")]
	private Color m_DescriptionTextEffectColor;

	[Token(Token = "0x4000CDF")]
	[FieldOffset(Offset = "0xD0")]
	private Vector2 m_DescriptionTextEffectDistance;

	[Token(Token = "0x4000CE0")]
	[FieldOffset(Offset = "0xD8")]
	private bool m_DescriptionTextEffectUseGraphicAlpha;

	[Token(Token = "0x4000CE1")]
	[FieldOffset(Offset = "0xE0")]
	private Font m_AttributeFont;

	[Token(Token = "0x4000CE2")]
	[FieldOffset(Offset = "0xE8")]
	private FontStyle m_AttributeFontStyle;

	[Token(Token = "0x4000CE3")]
	[FieldOffset(Offset = "0xEC")]
	private int m_AttributeFontSize;

	[Token(Token = "0x4000CE4")]
	[FieldOffset(Offset = "0xF0")]
	private float m_AttributeFontLineSpacing;

	[Token(Token = "0x4000CE5")]
	[FieldOffset(Offset = "0xF4")]
	private Color m_AttributeFontColor;

	[Token(Token = "0x4000CE6")]
	[FieldOffset(Offset = "0x104")]
	private TextEffectType m_AttributeTextEffect;

	[Token(Token = "0x4000CE7")]
	[FieldOffset(Offset = "0x108")]
	private Color m_AttributeTextEffectColor;

	[Token(Token = "0x4000CE8")]
	[FieldOffset(Offset = "0x118")]
	private Vector2 m_AttributeTextEffectDistance;

	[Token(Token = "0x4000CE9")]
	[FieldOffset(Offset = "0x120")]
	private bool m_AttributeTextEffectUseGraphicAlpha;

	[Token(Token = "0x4000CEA")]
	[FieldOffset(Offset = "0x128")]
	private RectTransform m_Rect;

	[Token(Token = "0x4000CEB")]
	[FieldOffset(Offset = "0x130")]
	private CanvasGroup m_CanvasGroup;

	[Token(Token = "0x4000CEC")]
	[FieldOffset(Offset = "0x138")]
	private ContentSizeFitter m_SizeFitter;

	[Token(Token = "0x4000CED")]
	[FieldOffset(Offset = "0x140")]
	private Canvas m_Canvas;

	[Token(Token = "0x4000CEE")]
	[FieldOffset(Offset = "0x148")]
	private VisualState m_VisualState;

	[Token(Token = "0x4000CEF")]
	[FieldOffset(Offset = "0x150")]
	private RectTransform m_AnchorToTarget;

	[Token(Token = "0x4000CF0")]
	[FieldOffset(Offset = "0x158")]
	private UITooltipLines m_LinesTemplate;

	[NonSerialized]
	[Token(Token = "0x4000CF1")]
	[FieldOffset(Offset = "0x160")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x17000229")]
	public float defaultWidth
	{
		[Token(Token = "0x6000CC1")]
		[Address(RVA = "0x473360", Offset = "0x473360", VA = "0x473360")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000CC2")]
		[Address(RVA = "0x473368", Offset = "0x473368", VA = "0x473368")]
		set
		{
		}
	}

	[Token(Token = "0x1700022A")]
	public bool followMouse
	{
		[Token(Token = "0x6000CC3")]
		[Address(RVA = "0x473370", Offset = "0x473370", VA = "0x473370")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000CC4")]
		[Address(RVA = "0x473378", Offset = "0x473378", VA = "0x473378")]
		set
		{
		}
	}

	[Token(Token = "0x1700022B")]
	public Vector2 offset
	{
		[Token(Token = "0x6000CC5")]
		[Address(RVA = "0x473384", Offset = "0x473384", VA = "0x473384")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000CC6")]
		[Address(RVA = "0x47338C", Offset = "0x47338C", VA = "0x47338C")]
		set
		{
		}
	}

	[Token(Token = "0x1700022C")]
	public Vector2 anchoredOffset
	{
		[Token(Token = "0x6000CC7")]
		[Address(RVA = "0x473394", Offset = "0x473394", VA = "0x473394")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000CC8")]
		[Address(RVA = "0x47339C", Offset = "0x47339C", VA = "0x47339C")]
		set
		{
		}
	}

	[Token(Token = "0x1700022D")]
	public float alpha
	{
		[Token(Token = "0x6000CC9")]
		[Address(RVA = "0x4733A4", Offset = "0x4733A4", VA = "0x4733A4")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x1700022E")]
	public VisualState visualState
	{
		[Token(Token = "0x6000CCA")]
		[Address(RVA = "0x47343C", Offset = "0x47343C", VA = "0x47343C")]
		get
		{
			return default(VisualState);
		}
	}

	[Token(Token = "0x1700022F")]
	public Camera uiCamera
	{
		[Token(Token = "0x6000CCB")]
		[Address(RVA = "0x473444", Offset = "0x473444", VA = "0x473444")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x17000230")]
	public Transition transition
	{
		[Token(Token = "0x6000CCC")]
		[Address(RVA = "0x4735B0", Offset = "0x4735B0", VA = "0x4735B0")]
		get
		{
			return default(Transition);
		}
		[Token(Token = "0x6000CCD")]
		[Address(RVA = "0x4735B8", Offset = "0x4735B8", VA = "0x4735B8")]
		set
		{
		}
	}

	[Token(Token = "0x17000231")]
	public TweenEasing transitionEasing
	{
		[Token(Token = "0x6000CCE")]
		[Address(RVA = "0x4735C0", Offset = "0x4735C0", VA = "0x4735C0")]
		get
		{
			return default(TweenEasing);
		}
		[Token(Token = "0x6000CCF")]
		[Address(RVA = "0x4735C8", Offset = "0x4735C8", VA = "0x4735C8")]
		set
		{
		}
	}

	[Token(Token = "0x17000232")]
	public float transitionDuration
	{
		[Token(Token = "0x6000CD0")]
		[Address(RVA = "0x4735D0", Offset = "0x4735D0", VA = "0x4735D0")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000CD1")]
		[Address(RVA = "0x4735D8", Offset = "0x4735D8", VA = "0x4735D8")]
		set
		{
		}
	}

	[Token(Token = "0x6000CD2")]
	[Address(RVA = "0x4735E0", Offset = "0x4735E0", VA = "0x4735E0")]
	protected UITooltip()
	{
	}

	[Token(Token = "0x6000CD3")]
	[Address(RVA = "0x4738A4", Offset = "0x4738A4", VA = "0x4738A4", Slot = "4")]
	protected virtual void Awake()
	{
	}

	[Token(Token = "0x6000CD4")]
	[Address(RVA = "0x473968", Offset = "0x473968", VA = "0x473968", Slot = "5")]
	protected virtual void Start()
	{
	}

	[Token(Token = "0x6000CD5")]
	[Address(RVA = "0x473A04", Offset = "0x473A04", VA = "0x473A04", Slot = "6")]
	protected virtual void OnDestroy()
	{
	}

	[Token(Token = "0x6000CD6")]
	[Address(RVA = "0x473A54", Offset = "0x473A54", VA = "0x473A54", Slot = "7")]
	protected virtual void OnCanvasGroupChanged()
	{
	}

	[Token(Token = "0x6000CD7")]
	[Address(RVA = "0x473AB4", Offset = "0x473AB4", VA = "0x473AB4", Slot = "8")]
	public virtual bool IsActive()
	{
		return default(bool);
	}

	[Token(Token = "0x6000CD8")]
	[Address(RVA = "0x473B04", Offset = "0x473B04", VA = "0x473B04", Slot = "9")]
	protected virtual void Update()
	{
	}

	[Token(Token = "0x6000CD9")]
	[Address(RVA = "0x473B70", Offset = "0x473B70", VA = "0x473B70", Slot = "10")]
	public virtual void UpdatePositionAndPivot()
	{
	}

	[Token(Token = "0x6000CDA")]
	[Address(RVA = "0x473E3C", Offset = "0x473E3C", VA = "0x473E3C")]
	public void UpdatePivot()
	{
	}

	[Token(Token = "0x6000CDB")]
	[Address(RVA = "0x473F5C", Offset = "0x473F5C", VA = "0x473F5C")]
	protected void SetPivot(Corner point)
	{
	}

	[Token(Token = "0x6000CDC")]
	[Address(RVA = "0x473FF0", Offset = "0x473FF0", VA = "0x473FF0")]
	protected void UpdateAnchorGraphicPosition()
	{
	}

	[Token(Token = "0x6000CDD")]
	[Address(RVA = "0x4741E8", Offset = "0x4741E8", VA = "0x4741E8", Slot = "11")]
	protected virtual void Internal_Show()
	{
	}

	[Token(Token = "0x6000CDE")]
	[Address(RVA = "0x474524", Offset = "0x474524", VA = "0x474524", Slot = "12")]
	protected virtual void Internal_Hide()
	{
	}

	[Token(Token = "0x6000CDF")]
	[Address(RVA = "0x474530", Offset = "0x474530", VA = "0x474530", Slot = "13")]
	protected virtual void Internal_AnchorToRect(RectTransform targetRect)
	{
	}

	[Token(Token = "0x6000CE0")]
	[Address(RVA = "0x474538", Offset = "0x474538", VA = "0x474538")]
	protected void Internal_SetWidth(float width)
	{
	}

	[Token(Token = "0x6000CE1")]
	[Address(RVA = "0x474580", Offset = "0x474580", VA = "0x474580")]
	protected void Internal_SetHorizontalFitMode(FitMode mode)
	{
	}

	[Token(Token = "0x6000CE2")]
	[Address(RVA = "0x473974", Offset = "0x473974", VA = "0x473974")]
	private void EvaluateAndTransitionToState(bool state, bool instant)
	{
	}

	[Token(Token = "0x6000CE3")]
	[Address(RVA = "0x474708", Offset = "0x474708", VA = "0x474708")]
	public void SetAlpha(float alpha)
	{
	}

	[Token(Token = "0x6000CE4")]
	[Address(RVA = "0x47459C", Offset = "0x47459C", VA = "0x47459C")]
	public void StartAlphaTween(float targetAlpha, float duration)
	{
	}

	[Token(Token = "0x6000CE5")]
	[Address(RVA = "0x474798", Offset = "0x474798", VA = "0x474798", Slot = "14")]
	protected virtual void OnTweenFinished()
	{
	}

	[Token(Token = "0x6000CE6")]
	[Address(RVA = "0x474724", Offset = "0x474724", VA = "0x474724")]
	private void InternalOnHide()
	{
	}

	[Token(Token = "0x6000CE7")]
	[Address(RVA = "0x474234", Offset = "0x474234", VA = "0x474234")]
	private void EvaluateAndCreateTooltipLines()
	{
	}

	[Token(Token = "0x6000CE8")]
	[Address(RVA = "0x4747DC", Offset = "0x4747DC", VA = "0x4747DC")]
	private GameObject CreateLine(RectOffset padding)
	{
		return null;
	}

	[Token(Token = "0x6000CE9")]
	[Address(RVA = "0x4749AC", Offset = "0x4749AC", VA = "0x4749AC")]
	private void CreateLineColumn(Transform parent, string content, bool isLeft, UITooltipLines.LineStyle style)
	{
	}

	[Token(Token = "0x6000CEA")]
	[Address(RVA = "0x474F50", Offset = "0x474F50", VA = "0x474F50", Slot = "15")]
	protected virtual void CleanupLines()
	{
	}

	[Token(Token = "0x6000CEB")]
	[Address(RVA = "0x4752AC", Offset = "0x4752AC", VA = "0x4752AC")]
	protected void Internal_SetLines(UITooltipLines lines)
	{
	}

	[Token(Token = "0x6000CEC")]
	[Address(RVA = "0x4752B4", Offset = "0x4752B4", VA = "0x4752B4")]
	protected void Internal_AddLine(string a, RectOffset padding)
	{
	}

	[Token(Token = "0x6000CED")]
	[Address(RVA = "0x475460", Offset = "0x475460", VA = "0x475460")]
	protected void Internal_AddLine(string a, RectOffset padding, UITooltipLines.LineStyle style)
	{
	}

	[Token(Token = "0x6000CEE")]
	[Address(RVA = "0x4755B8", Offset = "0x4755B8", VA = "0x4755B8")]
	protected void Internal_AddLine(string a, string b, RectOffset padding)
	{
	}

	[Token(Token = "0x6000CEF")]
	[Address(RVA = "0x4756FC", Offset = "0x4756FC", VA = "0x4756FC")]
	protected void Internal_AddLine(string a, string b, RectOffset padding, UITooltipLines.LineStyle style)
	{
	}

	[Token(Token = "0x6000CF0")]
	[Address(RVA = "0x47584C", Offset = "0x47584C", VA = "0x47584C")]
	protected void Internal_AddLineColumn(string a)
	{
	}

	[Token(Token = "0x6000CF1")]
	[Address(RVA = "0x4759E4", Offset = "0x4759E4", VA = "0x4759E4", Slot = "16")]
	protected virtual void Internal_AddTitle(string title)
	{
	}

	[Token(Token = "0x6000CF2")]
	[Address(RVA = "0x475A98", Offset = "0x475A98", VA = "0x475A98", Slot = "17")]
	protected virtual void Internal_AddDescription(string description)
	{
	}

	[Token(Token = "0x6000CF3")]
	[Address(RVA = "0x4707D0", Offset = "0x4707D0", VA = "0x4707D0")]
	public static void AddTitle(string title)
	{
	}

	[Token(Token = "0x6000CF4")]
	[Address(RVA = "0x470A28", Offset = "0x470A28", VA = "0x470A28")]
	public static void AddDescription(string description)
	{
	}

	[Token(Token = "0x6000CF5")]
	[Address(RVA = "0x475B4C", Offset = "0x475B4C", VA = "0x475B4C")]
	public static void SetLines(UITooltipLines lines)
	{
	}

	[Token(Token = "0x6000CF6")]
	[Address(RVA = "0x470894", Offset = "0x470894", VA = "0x470894")]
	public static void AddLine(string content)
	{
	}

	[Token(Token = "0x6000CF7")]
	[Address(RVA = "0x475BF4", Offset = "0x475BF4", VA = "0x475BF4")]
	public static void AddLine(string content, RectOffset padding)
	{
	}

	[Token(Token = "0x6000CF8")]
	[Address(RVA = "0x475CB4", Offset = "0x475CB4", VA = "0x475CB4")]
	public static void AddLine(string content, RectOffset padding, UITooltipLines.LineStyle style)
	{
	}

	[Token(Token = "0x6000CF9")]
	[Address(RVA = "0x475D88", Offset = "0x475D88", VA = "0x475D88")]
	public static void AddLine(string leftContent, string rightContent)
	{
	}

	[Token(Token = "0x6000CFA")]
	[Address(RVA = "0x475E6C", Offset = "0x475E6C", VA = "0x475E6C")]
	public static void AddLine(string leftContent, string rightContent, RectOffset padding)
	{
	}

	[Token(Token = "0x6000CFB")]
	[Address(RVA = "0x475F40", Offset = "0x475F40", VA = "0x475F40")]
	public static void AddLine(string leftContent, string rightContent, RectOffset padding, UITooltipLines.LineStyle style)
	{
	}

	[Token(Token = "0x6000CFC")]
	[Address(RVA = "0x470970", Offset = "0x470970", VA = "0x470970")]
	public static void AddLineColumn(string content)
	{
	}

	[Token(Token = "0x6000CFD")]
	[Address(RVA = "0x470650", Offset = "0x470650", VA = "0x470650")]
	public static void Show()
	{
	}

	[Token(Token = "0x6000CFE")]
	[Address(RVA = "0x47071C", Offset = "0x47071C", VA = "0x47071C")]
	public static void Hide()
	{
	}

	[Token(Token = "0x6000CFF")]
	[Address(RVA = "0x47058C", Offset = "0x47058C", VA = "0x47058C")]
	public static void AnchorToRect(RectTransform targetRect)
	{
	}

	[Token(Token = "0x6000D00")]
	[Address(RVA = "0x47601C", Offset = "0x47601C", VA = "0x47601C")]
	public static void SetHorizontalFitMode(FitMode mode)
	{
	}

	[Token(Token = "0x6000D01")]
	[Address(RVA = "0x4760E0", Offset = "0x4760E0", VA = "0x4760E0")]
	protected void SetWidth(float width)
	{
	}

	[Token(Token = "0x6000D02")]
	[Address(RVA = "0x473EF8", Offset = "0x473EF8", VA = "0x473EF8")]
	public static Corner VectorPivotToCorner(Vector2 pivot)
	{
		return default(Corner);
	}

	[Token(Token = "0x6000D03")]
	[Address(RVA = "0x473F3C", Offset = "0x473F3C", VA = "0x473F3C")]
	public static Corner GetOppositeCorner(Corner corner)
	{
		return default(Corner);
	}
}
