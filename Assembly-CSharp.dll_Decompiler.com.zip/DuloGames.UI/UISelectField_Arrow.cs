using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DA")]
public class UISelectField_Arrow : MonoBehaviour
{
	[Token(Token = "0x4000C3B")]
	[FieldOffset(Offset = "0x18")]
	public Graphic targetGraphic;

	[Token(Token = "0x4000C3C")]
	[FieldOffset(Offset = "0x20")]
	public Transition transitionType;

	[Token(Token = "0x4000C3D")]
	[FieldOffset(Offset = "0x24")]
	public ColorBlockExtended colors;

	[Token(Token = "0x4000C3E")]
	[FieldOffset(Offset = "0xA0")]
	public SpriteStateExtended spriteState;

	[Token(Token = "0x4000C3F")]
	[FieldOffset(Offset = "0xD0")]
	public AnimationTriggersExtended animationTriggers;

	[Token(Token = "0x6000BE4")]
	[Address(RVA = "0x3EE7C4", Offset = "0x3EE7C4", VA = "0x3EE7C4")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000BE5")]
	[Address(RVA = "0x3EE854", Offset = "0x3EE854", VA = "0x3EE854")]
	public void UpdateState(UISelectField.VisualState state)
	{
	}

	[Token(Token = "0x6000BE6")]
	[Address(RVA = "0x3ECC68", Offset = "0x3ECC68", VA = "0x3ECC68")]
	public void UpdateState(UISelectField.VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000BE7")]
	[Address(RVA = "0x3EE85C", Offset = "0x3EE85C", VA = "0x3EE85C")]
	private void StartColorTween(Color color, bool instant)
	{
	}

	[Token(Token = "0x6000BE8")]
	[Address(RVA = "0x3EE98C", Offset = "0x3EE98C", VA = "0x3EE98C")]
	private void DoSpriteSwap(Sprite newSprite)
	{
	}

	[Token(Token = "0x6000BE9")]
	[Address(RVA = "0x3EEAA4", Offset = "0x3EEAA4", VA = "0x3EEAA4")]
	private void TriggerAnimation(string trigger)
	{
	}

	[Token(Token = "0x6000BEA")]
	[Address(RVA = "0x3EEC8C", Offset = "0x3EEC8C", VA = "0x3EEC8C")]
	public UISelectField_Arrow()
	{
	}
}
