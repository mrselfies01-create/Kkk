using Il2CppDummyDll;

namespace DuloGames.UI;

[Token(Token = "0x20001D8")]
public interface IUIProgressBar
{
	[Token(Token = "0x170001FD")]
	float fillAmount
	{
		[Token(Token = "0x6000BB7")]
		get;
		[Token(Token = "0x6000BB8")]
		set;
	}
}
