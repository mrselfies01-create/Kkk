using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Microsoft.Win32;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E4")]
public class UIJoystick : UIBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer, IRegistryApi, ICloneable
{
	[Token(Token = "0x2000271")]
	public enum AxisOption
	{
		[Token(Token = "0x4000F7D")]
		Both,
		[Token(Token = "0x4000F7E")]
		OnlyHorizontal,
		[Token(Token = "0x4000F7F")]
		OnlyVertical
	}

	[Token(Token = "0x4000C7A")]
	[FieldOffset(Offset = "0x18")]
	private RectTransform m_Handle;

	[Token(Token = "0x4000C7B")]
	[FieldOffset(Offset = "0x20")]
	private RectTransform m_HandlingArea;

	[Token(Token = "0x4000C7C")]
	[FieldOffset(Offset = "0x28")]
	private Image m_ActiveGraphic;

	[Token(Token = "0x4000C7D")]
	[FieldOffset(Offset = "0x30")]
	private Vector2 m_Axis;

	[Token(Token = "0x4000C7E")]
	[FieldOffset(Offset = "0x38")]
	private float m_Spring;

	[Token(Token = "0x4000C7F")]
	[FieldOffset(Offset = "0x3C")]
	private float m_DeadZone;

	[Token(Token = "0x4000C80")]
	[FieldOffset(Offset = "0x40")]
	public AnimationCurve outputCurve;

	[Token(Token = "0x4000C81")]
	[FieldOffset(Offset = "0x48")]
	private bool m_IsDragging;

	[Token(Token = "0x17000216")]
	public RectTransform Handle
	{
		[Token(Token = "0x6000C61")]
		[Address(RVA = "0x3E7FCC", Offset = "0x3E7FCC", VA = "0x3E7FCC")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C62")]
		[Address(RVA = "0x3E7FD4", Offset = "0x3E7FD4", VA = "0x3E7FD4")]
		set
		{
		}
	}

	[Token(Token = "0x17000217")]
	public RectTransform HandlingArea
	{
		[Token(Token = "0x6000C63")]
		[Address(RVA = "0x3E8100", Offset = "0x3E8100", VA = "0x3E8100")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C64")]
		[Address(RVA = "0x3E8108", Offset = "0x3E8108", VA = "0x3E8108")]
		set
		{
		}
	}

	[Token(Token = "0x17000218")]
	public Image ActiveGraphic
	{
		[Token(Token = "0x6000C65")]
		[Address(RVA = "0x3E8110", Offset = "0x3E8110", VA = "0x3E8110")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C66")]
		[Address(RVA = "0x3E8118", Offset = "0x3E8118", VA = "0x3E8118")]
		set
		{
		}
	}

	[Token(Token = "0x17000219")]
	public float Spring
	{
		[Token(Token = "0x6000C67")]
		[Address(RVA = "0x3E8120", Offset = "0x3E8120", VA = "0x3E8120")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C68")]
		[Address(RVA = "0x3E8128", Offset = "0x3E8128", VA = "0x3E8128")]
		set
		{
		}
	}

	[Token(Token = "0x1700021A")]
	public float DeadZone
	{
		[Token(Token = "0x6000C69")]
		[Address(RVA = "0x3E8130", Offset = "0x3E8130", VA = "0x3E8130")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000C6A")]
		[Address(RVA = "0x3E8138", Offset = "0x3E8138", VA = "0x3E8138")]
		set
		{
		}
	}

	[Token(Token = "0x1700021B")]
	public Vector2 JoystickAxis
	{
		[Token(Token = "0x6000C6E")]
		[Address(RVA = "0x3DDA38", Offset = "0x3DDA38", VA = "0x3DDA38")]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			return default(Vector2);
		}
		[Token(Token = "0x6000C6F")]
		[Address(RVA = "0x3E8540", Offset = "0x3E8540", VA = "0x3E8540")]
		set
		{
		}
	}

	[Token(Token = "0x6000C6B")]
	[Address(RVA = "0x3E8140", Offset = "0x3E8140", VA = "0x3E8140", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000C6C")]
	[Address(RVA = "0x3E8260", Offset = "0x3E8260", VA = "0x3E8260")]
	protected void CreateVirtualAxes()
	{
	}

	[Token(Token = "0x6000C6D")]
	[Address(RVA = "0x3E8264", Offset = "0x3E8264", VA = "0x3E8264")]
	protected void LateUpdate()
	{
	}

	[Token(Token = "0x6000C70")]
	[Address(RVA = "0x3E8404", Offset = "0x3E8404", VA = "0x3E8404")]
	public void SetAxis(Vector2 axis)
	{
	}

	[Token(Token = "0x6000C71")]
	[Address(RVA = "0x3E8544", Offset = "0x3E8544", VA = "0x3E8544", Slot = "17")]
	public void OnBeginDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C72")]
	[Address(RVA = "0x3E8688", Offset = "0x3E8688", VA = "0x3E8688", Slot = "18")]
	public void OnEndDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C73")]
	[Address(RVA = "0x3E8690", Offset = "0x3E8690", VA = "0x3E8690", Slot = "19")]
	public void OnDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C74")]
	[Address(RVA = "0x3E7FDC", Offset = "0x3E7FDC", VA = "0x3E7FDC")]
	private void UpdateHandle()
	{
	}

	[Token(Token = "0x6000C75")]
	[Address(RVA = "0x3E8840", Offset = "0x3E8840", VA = "0x3E8840", Slot = "20")]
	public void OnPointerDown(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C76")]
	[Address(RVA = "0x3E88EC", Offset = "0x3E88EC", VA = "0x3E88EC", Slot = "21")]
	public void OnPointerUp(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000C77")]
	[Address(RVA = "0x3E8998", Offset = "0x3E8998", VA = "0x3E8998")]
	public UIJoystick()
	{
	}
}
