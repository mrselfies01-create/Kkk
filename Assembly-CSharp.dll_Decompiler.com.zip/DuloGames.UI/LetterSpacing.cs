using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001AD")]
public class LetterSpacing : BaseMeshEffect, IDisposable
{
	[Token(Token = "0x4000B39")]
	[FieldOffset(Offset = "0x20")]
	private float m_spacing;

	[Token(Token = "0x170001BF")]
	public float spacing
	{
		[Token(Token = "0x6000A73")]
		[Address(RVA = "0x38D328", Offset = "0x38D328", VA = "0x38D328")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000A74")]
		[Address(RVA = "0x38D330", Offset = "0x38D330", VA = "0x38D330")]
		set
		{
		}
	}

	[Token(Token = "0x170001C0")]
	private Text text
	{
		[Token(Token = "0x6000A75")]
		[Address(RVA = "0x38D470", Offset = "0x38D470", VA = "0x38D470")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x170001C1")]
	public float minWidth
	{
		[Token(Token = "0x6000A76")]
		[Address(RVA = "0x38D4D0", Offset = "0x38D4D0", VA = "0x38D4D0", Slot = "23")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C2")]
	public float preferredWidth
	{
		[Token(Token = "0x6000A77")]
		[Address(RVA = "0x38D4F8", Offset = "0x38D4F8", VA = "0x38D4F8", Slot = "24")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C3")]
	public float flexibleWidth
	{
		[Token(Token = "0x6000A78")]
		[Address(RVA = "0x38D5A4", Offset = "0x38D5A4", VA = "0x38D5A4", Slot = "25")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C4")]
	public float minHeight
	{
		[Token(Token = "0x6000A79")]
		[Address(RVA = "0x38D5CC", Offset = "0x38D5CC", VA = "0x38D5CC", Slot = "26")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C5")]
	public float preferredHeight
	{
		[Token(Token = "0x6000A7A")]
		[Address(RVA = "0x38D5F4", Offset = "0x38D5F4", VA = "0x38D5F4", Slot = "27")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C6")]
	public float flexibleHeight
	{
		[Token(Token = "0x6000A7B")]
		[Address(RVA = "0x38D61C", Offset = "0x38D61C", VA = "0x38D61C", Slot = "28")]
		get
		{
			return default(float);
		}
	}

	[Token(Token = "0x170001C7")]
	public int layoutPriority
	{
		[Token(Token = "0x6000A7C")]
		[Address(RVA = "0x38D644", Offset = "0x38D644", VA = "0x38D644", Slot = "29")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x6000A7D")]
	[Address(RVA = "0x38D66C", Offset = "0x38D66C", VA = "0x38D66C")]
	protected LetterSpacing()
	{
	}

	[Token(Token = "0x6000A7E")]
	[Address(RVA = "0x38D674", Offset = "0x38D674", VA = "0x38D674", Slot = "21")]
	public void CalculateLayoutInputHorizontal()
	{
	}

	[Token(Token = "0x6000A7F")]
	[Address(RVA = "0x38D678", Offset = "0x38D678", VA = "0x38D678", Slot = "22")]
	public void CalculateLayoutInputVertical()
	{
	}

	[Token(Token = "0x6000A80")]
	[Address(RVA = "0x38D67C", Offset = "0x38D67C", VA = "0x38D67C")]
	private string[] GetLines()
	{
		return null;
	}

	[Token(Token = "0x6000A81")]
	[Address(RVA = "0x38DB0C", Offset = "0x38DB0C", VA = "0x38DB0C", Slot = "20")]
	public override void ModifyMesh(VertexHelper vertexHelper)
	{
	}

	[Token(Token = "0x6000A82")]
	[Address(RVA = "0x38DBDC", Offset = "0x38DBDC", VA = "0x38DBDC")]
	public void ModifyVertices(List<UIVertex> verts)
	{
	}
}
