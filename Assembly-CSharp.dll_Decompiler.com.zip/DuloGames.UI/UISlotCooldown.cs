using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001C1")]
public class UISlotCooldown : MonoBehaviour
{
	[Token(Token = "0x2000258")]
	public class CooldownInfo
	{
		[Token(Token = "0x4000F42")]
		[FieldOffset(Offset = "0x10")]
		public float duration;

		[Token(Token = "0x4000F43")]
		[FieldOffset(Offset = "0x14")]
		public float startTime;

		[Token(Token = "0x4000F44")]
		[FieldOffset(Offset = "0x18")]
		public float endTime;

		[Token(Token = "0x6000DC3")]
		[Address(RVA = "0x7901DC", Offset = "0x7901DC", VA = "0x7901DC")]
		public CooldownInfo(float duration, float startTime, float endTime)
		{
		}
	}

	[Token(Token = "0x2000259")]
	private sealed class _003C_StartCooldown_003Ed__19 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000F45")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000F46")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000F47")]
		[FieldOffset(Offset = "0x20")]
		public CooldownInfo cooldownInfo;

		[Token(Token = "0x4000F48")]
		[FieldOffset(Offset = "0x28")]
		public UISlotCooldown _003C_003E4__this;

		[Token(Token = "0x17000272")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000DC7")]
			[Address(RVA = "0x79016C", Offset = "0x79016C", VA = "0x79016C", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000273")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000DC9")]
			[Address(RVA = "0x7901D4", Offset = "0x7901D4", VA = "0x7901D4", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000DC4")]
		[Address(RVA = "0x78FF7C", Offset = "0x78FF7C", VA = "0x78FF7C")]
		public _003C_StartCooldown_003Ed__19(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000DC5")]
		[Address(RVA = "0x78FFA8", Offset = "0x78FFA8", VA = "0x78FFA8", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000DC6")]
		[Address(RVA = "0x78FFAC", Offset = "0x78FFAC", VA = "0x78FFAC", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000DC8")]
		[Address(RVA = "0x790174", Offset = "0x790174", VA = "0x790174", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x4000BBD")]
	[FieldOffset(Offset = "0x0")]
	private static Dictionary<int, CooldownInfo> spellCooldowns;

	[Token(Token = "0x4000BBE")]
	[FieldOffset(Offset = "0x18")]
	private UISlotBase m_TargetSlot;

	[Token(Token = "0x4000BBF")]
	[FieldOffset(Offset = "0x20")]
	private Image m_TargetGraphic;

	[Token(Token = "0x4000BC0")]
	[FieldOffset(Offset = "0x28")]
	private Text m_TargetText;

	[Token(Token = "0x4000BC1")]
	[FieldOffset(Offset = "0x30")]
	private Image m_FinishGraphic;

	[Token(Token = "0x4000BC2")]
	[FieldOffset(Offset = "0x38")]
	private float m_FinishOffsetY;

	[Token(Token = "0x4000BC3")]
	[FieldOffset(Offset = "0x3C")]
	private float m_FinishFadingPct;

	[Token(Token = "0x4000BC4")]
	[FieldOffset(Offset = "0x40")]
	private bool m_IsOnCooldown;

	[Token(Token = "0x4000BC5")]
	[FieldOffset(Offset = "0x44")]
	private int m_CurrentSpellId;

	[Token(Token = "0x170001EE")]
	public bool IsOnCooldown
	{
		[Token(Token = "0x6000B38")]
		[Address(RVA = "0x46F014", Offset = "0x46F014", VA = "0x46F014")]
		get
		{
			return default(bool);
		}
	}

	[Token(Token = "0x6000B36")]
	[Address(RVA = "0x46EC9C", Offset = "0x46EC9C", VA = "0x46EC9C")]
	protected void Start()
	{
	}

	[Token(Token = "0x6000B37")]
	[Address(RVA = "0x46EFB4", Offset = "0x46EFB4", VA = "0x46EFB4")]
	protected void OnDisable()
	{
	}

	[Token(Token = "0x6000B39")]
	[Address(RVA = "0x46F01C", Offset = "0x46F01C", VA = "0x46F01C")]
	public void OnAssignSpell(UISpellSlot spellSlot)
	{
	}

	[Token(Token = "0x6000B3A")]
	[Address(RVA = "0x46F468", Offset = "0x46F468", VA = "0x46F468")]
	public void OnUnassignSpell(UISpellSlot spellSlot)
	{
	}

	[Token(Token = "0x6000B3B")]
	[Address(RVA = "0x46F46C", Offset = "0x46F46C", VA = "0x46F46C")]
	public void StartCooldown(int spellId, float duration)
	{
	}

	[Token(Token = "0x6000B3C")]
	[Address(RVA = "0x46F1B8", Offset = "0x46F1B8", VA = "0x46F1B8")]
	public void ResumeCooldown(int spellId)
	{
	}

	[Token(Token = "0x6000B3D")]
	[Address(RVA = "0x46EFB8", Offset = "0x46EFB8", VA = "0x46EFB8")]
	public void InterruptCooldown()
	{
	}

	[Token(Token = "0x6000B3E")]
	[Address(RVA = "0x46FB10", Offset = "0x46FB10", VA = "0x46FB10")]
	private IEnumerator _StartCooldown(CooldownInfo cooldownInfo)
	{
		return null;
	}

	[Token(Token = "0x6000B3F")]
	[Address(RVA = "0x46FB8C", Offset = "0x46FB8C", VA = "0x46FB8C")]
	private void OnCooldownCompleted()
	{
	}

	[Token(Token = "0x6000B40")]
	[Address(RVA = "0x46F9DC", Offset = "0x46F9DC", VA = "0x46F9DC")]
	private void OnCooldownFinished()
	{
	}

	[Token(Token = "0x6000B41")]
	[Address(RVA = "0x46F7AC", Offset = "0x46F7AC", VA = "0x46F7AC")]
	protected void UpdateFinishPosition(float RemainingTimePct)
	{
	}

	[Token(Token = "0x6000B42")]
	[Address(RVA = "0x46FC58", Offset = "0x46FC58", VA = "0x46FC58")]
	public UISlotCooldown()
	{
	}
}
