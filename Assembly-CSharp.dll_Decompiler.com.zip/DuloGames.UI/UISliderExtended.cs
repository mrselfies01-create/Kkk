using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E8")]
public class UISliderExtended : Slider
{
	[Token(Token = "0x2000277")]
	public enum TextEffectType
	{
		[Token(Token = "0x4000F8A")]
		None,
		[Token(Token = "0x4000F8B")]
		Shadow,
		[Token(Token = "0x4000F8C")]
		Outline
	}

	[Token(Token = "0x2000278")]
	public enum Transition
	{
		[Token(Token = "0x4000F8E")]
		None,
		[Token(Token = "0x4000F8F")]
		ColorTint
	}

	[Token(Token = "0x2000279")]
	public enum TransitionTarget
	{
		[Token(Token = "0x4000F91")]
		Image,
		[Token(Token = "0x4000F92")]
		Text
	}

	[Token(Token = "0x4000C9C")]
	[FieldOffset(Offset = "0x158")]
	private List<string> m_Options;

	[Token(Token = "0x4000C9D")]
	[FieldOffset(Offset = "0x160")]
	private List<GameObject> m_OptionGameObjects;

	[Token(Token = "0x4000C9E")]
	[FieldOffset(Offset = "0x168")]
	private GameObject m_OptionsContGameObject;

	[Token(Token = "0x4000C9F")]
	[FieldOffset(Offset = "0x170")]
	private RectTransform m_OptionsContRect;

	[Token(Token = "0x4000CA0")]
	[FieldOffset(Offset = "0x178")]
	private GridLayoutGroup m_OptionsContGrid;

	[Token(Token = "0x4000CA1")]
	[FieldOffset(Offset = "0x180")]
	private GameObject m_CurrentOptionGameObject;

	[Token(Token = "0x4000CA2")]
	[FieldOffset(Offset = "0x188")]
	private RectOffset m_OptionsPadding;

	[Token(Token = "0x4000CA3")]
	[FieldOffset(Offset = "0x190")]
	private Sprite m_OptionSprite;

	[Token(Token = "0x4000CA4")]
	[FieldOffset(Offset = "0x198")]
	private Font m_OptionTextFont;

	[Token(Token = "0x4000CA5")]
	[FieldOffset(Offset = "0x1A0")]
	private FontStyle m_OptionTextStyle;

	[Token(Token = "0x4000CA6")]
	[FieldOffset(Offset = "0x1A4")]
	private int m_OptionTextSize;

	[Token(Token = "0x4000CA7")]
	[FieldOffset(Offset = "0x1A8")]
	private Color m_OptionTextColor;

	[Token(Token = "0x4000CA8")]
	[FieldOffset(Offset = "0x1B8")]
	private TextEffectType m_OptionTextEffect;

	[Token(Token = "0x4000CA9")]
	[FieldOffset(Offset = "0x1BC")]
	private Color m_OptionTextEffectColor;

	[Token(Token = "0x4000CAA")]
	[FieldOffset(Offset = "0x1CC")]
	private Vector2 m_OptionTextEffectDistance;

	[Token(Token = "0x4000CAB")]
	[FieldOffset(Offset = "0x1D4")]
	private bool m_OptionTextEffectUseGraphicAlpha;

	[Token(Token = "0x4000CAC")]
	[FieldOffset(Offset = "0x1D8")]
	private Vector2 m_OptionTextOffset;

	[Token(Token = "0x4000CAD")]
	[FieldOffset(Offset = "0x1E0")]
	private Transition m_OptionTransition;

	[Token(Token = "0x4000CAE")]
	[FieldOffset(Offset = "0x1E4")]
	private TransitionTarget m_OptionTransitionTarget;

	[Token(Token = "0x4000CAF")]
	[FieldOffset(Offset = "0x1E8")]
	private Color m_OptionTransitionColorNormal;

	[Token(Token = "0x4000CB0")]
	[FieldOffset(Offset = "0x1F8")]
	private Color m_OptionTransitionColorActive;

	[Token(Token = "0x4000CB1")]
	[FieldOffset(Offset = "0x208")]
	private float m_OptionTransitionMultiplier;

	[Token(Token = "0x4000CB2")]
	[FieldOffset(Offset = "0x20C")]
	private float m_OptionTransitionDuration;

	[Token(Token = "0x17000224")]
	public List<string> options
	{
		[Token(Token = "0x6000C97")]
		[Address(RVA = "0x46A544", Offset = "0x46A544", VA = "0x46A544")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C98")]
		[Address(RVA = "0x46A54C", Offset = "0x46A54C", VA = "0x46A54C")]
		set
		{
		}
	}

	[Token(Token = "0x17000225")]
	public GameObject selectedOptionGameObject
	{
		[Token(Token = "0x6000C99")]
		[Address(RVA = "0x46ACC4", Offset = "0x46ACC4", VA = "0x46ACC4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x17000226")]
	public int selectedOptionIndex
	{
		[Token(Token = "0x6000C9A")]
		[Address(RVA = "0x46ACCC", Offset = "0x46ACCC", VA = "0x46ACCC")]
		get
		{
			return default(int);
		}
	}

	[Token(Token = "0x17000227")]
	public RectOffset optionsPadding
	{
		[Token(Token = "0x6000C9B")]
		[Address(RVA = "0x46AD7C", Offset = "0x46AD7C", VA = "0x46AD7C")]
		get
		{
			return null;
		}
		[Token(Token = "0x6000C9C")]
		[Address(RVA = "0x46AD84", Offset = "0x46AD84", VA = "0x46AD84")]
		set
		{
		}
	}

	[Token(Token = "0x6000C9D")]
	[Address(RVA = "0x46AD8C", Offset = "0x46AD8C", VA = "0x46AD8C")]
	public bool HasOptions()
	{
		return default(bool);
	}

	[Token(Token = "0x6000C9E")]
	[Address(RVA = "0x46ADE8", Offset = "0x46ADE8", VA = "0x46ADE8", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000C9F")]
	[Address(RVA = "0x46AEAC", Offset = "0x46AEAC", VA = "0x46AEAC", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000CA0")]
	[Address(RVA = "0x46AED4", Offset = "0x46AED4", VA = "0x46AED4", Slot = "10")]
	protected override void OnRectTransformDimensionsChange()
	{
	}

	[Token(Token = "0x6000CA1")]
	[Address(RVA = "0x46B170", Offset = "0x46B170", VA = "0x46B170")]
	public void OnValueChanged(float value)
	{
	}

	[Token(Token = "0x6000CA2")]
	[Address(RVA = "0x46B398", Offset = "0x46B398", VA = "0x46B398")]
	private void StartColorTween(Graphic target, Color targetColor, float duration)
	{
	}

	[Token(Token = "0x6000CA3")]
	[Address(RVA = "0x46AAE4", Offset = "0x46AAE4", VA = "0x46AAE4")]
	protected void ValidateOptions()
	{
	}

	[Token(Token = "0x6000CA4")]
	[Address(RVA = "0x46AF1C", Offset = "0x46AF1C", VA = "0x46AF1C")]
	public void UpdateGridProperties()
	{
	}

	[Token(Token = "0x6000CA5")]
	[Address(RVA = "0x46B758", Offset = "0x46B758", VA = "0x46B758")]
	public void UpdateOptionsProperties()
	{
	}

	[Token(Token = "0x6000CA6")]
	[Address(RVA = "0x46A574", Offset = "0x46A574", VA = "0x46A574")]
	protected void RebuildOptions()
	{
	}

	[Token(Token = "0x6000CA7")]
	[Address(RVA = "0x46BF80", Offset = "0x46BF80", VA = "0x46BF80")]
	private void AddTextEffect(GameObject gObject)
	{
	}

	[Token(Token = "0x6000CA8")]
	[Address(RVA = "0x46BC98", Offset = "0x46BC98", VA = "0x46BC98")]
	private void UpdateTextEffect(GameObject gObject)
	{
	}

	[Token(Token = "0x6000CA9")]
	[Address(RVA = "0x46C05C", Offset = "0x46C05C", VA = "0x46C05C")]
	public void RebuildTextEffects()
	{
	}

	[Token(Token = "0x6000CAA")]
	[Address(RVA = "0x46BE18", Offset = "0x46BE18", VA = "0x46BE18")]
	protected void DestroyOptions()
	{
	}

	[Token(Token = "0x6000CAB")]
	[Address(RVA = "0x46B4D8", Offset = "0x46B4D8", VA = "0x46B4D8")]
	protected void CreateOptionsContainer()
	{
	}

	[Token(Token = "0x6000CAC")]
	[Address(RVA = "0x46C3DC", Offset = "0x46C3DC", VA = "0x46C3DC")]
	public UISliderExtended()
	{
	}
}
