using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001CA")]
public static class UIUtility
{
	[Token(Token = "0x6000B75")]
	[Address(RVA = "0x474430", Offset = "0x474430", VA = "0x474430")]
	public static void BringToFront(GameObject go)
	{
	}

	[Token(Token = "0x6000B76")]
	public static T FindInParents<T>(GameObject go) where T : Component
	{
		return (T)null;
	}
}
