using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DB")]
public class UISelectField_Label : MonoBehaviour
{
	[Token(Token = "0x2000264")]
	public enum TransitionType
	{
		[Token(Token = "0x4000F65")]
		None,
		[Token(Token = "0x4000F66")]
		CrossFade
	}

	[Token(Token = "0x4000C40")]
	[FieldOffset(Offset = "0x18")]
	public Text textComponent;

	[Token(Token = "0x4000C41")]
	[FieldOffset(Offset = "0x20")]
	public TransitionType transitionType;

	[Token(Token = "0x4000C42")]
	[FieldOffset(Offset = "0x24")]
	public ColorBlockExtended colors;

	[Token(Token = "0x6000BEB")]
	[Address(RVA = "0x4690EC", Offset = "0x4690EC", VA = "0x4690EC")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000BEC")]
	[Address(RVA = "0x46917C", Offset = "0x46917C", VA = "0x46917C")]
	public void UpdateState(UISelectField.VisualState state)
	{
	}

	[Token(Token = "0x6000BED")]
	[Address(RVA = "0x469184", Offset = "0x469184", VA = "0x469184")]
	public void UpdateState(UISelectField.VisualState state, bool instant)
	{
	}

	[Token(Token = "0x6000BEE")]
	[Address(RVA = "0x46933C", Offset = "0x46933C", VA = "0x46933C")]
	private void StartColorTween(Color color, bool instant)
	{
	}

	[Token(Token = "0x6000BEF")]
	[Address(RVA = "0x46946C", Offset = "0x46946C", VA = "0x46946C")]
	private void TriggerAnimation(string trigger)
	{
	}

	[Token(Token = "0x6000BF0")]
	[Address(RVA = "0x46954C", Offset = "0x46954C", VA = "0x46954C")]
	public UISelectField_Label()
	{
	}
}
