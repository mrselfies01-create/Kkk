using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI.Tweens;

namespace DuloGames.UI;

[Token(Token = "0x20001CF")]
public class Test_FadeInOut : MonoBehaviour
{
	[Token(Token = "0x4000BE6")]
	[FieldOffset(Offset = "0x18")]
	private float m_Duration;

	[Token(Token = "0x4000BE7")]
	[FieldOffset(Offset = "0x1C")]
	private TweenEasing m_Easing;

	[Token(Token = "0x4000BE8")]
	[FieldOffset(Offset = "0x20")]
	private CanvasGroup m_Group;

	[NonSerialized]
	[Token(Token = "0x4000BE9")]
	[FieldOffset(Offset = "0x28")]
	private readonly TweenRunner<FloatTween> m_FloatTweenRunner;

	[Token(Token = "0x6000B92")]
	[Address(RVA = "0x3E008C", Offset = "0x3E008C", VA = "0x3E008C")]
	protected Test_FadeInOut()
	{
	}

	[Token(Token = "0x6000B93")]
	[Address(RVA = "0x3E0120", Offset = "0x3E0120", VA = "0x3E0120")]
	protected void OnEnable()
	{
	}

	[Token(Token = "0x6000B94")]
	[Address(RVA = "0x3E01E8", Offset = "0x3E01E8", VA = "0x3E01E8")]
	private void StartAlphaTween(float targetAlpha, float duration, bool ignoreTimeScale)
	{
	}

	[Token(Token = "0x6000B95")]
	[Address(RVA = "0x3E03AC", Offset = "0x3E03AC", VA = "0x3E03AC")]
	private void SetAlpha(float alpha)
	{
	}

	[Token(Token = "0x6000B96")]
	[Address(RVA = "0x3E0454", Offset = "0x3E0454", VA = "0x3E0454", Slot = "4")]
	protected virtual void OnTweenFinished()
	{
	}
}
