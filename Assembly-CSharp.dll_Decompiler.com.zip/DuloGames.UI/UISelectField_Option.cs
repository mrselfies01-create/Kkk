using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DD")]
public class UISelectField_Option : Toggle
{
	[Serializable]
	[Token(Token = "0x2000267")]
	public class SelectOptionEvent : UnityEvent<string>
	{
		[Token(Token = "0x6000DCF")]
		[Address(RVA = "0x78FDD4", Offset = "0x78FDD4", VA = "0x78FDD4")]
		public SelectOptionEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x2000268")]
	public class PointerUpEvent : UnityEvent<BaseEventData>
	{
		[Token(Token = "0x6000DD0")]
		[Address(RVA = "0x78FD84", Offset = "0x78FD84", VA = "0x78FD84")]
		public PointerUpEvent()
		{
		}
	}

	[Token(Token = "0x4000C48")]
	[FieldOffset(Offset = "0x118")]
	public UISelectField selectField;

	[Token(Token = "0x4000C49")]
	[FieldOffset(Offset = "0x120")]
	public Text textComponent;

	[Token(Token = "0x4000C4A")]
	[FieldOffset(Offset = "0x128")]
	private bool m_HasInitialized;

	[Token(Token = "0x4000C4B")]
	[FieldOffset(Offset = "0x130")]
	public SelectOptionEvent onSelectOption;

	[Token(Token = "0x4000C4C")]
	[FieldOffset(Offset = "0x138")]
	public PointerUpEvent onPointerUp;

	[Token(Token = "0x6000BF8")]
	[Address(RVA = "0x4698DC", Offset = "0x4698DC", VA = "0x4698DC", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000BF9")]
	[Address(RVA = "0x46993C", Offset = "0x46993C", VA = "0x46993C")]
	public void Initialize(UISelectField select, Text text)
	{
	}

	[Token(Token = "0x6000BFA")]
	[Address(RVA = "0x469954", Offset = "0x469954", VA = "0x469954", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000BFB")]
	[Address(RVA = "0x469A14", Offset = "0x469A14", VA = "0x469A14", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000BFC")]
	[Address(RVA = "0x469ABC", Offset = "0x469ABC", VA = "0x469ABC")]
	public bool IsPressed()
	{
		return default(bool);
	}

	[Token(Token = "0x6000BFD")]
	[Address(RVA = "0x469AC4", Offset = "0x469AC4", VA = "0x469AC4")]
	public bool IsHighlighted(BaseEventData eventData)
	{
		return default(bool);
	}

	[Token(Token = "0x6000BFE")]
	[Address(RVA = "0x469ACC", Offset = "0x469ACC", VA = "0x469ACC", Slot = "33")]
	public override void OnPointerUp(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000BFF")]
	[Address(RVA = "0x469B50", Offset = "0x469B50", VA = "0x469B50")]
	private void OnValueChanged(bool state)
	{
	}

	[Token(Token = "0x6000C00")]
	[Address(RVA = "0x469C44", Offset = "0x469C44", VA = "0x469C44", Slot = "26")]
	protected override void DoStateTransition(SelectionState state, bool instant)
	{
	}

	[Token(Token = "0x6000C01")]
	[Address(RVA = "0x46A314", Offset = "0x46A314", VA = "0x46A314")]
	private void DoTextStateTransition(SelectionState state, bool instant)
	{
	}

	[Token(Token = "0x6000C02")]
	[Address(RVA = "0x469E68", Offset = "0x469E68", VA = "0x469E68")]
	private void StartColorTween(Color color, float duration)
	{
	}

	[Token(Token = "0x6000C03")]
	[Address(RVA = "0x469F58", Offset = "0x469F58", VA = "0x469F58")]
	private void DoSpriteSwap(Sprite newSprite)
	{
	}

	[Token(Token = "0x6000C04")]
	[Address(RVA = "0x46A040", Offset = "0x46A040", VA = "0x46A040")]
	private void TriggerAnimation(string trigger)
	{
	}

	[Token(Token = "0x6000C05")]
	[Address(RVA = "0x46A4BC", Offset = "0x46A4BC", VA = "0x46A4BC")]
	public UISelectField_Option()
	{
	}
}
