using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E6")]
public class UIPagination : MonoBehaviour
{
	[Token(Token = "0x4000C8D")]
	[FieldOffset(Offset = "0x18")]
	private Transform m_PagesContainer;

	[Token(Token = "0x4000C8E")]
	[FieldOffset(Offset = "0x20")]
	private Button m_ButtonPrev;

	[Token(Token = "0x4000C8F")]
	[FieldOffset(Offset = "0x28")]
	private Button m_ButtonNext;

	[Token(Token = "0x4000C90")]
	[FieldOffset(Offset = "0x30")]
	private Text m_LabelText;

	[Token(Token = "0x4000C91")]
	[FieldOffset(Offset = "0x38")]
	private Color m_LabelActiveColor;

	[Token(Token = "0x4000C92")]
	[FieldOffset(Offset = "0x48")]
	private int activePage;

	[Token(Token = "0x6000C7E")]
	[Address(RVA = "0x3E9A20", Offset = "0x3E9A20", VA = "0x3E9A20")]
	private void Start()
	{
	}

	[Token(Token = "0x6000C7F")]
	[Address(RVA = "0x3E9C14", Offset = "0x3E9C14", VA = "0x3E9C14")]
	private void UpdatePagesVisibility()
	{
	}

	[Token(Token = "0x6000C80")]
	[Address(RVA = "0x3E9F44", Offset = "0x3E9F44", VA = "0x3E9F44")]
	private void OnPrevClick()
	{
	}

	[Token(Token = "0x6000C81")]
	[Address(RVA = "0x3EA000", Offset = "0x3EA000", VA = "0x3EA000")]
	private void OnNextClick()
	{
	}

	[Token(Token = "0x6000C82")]
	[Address(RVA = "0x3EA0D0", Offset = "0x3EA0D0", VA = "0x3EA0D0")]
	public UIPagination()
	{
	}
}
