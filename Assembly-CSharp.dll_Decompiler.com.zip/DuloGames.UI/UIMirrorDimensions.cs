using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001C7")]
public class UIMirrorDimensions : MonoBehaviour
{
	[Token(Token = "0x4000BD7")]
	[FieldOffset(Offset = "0x18")]
	private RectTransform m_Target;

	[Token(Token = "0x6000B6E")]
	[Address(RVA = "0x3E98DC", Offset = "0x3E98DC", VA = "0x3E98DC")]
	protected void OnRectTransformDimensionsChange()
	{
	}

	[Token(Token = "0x6000B6F")]
	[Address(RVA = "0x3E9A18", Offset = "0x3E9A18", VA = "0x3E9A18")]
	public UIMirrorDimensions()
	{
	}
}
