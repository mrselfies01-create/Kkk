using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace DuloGames.UI;

[Token(Token = "0x20001C2")]
public class UISpellSlot : UISlotBase
{
	[Serializable]
	[Token(Token = "0x200025A")]
	public class OnAssignEvent : UnityEvent<UISpellSlot>
	{
		[Token(Token = "0x6000DCA")]
		[Address(RVA = "0x790224", Offset = "0x790224", VA = "0x790224")]
		public OnAssignEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x200025B")]
	public class OnUnassignEvent : UnityEvent<UISpellSlot>
	{
		[Token(Token = "0x6000DCB")]
		[Address(RVA = "0x7902C4", Offset = "0x7902C4", VA = "0x7902C4")]
		public OnUnassignEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x200025C")]
	public class OnClickEvent : UnityEvent<UISpellSlot>
	{
		[Token(Token = "0x6000DCC")]
		[Address(RVA = "0x790274", Offset = "0x790274", VA = "0x790274")]
		public OnClickEvent()
		{
		}
	}

	[Token(Token = "0x4000BC6")]
	[FieldOffset(Offset = "0xF0")]
	private UISpellSlot_Group m_SlotGroup;

	[Token(Token = "0x4000BC7")]
	[FieldOffset(Offset = "0xF4")]
	private int m_ID;

	[Token(Token = "0x4000BC8")]
	[FieldOffset(Offset = "0xF8")]
	public OnAssignEvent onAssign;

	[Token(Token = "0x4000BC9")]
	[FieldOffset(Offset = "0x100")]
	public OnUnassignEvent onUnassign;

	[Token(Token = "0x4000BCA")]
	[FieldOffset(Offset = "0x108")]
	public OnClickEvent onClick;

	[Token(Token = "0x4000BCB")]
	[FieldOffset(Offset = "0x110")]
	private UISpellInfo m_SpellInfo;

	[Token(Token = "0x4000BCC")]
	[FieldOffset(Offset = "0x118")]
	private UISlotCooldown m_Cooldown;

	[Token(Token = "0x170001EF")]
	public UISpellSlot_Group slotGroup
	{
		[Token(Token = "0x6000B44")]
		[Address(RVA = "0x46FED8", Offset = "0x46FED8", VA = "0x46FED8")]
		get
		{
			return default(UISpellSlot_Group);
		}
		[Token(Token = "0x6000B45")]
		[Address(RVA = "0x46FEE0", Offset = "0x46FEE0", VA = "0x46FEE0")]
		set
		{
		}
	}

	[Token(Token = "0x170001F0")]
	public int ID
	{
		[Token(Token = "0x6000B46")]
		[Address(RVA = "0x46FEE8", Offset = "0x46FEE8", VA = "0x46FEE8")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000B47")]
		[Address(RVA = "0x46FEF0", Offset = "0x46FEF0", VA = "0x46FEF0")]
		set
		{
		}
	}

	[Token(Token = "0x6000B48")]
	[Address(RVA = "0x46FEF8", Offset = "0x46FEF8", VA = "0x46FEF8")]
	public UISpellInfo GetSpellInfo()
	{
		return null;
	}

	[Token(Token = "0x6000B49")]
	[Address(RVA = "0x46FF00", Offset = "0x46FF00", VA = "0x46FF00", Slot = "36")]
	public override bool IsAssigned()
	{
		return default(bool);
	}

	[Token(Token = "0x6000B4A")]
	[Address(RVA = "0x46FF10", Offset = "0x46FF10", VA = "0x46FF10")]
	public bool Assign(UISpellInfo spellInfo)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B4B")]
	[Address(RVA = "0x46FFAC", Offset = "0x46FFAC", VA = "0x46FFAC", Slot = "37")]
	public override bool Assign(Object source)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B4C")]
	[Address(RVA = "0x470080", Offset = "0x470080", VA = "0x470080", Slot = "38")]
	public override void Unassign()
	{
	}

	[Token(Token = "0x6000B4D")]
	[Address(RVA = "0x4700F0", Offset = "0x4700F0", VA = "0x4700F0", Slot = "44")]
	public override bool CanSwapWith(Object target)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B4E")]
	[Address(RVA = "0x470170", Offset = "0x470170", VA = "0x470170", Slot = "45")]
	public override bool PerformSlotSwap(Object sourceObject)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B4F")]
	[Address(RVA = "0x470220", Offset = "0x470220", VA = "0x470220", Slot = "31")]
	public override void OnPointerClick(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B50")]
	[Address(RVA = "0x4702FC", Offset = "0x4702FC", VA = "0x4702FC", Slot = "28")]
	public override void OnTooltip(bool show)
	{
	}

	[Token(Token = "0x6000B51")]
	[Address(RVA = "0x4707C8", Offset = "0x4707C8", VA = "0x4707C8")]
	public void AssignCooldownComponent(UISlotCooldown cooldown)
	{
	}

	[Token(Token = "0x6000B52")]
	[Address(RVA = "0x4703A4", Offset = "0x4703A4", VA = "0x4703A4")]
	public static void PrepareTooltip(UISpellInfo spellInfo)
	{
	}

	[Token(Token = "0x6000B53")]
	[Address(RVA = "0x470AEC", Offset = "0x470AEC", VA = "0x470AEC")]
	public static List<UISpellSlot> GetSlots()
	{
		return null;
	}

	[Token(Token = "0x6000B54")]
	[Address(RVA = "0x470BF4", Offset = "0x470BF4", VA = "0x470BF4")]
	public static List<UISpellSlot> GetSlotsWithID(int ID)
	{
		return null;
	}

	[Token(Token = "0x6000B55")]
	[Address(RVA = "0x470D0C", Offset = "0x470D0C", VA = "0x470D0C")]
	public static List<UISpellSlot> GetSlotsInGroup(UISpellSlot_Group group)
	{
		return null;
	}

	[Token(Token = "0x6000B56")]
	[Address(RVA = "0x470E24", Offset = "0x470E24", VA = "0x470E24")]
	public static UISpellSlot GetSlot(int ID, UISpellSlot_Group group)
	{
		return null;
	}

	[Token(Token = "0x6000B57")]
	[Address(RVA = "0x470F10", Offset = "0x470F10", VA = "0x470F10")]
	public UISpellSlot()
	{
	}
}
