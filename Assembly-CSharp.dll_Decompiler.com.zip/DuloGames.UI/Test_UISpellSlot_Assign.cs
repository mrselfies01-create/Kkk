using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001D5")]
public class Test_UISpellSlot_Assign : MonoBehaviour
{
	[Token(Token = "0x4000BFE")]
	[FieldOffset(Offset = "0x18")]
	public UISpellSlot slot;

	[Token(Token = "0x4000BFF")]
	[FieldOffset(Offset = "0x20")]
	public UISpellDatabase spellDatabase;

	[Token(Token = "0x4000C00")]
	[FieldOffset(Offset = "0x28")]
	public int assignSpell;

	[Token(Token = "0x6000BAB")]
	[Address(RVA = "0x3E16C0", Offset = "0x3E16C0", VA = "0x3E16C0")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000BAC")]
	[Address(RVA = "0x3E1750", Offset = "0x3E1750", VA = "0x3E1750")]
	private void Start()
	{
	}

	[Token(Token = "0x6000BAD")]
	[Address(RVA = "0x3E1834", Offset = "0x3E1834", VA = "0x3E1834")]
	private void Destruct()
	{
	}

	[Token(Token = "0x6000BAE")]
	[Address(RVA = "0x3E189C", Offset = "0x3E189C", VA = "0x3E189C")]
	public Test_UISpellSlot_Assign()
	{
	}
}
