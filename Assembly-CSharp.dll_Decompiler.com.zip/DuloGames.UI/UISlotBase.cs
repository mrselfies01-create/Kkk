using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Microsoft.Win32;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001C0")]
public class UISlotBase : UIBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer, IRegistryApi, ICloneable, IDisposable, IEnumerator<_00210>, IEnumerator, IEnumerable
{
	[Token(Token = "0x2000255")]
	public enum Transition
	{
		[Token(Token = "0x4000F36")]
		None,
		[Token(Token = "0x4000F37")]
		ColorTint,
		[Token(Token = "0x4000F38")]
		SpriteSwap,
		[Token(Token = "0x4000F39")]
		Animation
	}

	[Token(Token = "0x2000256")]
	public enum DragKeyModifier
	{
		[Token(Token = "0x4000F3B")]
		None,
		[Token(Token = "0x4000F3C")]
		Control,
		[Token(Token = "0x4000F3D")]
		Alt,
		[Token(Token = "0x4000F3E")]
		Shift
	}

	[Token(Token = "0x2000257")]
	private sealed class _003CTooltipDelayedShow_003Ed__104 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000F3F")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000F40")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000F41")]
		[FieldOffset(Offset = "0x20")]
		public UISlotBase _003C_003E4__this;

		[Token(Token = "0x17000270")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000DC0")]
			[Address(RVA = "0x78FF0C", Offset = "0x78FF0C", VA = "0x78FF0C", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000271")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000DC2")]
			[Address(RVA = "0x78FF74", Offset = "0x78FF74", VA = "0x78FF74", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000DBD")]
		[Address(RVA = "0x78FE24", Offset = "0x78FE24", VA = "0x78FE24")]
		public _003CTooltipDelayedShow_003Ed__104(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000DBE")]
		[Address(RVA = "0x78FE50", Offset = "0x78FE50", VA = "0x78FE50", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000DBF")]
		[Address(RVA = "0x78FE54", Offset = "0x78FE54", VA = "0x78FE54", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000DC1")]
		[Address(RVA = "0x78FF14", Offset = "0x78FF14", VA = "0x78FF14", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x4000B9C")]
	[FieldOffset(Offset = "0x18")]
	protected GameObject m_CurrentDraggedObject;

	[Token(Token = "0x4000B9D")]
	[FieldOffset(Offset = "0x20")]
	protected RectTransform m_CurrentDraggingPlane;

	[Token(Token = "0x4000B9E")]
	[FieldOffset(Offset = "0x28")]
	public Graphic iconGraphic;

	[Token(Token = "0x4000B9F")]
	[FieldOffset(Offset = "0x30")]
	private GameObject m_CloneTarget;

	[Token(Token = "0x4000BA0")]
	[FieldOffset(Offset = "0x38")]
	private bool m_DragAndDropEnabled;

	[Token(Token = "0x4000BA1")]
	[FieldOffset(Offset = "0x39")]
	private bool m_IsStatic;

	[Token(Token = "0x4000BA2")]
	[FieldOffset(Offset = "0x3A")]
	private bool m_AllowThrowAway;

	[Token(Token = "0x4000BA3")]
	[FieldOffset(Offset = "0x3C")]
	private DragKeyModifier m_DragKeyModifier;

	[Token(Token = "0x4000BA4")]
	[FieldOffset(Offset = "0x40")]
	private bool m_TooltipEnabled;

	[Token(Token = "0x4000BA5")]
	[FieldOffset(Offset = "0x44")]
	private float m_TooltipDelay;

	[Token(Token = "0x4000BA6")]
	[FieldOffset(Offset = "0x48")]
	public Transition hoverTransition;

	[Token(Token = "0x4000BA7")]
	[FieldOffset(Offset = "0x50")]
	public Graphic hoverTargetGraphic;

	[Token(Token = "0x4000BA8")]
	[FieldOffset(Offset = "0x58")]
	public Color hoverNormalColor;

	[Token(Token = "0x4000BA9")]
	[FieldOffset(Offset = "0x68")]
	public Color hoverHighlightColor;

	[Token(Token = "0x4000BAA")]
	[FieldOffset(Offset = "0x78")]
	public float hoverTransitionDuration;

	[Token(Token = "0x4000BAB")]
	[FieldOffset(Offset = "0x80")]
	public Sprite hoverOverrideSprite;

	[Token(Token = "0x4000BAC")]
	[FieldOffset(Offset = "0x88")]
	public string hoverNormalTrigger;

	[Token(Token = "0x4000BAD")]
	[FieldOffset(Offset = "0x90")]
	public string hoverHighlightTrigger;

	[Token(Token = "0x4000BAE")]
	[FieldOffset(Offset = "0x98")]
	public Transition pressTransition;

	[Token(Token = "0x4000BAF")]
	[FieldOffset(Offset = "0xA0")]
	public Graphic pressTargetGraphic;

	[Token(Token = "0x4000BB0")]
	[FieldOffset(Offset = "0xA8")]
	public Color pressNormalColor;

	[Token(Token = "0x4000BB1")]
	[FieldOffset(Offset = "0xB8")]
	public Color pressPressColor;

	[Token(Token = "0x4000BB2")]
	[FieldOffset(Offset = "0xC8")]
	public float pressTransitionDuration;

	[Token(Token = "0x4000BB3")]
	[FieldOffset(Offset = "0xD0")]
	public Sprite pressOverrideSprite;

	[Token(Token = "0x4000BB4")]
	[FieldOffset(Offset = "0xD8")]
	public string pressNormalTrigger;

	[Token(Token = "0x4000BB5")]
	[FieldOffset(Offset = "0xE0")]
	public string pressPressTrigger;

	[Token(Token = "0x4000BB6")]
	[FieldOffset(Offset = "0xE8")]
	private bool m_PressTransitionInstaOut;

	[Token(Token = "0x4000BB7")]
	[FieldOffset(Offset = "0xE9")]
	private bool m_PressForceHoverNormal;

	[Token(Token = "0x4000BB8")]
	[FieldOffset(Offset = "0xEA")]
	private bool isPointerDown;

	[Token(Token = "0x4000BB9")]
	[FieldOffset(Offset = "0xEB")]
	private bool isPointerInside;

	[Token(Token = "0x4000BBA")]
	[FieldOffset(Offset = "0xEC")]
	private bool m_DragHasBegan;

	[Token(Token = "0x4000BBB")]
	[FieldOffset(Offset = "0xED")]
	private bool m_DropPreformed;

	[Token(Token = "0x4000BBC")]
	[FieldOffset(Offset = "0xEE")]
	private bool m_IsTooltipShown;

	[Token(Token = "0x170001E5")]
	public bool dragAndDropEnabled
	{
		[Token(Token = "0x6000AF8")]
		[Address(RVA = "0x46C59C", Offset = "0x46C59C", VA = "0x46C59C")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000AF9")]
		[Address(RVA = "0x46C5A4", Offset = "0x46C5A4", VA = "0x46C5A4")]
		set
		{
		}
	}

	[Token(Token = "0x170001E6")]
	public bool isStatic
	{
		[Token(Token = "0x6000AFA")]
		[Address(RVA = "0x46C5B0", Offset = "0x46C5B0", VA = "0x46C5B0")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000AFB")]
		[Address(RVA = "0x46C5B8", Offset = "0x46C5B8", VA = "0x46C5B8")]
		set
		{
		}
	}

	[Token(Token = "0x170001E7")]
	public bool allowThrowAway
	{
		[Token(Token = "0x6000AFC")]
		[Address(RVA = "0x46C5C4", Offset = "0x46C5C4", VA = "0x46C5C4")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000AFD")]
		[Address(RVA = "0x46C5CC", Offset = "0x46C5CC", VA = "0x46C5CC")]
		set
		{
		}
	}

	[Token(Token = "0x170001E8")]
	public DragKeyModifier dragKeyModifier
	{
		[Token(Token = "0x6000AFE")]
		[Address(RVA = "0x46C5D8", Offset = "0x46C5D8", VA = "0x46C5D8")]
		get
		{
			return default(DragKeyModifier);
		}
		[Token(Token = "0x6000AFF")]
		[Address(RVA = "0x46C5E0", Offset = "0x46C5E0", VA = "0x46C5E0")]
		set
		{
		}
	}

	[Token(Token = "0x170001E9")]
	public bool tooltipEnabled
	{
		[Token(Token = "0x6000B00")]
		[Address(RVA = "0x46C5E8", Offset = "0x46C5E8", VA = "0x46C5E8")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B01")]
		[Address(RVA = "0x46C5F0", Offset = "0x46C5F0", VA = "0x46C5F0")]
		set
		{
		}
	}

	[Token(Token = "0x170001EA")]
	public float tooltipDelay
	{
		[Token(Token = "0x6000B02")]
		[Address(RVA = "0x46C5FC", Offset = "0x46C5FC", VA = "0x46C5FC")]
		get
		{
			return default(float);
		}
		[Token(Token = "0x6000B03")]
		[Address(RVA = "0x46C604", Offset = "0x46C604", VA = "0x46C604")]
		set
		{
		}
	}

	[Token(Token = "0x170001EB")]
	public bool pressTransitionInstaOut
	{
		[Token(Token = "0x6000B04")]
		[Address(RVA = "0x46C60C", Offset = "0x46C60C", VA = "0x46C60C")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B05")]
		[Address(RVA = "0x46C614", Offset = "0x46C614", VA = "0x46C614")]
		set
		{
		}
	}

	[Token(Token = "0x170001EC")]
	public bool pressForceHoverNormal
	{
		[Token(Token = "0x6000B06")]
		[Address(RVA = "0x46C620", Offset = "0x46C620", VA = "0x46C620")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B07")]
		[Address(RVA = "0x46C628", Offset = "0x46C628", VA = "0x46C628")]
		set
		{
		}
	}

	[Token(Token = "0x170001ED")]
	public bool dropPreformed
	{
		[Token(Token = "0x6000B08")]
		[Address(RVA = "0x46C634", Offset = "0x46C634", VA = "0x46C634")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000B09")]
		[Address(RVA = "0x46C63C", Offset = "0x46C63C", VA = "0x46C63C")]
		set
		{
		}
	}

	[Token(Token = "0x6000B0A")]
	[Address(RVA = "0x46C648", Offset = "0x46C648", VA = "0x46C648", Slot = "6")]
	protected override void Start()
	{
	}

	[Token(Token = "0x6000B0B")]
	[Address(RVA = "0x46C724", Offset = "0x46C724", VA = "0x46C724", Slot = "5")]
	protected override void OnEnable()
	{
	}

	[Token(Token = "0x6000B0C")]
	[Address(RVA = "0x46C774", Offset = "0x46C774", VA = "0x46C774", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000B0D")]
	[Address(RVA = "0x46C7C8", Offset = "0x46C7C8", VA = "0x46C7C8", Slot = "26")]
	public virtual void OnPointerEnter(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B0E")]
	[Address(RVA = "0x46C8D8", Offset = "0x46C8D8", VA = "0x46C8D8", Slot = "27")]
	public virtual void OnPointerExit(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B0F")]
	[Address(RVA = "0x46C994", Offset = "0x46C994", VA = "0x46C994", Slot = "28")]
	public virtual void OnTooltip(bool show)
	{
	}

	[Token(Token = "0x6000B10")]
	[Address(RVA = "0x46C998", Offset = "0x46C998", VA = "0x46C998", Slot = "29")]
	public virtual void OnPointerDown(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B11")]
	[Address(RVA = "0x46C9D4", Offset = "0x46C9D4", VA = "0x46C9D4", Slot = "30")]
	public virtual void OnPointerUp(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B12")]
	[Address(RVA = "0x46C9EC", Offset = "0x46C9EC", VA = "0x46C9EC", Slot = "31")]
	public virtual void OnPointerClick(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B13")]
	[Address(RVA = "0x46C9F0", Offset = "0x46C9F0", VA = "0x46C9F0")]
	protected bool IsHighlighted(BaseEventData eventData)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B14")]
	[Address(RVA = "0x46CB9C", Offset = "0x46CB9C", VA = "0x46CB9C")]
	protected bool IsPressed(BaseEventData eventData)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B15")]
	[Address(RVA = "0x46CBE4", Offset = "0x46CBE4", VA = "0x46CBE4", Slot = "32")]
	protected virtual void EvaluateAndTransitionHoveredState(bool instant)
	{
	}

	[Token(Token = "0x6000B16")]
	[Address(RVA = "0x46CF40", Offset = "0x46CF40", VA = "0x46CF40", Slot = "33")]
	protected virtual void EvaluateAndTransitionPressedState(bool instant)
	{
	}

	[Token(Token = "0x6000B17")]
	[Address(RVA = "0x46D298", Offset = "0x46D298", VA = "0x46D298", Slot = "34")]
	protected virtual void StartColorTween(Graphic target, Color targetColor, float duration)
	{
	}

	[Token(Token = "0x6000B18")]
	[Address(RVA = "0x46D384", Offset = "0x46D384", VA = "0x46D384", Slot = "35")]
	protected virtual void DoSpriteSwap(Graphic target, Sprite newSprite)
	{
	}

	[Token(Token = "0x6000B19")]
	[Address(RVA = "0x46CDB0", Offset = "0x46CDB0", VA = "0x46CDB0")]
	private void TriggerHoverStateAnimation(string triggername)
	{
	}

	[Token(Token = "0x6000B1A")]
	[Address(RVA = "0x46D0F8", Offset = "0x46D0F8", VA = "0x46D0F8")]
	private void TriggerPressStateAnimation(string triggername)
	{
	}

	[Token(Token = "0x6000B1B")]
	[Address(RVA = "0x46D494", Offset = "0x46D494", VA = "0x46D494", Slot = "36")]
	public virtual bool IsAssigned()
	{
		return default(bool);
	}

	[Token(Token = "0x6000B1C")]
	[Address(RVA = "0x46D6F8", Offset = "0x46D6F8", VA = "0x46D6F8")]
	public bool Assign(Sprite icon)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B1D")]
	[Address(RVA = "0x46D944", Offset = "0x46D944", VA = "0x46D944")]
	public bool Assign(Texture icon)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B1E")]
	[Address(RVA = "0x46DB90", Offset = "0x46DB90", VA = "0x46DB90", Slot = "37")]
	public virtual bool Assign(Object source)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B1F")]
	[Address(RVA = "0x46DD04", Offset = "0x46DD04", VA = "0x46DD04", Slot = "38")]
	public virtual void Unassign()
	{
	}

	[Token(Token = "0x6000B20")]
	[Address(RVA = "0x46D568", Offset = "0x46D568", VA = "0x46D568")]
	public Sprite GetIconSprite()
	{
		return null;
	}

	[Token(Token = "0x6000B21")]
	[Address(RVA = "0x46D630", Offset = "0x46D630", VA = "0x46D630")]
	public Texture GetIconTexture()
	{
		return null;
	}

	[Token(Token = "0x6000B22")]
	[Address(RVA = "0x46DE3C", Offset = "0x46DE3C", VA = "0x46DE3C")]
	public Object GetIconAsObject()
	{
		return null;
	}

	[Token(Token = "0x6000B23")]
	[Address(RVA = "0x46D790", Offset = "0x46D790", VA = "0x46D790")]
	public void SetIcon(Sprite iconSprite)
	{
	}

	[Token(Token = "0x6000B24")]
	[Address(RVA = "0x46D9DC", Offset = "0x46D9DC", VA = "0x46D9DC")]
	public void SetIcon(Texture iconTex)
	{
	}

	[Token(Token = "0x6000B25")]
	[Address(RVA = "0x46DD08", Offset = "0x46DD08", VA = "0x46DD08")]
	public void ClearIcon()
	{
	}

	[Token(Token = "0x6000B26")]
	[Address(RVA = "0x46DF40", Offset = "0x46DF40", VA = "0x46DF40", Slot = "39")]
	public virtual void OnBeginDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B27")]
	[Address(RVA = "0x46DFE8", Offset = "0x46DFE8", VA = "0x46DFE8", Slot = "40")]
	public virtual bool DragKeyModifierIsDown()
	{
		return default(bool);
	}

	[Token(Token = "0x6000B28")]
	[Address(RVA = "0x46E068", Offset = "0x46E068", VA = "0x46E068", Slot = "41")]
	public virtual void OnDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B29")]
	[Address(RVA = "0x46E224", Offset = "0x46E224", VA = "0x46E224", Slot = "42")]
	public virtual void OnDrop(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B2A")]
	[Address(RVA = "0x46E434", Offset = "0x46E434", VA = "0x46E434", Slot = "43")]
	public virtual void OnEndDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B2B")]
	[Address(RVA = "0x46E53C", Offset = "0x46E53C", VA = "0x46E53C", Slot = "44")]
	public virtual bool CanSwapWith(Object target)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B2C")]
	[Address(RVA = "0x46E5BC", Offset = "0x46E5BC", VA = "0x46E5BC", Slot = "45")]
	public virtual bool PerformSlotSwap(Object targetObject)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B2D")]
	[Address(RVA = "0x46E68C", Offset = "0x46E68C", VA = "0x46E68C", Slot = "46")]
	protected virtual void OnAssignBySlotFailed(Object source)
	{
	}

	[Token(Token = "0x6000B2E")]
	[Address(RVA = "0x46E8A4", Offset = "0x46E8A4", VA = "0x46E8A4", Slot = "47")]
	protected virtual void OnThrowAway()
	{
	}

	[Token(Token = "0x6000B2F")]
	[Address(RVA = "0x46E8C8", Offset = "0x46E8C8", VA = "0x46E8C8", Slot = "48")]
	protected virtual void OnThrowAwayDenied()
	{
	}

	[Token(Token = "0x6000B30")]
	[Address(RVA = "0x46E8CC", Offset = "0x46E8CC", VA = "0x46E8CC", Slot = "49")]
	protected virtual void CreateTemporaryIcon(PointerEventData eventData)
	{
	}

	[Token(Token = "0x6000B31")]
	[Address(RVA = "0x46E10C", Offset = "0x46E10C", VA = "0x46E10C")]
	private void UpdateDraggedPosition(PointerEventData data)
	{
	}

	[Token(Token = "0x6000B32")]
	[Address(RVA = "0x46C8B0", Offset = "0x46C8B0", VA = "0x46C8B0")]
	protected void InternalShowTooltip()
	{
	}

	[Token(Token = "0x6000B33")]
	[Address(RVA = "0x46C910", Offset = "0x46C910", VA = "0x46C910")]
	protected void InternalHideTooltip()
	{
	}

	[Token(Token = "0x6000B34")]
	[Address(RVA = "0x46EB0C", Offset = "0x46EB0C", VA = "0x46EB0C")]
	protected IEnumerator TooltipDelayedShow()
	{
		return null;
	}

	[Token(Token = "0x6000B35")]
	[Address(RVA = "0x46EB7C", Offset = "0x46EB7C", VA = "0x46EB7C")]
	public UISlotBase()
	{
	}
}
