using System;
using Il2CppDummyDll;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B9")]
public class UITalentInfo
{
	[Token(Token = "0x4000B83")]
	[FieldOffset(Offset = "0x10")]
	public int ID;

	[Token(Token = "0x4000B84")]
	[FieldOffset(Offset = "0x14")]
	public int spellEntry;

	[Token(Token = "0x4000B85")]
	[FieldOffset(Offset = "0x18")]
	public int maxPoints;

	[Token(Token = "0x6000AC1")]
	[Address(RVA = "0x472154", Offset = "0x472154", VA = "0x472154")]
	public UITalentInfo()
	{
	}
}
