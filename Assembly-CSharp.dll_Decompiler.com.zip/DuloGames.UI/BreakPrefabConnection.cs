using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001C4")]
public class BreakPrefabConnection : MonoBehaviour
{
	[Token(Token = "0x6000B67")]
	[Address(RVA = "0x5B1A80", Offset = "0x5B1A80", VA = "0x5B1A80")]
	private void Start()
	{
	}

	[Token(Token = "0x6000B68")]
	[Address(RVA = "0x5B1AE8", Offset = "0x5B1AE8", VA = "0x5B1AE8")]
	public BreakPrefabConnection()
	{
	}
}
