using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001CD")]
public class UIMaskRaycastFilter : MonoBehaviour, IDisposable
{
	[Token(Token = "0x4000BDF")]
	[FieldOffset(Offset = "0x18")]
	private Image m_Image;

	[Token(Token = "0x4000BE0")]
	[FieldOffset(Offset = "0x20")]
	private Sprite m_Sprite;

	[Token(Token = "0x4000BE1")]
	[FieldOffset(Offset = "0x28")]
	private float m_AlphaTreshold;

	[Token(Token = "0x6000B84")]
	[Address(RVA = "0x3E91C0", Offset = "0x3E91C0", VA = "0x3E91C0")]
	protected void Awake()
	{
	}

	[Token(Token = "0x6000B85")]
	[Address(RVA = "0x3E9270", Offset = "0x3E9270", VA = "0x3E9270", Slot = "4")]
	public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera)
	{
		return default(bool);
	}

	[Token(Token = "0x6000B86")]
	[Address(RVA = "0x3E98C8", Offset = "0x3E98C8", VA = "0x3E98C8")]
	public UIMaskRaycastFilter()
	{
	}
}
