using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001A6")]
public class UITalentDatabase : ScriptableObject
{
	[Token(Token = "0x4000B2B")]
	[FieldOffset(Offset = "0x18")]
	public UITalentInfo[] talents;

	[Token(Token = "0x6000A5C")]
	[Address(RVA = "0x4720A8", Offset = "0x4720A8", VA = "0x4720A8")]
	public UITalentInfo Get(int index)
	{
		return null;
	}

	[Token(Token = "0x6000A5D")]
	[Address(RVA = "0x4720E4", Offset = "0x4720E4", VA = "0x4720E4")]
	public UITalentInfo GetByID(int ID)
	{
		return null;
	}

	[Token(Token = "0x6000A5E")]
	[Address(RVA = "0x47214C", Offset = "0x47214C", VA = "0x47214C")]
	public UITalentDatabase()
	{
	}
}
