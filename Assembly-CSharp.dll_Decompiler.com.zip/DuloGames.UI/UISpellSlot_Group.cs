using System;
using Il2CppDummyDll;

namespace DuloGames.UI;

[Serializable]
[Token(Token = "0x20001B8")]
public enum UISpellSlot_Group
{
	[Token(Token = "0x4000B80")]
	None,
	[Token(Token = "0x4000B81")]
	ActionBar_Main,
	[Token(Token = "0x4000B82")]
	ActionBar_Extra
}
