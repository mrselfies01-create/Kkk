using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001BF")]
public class UIItemSlotOverlay : MonoBehaviour
{
	[Token(Token = "0x4000B9A")]
	[FieldOffset(Offset = "0x18")]
	private UIItemSlot m_Slot;

	[Token(Token = "0x4000B9B")]
	[FieldOffset(Offset = "0x20")]
	private Image m_Target;

	[Token(Token = "0x6000AF4")]
	[Address(RVA = "0x3E7C68", Offset = "0x3E7C68", VA = "0x3E7C68")]
	protected void Start()
	{
	}

	[Token(Token = "0x6000AF5")]
	[Address(RVA = "0x3E7E94", Offset = "0x3E7E94", VA = "0x3E7E94")]
	private void OnAssign(UIItemSlot slot)
	{
	}

	[Token(Token = "0x6000AF6")]
	[Address(RVA = "0x3E7F2C", Offset = "0x3E7F2C", VA = "0x3E7F2C")]
	private void OnUnassign(UIItemSlot slot)
	{
	}

	[Token(Token = "0x6000AF7")]
	[Address(RVA = "0x3E7FC4", Offset = "0x3E7FC4", VA = "0x3E7FC4")]
	public UIItemSlotOverlay()
	{
	}
}
