using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001D1")]
public class Test_UIEquipSlot_Assign : MonoBehaviour
{
	[Token(Token = "0x4000BEE")]
	[FieldOffset(Offset = "0x18")]
	public UIEquipSlot slot;

	[Token(Token = "0x4000BEF")]
	[FieldOffset(Offset = "0x20")]
	public UIItemDatabase itemDatabase;

	[Token(Token = "0x4000BF0")]
	[FieldOffset(Offset = "0x28")]
	public int assignItem;

	[Token(Token = "0x6000B9C")]
	[Address(RVA = "0x3E0948", Offset = "0x3E0948", VA = "0x3E0948")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000B9D")]
	[Address(RVA = "0x3E09D8", Offset = "0x3E09D8", VA = "0x3E09D8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000B9E")]
	[Address(RVA = "0x3E0AB4", Offset = "0x3E0AB4", VA = "0x3E0AB4")]
	private void Destruct()
	{
	}

	[Token(Token = "0x6000B9F")]
	[Address(RVA = "0x3E0C40", Offset = "0x3E0C40", VA = "0x3E0C40")]
	public Test_UIEquipSlot_Assign()
	{
	}
}
