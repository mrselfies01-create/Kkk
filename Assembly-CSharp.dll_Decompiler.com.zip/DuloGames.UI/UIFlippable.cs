using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001E2")]
public class UIFlippable : MonoBehaviour, IDisposable
{
	[Token(Token = "0x4000C69")]
	[FieldOffset(Offset = "0x18")]
	private bool m_Horizontal;

	[Token(Token = "0x4000C6A")]
	[FieldOffset(Offset = "0x19")]
	private bool m_Veritical;

	[Token(Token = "0x17000210")]
	public bool horizontal
	{
		[Token(Token = "0x6000C44")]
		[Address(RVA = "0x3E6440", Offset = "0x3E6440", VA = "0x3E6440")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C45")]
		[Address(RVA = "0x3E6448", Offset = "0x3E6448", VA = "0x3E6448")]
		set
		{
		}
	}

	[Token(Token = "0x17000211")]
	public bool vertical
	{
		[Token(Token = "0x6000C46")]
		[Address(RVA = "0x3E6454", Offset = "0x3E6454", VA = "0x3E6454")]
		get
		{
			return default(bool);
		}
		[Token(Token = "0x6000C47")]
		[Address(RVA = "0x3E645C", Offset = "0x3E645C", VA = "0x3E645C")]
		set
		{
		}
	}

	[Token(Token = "0x6000C48")]
	[Address(RVA = "0x3E6468", Offset = "0x3E6468", VA = "0x3E6468", Slot = "5")]
	public void ModifyMesh(VertexHelper vertexHelper)
	{
	}

	[Token(Token = "0x6000C49")]
	[Address(RVA = "0x3E6708", Offset = "0x3E6708", VA = "0x3E6708", Slot = "4")]
	public void ModifyMesh(Mesh mesh)
	{
	}

	[Token(Token = "0x6000C4A")]
	[Address(RVA = "0x3E6534", Offset = "0x3E6534", VA = "0x3E6534")]
	public void ModifyVertices(List<UIVertex> verts)
	{
	}

	[Token(Token = "0x6000C4B")]
	[Address(RVA = "0x3E69A4", Offset = "0x3E69A4", VA = "0x3E69A4")]
	public UIFlippable()
	{
	}
}
