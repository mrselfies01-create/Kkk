using Il2CppDummyDll;
using UnityEngine;

namespace DuloGames.UI;

[Token(Token = "0x20001D6")]
public class Test_UITalentSlot_Assign : MonoBehaviour
{
	[Token(Token = "0x4000C01")]
	[FieldOffset(Offset = "0x18")]
	public UITalentSlot slot;

	[Token(Token = "0x4000C02")]
	[FieldOffset(Offset = "0x20")]
	public UITalentDatabase talentDatabase;

	[Token(Token = "0x4000C03")]
	[FieldOffset(Offset = "0x28")]
	public UISpellDatabase spellDatabase;

	[Token(Token = "0x4000C04")]
	[FieldOffset(Offset = "0x30")]
	public int assignTalent;

	[Token(Token = "0x4000C05")]
	[FieldOffset(Offset = "0x34")]
	public int addPoints;

	[Token(Token = "0x6000BAF")]
	[Address(RVA = "0x3E18A4", Offset = "0x3E18A4", VA = "0x3E18A4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000BB0")]
	[Address(RVA = "0x3E1A3C", Offset = "0x3E1A3C", VA = "0x3E1A3C")]
	private void Destruct()
	{
	}

	[Token(Token = "0x6000BB1")]
	[Address(RVA = "0x3E1AA4", Offset = "0x3E1AA4", VA = "0x3E1AA4")]
	public Test_UITalentSlot_Assign()
	{
	}
}
