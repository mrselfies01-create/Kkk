using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;

namespace DuloGames.UI;

[Token(Token = "0x20001BD")]
public class UIEquipSlot : UISlotBase
{
	[Serializable]
	[Token(Token = "0x2000251")]
	public class OnAssignEvent : UnityEvent<UIEquipSlot>
	{
		[Token(Token = "0x6000DB9")]
		[Address(RVA = "0x78FB04", Offset = "0x78FB04", VA = "0x78FB04")]
		public OnAssignEvent()
		{
		}
	}

	[Serializable]
	[Token(Token = "0x2000252")]
	public class OnUnassignEvent : UnityEvent<UIEquipSlot>
	{
		[Token(Token = "0x6000DBA")]
		[Address(RVA = "0x78FB54", Offset = "0x78FB54", VA = "0x78FB54")]
		public OnUnassignEvent()
		{
		}
	}

	[Token(Token = "0x4000B91")]
	[FieldOffset(Offset = "0xF0")]
	private UIEquipmentType m_EquipType;

	[Token(Token = "0x4000B92")]
	[FieldOffset(Offset = "0xF8")]
	private UIItemInfo m_ItemInfo;

	[Token(Token = "0x4000B93")]
	[FieldOffset(Offset = "0x100")]
	public OnAssignEvent onAssign;

	[Token(Token = "0x4000B94")]
	[FieldOffset(Offset = "0x108")]
	public OnUnassignEvent onUnassign;

	[Token(Token = "0x170001E2")]
	public UIEquipmentType equipType
	{
		[Token(Token = "0x6000AD2")]
		[Address(RVA = "0x3E597C", Offset = "0x3E597C", VA = "0x3E597C")]
		get
		{
			return default(UIEquipmentType);
		}
		[Token(Token = "0x6000AD3")]
		[Address(RVA = "0x3E5984", Offset = "0x3E5984", VA = "0x3E5984")]
		set
		{
		}
	}

	[Token(Token = "0x6000AD4")]
	[Address(RVA = "0x3E598C", Offset = "0x3E598C", VA = "0x3E598C")]
	public UIItemInfo GetItemInfo()
	{
		return null;
	}

	[Token(Token = "0x6000AD5")]
	[Address(RVA = "0x3E5994", Offset = "0x3E5994", VA = "0x3E5994", Slot = "36")]
	public override bool IsAssigned()
	{
		return default(bool);
	}

	[Token(Token = "0x6000AD6")]
	[Address(RVA = "0x3E0B84", Offset = "0x3E0B84", VA = "0x3E0B84")]
	public bool Assign(UIItemInfo itemInfo)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AD7")]
	[Address(RVA = "0x3E59A4", Offset = "0x3E59A4", VA = "0x3E59A4", Slot = "37")]
	public override bool Assign(Object source)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AD8")]
	[Address(RVA = "0x3E5A8C", Offset = "0x3E5A8C", VA = "0x3E5A8C", Slot = "50")]
	public virtual bool CheckEquipType(UIItemInfo info)
	{
		return default(bool);
	}

	[Token(Token = "0x6000AD9")]
	[Address(RVA = "0x3E5AB0", Offset = "0x3E5AB0", VA = "0x3E5AB0", Slot = "38")]
	public override void Unassign()
	{
	}

	[Token(Token = "0x6000ADA")]
	[Address(RVA = "0x3E5B24", Offset = "0x3E5B24", VA = "0x3E5B24", Slot = "44")]
	public override bool CanSwapWith(Object target)
	{
		return default(bool);
	}

	[Token(Token = "0x6000ADB")]
	[Address(RVA = "0x3E5C28", Offset = "0x3E5C28", VA = "0x3E5C28", Slot = "45")]
	public override bool PerformSlotSwap(Object sourceObject)
	{
		return default(bool);
	}

	[Token(Token = "0x6000ADC")]
	[Address(RVA = "0x3E5D1C", Offset = "0x3E5D1C", VA = "0x3E5D1C", Slot = "28")]
	public override void OnTooltip(bool show)
	{
	}

	[Token(Token = "0x6000ADD")]
	[Address(RVA = "0x3E5E0C", Offset = "0x3E5E0C", VA = "0x3E5E0C")]
	public static string EquipTypeToString(UIEquipmentType type)
	{
		return null;
	}

	[Token(Token = "0x6000ADE")]
	[Address(RVA = "0x3E60C4", Offset = "0x3E60C4", VA = "0x3E60C4")]
	public static List<UIEquipSlot> GetSlots()
	{
		return null;
	}

	[Token(Token = "0x6000ADF")]
	[Address(RVA = "0x3E61CC", Offset = "0x3E61CC", VA = "0x3E61CC")]
	public static UIEquipSlot GetSlotWithType(UIEquipmentType type)
	{
		return null;
	}

	[Token(Token = "0x6000AE0")]
	[Address(RVA = "0x3E62A0", Offset = "0x3E62A0", VA = "0x3E62A0")]
	public static List<UIEquipSlot> GetSlotsWithType(UIEquipmentType type)
	{
		return null;
	}

	[Token(Token = "0x6000AE1")]
	[Address(RVA = "0x3E63B8", Offset = "0x3E63B8", VA = "0x3E63B8")]
	public UIEquipSlot()
	{
	}
}
