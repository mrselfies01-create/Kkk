using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001AB")]
public class UIUnitFrame_Bar : MonoBehaviour
{
	[Token(Token = "0x4000B2E")]
	[FieldOffset(Offset = "0x18")]
	private RectTransform m_TargetTransform;

	[Token(Token = "0x4000B2F")]
	[FieldOffset(Offset = "0x20")]
	private int m_MaxValue;

	[Token(Token = "0x4000B30")]
	[FieldOffset(Offset = "0x24")]
	private int m_CurValue;

	[Token(Token = "0x4000B31")]
	[FieldOffset(Offset = "0x28")]
	private float m_MinWidth;

	[Token(Token = "0x4000B32")]
	[FieldOffset(Offset = "0x2C")]
	private float m_MaxWidth;

	[Token(Token = "0x4000B33")]
	[FieldOffset(Offset = "0x30")]
	private Text m_CurValueText;

	[Token(Token = "0x4000B34")]
	[FieldOffset(Offset = "0x38")]
	private Text m_MaxValueText;

	[Token(Token = "0x4000B35")]
	[FieldOffset(Offset = "0x40")]
	private bool m_TextInPct;

	[Token(Token = "0x4000B36")]
	[FieldOffset(Offset = "0x48")]
	private UnityEvent m_OnChange;

	[Token(Token = "0x170001BD")]
	public int maxValue
	{
		[Token(Token = "0x6000A67")]
		[Address(RVA = "0x476324", Offset = "0x476324", VA = "0x476324")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000A68")]
		[Address(RVA = "0x47632C", Offset = "0x47632C", VA = "0x47632C")]
		set
		{
		}
	}

	[Token(Token = "0x170001BE")]
	public int value
	{
		[Token(Token = "0x6000A69")]
		[Address(RVA = "0x476420", Offset = "0x476420", VA = "0x476420")]
		get
		{
			return default(int);
		}
		[Token(Token = "0x6000A6A")]
		[Address(RVA = "0x476428", Offset = "0x476428", VA = "0x476428")]
		set
		{
		}
	}

	[Token(Token = "0x6000A6B")]
	[Address(RVA = "0x476330", Offset = "0x476330", VA = "0x476330")]
	public void SetMaxValue(int value)
	{
	}

	[Token(Token = "0x6000A6C")]
	[Address(RVA = "0x47642C", Offset = "0x47642C", VA = "0x47642C")]
	public void SetValue(int value)
	{
	}

	[Token(Token = "0x6000A6D")]
	[Address(RVA = "0x4765E4", Offset = "0x4765E4", VA = "0x4765E4")]
	public void UpdateText()
	{
	}

	[Token(Token = "0x6000A6E")]
	[Address(RVA = "0x476478", Offset = "0x476478", VA = "0x476478")]
	public void UpdateBarFill()
	{
	}

	[Token(Token = "0x6000A6F")]
	[Address(RVA = "0x47670C", Offset = "0x47670C", VA = "0x47670C")]
	public UIUnitFrame_Bar()
	{
	}
}
