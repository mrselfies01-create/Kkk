using System;
using Il2CppDummyDll;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DuloGames.UI;

[Token(Token = "0x20001DF")]
public class UIButtonExtended : Button
{
	[Token(Token = "0x2000269")]
	public enum VisualState
	{
		[Token(Token = "0x4000F6B")]
		Normal,
		[Token(Token = "0x4000F6C")]
		Highlighted,
		[Token(Token = "0x4000F6D")]
		Pressed,
		[Token(Token = "0x4000F6E")]
		Disabled
	}

	[Serializable]
	[Token(Token = "0x200026A")]
	public class StateChangeEvent : UnityEvent<VisualState, bool>
	{
		[Token(Token = "0x6000DD1")]
		[Address(RVA = "0x78F994", Offset = "0x78F994", VA = "0x78F994")]
		public StateChangeEvent()
		{
		}
	}

	[Token(Token = "0x4000C50")]
	[FieldOffset(Offset = "0xF8")]
	public StateChangeEvent onStateChange;

	[Token(Token = "0x6000C10")]
	[Address(RVA = "0x3E308C", Offset = "0x3E308C", VA = "0x3E308C", Slot = "7")]
	protected override void OnDisable()
	{
	}

	[Token(Token = "0x6000C11")]
	[Address(RVA = "0x3E3100", Offset = "0x3E3100", VA = "0x3E3100", Slot = "26")]
	protected override void DoStateTransition(SelectionState state, bool instant)
	{
	}

	[Token(Token = "0x6000C12")]
	[Address(RVA = "0x3E3194", Offset = "0x3E3194", VA = "0x3E3194")]
	public UIButtonExtended()
	{
	}
}
