using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000118")]
public class CameraFilterPack_TV_VHS_Rewind : MonoBehaviour
{
	[Token(Token = "0x40007F7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007F8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007F9")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007FA")]
	[FieldOffset(Offset = "0x30")]
	public float Cryptage;

	[Token(Token = "0x40007FB")]
	[FieldOffset(Offset = "0x34")]
	public float Parasite;

	[Token(Token = "0x40007FC")]
	[FieldOffset(Offset = "0x38")]
	public float Parasite2;

	[Token(Token = "0x40007FD")]
	[FieldOffset(Offset = "0x3C")]
	private float WhiteParasite;

	[Token(Token = "0x17000119")]
	private Material material
	{
		[Token(Token = "0x60006E7")]
		[Address(RVA = "0x63A344", Offset = "0x63A344", VA = "0x63A344")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006E8")]
	[Address(RVA = "0x63A408", Offset = "0x63A408", VA = "0x63A408")]
	private void Start()
	{
	}

	[Token(Token = "0x60006E9")]
	[Address(RVA = "0x63A484", Offset = "0x63A484", VA = "0x63A484")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006EA")]
	[Address(RVA = "0x63A708", Offset = "0x63A708", VA = "0x63A708")]
	private void Update()
	{
	}

	[Token(Token = "0x60006EB")]
	[Address(RVA = "0x63A70C", Offset = "0x63A70C", VA = "0x63A70C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006EC")]
	[Address(RVA = "0x63A7BC", Offset = "0x63A7BC", VA = "0x63A7BC")]
	public CameraFilterPack_TV_VHS_Rewind()
	{
	}
}
