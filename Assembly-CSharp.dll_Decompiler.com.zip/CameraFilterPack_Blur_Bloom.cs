using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000045")]
public class CameraFilterPack_Blur_Bloom : MonoBehaviour
{
	[Token(Token = "0x4000295")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000296")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000297")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000298")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x4000299")]
	[FieldOffset(Offset = "0x34")]
	public float Glow;

	[Token(Token = "0x17000046")]
	private Material material
	{
		[Token(Token = "0x60001CF")]
		[Address(RVA = "0x664E30", Offset = "0x664E30", VA = "0x664E30")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001D0")]
	[Address(RVA = "0x664EF4", Offset = "0x664EF4", VA = "0x664EF4")]
	private void Start()
	{
	}

	[Token(Token = "0x60001D1")]
	[Address(RVA = "0x664F70", Offset = "0x664F70", VA = "0x664F70")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001D2")]
	[Address(RVA = "0x66519C", Offset = "0x66519C", VA = "0x66519C")]
	private void Update()
	{
	}

	[Token(Token = "0x60001D3")]
	[Address(RVA = "0x6651A0", Offset = "0x6651A0", VA = "0x6651A0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001D4")]
	[Address(RVA = "0x665250", Offset = "0x665250", VA = "0x665250")]
	public CameraFilterPack_Blur_Bloom()
	{
	}
}
