using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000132")]
public class FadeController : MonoBehaviour
{
	[Token(Token = "0x40008A5")]
	[FieldOffset(Offset = "0x18")]
	public StartScreenController ssController;

	[Token(Token = "0x40008A6")]
	[FieldOffset(Offset = "0x20")]
	public float fadeValue;

	[Token(Token = "0x6000781")]
	[Address(RVA = "0x389258", Offset = "0x389258", VA = "0x389258")]
	private void Start()
	{
	}

	[Token(Token = "0x6000782")]
	[Address(RVA = "0x38925C", Offset = "0x38925C", VA = "0x38925C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000783")]
	[Address(RVA = "0x389260", Offset = "0x389260", VA = "0x389260")]
	public FadeController()
	{
	}
}
