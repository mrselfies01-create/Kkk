using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000013")]
public class CameraFilterPack_3D_Shield : MonoBehaviour
{
	[Token(Token = "0x40000AD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000AE")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x40000AF")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x40000B0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40000B1")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x40000B2")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x40000B3")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x40000B4")]
	[FieldOffset(Offset = "0x3C")]
	public float _FadeShield;

	[Token(Token = "0x40000B5")]
	[FieldOffset(Offset = "0x40")]
	public float LightIntensity;

	[Token(Token = "0x40000B6")]
	[FieldOffset(Offset = "0x44")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x40000B7")]
	[FieldOffset(Offset = "0x48")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x40000B8")]
	[FieldOffset(Offset = "0x4C")]
	public float Speed;

	[Token(Token = "0x40000B9")]
	[FieldOffset(Offset = "0x50")]
	public float Speed_X;

	[Token(Token = "0x40000BA")]
	[FieldOffset(Offset = "0x54")]
	public float Speed_Y;

	[Token(Token = "0x40000BB")]
	[FieldOffset(Offset = "0x58")]
	public float Intensity;

	[Token(Token = "0x40000BC")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x17000014")]
	private Material material
	{
		[Token(Token = "0x6000064")]
		[Address(RVA = "0x5B71D4", Offset = "0x5B71D4", VA = "0x5B71D4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000065")]
	[Address(RVA = "0x5B7298", Offset = "0x5B7298", VA = "0x5B7298")]
	private void Start()
	{
	}

	[Token(Token = "0x6000066")]
	[Address(RVA = "0x5B7314", Offset = "0x5B7314", VA = "0x5B7314")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000067")]
	[Address(RVA = "0x5B7740", Offset = "0x5B7740", VA = "0x5B7740")]
	private void Update()
	{
	}

	[Token(Token = "0x6000068")]
	[Address(RVA = "0x5B7744", Offset = "0x5B7744", VA = "0x5B7744")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000069")]
	[Address(RVA = "0x5B77F4", Offset = "0x5B77F4", VA = "0x5B77F4")]
	public CameraFilterPack_3D_Shield()
	{
	}
}
