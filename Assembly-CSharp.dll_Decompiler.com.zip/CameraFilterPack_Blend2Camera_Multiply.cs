using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000039")]
public class CameraFilterPack_Blend2Camera_Multiply : MonoBehaviour
{
	[Token(Token = "0x4000225")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000226")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000227")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000228")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000229")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400022A")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400022B")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400022C")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003A")]
	private Material material
	{
		[Token(Token = "0x6000170")]
		[Address(RVA = "0x5C6CE8", Offset = "0x5C6CE8", VA = "0x5C6CE8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000171")]
	[Address(RVA = "0x5C6DAC", Offset = "0x5C6DAC", VA = "0x5C6DAC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000172")]
	[Address(RVA = "0x5C6EC4", Offset = "0x5C6EC4", VA = "0x5C6EC4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000173")]
	[Address(RVA = "0x5C7154", Offset = "0x5C7154", VA = "0x5C7154")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000174")]
	[Address(RVA = "0x5C7240", Offset = "0x5C7240", VA = "0x5C7240")]
	private void Update()
	{
	}

	[Token(Token = "0x6000175")]
	[Address(RVA = "0x5C7244", Offset = "0x5C7244", VA = "0x5C7244")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000176")]
	[Address(RVA = "0x5C7330", Offset = "0x5C7330", VA = "0x5C7330")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000177")]
	[Address(RVA = "0x5C7428", Offset = "0x5C7428", VA = "0x5C7428")]
	public CameraFilterPack_Blend2Camera_Multiply()
	{
	}
}
