using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000097")]
public class CameraFilterPack_Drawing_NewCellShading : MonoBehaviour
{
	[Token(Token = "0x400047C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400047D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400047E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400047F")]
	[FieldOffset(Offset = "0x30")]
	public float Threshold;

	[Token(Token = "0x17000098")]
	private Material material
	{
		[Token(Token = "0x60003BD")]
		[Address(RVA = "0x692558", Offset = "0x692558", VA = "0x692558")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003BE")]
	[Address(RVA = "0x69261C", Offset = "0x69261C", VA = "0x69261C")]
	private void Start()
	{
	}

	[Token(Token = "0x60003BF")]
	[Address(RVA = "0x692698", Offset = "0x692698", VA = "0x692698")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003C0")]
	[Address(RVA = "0x6928A0", Offset = "0x6928A0", VA = "0x6928A0")]
	private void Update()
	{
	}

	[Token(Token = "0x60003C1")]
	[Address(RVA = "0x6928A4", Offset = "0x6928A4", VA = "0x6928A4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003C2")]
	[Address(RVA = "0x692954", Offset = "0x692954", VA = "0x692954")]
	public CameraFilterPack_Drawing_NewCellShading()
	{
	}
}
