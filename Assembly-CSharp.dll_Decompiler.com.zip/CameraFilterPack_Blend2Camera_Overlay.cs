using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003A")]
public class CameraFilterPack_Blend2Camera_Overlay : MonoBehaviour
{
	[Token(Token = "0x400022D")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400022E")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400022F")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000230")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000231")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000232")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000233")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000234")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003B")]
	private Material material
	{
		[Token(Token = "0x6000178")]
		[Address(RVA = "0x5C7490", Offset = "0x5C7490", VA = "0x5C7490")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000179")]
	[Address(RVA = "0x5C7554", Offset = "0x5C7554", VA = "0x5C7554")]
	private void Start()
	{
	}

	[Token(Token = "0x600017A")]
	[Address(RVA = "0x5C766C", Offset = "0x5C766C", VA = "0x5C766C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600017B")]
	[Address(RVA = "0x5C78FC", Offset = "0x5C78FC", VA = "0x5C78FC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600017C")]
	[Address(RVA = "0x5C79E8", Offset = "0x5C79E8", VA = "0x5C79E8")]
	private void Update()
	{
	}

	[Token(Token = "0x600017D")]
	[Address(RVA = "0x5C79EC", Offset = "0x5C79EC", VA = "0x5C79EC")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600017E")]
	[Address(RVA = "0x5C7AD8", Offset = "0x5C7AD8", VA = "0x5C7AD8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600017F")]
	[Address(RVA = "0x5C7BD0", Offset = "0x5C7BD0", VA = "0x5C7BD0")]
	public CameraFilterPack_Blend2Camera_Overlay()
	{
	}
}
