using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010B")]
public class CameraFilterPack_TV_Distorted : MonoBehaviour
{
	[Token(Token = "0x40007B1")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007B2")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007B3")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40007B4")]
	[FieldOffset(Offset = "0x28")]
	public float RGB;

	[Token(Token = "0x40007B5")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x1700010C")]
	private Material material
	{
		[Token(Token = "0x6000699")]
		[Address(RVA = "0x636CD8", Offset = "0x636CD8", VA = "0x636CD8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600069A")]
	[Address(RVA = "0x636D9C", Offset = "0x636D9C", VA = "0x636D9C")]
	private void Start()
	{
	}

	[Token(Token = "0x600069B")]
	[Address(RVA = "0x636E18", Offset = "0x636E18", VA = "0x636E18")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600069C")]
	[Address(RVA = "0x636FC0", Offset = "0x636FC0", VA = "0x636FC0")]
	private void Update()
	{
	}

	[Token(Token = "0x600069D")]
	[Address(RVA = "0x636FC4", Offset = "0x636FC4", VA = "0x636FC4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600069E")]
	[Address(RVA = "0x637074", Offset = "0x637074", VA = "0x637074")]
	public CameraFilterPack_TV_Distorted()
	{
	}
}
