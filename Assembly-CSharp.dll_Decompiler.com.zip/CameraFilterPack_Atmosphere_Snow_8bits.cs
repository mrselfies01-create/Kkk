using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000023")]
public class CameraFilterPack_Atmosphere_Snow_8bits : MonoBehaviour
{
	[Token(Token = "0x4000164")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000165")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000166")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000167")]
	[FieldOffset(Offset = "0x30")]
	public float Threshold;

	[Token(Token = "0x4000168")]
	[FieldOffset(Offset = "0x34")]
	public float Size;

	[Token(Token = "0x4000169")]
	[FieldOffset(Offset = "0x38")]
	public float DirectionX;

	[Token(Token = "0x400016A")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x17000024")]
	private Material material
	{
		[Token(Token = "0x60000C4")]
		[Address(RVA = "0x5BCB48", Offset = "0x5BCB48", VA = "0x5BCB48")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000C5")]
	[Address(RVA = "0x5BCC0C", Offset = "0x5BCC0C", VA = "0x5BCC0C")]
	private void Start()
	{
	}

	[Token(Token = "0x60000C6")]
	[Address(RVA = "0x5BCC88", Offset = "0x5BCC88", VA = "0x5BCC88")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000C7")]
	[Address(RVA = "0x5BCF0C", Offset = "0x5BCF0C", VA = "0x5BCF0C")]
	private void Update()
	{
	}

	[Token(Token = "0x60000C8")]
	[Address(RVA = "0x5BCF10", Offset = "0x5BCF10", VA = "0x5BCF10")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000C9")]
	[Address(RVA = "0x5BCFC0", Offset = "0x5BCFC0", VA = "0x5BCFC0")]
	public CameraFilterPack_Atmosphere_Snow_8bits()
	{
	}
}
