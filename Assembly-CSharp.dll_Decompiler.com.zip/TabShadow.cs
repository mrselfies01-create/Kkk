using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000142")]
public class TabShadow : MonoBehaviour
{
	[Token(Token = "0x4000998")]
	[FieldOffset(Offset = "0x18")]
	private Toggle toggle;

	[Token(Token = "0x4000999")]
	[FieldOffset(Offset = "0x20")]
	private Image shadow;

	[Token(Token = "0x60007EB")]
	[Address(RVA = "0x3DFF70", Offset = "0x3DFF70", VA = "0x3DFF70")]
	private void Start()
	{
	}

	[Token(Token = "0x60007EC")]
	[Address(RVA = "0x3DFFE0", Offset = "0x3DFFE0", VA = "0x3DFFE0")]
	private void Update()
	{
	}

	[Token(Token = "0x60007ED")]
	[Address(RVA = "0x3E0084", Offset = "0x3E0084", VA = "0x3E0084")]
	public TabShadow()
	{
	}
}
