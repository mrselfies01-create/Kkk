using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011B")]
public class CameraFilterPack_TV_Videoflip : MonoBehaviour
{
	[Token(Token = "0x4000805")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000806")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000807")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700011C")]
	private Material material
	{
		[Token(Token = "0x60006F9")]
		[Address(RVA = "0x63AF58", Offset = "0x63AF58", VA = "0x63AF58")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006FA")]
	[Address(RVA = "0x63B01C", Offset = "0x63B01C", VA = "0x63B01C")]
	private void Start()
	{
	}

	[Token(Token = "0x60006FB")]
	[Address(RVA = "0x63B098", Offset = "0x63B098", VA = "0x63B098")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006FC")]
	[Address(RVA = "0x63B28C", Offset = "0x63B28C", VA = "0x63B28C")]
	private void Update()
	{
	}

	[Token(Token = "0x60006FD")]
	[Address(RVA = "0x63B290", Offset = "0x63B290", VA = "0x63B290")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006FE")]
	[Address(RVA = "0x63B340", Offset = "0x63B340", VA = "0x63B340")]
	public CameraFilterPack_TV_Videoflip()
	{
	}
}
