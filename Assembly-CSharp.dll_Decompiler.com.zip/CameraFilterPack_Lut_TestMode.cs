using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E1")]
public class CameraFilterPack_Lut_TestMode : MonoBehaviour
{
	[Token(Token = "0x4000683")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000684")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000685")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000686")]
	[FieldOffset(Offset = "0x30")]
	public Texture2D LutTexture;

	[Token(Token = "0x4000687")]
	[FieldOffset(Offset = "0x38")]
	private Texture3D converted3DLut;

	[Token(Token = "0x4000688")]
	[FieldOffset(Offset = "0x40")]
	public float Blend;

	[Token(Token = "0x4000689")]
	[FieldOffset(Offset = "0x44")]
	public float OriginalIntensity;

	[Token(Token = "0x400068A")]
	[FieldOffset(Offset = "0x48")]
	public float ResultIntensity;

	[Token(Token = "0x400068B")]
	[FieldOffset(Offset = "0x4C")]
	public float FinalIntensity;

	[Token(Token = "0x400068C")]
	[FieldOffset(Offset = "0x50")]
	public float TestMode;

	[Token(Token = "0x400068D")]
	[FieldOffset(Offset = "0x58")]
	private string MemoPath;

	[Token(Token = "0x170000E2")]
	private Material material
	{
		[Token(Token = "0x6000592")]
		[Address(RVA = "0x6295A8", Offset = "0x6295A8", VA = "0x6295A8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000593")]
	[Address(RVA = "0x62966C", Offset = "0x62966C", VA = "0x62966C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000594")]
	[Address(RVA = "0x6296E8", Offset = "0x6296E8", VA = "0x6296E8")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x6000595")]
	[Address(RVA = "0x6298D4", Offset = "0x6298D4", VA = "0x6298D4")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x6000596")]
	[Address(RVA = "0x6299C8", Offset = "0x6299C8", VA = "0x6299C8")]
	public void Convert(Texture2D temp2DTex)
	{
	}

	[Token(Token = "0x6000597")]
	[Address(RVA = "0x629C98", Offset = "0x629C98", VA = "0x629C98")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000598")]
	[Address(RVA = "0x629F28", Offset = "0x629F28", VA = "0x629F28")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000599")]
	[Address(RVA = "0x629F2C", Offset = "0x629F2C", VA = "0x629F2C")]
	private void Update()
	{
	}

	[Token(Token = "0x600059A")]
	[Address(RVA = "0x629F30", Offset = "0x629F30", VA = "0x629F30")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600059B")]
	[Address(RVA = "0x629FE0", Offset = "0x629FE0", VA = "0x629FE0")]
	public CameraFilterPack_Lut_TestMode()
	{
	}
}
