using System;
using Il2CppDummyDll;

[Token(Token = "0x2000138")]
public class OrderSongs : IDisposable
{
	[Token(Token = "0x60007A8")]
	[Address(RVA = "0x3931B8", Offset = "0x3931B8", VA = "0x3931B8", Slot = "4")]
	private int System_002ECollections_002EIComparer_002ECompare(object x, object y)
	{
		return default(int);
	}

	[Token(Token = "0x60007A9")]
	[Address(RVA = "0x391798", Offset = "0x391798", VA = "0x391798")]
	public OrderSongs()
	{
	}
}
