using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CE")]
public class CameraFilterPack_Gradients_Desert : MonoBehaviour
{
	[Token(Token = "0x40005FB")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005FC")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x40005FD")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x40005FE")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40005FF")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000600")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000CF")]
	private Material material
	{
		[Token(Token = "0x6000508")]
		[Address(RVA = "0x6A25D4", Offset = "0x6A25D4", VA = "0x6A25D4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000509")]
	[Address(RVA = "0x6A2698", Offset = "0x6A2698", VA = "0x6A2698")]
	private void Start()
	{
	}

	[Token(Token = "0x600050A")]
	[Address(RVA = "0x6A26E8", Offset = "0x6A26E8", VA = "0x6A26E8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600050B")]
	[Address(RVA = "0x6A2924", Offset = "0x6A2924", VA = "0x6A2924")]
	private void Update()
	{
	}

	[Token(Token = "0x600050C")]
	[Address(RVA = "0x6A2928", Offset = "0x6A2928", VA = "0x6A2928")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600050D")]
	[Address(RVA = "0x6A29D8", Offset = "0x6A29D8", VA = "0x6A29D8")]
	public CameraFilterPack_Gradients_Desert()
	{
	}
}
