using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000127")]
public class CameraFilterPack_Vision_Crystal : MonoBehaviour
{
	[Token(Token = "0x4000851")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000852")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000853")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000854")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x4000855")]
	[FieldOffset(Offset = "0x34")]
	public float X;

	[Token(Token = "0x4000856")]
	[FieldOffset(Offset = "0x38")]
	public float Y;

	[Token(Token = "0x4000857")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000128")]
	private Material material
	{
		[Token(Token = "0x6000741")]
		[Address(RVA = "0x63E4F0", Offset = "0x63E4F0", VA = "0x63E4F0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000742")]
	[Address(RVA = "0x63E5B4", Offset = "0x63E5B4", VA = "0x63E5B4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000743")]
	[Address(RVA = "0x63E630", Offset = "0x63E630", VA = "0x63E630")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000744")]
	[Address(RVA = "0x63E8B4", Offset = "0x63E8B4", VA = "0x63E8B4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000745")]
	[Address(RVA = "0x63E8B8", Offset = "0x63E8B8", VA = "0x63E8B8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000746")]
	[Address(RVA = "0x63E968", Offset = "0x63E968", VA = "0x63E968")]
	public CameraFilterPack_Vision_Crystal()
	{
	}
}
