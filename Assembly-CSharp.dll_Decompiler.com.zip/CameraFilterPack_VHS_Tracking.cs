using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000122")]
public class CameraFilterPack_VHS_Tracking : MonoBehaviour
{
	[Token(Token = "0x400082F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000830")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000831")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000832")]
	[FieldOffset(Offset = "0x30")]
	public float Tracking;

	[Token(Token = "0x17000123")]
	private Material material
	{
		[Token(Token = "0x6000723")]
		[Address(RVA = "0x63CD78", Offset = "0x63CD78", VA = "0x63CD78")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000724")]
	[Address(RVA = "0x63CE3C", Offset = "0x63CE3C", VA = "0x63CE3C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000725")]
	[Address(RVA = "0x63CEB8", Offset = "0x63CEB8", VA = "0x63CEB8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000726")]
	[Address(RVA = "0x63D0D0", Offset = "0x63D0D0", VA = "0x63D0D0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000727")]
	[Address(RVA = "0x63D0D4", Offset = "0x63D0D4", VA = "0x63D0D4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000728")]
	[Address(RVA = "0x63D184", Offset = "0x63D184", VA = "0x63D184")]
	public CameraFilterPack_VHS_Tracking()
	{
	}
}
