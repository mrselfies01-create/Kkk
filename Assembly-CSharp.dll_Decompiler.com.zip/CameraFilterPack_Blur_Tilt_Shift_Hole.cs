using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000053")]
public class CameraFilterPack_Blur_Tilt_Shift_Hole : MonoBehaviour
{
	[Token(Token = "0x40002E9")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002EA")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002EB")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002EC")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40002ED")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x40002EE")]
	[FieldOffset(Offset = "0x38")]
	public float Smooth;

	[Token(Token = "0x40002EF")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x40002F0")]
	[FieldOffset(Offset = "0x40")]
	public float PositionX;

	[Token(Token = "0x40002F1")]
	[FieldOffset(Offset = "0x44")]
	public float PositionY;

	[Token(Token = "0x17000054")]
	private Material material
	{
		[Token(Token = "0x6000223")]
		[Address(RVA = "0x6690AC", Offset = "0x6690AC", VA = "0x6690AC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000224")]
	[Address(RVA = "0x669170", Offset = "0x669170", VA = "0x669170")]
	private void Start()
	{
	}

	[Token(Token = "0x6000225")]
	[Address(RVA = "0x6691EC", Offset = "0x6691EC", VA = "0x6691EC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000226")]
	[Address(RVA = "0x6695C0", Offset = "0x6695C0", VA = "0x6695C0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000227")]
	[Address(RVA = "0x6695C4", Offset = "0x6695C4", VA = "0x6695C4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000228")]
	[Address(RVA = "0x669674", Offset = "0x669674", VA = "0x669674")]
	public CameraFilterPack_Blur_Tilt_Shift_Hole()
	{
	}
}
