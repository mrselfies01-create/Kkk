using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000058")]
public class CameraFilterPack_Classic_ThermalVision : MonoBehaviour
{
	[Token(Token = "0x400030E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400030F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000310")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000311")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x4000312")]
	[FieldOffset(Offset = "0x34")]
	public float _Fade;

	[Token(Token = "0x4000313")]
	[FieldOffset(Offset = "0x38")]
	public float _Crt;

	[Token(Token = "0x4000314")]
	[FieldOffset(Offset = "0x3C")]
	public float _Curve;

	[Token(Token = "0x4000315")]
	[FieldOffset(Offset = "0x40")]
	public float _Color1;

	[Token(Token = "0x4000316")]
	[FieldOffset(Offset = "0x44")]
	public float _Color2;

	[Token(Token = "0x4000317")]
	[FieldOffset(Offset = "0x48")]
	public float _Color3;

	[Token(Token = "0x17000059")]
	private Material material
	{
		[Token(Token = "0x6000241")]
		[Address(RVA = "0x66A9B8", Offset = "0x66A9B8", VA = "0x66A9B8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000242")]
	[Address(RVA = "0x66AA7C", Offset = "0x66AA7C", VA = "0x66AA7C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000243")]
	[Address(RVA = "0x66AAF8", Offset = "0x66AAF8", VA = "0x66AAF8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000244")]
	[Address(RVA = "0x66ADE8", Offset = "0x66ADE8", VA = "0x66ADE8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000245")]
	[Address(RVA = "0x66ADEC", Offset = "0x66ADEC", VA = "0x66ADEC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000246")]
	[Address(RVA = "0x66AE9C", Offset = "0x66AE9C", VA = "0x66AE9C")]
	public CameraFilterPack_Classic_ThermalVision()
	{
	}
}
