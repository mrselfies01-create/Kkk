using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001D")]
public class CameraFilterPack_Alien_Vision : MonoBehaviour
{
	[Token(Token = "0x4000125")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000126")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000127")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000128")]
	[FieldOffset(Offset = "0x30")]
	public float Therma_Variation;

	[Token(Token = "0x4000129")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x400012A")]
	[FieldOffset(Offset = "0x38")]
	private float Burn;

	[Token(Token = "0x400012B")]
	[FieldOffset(Offset = "0x3C")]
	private float SceneCut;

	[Token(Token = "0x1700001E")]
	private Material material
	{
		[Token(Token = "0x60000A0")]
		[Address(RVA = "0x5BAA50", Offset = "0x5BAA50", VA = "0x5BAA50")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000A1")]
	[Address(RVA = "0x5BAB14", Offset = "0x5BAB14", VA = "0x5BAB14")]
	private void Start()
	{
	}

	[Token(Token = "0x60000A2")]
	[Address(RVA = "0x5BAB90", Offset = "0x5BAB90", VA = "0x5BAB90")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000A3")]
	[Address(RVA = "0x5BAE14", Offset = "0x5BAE14", VA = "0x5BAE14")]
	private void Update()
	{
	}

	[Token(Token = "0x60000A4")]
	[Address(RVA = "0x5BAE18", Offset = "0x5BAE18", VA = "0x5BAE18")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000A5")]
	[Address(RVA = "0x5BAEC8", Offset = "0x5BAEC8", VA = "0x5BAEC8")]
	public CameraFilterPack_Alien_Vision()
	{
	}
}
