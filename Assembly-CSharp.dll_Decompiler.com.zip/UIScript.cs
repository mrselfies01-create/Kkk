using Audial;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x200013E")]
public class UIScript : MonoBehaviour
{
	[Token(Token = "0x4000939")]
	[FieldOffset(Offset = "0x18")]
	public float startSpeedMin;

	[Token(Token = "0x400093A")]
	[FieldOffset(Offset = "0x1C")]
	public float startSpeedNormal;

	[Token(Token = "0x400093B")]
	[FieldOffset(Offset = "0x20")]
	public float startSpeedMax;

	[Token(Token = "0x400093C")]
	[FieldOffset(Offset = "0x24")]
	public float startSizeMin;

	[Token(Token = "0x400093D")]
	[FieldOffset(Offset = "0x28")]
	public float startSizeMax;

	[Token(Token = "0x400093E")]
	[FieldOffset(Offset = "0x30")]
	private CameraFilterPack_Real_VHS VHSEffect;

	[Token(Token = "0x400093F")]
	[FieldOffset(Offset = "0x38")]
	public Delay delayEffect;

	[Token(Token = "0x4000940")]
	[FieldOffset(Offset = "0x40")]
	private float Channel1Time;

	[Token(Token = "0x4000941")]
	[FieldOffset(Offset = "0x44")]
	private float Channel2Time;

	[Token(Token = "0x4000942")]
	[FieldOffset(Offset = "0x48")]
	private float Channel3Time;

	[Token(Token = "0x4000943")]
	[FieldOffset(Offset = "0x4C")]
	private float Channel4Time;

	[Token(Token = "0x4000944")]
	[FieldOffset(Offset = "0x50")]
	public float ChannelMinDelay;

	[Token(Token = "0x4000945")]
	[FieldOffset(Offset = "0x54")]
	public float ChannelMaxDelay;

	[Token(Token = "0x4000946")]
	[FieldOffset(Offset = "0x58")]
	public float EffectMinDelay;

	[Token(Token = "0x4000947")]
	[FieldOffset(Offset = "0x5C")]
	public float EffectMaxDelay;

	[Token(Token = "0x4000948")]
	[FieldOffset(Offset = "0x60")]
	public float NoiseMinDelay;

	[Token(Token = "0x4000949")]
	[FieldOffset(Offset = "0x64")]
	public float NoiseMaxDelay;

	[Token(Token = "0x400094A")]
	[FieldOffset(Offset = "0x68")]
	public float ChannelScale;

	[Token(Token = "0x400094B")]
	[FieldOffset(Offset = "0x6C")]
	public float Channel1Delay;

	[Token(Token = "0x400094C")]
	[FieldOffset(Offset = "0x70")]
	public float Channel2Delay;

	[Token(Token = "0x400094D")]
	[FieldOffset(Offset = "0x74")]
	public float Channel3Delay;

	[Token(Token = "0x400094E")]
	[FieldOffset(Offset = "0x78")]
	public float Channel4Delay;

	[Token(Token = "0x400094F")]
	[FieldOffset(Offset = "0x80")]
	public SpinDial speedDial;

	[Token(Token = "0x4000950")]
	[FieldOffset(Offset = "0x88")]
	private AudioSource audio;

	[Token(Token = "0x4000951")]
	[FieldOffset(Offset = "0x90")]
	public Sprite startImage;

	[Token(Token = "0x4000952")]
	[FieldOffset(Offset = "0x98")]
	public Sprite stopImage;

	[Token(Token = "0x4000953")]
	[FieldOffset(Offset = "0xA0")]
	public Image startStopImage;

	[Token(Token = "0x4000954")]
	[FieldOffset(Offset = "0xA8")]
	public Image echoImage;

	[Token(Token = "0x4000955")]
	[FieldOffset(Offset = "0xB0")]
	public Image reverbImage;

	[Token(Token = "0x4000956")]
	[FieldOffset(Offset = "0xB8")]
	public Image whiteNoiseImage;

	[Token(Token = "0x4000957")]
	[FieldOffset(Offset = "0xC0")]
	public Button reverbButton;

	[Token(Token = "0x4000958")]
	[FieldOffset(Offset = "0xC8")]
	public Button echoButton;

	[Token(Token = "0x4000959")]
	[FieldOffset(Offset = "0xD0")]
	public Button whiteNoiseButton;

	[Token(Token = "0x400095A")]
	[FieldOffset(Offset = "0xD8")]
	public Delay echo;

	[Token(Token = "0x400095B")]
	[FieldOffset(Offset = "0xE0")]
	public Reverb reverb;

	[Token(Token = "0x400095C")]
	[FieldOffset(Offset = "0xE8")]
	public CameraFilterPack_VHS_Tracking vhsEffect;

	[Token(Token = "0x400095D")]
	[FieldOffset(Offset = "0xF0")]
	public float tracking;

	[Token(Token = "0x400095E")]
	[FieldOffset(Offset = "0xF4")]
	public float glitch;

	[Token(Token = "0x400095F")]
	[FieldOffset(Offset = "0xF8")]
	public float jitter;

	[Token(Token = "0x4000960")]
	[FieldOffset(Offset = "0xFC")]
	public float effectChangeDelay;

	[Token(Token = "0x4000961")]
	[FieldOffset(Offset = "0x100")]
	public float effectChangeTime;

	[Token(Token = "0x4000962")]
	[FieldOffset(Offset = "0x104")]
	public bool channel1On;

	[Token(Token = "0x4000963")]
	[FieldOffset(Offset = "0x105")]
	public bool channel2On;

	[Token(Token = "0x4000964")]
	[FieldOffset(Offset = "0x106")]
	public bool channel3On;

	[Token(Token = "0x4000965")]
	[FieldOffset(Offset = "0x107")]
	public bool channel4On;

	[Token(Token = "0x4000966")]
	[FieldOffset(Offset = "0x108")]
	private bool playingAudio;

	[Token(Token = "0x4000967")]
	[FieldOffset(Offset = "0x109")]
	private bool noise;

	[Token(Token = "0x4000968")]
	[FieldOffset(Offset = "0x110")]
	public string filename;

	[Token(Token = "0x4000969")]
	[FieldOffset(Offset = "0x118")]
	public string noisefilename;

	[Token(Token = "0x400096A")]
	[FieldOffset(Offset = "0x120")]
	private float lastspeed;

	[Token(Token = "0x60007C3")]
	[Address(RVA = "0x3EAB50", Offset = "0x3EAB50", VA = "0x3EAB50")]
	public void SetChannel1(bool on)
	{
	}

	[Token(Token = "0x60007C4")]
	[Address(RVA = "0x3EAB5C", Offset = "0x3EAB5C", VA = "0x3EAB5C")]
	public void SetChannel2(bool on)
	{
	}

	[Token(Token = "0x60007C5")]
	[Address(RVA = "0x3EAB68", Offset = "0x3EAB68", VA = "0x3EAB68")]
	public void SetChannel3(bool on)
	{
	}

	[Token(Token = "0x60007C6")]
	[Address(RVA = "0x3EAB74", Offset = "0x3EAB74", VA = "0x3EAB74")]
	public void SetChannel4(bool on)
	{
	}

	[Token(Token = "0x60007C7")]
	[Address(RVA = "0x3EAB80", Offset = "0x3EAB80", VA = "0x3EAB80")]
	private void Start()
	{
	}

	[Token(Token = "0x60007C8")]
	[Address(RVA = "0x3EACF8", Offset = "0x3EACF8", VA = "0x3EACF8")]
	public void StartStop()
	{
	}

	[Token(Token = "0x60007C9")]
	[Address(RVA = "0x3EAD70", Offset = "0x3EAD70", VA = "0x3EAD70")]
	public void EchoPressed()
	{
	}

	[Token(Token = "0x60007CA")]
	[Address(RVA = "0x3EAE10", Offset = "0x3EAE10", VA = "0x3EAE10")]
	public void ReverbPressed()
	{
	}

	[Token(Token = "0x60007CB")]
	[Address(RVA = "0x3EAEB0", Offset = "0x3EAEB0", VA = "0x3EAEB0")]
	public void WhiteNoisePressed()
	{
	}

	[Token(Token = "0x60007CC")]
	[Address(RVA = "0x3EAF20", Offset = "0x3EAF20", VA = "0x3EAF20")]
	private float GetTarget()
	{
		return default(float);
	}

	[Token(Token = "0x60007CD")]
	[Address(RVA = "0x3EAFB8", Offset = "0x3EAFB8", VA = "0x3EAFB8")]
	private float GetChannelDelay()
	{
		return default(float);
	}

	[Token(Token = "0x60007CE")]
	[Address(RVA = "0x3EAFF0", Offset = "0x3EAFF0", VA = "0x3EAFF0")]
	public void SetDelay(float delay)
	{
	}

	[Token(Token = "0x60007CF")]
	[Address(RVA = "0x3EB010", Offset = "0x3EB010", VA = "0x3EB010")]
	public void SetPingPong(bool on)
	{
	}

	[Token(Token = "0x60007D0")]
	[Address(RVA = "0x3EB030", Offset = "0x3EB030", VA = "0x3EB030")]
	public bool almostEqual(float a, float b)
	{
		return default(bool);
	}

	[Token(Token = "0x60007D1")]
	[Address(RVA = "0x3EB058", Offset = "0x3EB058", VA = "0x3EB058")]
	private void Update()
	{
	}

	[Token(Token = "0x60007D2")]
	[Address(RVA = "0x3EAC90", Offset = "0x3EAC90", VA = "0x3EAC90")]
	private void SetChannelDelay()
	{
	}

	[Token(Token = "0x60007D3")]
	[Address(RVA = "0x3EB548", Offset = "0x3EB548", VA = "0x3EB548")]
	public UIScript()
	{
	}
}
