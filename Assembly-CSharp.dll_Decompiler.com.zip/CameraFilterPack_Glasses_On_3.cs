using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C6")]
public class CameraFilterPack_Glasses_On_3 : MonoBehaviour
{
	[Token(Token = "0x40005A5")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005A6")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005A7")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40005A8")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x40005A9")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x40005AA")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x40005AB")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x40005AC")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x40005AD")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x40005AE")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x40005AF")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x40005B0")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x40005B1")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x40005B2")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C7")]
	private Material material
	{
		[Token(Token = "0x60004D8")]
		[Address(RVA = "0x69F6DC", Offset = "0x69F6DC", VA = "0x69F6DC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004D9")]
	[Address(RVA = "0x69F7A0", Offset = "0x69F7A0", VA = "0x69F7A0")]
	private void Start()
	{
	}

	[Token(Token = "0x60004DA")]
	[Address(RVA = "0x69F858", Offset = "0x69F858", VA = "0x69F858")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004DB")]
	[Address(RVA = "0x69FB50", Offset = "0x69FB50", VA = "0x69FB50")]
	private void Update()
	{
	}

	[Token(Token = "0x60004DC")]
	[Address(RVA = "0x69FB54", Offset = "0x69FB54", VA = "0x69FB54")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004DD")]
	[Address(RVA = "0x69FC04", Offset = "0x69FC04", VA = "0x69FC04")]
	public CameraFilterPack_Glasses_On_3()
	{
	}
}
