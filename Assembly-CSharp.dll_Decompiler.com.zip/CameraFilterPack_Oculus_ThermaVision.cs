using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F2")]
public class CameraFilterPack_Oculus_ThermaVision : MonoBehaviour
{
	[Token(Token = "0x4000704")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000705")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000706")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000707")]
	[FieldOffset(Offset = "0x30")]
	public float Therma_Variation;

	[Token(Token = "0x4000708")]
	[FieldOffset(Offset = "0x34")]
	private float Contrast;

	[Token(Token = "0x4000709")]
	[FieldOffset(Offset = "0x38")]
	private float Burn;

	[Token(Token = "0x400070A")]
	[FieldOffset(Offset = "0x3C")]
	private float SceneCut;

	[Token(Token = "0x170000F3")]
	private Material material
	{
		[Token(Token = "0x6000602")]
		[Address(RVA = "0x62F724", Offset = "0x62F724", VA = "0x62F724")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000603")]
	[Address(RVA = "0x62F7E8", Offset = "0x62F7E8", VA = "0x62F7E8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000604")]
	[Address(RVA = "0x62F864", Offset = "0x62F864", VA = "0x62F864")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000605")]
	[Address(RVA = "0x62FAE8", Offset = "0x62FAE8", VA = "0x62FAE8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000606")]
	[Address(RVA = "0x62FAEC", Offset = "0x62FAEC", VA = "0x62FAEC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000607")]
	[Address(RVA = "0x62FB9C", Offset = "0x62FB9C", VA = "0x62FB9C")]
	public CameraFilterPack_Oculus_ThermaVision()
	{
	}
}
