using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000029")]
public class CameraFilterPack_Blend2Camera_ColorKey : MonoBehaviour
{
	[Token(Token = "0x4000198")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000199")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400019A")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x400019B")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400019C")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400019D")]
	[FieldOffset(Offset = "0x40")]
	public float BlendFX;

	[Token(Token = "0x400019E")]
	[FieldOffset(Offset = "0x44")]
	public Color ColorKey;

	[Token(Token = "0x400019F")]
	[FieldOffset(Offset = "0x54")]
	public float Adjust;

	[Token(Token = "0x40001A0")]
	[FieldOffset(Offset = "0x58")]
	public float Precision;

	[Token(Token = "0x40001A1")]
	[FieldOffset(Offset = "0x5C")]
	public float Luminosity;

	[Token(Token = "0x40001A2")]
	[FieldOffset(Offset = "0x60")]
	public float Change_Red;

	[Token(Token = "0x40001A3")]
	[FieldOffset(Offset = "0x64")]
	public float Change_Green;

	[Token(Token = "0x40001A4")]
	[FieldOffset(Offset = "0x68")]
	public float Change_Blue;

	[Token(Token = "0x40001A5")]
	[FieldOffset(Offset = "0x70")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x40001A6")]
	[FieldOffset(Offset = "0x78")]
	private Vector2 ScreenSize;

	[Token(Token = "0x1700002A")]
	private Material material
	{
		[Token(Token = "0x60000F2")]
		[Address(RVA = "0x5BF488", Offset = "0x5BF488", VA = "0x5BF488")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000F3")]
	[Address(RVA = "0x5BF54C", Offset = "0x5BF54C", VA = "0x5BF54C")]
	private void Start()
	{
	}

	[Token(Token = "0x60000F4")]
	[Address(RVA = "0x5BF64C", Offset = "0x5BF64C", VA = "0x5BF64C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000F5")]
	[Address(RVA = "0x5BF930", Offset = "0x5BF930", VA = "0x5BF930")]
	private void Update()
	{
	}

	[Token(Token = "0x60000F6")]
	[Address(RVA = "0x5BF970", Offset = "0x5BF970", VA = "0x5BF970")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000F7")]
	[Address(RVA = "0x5BF994", Offset = "0x5BF994", VA = "0x5BF994")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000F8")]
	[Address(RVA = "0x5BFAD0", Offset = "0x5BFAD0", VA = "0x5BFAD0")]
	public CameraFilterPack_Blend2Camera_ColorKey()
	{
	}
}
