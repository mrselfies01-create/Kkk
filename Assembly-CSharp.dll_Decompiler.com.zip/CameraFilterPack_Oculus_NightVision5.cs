using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F1")]
public class CameraFilterPack_Oculus_NightVision5 : MonoBehaviour
{
	[Token(Token = "0x40006FB")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40006FC")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40006FD")]
	[FieldOffset(Offset = "0x28")]
	public float FadeFX;

	[Token(Token = "0x40006FE")]
	[FieldOffset(Offset = "0x2C")]
	public float _Size;

	[Token(Token = "0x40006FF")]
	[FieldOffset(Offset = "0x30")]
	public float _Smooth;

	[Token(Token = "0x4000700")]
	[FieldOffset(Offset = "0x34")]
	public float _Dist;

	[Token(Token = "0x4000701")]
	[FieldOffset(Offset = "0x38")]
	private float TimeX;

	[Token(Token = "0x4000702")]
	[FieldOffset(Offset = "0x40")]
	private Material SCMaterial;

	[Token(Token = "0x4000703")]
	[FieldOffset(Offset = "0x48")]
	private float[] Matrix9;

	[Token(Token = "0x170000F2")]
	private Material material
	{
		[Token(Token = "0x60005FA")]
		[Address(RVA = "0x62EF1C", Offset = "0x62EF1C", VA = "0x62EF1C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005FB")]
	[Address(RVA = "0x62EFE0", Offset = "0x62EFE0", VA = "0x62EFE0")]
	private void ChangeFilters()
	{
	}

	[Token(Token = "0x60005FC")]
	[Address(RVA = "0x62F050", Offset = "0x62F050", VA = "0x62F050")]
	private void Start()
	{
	}

	[Token(Token = "0x60005FD")]
	[Address(RVA = "0x62F0A4", Offset = "0x62F0A4", VA = "0x62F0A4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005FE")]
	[Address(RVA = "0x62F600", Offset = "0x62F600", VA = "0x62F600")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60005FF")]
	[Address(RVA = "0x62F604", Offset = "0x62F604", VA = "0x62F604")]
	private void Update()
	{
	}

	[Token(Token = "0x6000600")]
	[Address(RVA = "0x62F608", Offset = "0x62F608", VA = "0x62F608")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000601")]
	[Address(RVA = "0x62F6B8", Offset = "0x62F6B8", VA = "0x62F6B8")]
	public CameraFilterPack_Oculus_NightVision5()
	{
	}
}
