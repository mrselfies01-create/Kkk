using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E7")]
public class CameraFilterPack_NewGlitch6 : MonoBehaviour
{
	[Token(Token = "0x40006AC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006AD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006AE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006AF")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x40006B0")]
	[FieldOffset(Offset = "0x34")]
	public float _FadeLight;

	[Token(Token = "0x40006B1")]
	[FieldOffset(Offset = "0x38")]
	public float _FadeDark;

	[Token(Token = "0x170000E8")]
	private Material material
	{
		[Token(Token = "0x60005BA")]
		[Address(RVA = "0x62B628", Offset = "0x62B628", VA = "0x62B628")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005BB")]
	[Address(RVA = "0x62B6EC", Offset = "0x62B6EC", VA = "0x62B6EC")]
	private void Start()
	{
	}

	[Token(Token = "0x60005BC")]
	[Address(RVA = "0x62B768", Offset = "0x62B768", VA = "0x62B768")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005BD")]
	[Address(RVA = "0x62B9C8", Offset = "0x62B9C8", VA = "0x62B9C8")]
	private void Update()
	{
	}

	[Token(Token = "0x60005BE")]
	[Address(RVA = "0x62B9CC", Offset = "0x62B9CC", VA = "0x62B9CC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005BF")]
	[Address(RVA = "0x62BA7C", Offset = "0x62BA7C", VA = "0x62BA7C")]
	public CameraFilterPack_NewGlitch6()
	{
	}
}
