using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011C")]
public class CameraFilterPack_TV_Vignetting : MonoBehaviour
{
	[Token(Token = "0x4000808")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000809")]
	[FieldOffset(Offset = "0x20")]
	private Material SCMaterial;

	[Token(Token = "0x400080A")]
	[FieldOffset(Offset = "0x28")]
	private Texture2D Vignette;

	[Token(Token = "0x400080B")]
	[FieldOffset(Offset = "0x30")]
	public float Vignetting;

	[Token(Token = "0x400080C")]
	[FieldOffset(Offset = "0x34")]
	public float VignettingFull;

	[Token(Token = "0x400080D")]
	[FieldOffset(Offset = "0x38")]
	public float VignettingDirt;

	[Token(Token = "0x400080E")]
	[FieldOffset(Offset = "0x3C")]
	public Color VignettingColor;

	[Token(Token = "0x1700011D")]
	private Material material
	{
		[Token(Token = "0x60006FF")]
		[Address(RVA = "0x63B350", Offset = "0x63B350", VA = "0x63B350")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000700")]
	[Address(RVA = "0x63B414", Offset = "0x63B414", VA = "0x63B414")]
	private void Start()
	{
	}

	[Token(Token = "0x6000701")]
	[Address(RVA = "0x63B4CC", Offset = "0x63B4CC", VA = "0x63B4CC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000702")]
	[Address(RVA = "0x63B68C", Offset = "0x63B68C", VA = "0x63B68C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000703")]
	[Address(RVA = "0x63B690", Offset = "0x63B690", VA = "0x63B690")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000704")]
	[Address(RVA = "0x63B740", Offset = "0x63B740", VA = "0x63B740")]
	public CameraFilterPack_TV_Vignetting()
	{
	}
}
