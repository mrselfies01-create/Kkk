using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F7")]
public class CameraFilterPack_Pixelisation_Dot : MonoBehaviour
{
	[Token(Token = "0x400072B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400072C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400072D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400072E")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400072F")]
	[FieldOffset(Offset = "0x34")]
	public float LightBackGround;

	[Token(Token = "0x4000730")]
	[FieldOffset(Offset = "0x38")]
	private float Speed;

	[Token(Token = "0x4000731")]
	[FieldOffset(Offset = "0x3C")]
	private float Size2;

	[Token(Token = "0x170000F8")]
	private Material material
	{
		[Token(Token = "0x6000620")]
		[Address(RVA = "0x630D8C", Offset = "0x630D8C", VA = "0x630D8C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000621")]
	[Address(RVA = "0x630E50", Offset = "0x630E50", VA = "0x630E50")]
	private void Start()
	{
	}

	[Token(Token = "0x6000622")]
	[Address(RVA = "0x630ECC", Offset = "0x630ECC", VA = "0x630ECC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000623")]
	[Address(RVA = "0x631150", Offset = "0x631150", VA = "0x631150")]
	private void Update()
	{
	}

	[Token(Token = "0x6000624")]
	[Address(RVA = "0x631154", Offset = "0x631154", VA = "0x631154")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000625")]
	[Address(RVA = "0x631204", Offset = "0x631204", VA = "0x631204")]
	public CameraFilterPack_Pixelisation_Dot()
	{
	}
}
