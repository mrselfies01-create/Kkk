using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A4")]
public class CameraFilterPack_EyesVision_1 : MonoBehaviour
{
	[Token(Token = "0x40004D4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004D5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004D6")]
	[FieldOffset(Offset = "0x24")]
	public float _EyeWave;

	[Token(Token = "0x40004D7")]
	[FieldOffset(Offset = "0x28")]
	public float _EyeSpeed;

	[Token(Token = "0x40004D8")]
	[FieldOffset(Offset = "0x2C")]
	public float _EyeMove;

	[Token(Token = "0x40004D9")]
	[FieldOffset(Offset = "0x30")]
	public float _EyeBlink;

	[Token(Token = "0x40004DA")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40004DB")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000A5")]
	private Material material
	{
		[Token(Token = "0x600040C")]
		[Address(RVA = "0x696094", Offset = "0x696094", VA = "0x696094")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600040D")]
	[Address(RVA = "0x696158", Offset = "0x696158", VA = "0x696158")]
	private void Start()
	{
	}

	[Token(Token = "0x600040E")]
	[Address(RVA = "0x696210", Offset = "0x696210", VA = "0x696210")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600040F")]
	[Address(RVA = "0x696424", Offset = "0x696424", VA = "0x696424")]
	private void Update()
	{
	}

	[Token(Token = "0x6000410")]
	[Address(RVA = "0x696428", Offset = "0x696428", VA = "0x696428")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000411")]
	[Address(RVA = "0x6964D8", Offset = "0x6964D8", VA = "0x6964D8")]
	public CameraFilterPack_EyesVision_1()
	{
	}
}
