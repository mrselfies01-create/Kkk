using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A3")]
public class CameraFilterPack_Edge_Sobel : MonoBehaviour
{
	[Token(Token = "0x40004D1")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004D2")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004D3")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000A4")]
	private Material material
	{
		[Token(Token = "0x6000406")]
		[Address(RVA = "0x695C9C", Offset = "0x695C9C", VA = "0x695C9C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000407")]
	[Address(RVA = "0x695D60", Offset = "0x695D60", VA = "0x695D60")]
	private void Start()
	{
	}

	[Token(Token = "0x6000408")]
	[Address(RVA = "0x695DDC", Offset = "0x695DDC", VA = "0x695DDC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000409")]
	[Address(RVA = "0x695FD0", Offset = "0x695FD0", VA = "0x695FD0")]
	private void Update()
	{
	}

	[Token(Token = "0x600040A")]
	[Address(RVA = "0x695FD4", Offset = "0x695FD4", VA = "0x695FD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600040B")]
	[Address(RVA = "0x696084", Offset = "0x696084", VA = "0x696084")]
	public CameraFilterPack_Edge_Sobel()
	{
	}
}
