using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000052")]
public class CameraFilterPack_Blur_Tilt_Shift : MonoBehaviour
{
	[Token(Token = "0x40002E1")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002E2")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002E3")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002E4")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40002E5")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x40002E6")]
	[FieldOffset(Offset = "0x38")]
	public float Smooth;

	[Token(Token = "0x40002E7")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x40002E8")]
	[FieldOffset(Offset = "0x40")]
	public float Position;

	[Token(Token = "0x17000053")]
	private Material material
	{
		[Token(Token = "0x600021D")]
		[Address(RVA = "0x668A5C", Offset = "0x668A5C", VA = "0x668A5C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600021E")]
	[Address(RVA = "0x668B20", Offset = "0x668B20", VA = "0x668B20")]
	private void Start()
	{
	}

	[Token(Token = "0x600021F")]
	[Address(RVA = "0x668B9C", Offset = "0x668B9C", VA = "0x668B9C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000220")]
	[Address(RVA = "0x668FCC", Offset = "0x668FCC", VA = "0x668FCC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000221")]
	[Address(RVA = "0x668FD0", Offset = "0x668FD0", VA = "0x668FD0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000222")]
	[Address(RVA = "0x669080", Offset = "0x669080", VA = "0x669080")]
	public CameraFilterPack_Blur_Tilt_Shift()
	{
	}
}
