using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000114")]
public class CameraFilterPack_TV_Posterize : MonoBehaviour
{
	[Token(Token = "0x40007DF")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007E0")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007E1")]
	[FieldOffset(Offset = "0x24")]
	public float Posterize;

	[Token(Token = "0x40007E2")]
	[FieldOffset(Offset = "0x28")]
	public float Fade;

	[Token(Token = "0x40007E3")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x17000115")]
	private Material material
	{
		[Token(Token = "0x60006CF")]
		[Address(RVA = "0x639214", Offset = "0x639214", VA = "0x639214")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006D0")]
	[Address(RVA = "0x6392D8", Offset = "0x6392D8", VA = "0x6392D8")]
	private void Start()
	{
	}

	[Token(Token = "0x60006D1")]
	[Address(RVA = "0x639354", Offset = "0x639354", VA = "0x639354")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006D2")]
	[Address(RVA = "0x6394FC", Offset = "0x6394FC", VA = "0x6394FC")]
	private void Update()
	{
	}

	[Token(Token = "0x60006D3")]
	[Address(RVA = "0x639500", Offset = "0x639500", VA = "0x639500")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006D4")]
	[Address(RVA = "0x6395B0", Offset = "0x6395B0", VA = "0x6395B0")]
	public CameraFilterPack_TV_Posterize()
	{
	}
}
