using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000020")]
public class CameraFilterPack_Atmosphere_Rain : MonoBehaviour
{
	[Token(Token = "0x4000138")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000139")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400013A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400013B")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x400013C")]
	[FieldOffset(Offset = "0x34")]
	public float Intensity;

	[Token(Token = "0x400013D")]
	[FieldOffset(Offset = "0x38")]
	public float DirectionX;

	[Token(Token = "0x400013E")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x400013F")]
	[FieldOffset(Offset = "0x40")]
	public float Speed;

	[Token(Token = "0x4000140")]
	[FieldOffset(Offset = "0x44")]
	public float Distortion;

	[Token(Token = "0x4000141")]
	[FieldOffset(Offset = "0x48")]
	public float StormFlashOnOff;

	[Token(Token = "0x4000142")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x17000021")]
	private Material material
	{
		[Token(Token = "0x60000B2")]
		[Address(RVA = "0x5BB840", Offset = "0x5BB840", VA = "0x5BB840")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000B3")]
	[Address(RVA = "0x5BB904", Offset = "0x5BB904", VA = "0x5BB904")]
	private void Start()
	{
	}

	[Token(Token = "0x60000B4")]
	[Address(RVA = "0x5BB9BC", Offset = "0x5BB9BC", VA = "0x5BB9BC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000B5")]
	[Address(RVA = "0x5BBCD0", Offset = "0x5BBCD0", VA = "0x5BBCD0")]
	private void Update()
	{
	}

	[Token(Token = "0x60000B6")]
	[Address(RVA = "0x5BBCD4", Offset = "0x5BBCD4", VA = "0x5BBCD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000B7")]
	[Address(RVA = "0x5BBD84", Offset = "0x5BBD84", VA = "0x5BBD84")]
	public CameraFilterPack_Atmosphere_Rain()
	{
	}
}
