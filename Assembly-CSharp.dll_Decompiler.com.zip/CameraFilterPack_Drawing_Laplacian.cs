using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008C")]
public class CameraFilterPack_Drawing_Laplacian : MonoBehaviour
{
	[Token(Token = "0x4000440")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000441")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000442")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700008D")]
	private Material material
	{
		[Token(Token = "0x600037B")]
		[Address(RVA = "0x68F87C", Offset = "0x68F87C", VA = "0x68F87C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600037C")]
	[Address(RVA = "0x68F940", Offset = "0x68F940", VA = "0x68F940")]
	private void Start()
	{
	}

	[Token(Token = "0x600037D")]
	[Address(RVA = "0x68F9BC", Offset = "0x68F9BC", VA = "0x68F9BC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600037E")]
	[Address(RVA = "0x68FBB0", Offset = "0x68FBB0", VA = "0x68FBB0")]
	private void Update()
	{
	}

	[Token(Token = "0x600037F")]
	[Address(RVA = "0x68FBB8", Offset = "0x68FBB8", VA = "0x68FBB8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000380")]
	[Address(RVA = "0x68FC68", Offset = "0x68FC68", VA = "0x68FC68")]
	public CameraFilterPack_Drawing_Laplacian()
	{
	}
}
