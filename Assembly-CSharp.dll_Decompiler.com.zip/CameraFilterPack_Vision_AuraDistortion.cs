using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000124")]
public class CameraFilterPack_Vision_AuraDistortion : MonoBehaviour
{
	[Token(Token = "0x400083B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400083C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400083D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400083E")]
	[FieldOffset(Offset = "0x30")]
	public float Twist;

	[Token(Token = "0x400083F")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000840")]
	[FieldOffset(Offset = "0x38")]
	public Color Color;

	[Token(Token = "0x4000841")]
	[FieldOffset(Offset = "0x48")]
	public float PosX;

	[Token(Token = "0x4000842")]
	[FieldOffset(Offset = "0x4C")]
	public float PosY;

	[Token(Token = "0x17000125")]
	private Material material
	{
		[Token(Token = "0x600072F")]
		[Address(RVA = "0x63D6B0", Offset = "0x63D6B0", VA = "0x63D6B0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000730")]
	[Address(RVA = "0x63D774", Offset = "0x63D774", VA = "0x63D774")]
	private void Start()
	{
	}

	[Token(Token = "0x6000731")]
	[Address(RVA = "0x63D7F0", Offset = "0x63D7F0", VA = "0x63D7F0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000732")]
	[Address(RVA = "0x63DA9C", Offset = "0x63DA9C", VA = "0x63DA9C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000733")]
	[Address(RVA = "0x63DAA0", Offset = "0x63DAA0", VA = "0x63DAA0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000734")]
	[Address(RVA = "0x63DB50", Offset = "0x63DB50", VA = "0x63DB50")]
	public CameraFilterPack_Vision_AuraDistortion()
	{
	}
}
