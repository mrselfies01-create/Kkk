using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000018")]
public class CameraFilterPack_AAA_Blood_Plus : MonoBehaviour
{
	[Token(Token = "0x40000EE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000EF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40000F0")]
	[FieldOffset(Offset = "0x24")]
	public float Blood_1;

	[Token(Token = "0x40000F1")]
	[FieldOffset(Offset = "0x28")]
	public float Blood_2;

	[Token(Token = "0x40000F2")]
	[FieldOffset(Offset = "0x2C")]
	public float Blood_3;

	[Token(Token = "0x40000F3")]
	[FieldOffset(Offset = "0x30")]
	public float Blood_4;

	[Token(Token = "0x40000F4")]
	[FieldOffset(Offset = "0x34")]
	public float Blood_5;

	[Token(Token = "0x40000F5")]
	[FieldOffset(Offset = "0x38")]
	public float Blood_6;

	[Token(Token = "0x40000F6")]
	[FieldOffset(Offset = "0x3C")]
	public float Blood_7;

	[Token(Token = "0x40000F7")]
	[FieldOffset(Offset = "0x40")]
	public float Blood_8;

	[Token(Token = "0x40000F8")]
	[FieldOffset(Offset = "0x44")]
	public float Blood_9;

	[Token(Token = "0x40000F9")]
	[FieldOffset(Offset = "0x48")]
	public float Blood_10;

	[Token(Token = "0x40000FA")]
	[FieldOffset(Offset = "0x4C")]
	public float Blood_11;

	[Token(Token = "0x40000FB")]
	[FieldOffset(Offset = "0x50")]
	public float Blood_12;

	[Token(Token = "0x40000FC")]
	[FieldOffset(Offset = "0x54")]
	public float LightReflect;

	[Token(Token = "0x40000FD")]
	[FieldOffset(Offset = "0x58")]
	private Material SCMaterial;

	[Token(Token = "0x40000FE")]
	[FieldOffset(Offset = "0x60")]
	private Texture2D Texture2;

	[Token(Token = "0x17000019")]
	private Material material
	{
		[Token(Token = "0x6000082")]
		[Address(RVA = "0x5B8F0C", Offset = "0x5B8F0C", VA = "0x5B8F0C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000083")]
	[Address(RVA = "0x5B8FD0", Offset = "0x5B8FD0", VA = "0x5B8FD0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000084")]
	[Address(RVA = "0x5B9088", Offset = "0x5B9088", VA = "0x5B9088")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000085")]
	[Address(RVA = "0x5B9528", Offset = "0x5B9528", VA = "0x5B9528")]
	private void Update()
	{
	}

	[Token(Token = "0x6000086")]
	[Address(RVA = "0x5B952C", Offset = "0x5B952C", VA = "0x5B952C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000087")]
	[Address(RVA = "0x5B95DC", Offset = "0x5B95DC", VA = "0x5B95DC")]
	public CameraFilterPack_AAA_Blood_Plus()
	{
	}
}
