using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010C")]
public class CameraFilterPack_TV_Horror : MonoBehaviour
{
	[Token(Token = "0x40007B6")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007B7")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007B8")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007B9")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x40007BA")]
	[FieldOffset(Offset = "0x34")]
	public float Distortion;

	[Token(Token = "0x40007BB")]
	[FieldOffset(Offset = "0x38")]
	private Texture2D Texture2;

	[Token(Token = "0x1700010D")]
	private Material material
	{
		[Token(Token = "0x600069F")]
		[Address(RVA = "0x637090", Offset = "0x637090", VA = "0x637090")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006A0")]
	[Address(RVA = "0x637154", Offset = "0x637154", VA = "0x637154")]
	private void Start()
	{
	}

	[Token(Token = "0x60006A1")]
	[Address(RVA = "0x63720C", Offset = "0x63720C", VA = "0x63720C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006A2")]
	[Address(RVA = "0x63746C", Offset = "0x63746C", VA = "0x63746C")]
	private void Update()
	{
	}

	[Token(Token = "0x60006A3")]
	[Address(RVA = "0x637470", Offset = "0x637470", VA = "0x637470")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006A4")]
	[Address(RVA = "0x637520", Offset = "0x637520", VA = "0x637520")]
	public CameraFilterPack_TV_Horror()
	{
	}
}
