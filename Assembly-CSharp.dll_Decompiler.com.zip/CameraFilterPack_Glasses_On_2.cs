using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C5")]
public class CameraFilterPack_Glasses_On_2 : MonoBehaviour
{
	[Token(Token = "0x4000597")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000598")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000599")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x400059A")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x400059B")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x400059C")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x400059D")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x400059E")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x400059F")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x40005A0")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x40005A1")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x40005A2")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x40005A3")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x40005A4")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C6")]
	private Material material
	{
		[Token(Token = "0x60004D2")]
		[Address(RVA = "0x69F0BC", Offset = "0x69F0BC", VA = "0x69F0BC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004D3")]
	[Address(RVA = "0x69F180", Offset = "0x69F180", VA = "0x69F180")]
	private void Start()
	{
	}

	[Token(Token = "0x60004D4")]
	[Address(RVA = "0x69F238", Offset = "0x69F238", VA = "0x69F238")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004D5")]
	[Address(RVA = "0x69F530", Offset = "0x69F530", VA = "0x69F530")]
	private void Update()
	{
	}

	[Token(Token = "0x60004D6")]
	[Address(RVA = "0x69F534", Offset = "0x69F534", VA = "0x69F534")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004D7")]
	[Address(RVA = "0x69F5E4", Offset = "0x69F5E4", VA = "0x69F5E4")]
	public CameraFilterPack_Glasses_On_2()
	{
	}
}
