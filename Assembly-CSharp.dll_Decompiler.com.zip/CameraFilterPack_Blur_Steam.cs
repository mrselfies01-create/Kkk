using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000051")]
public class CameraFilterPack_Blur_Steam : MonoBehaviour
{
	[Token(Token = "0x40002DC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002DD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002DE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002DF")]
	[FieldOffset(Offset = "0x30")]
	public float Radius;

	[Token(Token = "0x40002E0")]
	[FieldOffset(Offset = "0x34")]
	public float Quality;

	[Token(Token = "0x17000052")]
	private Material material
	{
		[Token(Token = "0x6000217")]
		[Address(RVA = "0x668620", Offset = "0x668620", VA = "0x668620")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000218")]
	[Address(RVA = "0x6686E4", Offset = "0x6686E4", VA = "0x6686E4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000219")]
	[Address(RVA = "0x668760", Offset = "0x668760", VA = "0x668760")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600021A")]
	[Address(RVA = "0x66898C", Offset = "0x66898C", VA = "0x66898C")]
	private void Update()
	{
	}

	[Token(Token = "0x600021B")]
	[Address(RVA = "0x668990", Offset = "0x668990", VA = "0x668990")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600021C")]
	[Address(RVA = "0x668A40", Offset = "0x668A40", VA = "0x668A40")]
	public CameraFilterPack_Blur_Steam()
	{
	}
}
