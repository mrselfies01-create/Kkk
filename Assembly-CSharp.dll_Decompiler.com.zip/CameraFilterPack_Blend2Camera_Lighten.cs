using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000033")]
public class CameraFilterPack_Blend2Camera_Lighten : MonoBehaviour
{
	[Token(Token = "0x40001F5")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001F6")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001F7")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001F8")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001F9")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001FA")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001FB")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001FC")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000034")]
	private Material material
	{
		[Token(Token = "0x6000140")]
		[Address(RVA = "0x5C3EF8", Offset = "0x5C3EF8", VA = "0x5C3EF8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000141")]
	[Address(RVA = "0x5C3FBC", Offset = "0x5C3FBC", VA = "0x5C3FBC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000142")]
	[Address(RVA = "0x5C40D4", Offset = "0x5C40D4", VA = "0x5C40D4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000143")]
	[Address(RVA = "0x5C4364", Offset = "0x5C4364", VA = "0x5C4364")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000144")]
	[Address(RVA = "0x5C4450", Offset = "0x5C4450", VA = "0x5C4450")]
	private void Update()
	{
	}

	[Token(Token = "0x6000145")]
	[Address(RVA = "0x5C4454", Offset = "0x5C4454", VA = "0x5C4454")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000146")]
	[Address(RVA = "0x5C4540", Offset = "0x5C4540", VA = "0x5C4540")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000147")]
	[Address(RVA = "0x5C4638", Offset = "0x5C4638", VA = "0x5C4638")]
	public CameraFilterPack_Blend2Camera_Lighten()
	{
	}
}
