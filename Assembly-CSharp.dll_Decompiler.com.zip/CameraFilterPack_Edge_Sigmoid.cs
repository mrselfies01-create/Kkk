using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A2")]
public class CameraFilterPack_Edge_Sigmoid : MonoBehaviour
{
	[Token(Token = "0x40004CD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004CE")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004CF")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004D0")]
	[FieldOffset(Offset = "0x30")]
	public float Gain;

	[Token(Token = "0x170000A3")]
	private Material material
	{
		[Token(Token = "0x6000400")]
		[Address(RVA = "0x695888", Offset = "0x695888", VA = "0x695888")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000401")]
	[Address(RVA = "0x69594C", Offset = "0x69594C", VA = "0x69594C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000402")]
	[Address(RVA = "0x6959C8", Offset = "0x6959C8", VA = "0x6959C8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000403")]
	[Address(RVA = "0x695BD0", Offset = "0x695BD0", VA = "0x695BD0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000404")]
	[Address(RVA = "0x695BD4", Offset = "0x695BD4", VA = "0x695BD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000405")]
	[Address(RVA = "0x695C84", Offset = "0x695C84", VA = "0x695C84")]
	public CameraFilterPack_Edge_Sigmoid()
	{
	}
}
