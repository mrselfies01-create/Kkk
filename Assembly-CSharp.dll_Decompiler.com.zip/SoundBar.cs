using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200013D")]
public class SoundBar : MonoBehaviour
{
	[Token(Token = "0x4000936")]
	[FieldOffset(Offset = "0x18")]
	public Renderer cube;

	[Token(Token = "0x4000937")]
	[FieldOffset(Offset = "0x20")]
	public Renderer ray;

	[Token(Token = "0x4000938")]
	[FieldOffset(Offset = "0x28")]
	public ParticleSystem pSystem;

	[Token(Token = "0x60007C2")]
	[Address(RVA = "0x3DD1F8", Offset = "0x3DD1F8", VA = "0x3DD1F8")]
	public SoundBar()
	{
	}
}
