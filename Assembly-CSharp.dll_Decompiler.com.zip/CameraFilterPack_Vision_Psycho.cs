using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012B")]
public class CameraFilterPack_Vision_Psycho : MonoBehaviour
{
	[Token(Token = "0x4000871")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000872")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000873")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000874")]
	[FieldOffset(Offset = "0x30")]
	public float HoleSize;

	[Token(Token = "0x4000875")]
	[FieldOffset(Offset = "0x34")]
	public float HoleSmooth;

	[Token(Token = "0x4000876")]
	[FieldOffset(Offset = "0x38")]
	public float Color1;

	[Token(Token = "0x4000877")]
	[FieldOffset(Offset = "0x3C")]
	public float Color2;

	[Token(Token = "0x1700012C")]
	private Material material
	{
		[Token(Token = "0x6000759")]
		[Address(RVA = "0x63F830", Offset = "0x63F830", VA = "0x63F830")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600075A")]
	[Address(RVA = "0x63F8F4", Offset = "0x63F8F4", VA = "0x63F8F4")]
	private void Start()
	{
	}

	[Token(Token = "0x600075B")]
	[Address(RVA = "0x63F970", Offset = "0x63F970", VA = "0x63F970")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600075C")]
	[Address(RVA = "0x63FBF4", Offset = "0x63FBF4", VA = "0x63FBF4")]
	private void Update()
	{
	}

	[Token(Token = "0x600075D")]
	[Address(RVA = "0x63FBF8", Offset = "0x63FBF8", VA = "0x63FBF8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600075E")]
	[Address(RVA = "0x63FCA8", Offset = "0x63FCA8", VA = "0x63FCA8")]
	public CameraFilterPack_Vision_Psycho()
	{
	}
}
