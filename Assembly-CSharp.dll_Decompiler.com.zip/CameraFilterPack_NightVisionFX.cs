using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E9")]
public class CameraFilterPack_NightVisionFX : MonoBehaviour
{
	[Token(Token = "0x20001F3")]
	public enum preset
	{
		[Token(Token = "0x4000D6E")]
		Night_Vision_Personalized = -1,
		[Token(Token = "0x4000D6F")]
		Night_Vision_FX,
		[Token(Token = "0x4000D70")]
		Night_Vision_Classic,
		[Token(Token = "0x4000D71")]
		Night_Vision_Full,
		[Token(Token = "0x4000D72")]
		Night_Vision_Dark,
		[Token(Token = "0x4000D73")]
		Night_Vision_Sharp,
		[Token(Token = "0x4000D74")]
		Night_Vision_BlueSky,
		[Token(Token = "0x4000D75")]
		Night_Vision_Low_Light,
		[Token(Token = "0x4000D76")]
		Night_Vision_Pinky,
		[Token(Token = "0x4000D77")]
		Night_Vision_RedBurn,
		[Token(Token = "0x4000D78")]
		Night_Vision_PurpleShadow
	}

	[Token(Token = "0x40006B8")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006B9")]
	[FieldOffset(Offset = "0x20")]
	public preset Preset;

	[Token(Token = "0x40006BA")]
	[FieldOffset(Offset = "0x24")]
	private preset PresetMemo;

	[Token(Token = "0x40006BB")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x40006BC")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40006BD")]
	[FieldOffset(Offset = "0x38")]
	public float OnOff;

	[Token(Token = "0x40006BE")]
	[FieldOffset(Offset = "0x3C")]
	public float Greenness;

	[Token(Token = "0x40006BF")]
	[FieldOffset(Offset = "0x40")]
	public float Vignette;

	[Token(Token = "0x40006C0")]
	[FieldOffset(Offset = "0x44")]
	public float Vignette_Alpha;

	[Token(Token = "0x40006C1")]
	[FieldOffset(Offset = "0x48")]
	public float Distortion;

	[Token(Token = "0x40006C2")]
	[FieldOffset(Offset = "0x4C")]
	public float Noise;

	[Token(Token = "0x40006C3")]
	[FieldOffset(Offset = "0x50")]
	public float Intensity;

	[Token(Token = "0x40006C4")]
	[FieldOffset(Offset = "0x54")]
	public float Light;

	[Token(Token = "0x40006C5")]
	[FieldOffset(Offset = "0x58")]
	public float Light2;

	[Token(Token = "0x40006C6")]
	[FieldOffset(Offset = "0x5C")]
	public float Line;

	[Token(Token = "0x40006C7")]
	[FieldOffset(Offset = "0x60")]
	public float Color_R;

	[Token(Token = "0x40006C8")]
	[FieldOffset(Offset = "0x64")]
	public float Color_G;

	[Token(Token = "0x40006C9")]
	[FieldOffset(Offset = "0x68")]
	public float Color_B;

	[Token(Token = "0x40006CA")]
	[FieldOffset(Offset = "0x6C")]
	public float _Binocular_Size;

	[Token(Token = "0x40006CB")]
	[FieldOffset(Offset = "0x70")]
	public float _Binocular_Smooth;

	[Token(Token = "0x40006CC")]
	[FieldOffset(Offset = "0x74")]
	public float _Binocular_Dist;

	[Token(Token = "0x170000EA")]
	private Material material
	{
		[Token(Token = "0x60005C6")]
		[Address(RVA = "0x62BF04", Offset = "0x62BF04", VA = "0x62BF04")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005C7")]
	[Address(RVA = "0x62BFC8", Offset = "0x62BFC8", VA = "0x62BFC8")]
	private void Start()
	{
	}

	[Token(Token = "0x60005C8")]
	[Address(RVA = "0x62C044", Offset = "0x62C044", VA = "0x62C044")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005C9")]
	[Address(RVA = "0x62C468", Offset = "0x62C468", VA = "0x62C468")]
	private void Update()
	{
	}

	[Token(Token = "0x60005CA")]
	[Address(RVA = "0x62C7BC", Offset = "0x62C7BC", VA = "0x62C7BC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005CB")]
	[Address(RVA = "0x62C86C", Offset = "0x62C86C", VA = "0x62C86C")]
	public CameraFilterPack_NightVisionFX()
	{
	}
}
