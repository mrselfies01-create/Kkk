using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008B")]
public class CameraFilterPack_Drawing_Halftone : MonoBehaviour
{
	[Token(Token = "0x400043B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400043C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400043D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400043E")]
	[FieldOffset(Offset = "0x30")]
	public float Threshold;

	[Token(Token = "0x400043F")]
	[FieldOffset(Offset = "0x34")]
	public float DotSize;

	[Token(Token = "0x1700008C")]
	private Material material
	{
		[Token(Token = "0x6000375")]
		[Address(RVA = "0x679074", Offset = "0x679074", VA = "0x679074")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000376")]
	[Address(RVA = "0x679138", Offset = "0x679138", VA = "0x679138")]
	private void Start()
	{
	}

	[Token(Token = "0x6000377")]
	[Address(RVA = "0x6791B4", Offset = "0x6791B4", VA = "0x6791B4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000378")]
	[Address(RVA = "0x67935C", Offset = "0x67935C", VA = "0x67935C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000379")]
	[Address(RVA = "0x679360", Offset = "0x679360", VA = "0x679360")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600037A")]
	[Address(RVA = "0x679410", Offset = "0x679410", VA = "0x679410")]
	public CameraFilterPack_Drawing_Halftone()
	{
	}
}
