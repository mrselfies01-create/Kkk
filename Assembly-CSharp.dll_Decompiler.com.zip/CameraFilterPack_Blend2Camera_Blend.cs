using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000024")]
public class CameraFilterPack_Blend2Camera_Blend : MonoBehaviour
{
	[Token(Token = "0x400016B")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400016C")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400016D")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x400016E")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400016F")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000170")]
	[FieldOffset(Offset = "0x40")]
	public float BlendFX;

	[Token(Token = "0x4000171")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000025")]
	private Material material
	{
		[Token(Token = "0x60000CA")]
		[Address(RVA = "0x5BCFE0", Offset = "0x5BCFE0", VA = "0x5BCFE0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000CB")]
	[Address(RVA = "0x5BD0A4", Offset = "0x5BD0A4", VA = "0x5BD0A4")]
	private void Start()
	{
	}

	[Token(Token = "0x60000CC")]
	[Address(RVA = "0x5BD1BC", Offset = "0x5BD1BC", VA = "0x5BD1BC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000CD")]
	[Address(RVA = "0x5BD3F8", Offset = "0x5BD3F8", VA = "0x5BD3F8")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000CE")]
	[Address(RVA = "0x5BD4E4", Offset = "0x5BD4E4", VA = "0x5BD4E4")]
	private void Update()
	{
	}

	[Token(Token = "0x60000CF")]
	[Address(RVA = "0x5BD4E8", Offset = "0x5BD4E8", VA = "0x5BD4E8")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000D0")]
	[Address(RVA = "0x5BD5D4", Offset = "0x5BD5D4", VA = "0x5BD5D4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000D1")]
	[Address(RVA = "0x5BD6CC", Offset = "0x5BD6CC", VA = "0x5BD6CC")]
	public CameraFilterPack_Blend2Camera_Blend()
	{
	}
}
