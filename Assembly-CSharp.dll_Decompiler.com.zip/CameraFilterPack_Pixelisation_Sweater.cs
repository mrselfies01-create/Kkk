using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FA")]
public class CameraFilterPack_Pixelisation_Sweater : MonoBehaviour
{
	[Token(Token = "0x400073A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400073B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400073C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400073D")]
	[FieldOffset(Offset = "0x30")]
	public float SweaterSize;

	[Token(Token = "0x400073E")]
	[FieldOffset(Offset = "0x34")]
	public float _Intensity;

	[Token(Token = "0x400073F")]
	[FieldOffset(Offset = "0x38")]
	public float Fade;

	[Token(Token = "0x4000740")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000FB")]
	private Material material
	{
		[Token(Token = "0x6000632")]
		[Address(RVA = "0x631A64", Offset = "0x631A64", VA = "0x631A64")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000633")]
	[Address(RVA = "0x631B28", Offset = "0x631B28", VA = "0x631B28")]
	private void Start()
	{
	}

	[Token(Token = "0x6000634")]
	[Address(RVA = "0x631BE0", Offset = "0x631BE0", VA = "0x631BE0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000635")]
	[Address(RVA = "0x631DD0", Offset = "0x631DD0", VA = "0x631DD0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000636")]
	[Address(RVA = "0x631DD4", Offset = "0x631DD4", VA = "0x631DD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000637")]
	[Address(RVA = "0x631E84", Offset = "0x631E84", VA = "0x631E84")]
	public CameraFilterPack_Pixelisation_Sweater()
	{
	}
}
