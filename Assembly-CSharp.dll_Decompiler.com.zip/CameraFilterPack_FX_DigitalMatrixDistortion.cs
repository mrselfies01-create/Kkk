using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AB")]
public class CameraFilterPack_FX_DigitalMatrixDistortion : MonoBehaviour
{
	[Token(Token = "0x4000504")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000505")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000506")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000507")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000508")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000509")]
	[FieldOffset(Offset = "0x38")]
	public float Distortion;

	[Token(Token = "0x170000AC")]
	private Material material
	{
		[Token(Token = "0x6000436")]
		[Address(RVA = "0x697F20", Offset = "0x697F20", VA = "0x697F20")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000437")]
	[Address(RVA = "0x697FE4", Offset = "0x697FE4", VA = "0x697FE4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000438")]
	[Address(RVA = "0x698060", Offset = "0x698060", VA = "0x698060")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000439")]
	[Address(RVA = "0x6982C0", Offset = "0x6982C0", VA = "0x6982C0")]
	private void Update()
	{
	}

	[Token(Token = "0x600043A")]
	[Address(RVA = "0x6982C4", Offset = "0x6982C4", VA = "0x6982C4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600043B")]
	[Address(RVA = "0x698374", Offset = "0x698374", VA = "0x698374")]
	public CameraFilterPack_FX_DigitalMatrixDistortion()
	{
	}
}
