using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BB")]
public class CameraFilterPack_FX_Psycho : MonoBehaviour
{
	[Token(Token = "0x4000557")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000558")]
	[FieldOffset(Offset = "0x20")]
	private Material SCMaterial;

	[Token(Token = "0x4000559")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x400055A")]
	[FieldOffset(Offset = "0x2C")]
	public float Distortion;

	[Token(Token = "0x170000BC")]
	private Material material
	{
		[Token(Token = "0x6000496")]
		[Address(RVA = "0x69C34C", Offset = "0x69C34C", VA = "0x69C34C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000497")]
	[Address(RVA = "0x69C410", Offset = "0x69C410", VA = "0x69C410")]
	private void Start()
	{
	}

	[Token(Token = "0x6000498")]
	[Address(RVA = "0x69C48C", Offset = "0x69C48C", VA = "0x69C48C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000499")]
	[Address(RVA = "0x69C610", Offset = "0x69C610", VA = "0x69C610")]
	private void Update()
	{
	}

	[Token(Token = "0x600049A")]
	[Address(RVA = "0x69C614", Offset = "0x69C614", VA = "0x69C614")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600049B")]
	[Address(RVA = "0x69C6C4", Offset = "0x69C6C4", VA = "0x69C6C4")]
	public CameraFilterPack_FX_Psycho()
	{
	}
}
