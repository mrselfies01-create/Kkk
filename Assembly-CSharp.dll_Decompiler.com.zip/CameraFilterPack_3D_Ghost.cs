using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000D")]
public class CameraFilterPack_3D_Ghost : MonoBehaviour
{
	[Token(Token = "0x4000061")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000062")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000063")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000064")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000065")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000066")]
	[FieldOffset(Offset = "0x34")]
	public float Ghost_Near;

	[Token(Token = "0x4000067")]
	[FieldOffset(Offset = "0x38")]
	public float Ghost_Far;

	[Token(Token = "0x4000068")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000069")]
	[FieldOffset(Offset = "0x40")]
	public float GhostWithoutObject;

	[Token(Token = "0x400006A")]
	[FieldOffset(Offset = "0x44")]
	public float GhostPosX;

	[Token(Token = "0x400006B")]
	[FieldOffset(Offset = "0x48")]
	public float GhostPosY;

	[Token(Token = "0x400006C")]
	[FieldOffset(Offset = "0x4C")]
	public float GhostFade2;

	[Token(Token = "0x400006D")]
	[FieldOffset(Offset = "0x50")]
	public float GhostFade;

	[Token(Token = "0x400006E")]
	[FieldOffset(Offset = "0x54")]
	public float GhostSize;

	[Token(Token = "0x1700000E")]
	private Material material
	{
		[Token(Token = "0x6000040")]
		[Address(RVA = "0x5B4E34", Offset = "0x5B4E34", VA = "0x5B4E34")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000041")]
	[Address(RVA = "0x5B4EF8", Offset = "0x5B4EF8", VA = "0x5B4EF8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000042")]
	[Address(RVA = "0x5B4F74", Offset = "0x5B4F74", VA = "0x5B4F74")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000043")]
	[Address(RVA = "0x5B5328", Offset = "0x5B5328", VA = "0x5B5328")]
	private void Update()
	{
	}

	[Token(Token = "0x6000044")]
	[Address(RVA = "0x5B532C", Offset = "0x5B532C", VA = "0x5B532C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000045")]
	[Address(RVA = "0x5B53DC", Offset = "0x5B53DC", VA = "0x5B53DC")]
	public CameraFilterPack_3D_Ghost()
	{
	}
}
