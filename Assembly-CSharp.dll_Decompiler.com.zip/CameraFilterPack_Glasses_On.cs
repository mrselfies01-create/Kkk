using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C4")]
public class CameraFilterPack_Glasses_On : MonoBehaviour
{
	[Token(Token = "0x4000589")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400058A")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400058B")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x400058C")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x400058D")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x400058E")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x400058F")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x4000590")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x4000591")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x4000592")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x4000593")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x4000594")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x4000595")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x4000596")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C5")]
	private Material material
	{
		[Token(Token = "0x60004CC")]
		[Address(RVA = "0x69EAB4", Offset = "0x69EAB4", VA = "0x69EAB4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004CD")]
	[Address(RVA = "0x69EB78", Offset = "0x69EB78", VA = "0x69EB78")]
	private void Start()
	{
	}

	[Token(Token = "0x60004CE")]
	[Address(RVA = "0x69EC30", Offset = "0x69EC30", VA = "0x69EC30")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004CF")]
	[Address(RVA = "0x69EF28", Offset = "0x69EF28", VA = "0x69EF28")]
	private void Update()
	{
	}

	[Token(Token = "0x60004D0")]
	[Address(RVA = "0x69EF2C", Offset = "0x69EF2C", VA = "0x69EF2C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004D1")]
	[Address(RVA = "0x69EFDC", Offset = "0x69EFDC", VA = "0x69EFDC")]
	public CameraFilterPack_Glasses_On()
	{
	}
}
