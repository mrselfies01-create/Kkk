using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D4")]
public class CameraFilterPack_Gradients_Stripe : MonoBehaviour
{
	[Token(Token = "0x400061F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000620")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x4000621")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x4000622")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000623")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000624")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D5")]
	private Material material
	{
		[Token(Token = "0x600052C")]
		[Address(RVA = "0x6A405C", Offset = "0x6A405C", VA = "0x6A405C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600052D")]
	[Address(RVA = "0x6A4120", Offset = "0x6A4120", VA = "0x6A4120")]
	private void Start()
	{
	}

	[Token(Token = "0x600052E")]
	[Address(RVA = "0x6A4170", Offset = "0x6A4170", VA = "0x6A4170")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600052F")]
	[Address(RVA = "0x6A43AC", Offset = "0x6A43AC", VA = "0x6A43AC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000530")]
	[Address(RVA = "0x6A43B0", Offset = "0x6A43B0", VA = "0x6A43B0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000531")]
	[Address(RVA = "0x6A4460", Offset = "0x6A4460", VA = "0x6A4460")]
	public CameraFilterPack_Gradients_Stripe()
	{
	}
}
