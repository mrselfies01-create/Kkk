using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012F")]
public class CameraFilterPack_Vision_Warp : MonoBehaviour
{
	[Token(Token = "0x4000896")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000897")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000898")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000899")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x400089A")]
	[FieldOffset(Offset = "0x34")]
	public float Value2;

	[Token(Token = "0x400089B")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x400089C")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000130")]
	private Material material
	{
		[Token(Token = "0x6000771")]
		[Address(RVA = "0x640C28", Offset = "0x640C28", VA = "0x640C28")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000772")]
	[Address(RVA = "0x640CEC", Offset = "0x640CEC", VA = "0x640CEC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000773")]
	[Address(RVA = "0x640D68", Offset = "0x640D68", VA = "0x640D68")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000774")]
	[Address(RVA = "0x640FEC", Offset = "0x640FEC", VA = "0x640FEC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000775")]
	[Address(RVA = "0x640FF0", Offset = "0x640FF0", VA = "0x640FF0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000776")]
	[Address(RVA = "0x6410A0", Offset = "0x6410A0", VA = "0x6410A0")]
	public CameraFilterPack_Vision_Warp()
	{
	}
}
