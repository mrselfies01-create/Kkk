using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DB")]
public class CameraFilterPack_Lut_2_Lut : MonoBehaviour
{
	[Token(Token = "0x4000647")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000648")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000649")]
	[FieldOffset(Offset = "0x24")]
	private Vector4 ScreenResolution;

	[Token(Token = "0x400064A")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400064B")]
	[FieldOffset(Offset = "0x40")]
	public Texture2D LutTexture;

	[Token(Token = "0x400064C")]
	[FieldOffset(Offset = "0x48")]
	public Texture2D LutTexture2;

	[Token(Token = "0x400064D")]
	[FieldOffset(Offset = "0x50")]
	private Texture3D converted3DLut;

	[Token(Token = "0x400064E")]
	[FieldOffset(Offset = "0x58")]
	private Texture3D converted3DLut2;

	[Token(Token = "0x400064F")]
	[FieldOffset(Offset = "0x60")]
	public float Blend;

	[Token(Token = "0x4000650")]
	[FieldOffset(Offset = "0x64")]
	public float Fade;

	[Token(Token = "0x4000651")]
	[FieldOffset(Offset = "0x68")]
	private string MemoPath;

	[Token(Token = "0x4000652")]
	[FieldOffset(Offset = "0x70")]
	private string MemoPath2;

	[Token(Token = "0x170000DC")]
	private Material material
	{
		[Token(Token = "0x6000556")]
		[Address(RVA = "0x6A5EF4", Offset = "0x6A5EF4", VA = "0x6A5EF4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000557")]
	[Address(RVA = "0x6A5FB8", Offset = "0x6A5FB8", VA = "0x6A5FB8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000558")]
	[Address(RVA = "0x6A6034", Offset = "0x6A6034", VA = "0x6A6034")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x6000559")]
	[Address(RVA = "0x6A62C4", Offset = "0x6A62C4", VA = "0x6A62C4")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x600055A")]
	[Address(RVA = "0x6A63B8", Offset = "0x6A63B8", VA = "0x6A63B8")]
	public Texture3D Convert(Texture2D temp2DTex, Texture3D cv3D)
	{
		return null;
	}

	[Token(Token = "0x600055B")]
	[Address(RVA = "0x6A6664", Offset = "0x6A6664", VA = "0x6A6664")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600055C")]
	[Address(RVA = "0x6A6A1C", Offset = "0x6A6A1C", VA = "0x6A6A1C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600055D")]
	[Address(RVA = "0x6A6A20", Offset = "0x6A6A20", VA = "0x6A6A20")]
	private void Update()
	{
	}

	[Token(Token = "0x600055E")]
	[Address(RVA = "0x6A6A24", Offset = "0x6A6A24", VA = "0x6A6A24")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600055F")]
	[Address(RVA = "0x6A6AD4", Offset = "0x6A6AD4", VA = "0x6A6AD4")]
	public CameraFilterPack_Lut_2_Lut()
	{
	}
}
