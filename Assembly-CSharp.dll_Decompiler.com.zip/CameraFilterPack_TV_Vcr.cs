using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000119")]
public class CameraFilterPack_TV_Vcr : MonoBehaviour
{
	[Token(Token = "0x40007FE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007FF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000800")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x4000801")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700011A")]
	private Material material
	{
		[Token(Token = "0x60006ED")]
		[Address(RVA = "0x63A7D8", Offset = "0x63A7D8", VA = "0x63A7D8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006EE")]
	[Address(RVA = "0x63A89C", Offset = "0x63A89C", VA = "0x63A89C")]
	private void Start()
	{
	}

	[Token(Token = "0x60006EF")]
	[Address(RVA = "0x63A918", Offset = "0x63A918", VA = "0x63A918")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006F0")]
	[Address(RVA = "0x63AA9C", Offset = "0x63AA9C", VA = "0x63AA9C")]
	private void Update()
	{
	}

	[Token(Token = "0x60006F1")]
	[Address(RVA = "0x63AAA0", Offset = "0x63AAA0", VA = "0x63AAA0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006F2")]
	[Address(RVA = "0x63AB50", Offset = "0x63AB50", VA = "0x63AB50")]
	public CameraFilterPack_TV_Vcr()
	{
	}
}
