using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000069")]
public class CameraFilterPack_Colors_Brightness : MonoBehaviour
{
	[Token(Token = "0x4000373")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000374")]
	[FieldOffset(Offset = "0x20")]
	public float _Brightness;

	[Token(Token = "0x4000375")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700006A")]
	private Material material
	{
		[Token(Token = "0x60002A9")]
		[Address(RVA = "0x66FF7C", Offset = "0x66FF7C", VA = "0x66FF7C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002AA")]
	[Address(RVA = "0x670040", Offset = "0x670040", VA = "0x670040")]
	private void Start()
	{
	}

	[Token(Token = "0x60002AB")]
	[Address(RVA = "0x6700BC", Offset = "0x6700BC", VA = "0x6700BC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002AC")]
	[Address(RVA = "0x6701E8", Offset = "0x6701E8", VA = "0x6701E8")]
	private void Update()
	{
	}

	[Token(Token = "0x60002AD")]
	[Address(RVA = "0x6701EC", Offset = "0x6701EC", VA = "0x6701EC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002AE")]
	[Address(RVA = "0x67029C", Offset = "0x67029C", VA = "0x67029C")]
	public CameraFilterPack_Colors_Brightness()
	{
	}
}
