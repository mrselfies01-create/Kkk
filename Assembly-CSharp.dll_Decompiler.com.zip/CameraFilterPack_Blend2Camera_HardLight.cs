using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000030")]
public class CameraFilterPack_Blend2Camera_HardLight : MonoBehaviour
{
	[Token(Token = "0x40001DD")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001DE")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001DF")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001E0")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001E1")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001E2")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001E3")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001E4")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000031")]
	private Material material
	{
		[Token(Token = "0x6000128")]
		[Address(RVA = "0x5C2800", Offset = "0x5C2800", VA = "0x5C2800")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000129")]
	[Address(RVA = "0x5C28C4", Offset = "0x5C28C4", VA = "0x5C28C4")]
	private void Start()
	{
	}

	[Token(Token = "0x600012A")]
	[Address(RVA = "0x5C29DC", Offset = "0x5C29DC", VA = "0x5C29DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600012B")]
	[Address(RVA = "0x5C2C6C", Offset = "0x5C2C6C", VA = "0x5C2C6C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600012C")]
	[Address(RVA = "0x5C2D58", Offset = "0x5C2D58", VA = "0x5C2D58")]
	private void Update()
	{
	}

	[Token(Token = "0x600012D")]
	[Address(RVA = "0x5C2D5C", Offset = "0x5C2D5C", VA = "0x5C2D5C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600012E")]
	[Address(RVA = "0x5C2E48", Offset = "0x5C2E48", VA = "0x5C2E48")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600012F")]
	[Address(RVA = "0x5C2F40", Offset = "0x5C2F40", VA = "0x5C2F40")]
	public CameraFilterPack_Blend2Camera_HardLight()
	{
	}
}
