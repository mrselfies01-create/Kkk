using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000007")]
public class CameraFilterPack_3D_Anomaly : MonoBehaviour
{
	[Token(Token = "0x4000015")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000016")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x4000017")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000018")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000019")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x400001A")]
	[FieldOffset(Offset = "0x34")]
	public float Anomaly_Near;

	[Token(Token = "0x400001B")]
	[FieldOffset(Offset = "0x38")]
	public float Anomaly_Far;

	[Token(Token = "0x400001C")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x400001D")]
	[FieldOffset(Offset = "0x40")]
	public float AnomalyWithoutObject;

	[Token(Token = "0x400001E")]
	[FieldOffset(Offset = "0x44")]
	public float Anomaly_Distortion;

	[Token(Token = "0x400001F")]
	[FieldOffset(Offset = "0x48")]
	public float Anomaly_Distortion_Size;

	[Token(Token = "0x4000020")]
	[FieldOffset(Offset = "0x4C")]
	public float Anomaly_Intensity;

	[Token(Token = "0x17000008")]
	private Material material
	{
		[Token(Token = "0x600001C")]
		[Address(RVA = "0x5B2A10", Offset = "0x5B2A10", VA = "0x5B2A10")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600001D")]
	[Address(RVA = "0x5B2AD4", Offset = "0x5B2AD4", VA = "0x5B2AD4")]
	private void Start()
	{
	}

	[Token(Token = "0x600001E")]
	[Address(RVA = "0x5B2B50", Offset = "0x5B2B50", VA = "0x5B2B50")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600001F")]
	[Address(RVA = "0x5B2EBC", Offset = "0x5B2EBC", VA = "0x5B2EBC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000020")]
	[Address(RVA = "0x5B2EC0", Offset = "0x5B2EC0", VA = "0x5B2EC0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000021")]
	[Address(RVA = "0x5B2F70", Offset = "0x5B2F70", VA = "0x5B2F70")]
	public CameraFilterPack_3D_Anomaly()
	{
	}
}
