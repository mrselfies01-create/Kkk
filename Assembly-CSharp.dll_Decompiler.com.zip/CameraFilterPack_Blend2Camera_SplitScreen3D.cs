using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000041")]
public class CameraFilterPack_Blend2Camera_SplitScreen3D : MonoBehaviour
{
	[Token(Token = "0x400026D")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400026E")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400026F")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000270")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000271")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000272")]
	[FieldOffset(Offset = "0x40")]
	public float _FixDistance;

	[Token(Token = "0x4000273")]
	[FieldOffset(Offset = "0x44")]
	public float _Distance;

	[Token(Token = "0x4000274")]
	[FieldOffset(Offset = "0x48")]
	public float _Size;

	[Token(Token = "0x4000275")]
	[FieldOffset(Offset = "0x4C")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000276")]
	[FieldOffset(Offset = "0x50")]
	public float BlendFX;

	[Token(Token = "0x4000277")]
	[FieldOffset(Offset = "0x54")]
	public float SplitX;

	[Token(Token = "0x4000278")]
	[FieldOffset(Offset = "0x58")]
	public float SplitY;

	[Token(Token = "0x4000279")]
	[FieldOffset(Offset = "0x5C")]
	public float Smooth;

	[Token(Token = "0x400027A")]
	[FieldOffset(Offset = "0x60")]
	public float Rotation;

	[Token(Token = "0x400027B")]
	[FieldOffset(Offset = "0x64")]
	private bool ForceYSwap;

	[Token(Token = "0x400027C")]
	[FieldOffset(Offset = "0x68")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x400027D")]
	[FieldOffset(Offset = "0x70")]
	private Vector2 ScreenSize;

	[Token(Token = "0x17000042")]
	private Material material
	{
		[Token(Token = "0x60001B1")]
		[Address(RVA = "0x663398", Offset = "0x663398", VA = "0x663398")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001B2")]
	[Address(RVA = "0x66345C", Offset = "0x66345C", VA = "0x66345C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60001B3")]
	[Address(RVA = "0x663498", Offset = "0x663498", VA = "0x663498")]
	private void Start()
	{
	}

	[Token(Token = "0x60001B4")]
	[Address(RVA = "0x663598", Offset = "0x663598", VA = "0x663598")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001B5")]
	[Address(RVA = "0x6638E8", Offset = "0x6638E8", VA = "0x6638E8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001B6")]
	[Address(RVA = "0x663924", Offset = "0x663924", VA = "0x663924")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60001B7")]
	[Address(RVA = "0x663928", Offset = "0x663928", VA = "0x663928")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001B8")]
	[Address(RVA = "0x663A20", Offset = "0x663A20", VA = "0x663A20")]
	public CameraFilterPack_Blend2Camera_SplitScreen3D()
	{
	}
}
