using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000038")]
public class CameraFilterPack_Blend2Camera_Luminosity : MonoBehaviour
{
	[Token(Token = "0x400021D")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400021E")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400021F")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000220")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000221")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000222")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000223")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000224")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000039")]
	private Material material
	{
		[Token(Token = "0x6000168")]
		[Address(RVA = "0x5C6540", Offset = "0x5C6540", VA = "0x5C6540")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000169")]
	[Address(RVA = "0x5C6604", Offset = "0x5C6604", VA = "0x5C6604")]
	private void Start()
	{
	}

	[Token(Token = "0x600016A")]
	[Address(RVA = "0x5C671C", Offset = "0x5C671C", VA = "0x5C671C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600016B")]
	[Address(RVA = "0x5C69AC", Offset = "0x5C69AC", VA = "0x5C69AC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600016C")]
	[Address(RVA = "0x5C6A98", Offset = "0x5C6A98", VA = "0x5C6A98")]
	private void Update()
	{
	}

	[Token(Token = "0x600016D")]
	[Address(RVA = "0x5C6A9C", Offset = "0x5C6A9C", VA = "0x5C6A9C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600016E")]
	[Address(RVA = "0x5C6B88", Offset = "0x5C6B88", VA = "0x5C6B88")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600016F")]
	[Address(RVA = "0x5C6C80", Offset = "0x5C6C80", VA = "0x5C6C80")]
	public CameraFilterPack_Blend2Camera_Luminosity()
	{
	}
}
