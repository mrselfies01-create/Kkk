using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AD")]
public class CameraFilterPack_FX_Drunk : MonoBehaviour
{
	[Token(Token = "0x400050E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400050F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000510")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000511")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x4000512")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000513")]
	[FieldOffset(Offset = "0x38")]
	public float Wavy;

	[Token(Token = "0x4000514")]
	[FieldOffset(Offset = "0x3C")]
	public float Distortion;

	[Token(Token = "0x4000515")]
	[FieldOffset(Offset = "0x40")]
	public float DistortionWave;

	[Token(Token = "0x4000516")]
	[FieldOffset(Offset = "0x44")]
	public float Fade;

	[Token(Token = "0x4000517")]
	[FieldOffset(Offset = "0x48")]
	public float ColoredSaturate;

	[Token(Token = "0x4000518")]
	[FieldOffset(Offset = "0x4C")]
	public float ColoredChange;

	[Token(Token = "0x4000519")]
	[FieldOffset(Offset = "0x50")]
	public float ChangeRed;

	[Token(Token = "0x400051A")]
	[FieldOffset(Offset = "0x54")]
	public float ChangeGreen;

	[Token(Token = "0x400051B")]
	[FieldOffset(Offset = "0x58")]
	public float ChangeBlue;

	[Token(Token = "0x170000AE")]
	private Material material
	{
		[Token(Token = "0x6000442")]
		[Address(RVA = "0x6987C0", Offset = "0x6987C0", VA = "0x6987C0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000443")]
	[Address(RVA = "0x698884", Offset = "0x698884", VA = "0x698884")]
	private void Start()
	{
	}

	[Token(Token = "0x6000444")]
	[Address(RVA = "0x698900", Offset = "0x698900", VA = "0x698900")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000445")]
	[Address(RVA = "0x698C80", Offset = "0x698C80", VA = "0x698C80")]
	private void Update()
	{
	}

	[Token(Token = "0x6000446")]
	[Address(RVA = "0x698C84", Offset = "0x698C84", VA = "0x698C84")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000447")]
	[Address(RVA = "0x698D34", Offset = "0x698D34", VA = "0x698D34")]
	public CameraFilterPack_FX_Drunk()
	{
	}
}
