using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F0")]
public class CameraFilterPack_Oculus_NightVision3 : MonoBehaviour
{
	[Token(Token = "0x40006F7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006F8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006F9")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006FA")]
	[FieldOffset(Offset = "0x30")]
	public float Greenness;

	[Token(Token = "0x170000F1")]
	private Material material
	{
		[Token(Token = "0x60005F4")]
		[Address(RVA = "0x62EB0C", Offset = "0x62EB0C", VA = "0x62EB0C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005F5")]
	[Address(RVA = "0x62EBD0", Offset = "0x62EBD0", VA = "0x62EBD0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005F6")]
	[Address(RVA = "0x62EC4C", Offset = "0x62EC4C", VA = "0x62EC4C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005F7")]
	[Address(RVA = "0x62EE54", Offset = "0x62EE54", VA = "0x62EE54")]
	private void Update()
	{
	}

	[Token(Token = "0x60005F8")]
	[Address(RVA = "0x62EE58", Offset = "0x62EE58", VA = "0x62EE58")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005F9")]
	[Address(RVA = "0x62EF08", Offset = "0x62EF08", VA = "0x62EF08")]
	public CameraFilterPack_Oculus_NightVision3()
	{
	}
}
