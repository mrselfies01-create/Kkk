using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000106")]
public class CameraFilterPack_TV_BrokenGlass : MonoBehaviour
{
	[Token(Token = "0x4000787")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000788")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000789")]
	[FieldOffset(Offset = "0x24")]
	public float Broken_Small;

	[Token(Token = "0x400078A")]
	[FieldOffset(Offset = "0x28")]
	public float Broken_Medium;

	[Token(Token = "0x400078B")]
	[FieldOffset(Offset = "0x2C")]
	public float Broken_High;

	[Token(Token = "0x400078C")]
	[FieldOffset(Offset = "0x30")]
	public float Broken_Big;

	[Token(Token = "0x400078D")]
	[FieldOffset(Offset = "0x34")]
	public float LightReflect;

	[Token(Token = "0x400078E")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400078F")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x17000107")]
	private Material material
	{
		[Token(Token = "0x600067B")]
		[Address(RVA = "0x635420", Offset = "0x635420", VA = "0x635420")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600067C")]
	[Address(RVA = "0x6354E4", Offset = "0x6354E4", VA = "0x6354E4")]
	private void Start()
	{
	}

	[Token(Token = "0x600067D")]
	[Address(RVA = "0x63559C", Offset = "0x63559C", VA = "0x63559C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600067E")]
	[Address(RVA = "0x6357D4", Offset = "0x6357D4", VA = "0x6357D4")]
	private void Update()
	{
	}

	[Token(Token = "0x600067F")]
	[Address(RVA = "0x6357D8", Offset = "0x6357D8", VA = "0x6357D8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000680")]
	[Address(RVA = "0x635888", Offset = "0x635888", VA = "0x635888")]
	public CameraFilterPack_TV_BrokenGlass()
	{
	}
}
