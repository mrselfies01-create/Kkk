using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000083")]
public class CameraFilterPack_Distortion_Wave_Horizontal : MonoBehaviour
{
	[Token(Token = "0x4000408")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000409")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400040A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400040B")]
	[FieldOffset(Offset = "0x30")]
	public float WaveIntensity;

	[Token(Token = "0x17000084")]
	private Material material
	{
		[Token(Token = "0x6000345")]
		[Address(RVA = "0x676D30", Offset = "0x676D30", VA = "0x676D30")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000346")]
	[Address(RVA = "0x676DF4", Offset = "0x676DF4", VA = "0x676DF4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000347")]
	[Address(RVA = "0x676E70", Offset = "0x676E70", VA = "0x676E70")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000348")]
	[Address(RVA = "0x677078", Offset = "0x677078", VA = "0x677078")]
	private void Update()
	{
	}

	[Token(Token = "0x6000349")]
	[Address(RVA = "0x67707C", Offset = "0x67707C", VA = "0x67707C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600034A")]
	[Address(RVA = "0x67712C", Offset = "0x67712C", VA = "0x67712C")]
	public CameraFilterPack_Distortion_Wave_Horizontal()
	{
	}
}
