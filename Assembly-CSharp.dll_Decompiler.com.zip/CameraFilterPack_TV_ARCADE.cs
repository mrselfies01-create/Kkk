using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000102")]
public class CameraFilterPack_TV_ARCADE : MonoBehaviour
{
	[Token(Token = "0x400076D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400076E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400076F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000770")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x17000103")]
	private Material material
	{
		[Token(Token = "0x6000663")]
		[Address(RVA = "0x6341E8", Offset = "0x6341E8", VA = "0x6341E8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000664")]
	[Address(RVA = "0x6342AC", Offset = "0x6342AC", VA = "0x6342AC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000665")]
	[Address(RVA = "0x634328", Offset = "0x634328", VA = "0x634328")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000666")]
	[Address(RVA = "0x634540", Offset = "0x634540", VA = "0x634540")]
	private void Update()
	{
	}

	[Token(Token = "0x6000667")]
	[Address(RVA = "0x634544", Offset = "0x634544", VA = "0x634544")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000668")]
	[Address(RVA = "0x6345F4", Offset = "0x6345F4", VA = "0x6345F4")]
	public CameraFilterPack_TV_ARCADE()
	{
	}
}
