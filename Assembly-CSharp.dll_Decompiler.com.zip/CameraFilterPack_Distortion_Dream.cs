using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000075")]
public class CameraFilterPack_Distortion_Dream : MonoBehaviour
{
	[Token(Token = "0x40003BA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003BB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003BC")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40003BD")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000076")]
	private Material material
	{
		[Token(Token = "0x60002F1")]
		[Address(RVA = "0x67313C", Offset = "0x67313C", VA = "0x67313C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002F2")]
	[Address(RVA = "0x673200", Offset = "0x673200", VA = "0x673200")]
	private void Start()
	{
	}

	[Token(Token = "0x60002F3")]
	[Address(RVA = "0x67327C", Offset = "0x67327C", VA = "0x67327C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002F4")]
	[Address(RVA = "0x673400", Offset = "0x673400", VA = "0x673400")]
	private void Update()
	{
	}

	[Token(Token = "0x60002F5")]
	[Address(RVA = "0x673404", Offset = "0x673404", VA = "0x673404")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002F6")]
	[Address(RVA = "0x6734B4", Offset = "0x6734B4", VA = "0x6734B4")]
	public CameraFilterPack_Distortion_Dream()
	{
	}
}
