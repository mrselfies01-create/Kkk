using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B3")]
public class CameraFilterPack_FX_Glitch3 : MonoBehaviour
{
	[Token(Token = "0x4000535")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000536")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000537")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000538")]
	[FieldOffset(Offset = "0x30")]
	public float _Glitch;

	[Token(Token = "0x4000539")]
	[FieldOffset(Offset = "0x34")]
	public float _Noise;

	[Token(Token = "0x170000B4")]
	private Material material
	{
		[Token(Token = "0x6000466")]
		[Address(RVA = "0x69A2B8", Offset = "0x69A2B8", VA = "0x69A2B8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000467")]
	[Address(RVA = "0x69A37C", Offset = "0x69A37C", VA = "0x69A37C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000468")]
	[Address(RVA = "0x69A3F8", Offset = "0x69A3F8", VA = "0x69A3F8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000469")]
	[Address(RVA = "0x69A634", Offset = "0x69A634", VA = "0x69A634")]
	private void Update()
	{
	}

	[Token(Token = "0x600046A")]
	[Address(RVA = "0x69A638", Offset = "0x69A638", VA = "0x69A638")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600046B")]
	[Address(RVA = "0x69A6E8", Offset = "0x69A6E8", VA = "0x69A6E8")]
	public CameraFilterPack_FX_Glitch3()
	{
	}
}
