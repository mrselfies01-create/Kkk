using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000F")]
public class CameraFilterPack_3D_Matrix : MonoBehaviour
{
	[Token(Token = "0x400007A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400007B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400007C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400007D")]
	[FieldOffset(Offset = "0x30")]
	public bool _Visualize;

	[Token(Token = "0x400007E")]
	[FieldOffset(Offset = "0x34")]
	public float _FixDistance;

	[Token(Token = "0x400007F")]
	[FieldOffset(Offset = "0x38")]
	public float LightIntensity;

	[Token(Token = "0x4000080")]
	[FieldOffset(Offset = "0x3C")]
	public float MatrixSize;

	[Token(Token = "0x4000081")]
	[FieldOffset(Offset = "0x40")]
	public float MatrixSpeed;

	[Token(Token = "0x4000082")]
	[FieldOffset(Offset = "0x44")]
	public float Fade;

	[Token(Token = "0x4000083")]
	[FieldOffset(Offset = "0x48")]
	public Color _MatrixColor;

	[Token(Token = "0x4000084")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x4000085")]
	[FieldOffset(Offset = "0x58")]
	private Texture2D Texture2;

	[Token(Token = "0x17000010")]
	private Material material
	{
		[Token(Token = "0x600004C")]
		[Address(RVA = "0x5B5994", Offset = "0x5B5994", VA = "0x5B5994")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600004D")]
	[Address(RVA = "0x5B5A58", Offset = "0x5B5A58", VA = "0x5B5A58")]
	private void Start()
	{
	}

	[Token(Token = "0x600004E")]
	[Address(RVA = "0x5B5B10", Offset = "0x5B5B10", VA = "0x5B5B10")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600004F")]
	[Address(RVA = "0x5B5EA8", Offset = "0x5B5EA8", VA = "0x5B5EA8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000050")]
	[Address(RVA = "0x5B5EAC", Offset = "0x5B5EAC", VA = "0x5B5EAC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000051")]
	[Address(RVA = "0x5B5F5C", Offset = "0x5B5F5C", VA = "0x5B5F5C")]
	public CameraFilterPack_3D_Matrix()
	{
	}
}
