using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000115")]
public class CameraFilterPack_TV_Rgb : MonoBehaviour
{
	[Token(Token = "0x40007E4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007E5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007E6")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40007E7")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000116")]
	private Material material
	{
		[Token(Token = "0x60006D5")]
		[Address(RVA = "0x6395CC", Offset = "0x6395CC", VA = "0x6395CC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006D6")]
	[Address(RVA = "0x639690", Offset = "0x639690", VA = "0x639690")]
	private void Start()
	{
	}

	[Token(Token = "0x60006D7")]
	[Address(RVA = "0x63970C", Offset = "0x63970C", VA = "0x63970C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006D8")]
	[Address(RVA = "0x639924", Offset = "0x639924", VA = "0x639924")]
	private void Update()
	{
	}

	[Token(Token = "0x60006D9")]
	[Address(RVA = "0x639928", Offset = "0x639928", VA = "0x639928")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006DA")]
	[Address(RVA = "0x6399D8", Offset = "0x6399D8", VA = "0x6399D8")]
	public CameraFilterPack_TV_Rgb()
	{
	}
}
