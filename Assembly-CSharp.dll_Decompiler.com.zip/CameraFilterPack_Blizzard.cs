using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000044")]
public class CameraFilterPack_Blizzard : MonoBehaviour
{
	[Token(Token = "0x400028E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400028F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000290")]
	[FieldOffset(Offset = "0x24")]
	public float _Speed;

	[Token(Token = "0x4000291")]
	[FieldOffset(Offset = "0x28")]
	public float _Size;

	[Token(Token = "0x4000292")]
	[FieldOffset(Offset = "0x2C")]
	public float _Fade;

	[Token(Token = "0x4000293")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000294")]
	[FieldOffset(Offset = "0x38")]
	private Texture2D Texture2;

	[Token(Token = "0x17000045")]
	private Material material
	{
		[Token(Token = "0x60001C9")]
		[Address(RVA = "0x664A00", Offset = "0x664A00", VA = "0x664A00")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001CA")]
	[Address(RVA = "0x664AC4", Offset = "0x664AC4", VA = "0x664AC4")]
	private void Start()
	{
	}

	[Token(Token = "0x60001CB")]
	[Address(RVA = "0x664B7C", Offset = "0x664B7C", VA = "0x664B7C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001CC")]
	[Address(RVA = "0x664D6C", Offset = "0x664D6C", VA = "0x664D6C")]
	private void Update()
	{
	}

	[Token(Token = "0x60001CD")]
	[Address(RVA = "0x664D70", Offset = "0x664D70", VA = "0x664D70")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001CE")]
	[Address(RVA = "0x664E20", Offset = "0x664E20", VA = "0x664E20")]
	public CameraFilterPack_Blizzard()
	{
	}
}
