using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006E")]
public class CameraFilterPack_Colors_RgbClamp : MonoBehaviour
{
	[Token(Token = "0x400038D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400038E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400038F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000390")]
	[FieldOffset(Offset = "0x30")]
	public float Red_Start;

	[Token(Token = "0x4000391")]
	[FieldOffset(Offset = "0x34")]
	public float Red_End;

	[Token(Token = "0x4000392")]
	[FieldOffset(Offset = "0x38")]
	public float Green_Start;

	[Token(Token = "0x4000393")]
	[FieldOffset(Offset = "0x3C")]
	public float Green_End;

	[Token(Token = "0x4000394")]
	[FieldOffset(Offset = "0x40")]
	public float Blue_Start;

	[Token(Token = "0x4000395")]
	[FieldOffset(Offset = "0x44")]
	public float Blue_End;

	[Token(Token = "0x4000396")]
	[FieldOffset(Offset = "0x48")]
	public float RGB_Start;

	[Token(Token = "0x4000397")]
	[FieldOffset(Offset = "0x4C")]
	public float RGB_End;

	[Token(Token = "0x1700006F")]
	private Material material
	{
		[Token(Token = "0x60002C7")]
		[Address(RVA = "0x671330", Offset = "0x671330", VA = "0x671330")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002C8")]
	[Address(RVA = "0x6713F4", Offset = "0x6713F4", VA = "0x6713F4")]
	private void Start()
	{
	}

	[Token(Token = "0x60002C9")]
	[Address(RVA = "0x671470", Offset = "0x671470", VA = "0x671470")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002CA")]
	[Address(RVA = "0x671784", Offset = "0x671784", VA = "0x671784")]
	private void Update()
	{
	}

	[Token(Token = "0x60002CB")]
	[Address(RVA = "0x671788", Offset = "0x671788", VA = "0x671788")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002CC")]
	[Address(RVA = "0x671838", Offset = "0x671838", VA = "0x671838")]
	public CameraFilterPack_Colors_RgbClamp()
	{
	}
}
