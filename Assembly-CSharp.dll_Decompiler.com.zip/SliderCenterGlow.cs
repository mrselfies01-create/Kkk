using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x200013F")]
public class SliderCenterGlow : MonoBehaviour
{
	[Token(Token = "0x400096B")]
	[FieldOffset(Offset = "0x18")]
	private Slider slider;

	[Token(Token = "0x400096C")]
	[FieldOffset(Offset = "0x20")]
	private RectTransform rt;

	[Token(Token = "0x400096D")]
	[FieldOffset(Offset = "0x28")]
	private RectTransform myRt;

	[Token(Token = "0x400096E")]
	[FieldOffset(Offset = "0x30")]
	public bool invertedDir;

	[Token(Token = "0x400096F")]
	[FieldOffset(Offset = "0x34")]
	public float zeroVal;

	[Token(Token = "0x4000970")]
	[FieldOffset(Offset = "0x38")]
	public float minVal;

	[Token(Token = "0x4000971")]
	[FieldOffset(Offset = "0x3C")]
	public float maxVal;

	[Token(Token = "0x60007D4")]
	[Address(RVA = "0x3DC880", Offset = "0x3DC880", VA = "0x3DC880")]
	private void Start()
	{
	}

	[Token(Token = "0x60007D5")]
	[Address(RVA = "0x3DC904", Offset = "0x3DC904", VA = "0x3DC904")]
	private void Update()
	{
	}

	[Token(Token = "0x60007D6")]
	[Address(RVA = "0x3DCA34", Offset = "0x3DCA34", VA = "0x3DCA34")]
	public SliderCenterGlow()
	{
	}
}
