using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000EC")]
public class CameraFilterPack_Noise_TV_2 : MonoBehaviour
{
	[Token(Token = "0x40006DB")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006DC")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006DD")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006DE")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x40006DF")]
	[FieldOffset(Offset = "0x34")]
	public float Fade_Additive;

	[Token(Token = "0x40006E0")]
	[FieldOffset(Offset = "0x38")]
	public float Fade_Distortion;

	[Token(Token = "0x40006E1")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x40006E2")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000ED")]
	private Material material
	{
		[Token(Token = "0x60005DA")]
		[Address(RVA = "0x62D52C", Offset = "0x62D52C", VA = "0x62D52C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005DB")]
	[Address(RVA = "0x62D5F0", Offset = "0x62D5F0", VA = "0x62D5F0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005DC")]
	[Address(RVA = "0x62D6A8", Offset = "0x62D6A8", VA = "0x62D6A8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005DD")]
	[Address(RVA = "0x62D950", Offset = "0x62D950", VA = "0x62D950")]
	private void Update()
	{
	}

	[Token(Token = "0x60005DE")]
	[Address(RVA = "0x62D954", Offset = "0x62D954", VA = "0x62D954")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005DF")]
	[Address(RVA = "0x62DA04", Offset = "0x62DA04", VA = "0x62DA04")]
	public CameraFilterPack_Noise_TV_2()
	{
	}
}
