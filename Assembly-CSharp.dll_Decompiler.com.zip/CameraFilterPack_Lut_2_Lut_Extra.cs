using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DC")]
public class CameraFilterPack_Lut_2_Lut_Extra : MonoBehaviour
{
	[Token(Token = "0x4000653")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000654")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000655")]
	[FieldOffset(Offset = "0x24")]
	private Vector4 ScreenResolution;

	[Token(Token = "0x4000656")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000657")]
	[FieldOffset(Offset = "0x40")]
	public Texture2D LutTexture;

	[Token(Token = "0x4000658")]
	[FieldOffset(Offset = "0x48")]
	public Texture2D LutTexture2;

	[Token(Token = "0x4000659")]
	[FieldOffset(Offset = "0x50")]
	private Texture3D converted3DLut;

	[Token(Token = "0x400065A")]
	[FieldOffset(Offset = "0x58")]
	private Texture3D converted3DLut2;

	[Token(Token = "0x400065B")]
	[FieldOffset(Offset = "0x60")]
	public float FadeLut1;

	[Token(Token = "0x400065C")]
	[FieldOffset(Offset = "0x64")]
	public float FadeLut2;

	[Token(Token = "0x400065D")]
	[FieldOffset(Offset = "0x68")]
	public float Pos;

	[Token(Token = "0x400065E")]
	[FieldOffset(Offset = "0x6C")]
	public float Smooth;

	[Token(Token = "0x400065F")]
	[FieldOffset(Offset = "0x70")]
	private string MemoPath;

	[Token(Token = "0x4000660")]
	[FieldOffset(Offset = "0x78")]
	private string MemoPath2;

	[Token(Token = "0x170000DD")]
	private Material material
	{
		[Token(Token = "0x6000560")]
		[Address(RVA = "0x6A6AEC", Offset = "0x6A6AEC", VA = "0x6A6AEC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000561")]
	[Address(RVA = "0x6A6BB0", Offset = "0x6A6BB0", VA = "0x6A6BB0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000562")]
	[Address(RVA = "0x6A6C2C", Offset = "0x6A6C2C", VA = "0x6A6C2C")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x6000563")]
	[Address(RVA = "0x6A6EBC", Offset = "0x6A6EBC", VA = "0x6A6EBC")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x6000564")]
	[Address(RVA = "0x6A6FB0", Offset = "0x6A6FB0", VA = "0x6A6FB0")]
	public Texture3D Convert(Texture2D temp2DTex, Texture3D cv3D)
	{
		return null;
	}

	[Token(Token = "0x6000565")]
	[Address(RVA = "0x6A725C", Offset = "0x6A725C", VA = "0x6A725C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000566")]
	[Address(RVA = "0x6A765C", Offset = "0x6A765C", VA = "0x6A765C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000567")]
	[Address(RVA = "0x6A7660", Offset = "0x6A7660", VA = "0x6A7660")]
	private void Update()
	{
	}

	[Token(Token = "0x6000568")]
	[Address(RVA = "0x6A7664", Offset = "0x6A7664", VA = "0x6A7664")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000569")]
	[Address(RVA = "0x6A7714", Offset = "0x6A7714", VA = "0x6A7714")]
	public CameraFilterPack_Lut_2_Lut_Extra()
	{
	}
}
