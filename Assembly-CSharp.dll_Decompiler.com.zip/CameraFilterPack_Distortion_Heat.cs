using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007B")]
public class CameraFilterPack_Distortion_Heat : MonoBehaviour
{
	[Token(Token = "0x40003D7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003D8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003D9")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003DA")]
	[FieldOffset(Offset = "0x30")]
	public float Distortion;

	[Token(Token = "0x1700007C")]
	private Material material
	{
		[Token(Token = "0x6000315")]
		[Address(RVA = "0x6749F0", Offset = "0x6749F0", VA = "0x6749F0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000316")]
	[Address(RVA = "0x674AB4", Offset = "0x674AB4", VA = "0x674AB4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000317")]
	[Address(RVA = "0x674B30", Offset = "0x674B30", VA = "0x674B30")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000318")]
	[Address(RVA = "0x674D48", Offset = "0x674D48", VA = "0x674D48")]
	private void Update()
	{
	}

	[Token(Token = "0x6000319")]
	[Address(RVA = "0x674D4C", Offset = "0x674D4C", VA = "0x674D4C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600031A")]
	[Address(RVA = "0x674DFC", Offset = "0x674DFC", VA = "0x674DFC")]
	public CameraFilterPack_Distortion_Heat()
	{
	}
}
