using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C1")]
public class CameraFilterPack_Film_ColorPerfection : MonoBehaviour
{
	[Token(Token = "0x4000576")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000577")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000578")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000579")]
	[FieldOffset(Offset = "0x30")]
	public float Gamma;

	[Token(Token = "0x400057A")]
	[FieldOffset(Offset = "0x34")]
	private float Value2;

	[Token(Token = "0x400057B")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x400057C")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x170000C2")]
	private Material material
	{
		[Token(Token = "0x60004BA")]
		[Address(RVA = "0x69DD08", Offset = "0x69DD08", VA = "0x69DD08")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004BB")]
	[Address(RVA = "0x69DDCC", Offset = "0x69DDCC", VA = "0x69DDCC")]
	private void Start()
	{
	}

	[Token(Token = "0x60004BC")]
	[Address(RVA = "0x69DE48", Offset = "0x69DE48", VA = "0x69DE48")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004BD")]
	[Address(RVA = "0x69E0CC", Offset = "0x69E0CC", VA = "0x69E0CC")]
	private void Update()
	{
	}

	[Token(Token = "0x60004BE")]
	[Address(RVA = "0x69E0D0", Offset = "0x69E0D0", VA = "0x69E0D0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004BF")]
	[Address(RVA = "0x69E180", Offset = "0x69E180", VA = "0x69E180")]
	public CameraFilterPack_Film_ColorPerfection()
	{
	}
}
