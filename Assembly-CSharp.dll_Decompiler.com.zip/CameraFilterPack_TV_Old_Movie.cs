using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000111")]
public class CameraFilterPack_TV_Old_Movie : MonoBehaviour
{
	[Token(Token = "0x40007CE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007CF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007D0")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x40007D1")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000112")]
	private Material material
	{
		[Token(Token = "0x60006BD")]
		[Address(RVA = "0x638584", Offset = "0x638584", VA = "0x638584")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006BE")]
	[Address(RVA = "0x638648", Offset = "0x638648", VA = "0x638648")]
	private void Start()
	{
	}

	[Token(Token = "0x60006BF")]
	[Address(RVA = "0x6386C4", Offset = "0x6386C4", VA = "0x6386C4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006C0")]
	[Address(RVA = "0x638848", Offset = "0x638848", VA = "0x638848")]
	private void Update()
	{
	}

	[Token(Token = "0x60006C1")]
	[Address(RVA = "0x63884C", Offset = "0x63884C", VA = "0x63884C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006C2")]
	[Address(RVA = "0x6388FC", Offset = "0x6388FC", VA = "0x6388FC")]
	public CameraFilterPack_TV_Old_Movie()
	{
	}
}
