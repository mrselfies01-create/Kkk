using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F4")]
public class CameraFilterPack_OldFilm_Cutting2 : MonoBehaviour
{
	[Token(Token = "0x4000713")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000714")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000715")]
	[FieldOffset(Offset = "0x24")]
	public float Speed;

	[Token(Token = "0x4000716")]
	[FieldOffset(Offset = "0x28")]
	public float Luminosity;

	[Token(Token = "0x4000717")]
	[FieldOffset(Offset = "0x2C")]
	public float Vignette;

	[Token(Token = "0x4000718")]
	[FieldOffset(Offset = "0x30")]
	public float Negative;

	[Token(Token = "0x4000719")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400071A")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000F5")]
	private Material material
	{
		[Token(Token = "0x600060E")]
		[Address(RVA = "0x63001C", Offset = "0x63001C", VA = "0x63001C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600060F")]
	[Address(RVA = "0x6300E0", Offset = "0x6300E0", VA = "0x6300E0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000610")]
	[Address(RVA = "0x630198", Offset = "0x630198", VA = "0x630198")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000611")]
	[Address(RVA = "0x6303BC", Offset = "0x6303BC", VA = "0x6303BC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000612")]
	[Address(RVA = "0x6303C0", Offset = "0x6303C0", VA = "0x6303C0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000613")]
	[Address(RVA = "0x630470", Offset = "0x630470", VA = "0x630470")]
	public CameraFilterPack_OldFilm_Cutting2()
	{
	}
}
