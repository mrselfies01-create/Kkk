using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CF")]
public class CameraFilterPack_Gradients_ElectricGradient : MonoBehaviour
{
	[Token(Token = "0x4000601")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000602")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x4000603")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x4000604")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000605")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000606")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D0")]
	private Material material
	{
		[Token(Token = "0x600050E")]
		[Address(RVA = "0x6A2A40", Offset = "0x6A2A40", VA = "0x6A2A40")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600050F")]
	[Address(RVA = "0x6A2B04", Offset = "0x6A2B04", VA = "0x6A2B04")]
	private void Start()
	{
	}

	[Token(Token = "0x6000510")]
	[Address(RVA = "0x6A2B54", Offset = "0x6A2B54", VA = "0x6A2B54")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000511")]
	[Address(RVA = "0x6A2D90", Offset = "0x6A2D90", VA = "0x6A2D90")]
	private void Update()
	{
	}

	[Token(Token = "0x6000512")]
	[Address(RVA = "0x6A2D94", Offset = "0x6A2D94", VA = "0x6A2D94")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000513")]
	[Address(RVA = "0x6A2E44", Offset = "0x6A2E44", VA = "0x6A2E44")]
	public CameraFilterPack_Gradients_ElectricGradient()
	{
	}
}
