using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AF")]
public class CameraFilterPack_FX_EarthQuake : MonoBehaviour
{
	[Token(Token = "0x4000523")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000524")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000525")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000526")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x4000527")]
	[FieldOffset(Offset = "0x34")]
	public float X;

	[Token(Token = "0x4000528")]
	[FieldOffset(Offset = "0x38")]
	public float Y;

	[Token(Token = "0x4000529")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x170000B0")]
	private Material material
	{
		[Token(Token = "0x600044E")]
		[Address(RVA = "0x6991EC", Offset = "0x6991EC", VA = "0x6991EC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600044F")]
	[Address(RVA = "0x6992B0", Offset = "0x6992B0", VA = "0x6992B0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000450")]
	[Address(RVA = "0x69932C", Offset = "0x69932C", VA = "0x69932C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000451")]
	[Address(RVA = "0x6995B0", Offset = "0x6995B0", VA = "0x6995B0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000452")]
	[Address(RVA = "0x6995B4", Offset = "0x6995B4", VA = "0x6995B4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000453")]
	[Address(RVA = "0x699664", Offset = "0x699664", VA = "0x699664")]
	public CameraFilterPack_FX_EarthQuake()
	{
	}
}
