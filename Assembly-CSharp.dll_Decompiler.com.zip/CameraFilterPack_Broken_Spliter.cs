using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000057")]
public class CameraFilterPack_Broken_Spliter : MonoBehaviour
{
	[Token(Token = "0x4000308")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000309")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400030A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400030B")]
	[FieldOffset(Offset = "0x30")]
	private float __Speed;

	[Token(Token = "0x400030C")]
	[FieldOffset(Offset = "0x34")]
	public float _PosX;

	[Token(Token = "0x400030D")]
	[FieldOffset(Offset = "0x38")]
	public float _PosY;

	[Token(Token = "0x17000058")]
	private Material material
	{
		[Token(Token = "0x600023B")]
		[Address(RVA = "0x66A540", Offset = "0x66A540", VA = "0x66A540")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600023C")]
	[Address(RVA = "0x66A604", Offset = "0x66A604", VA = "0x66A604")]
	private void Start()
	{
	}

	[Token(Token = "0x600023D")]
	[Address(RVA = "0x66A680", Offset = "0x66A680", VA = "0x66A680")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600023E")]
	[Address(RVA = "0x66A8E0", Offset = "0x66A8E0", VA = "0x66A8E0")]
	private void Update()
	{
	}

	[Token(Token = "0x600023F")]
	[Address(RVA = "0x66A8E4", Offset = "0x66A8E4", VA = "0x66A8E4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000240")]
	[Address(RVA = "0x66A994", Offset = "0x66A994", VA = "0x66A994")]
	public CameraFilterPack_Broken_Spliter()
	{
	}
}
