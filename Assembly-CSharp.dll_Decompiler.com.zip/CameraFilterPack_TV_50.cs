using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000100")]
public class CameraFilterPack_TV_50 : MonoBehaviour
{
	[Token(Token = "0x4000765")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000766")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000767")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000768")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x17000101")]
	private Material material
	{
		[Token(Token = "0x6000657")]
		[Address(RVA = "0x6339A8", Offset = "0x6339A8", VA = "0x6339A8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000658")]
	[Address(RVA = "0x633A6C", Offset = "0x633A6C", VA = "0x633A6C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000659")]
	[Address(RVA = "0x633AE8", Offset = "0x633AE8", VA = "0x633AE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600065A")]
	[Address(RVA = "0x633D00", Offset = "0x633D00", VA = "0x633D00")]
	private void Update()
	{
	}

	[Token(Token = "0x600065B")]
	[Address(RVA = "0x633D04", Offset = "0x633D04", VA = "0x633D04")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600065C")]
	[Address(RVA = "0x633DB4", Offset = "0x633DB4", VA = "0x633DB4")]
	public CameraFilterPack_TV_50()
	{
	}
}
