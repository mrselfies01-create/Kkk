using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000036")]
public class CameraFilterPack_Blend2Camera_LinearDodge : MonoBehaviour
{
	[Token(Token = "0x400020D")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400020E")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400020F")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000210")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000211")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000212")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000213")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000214")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000037")]
	private Material material
	{
		[Token(Token = "0x6000158")]
		[Address(RVA = "0x5C55F0", Offset = "0x5C55F0", VA = "0x5C55F0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000159")]
	[Address(RVA = "0x5C56B4", Offset = "0x5C56B4", VA = "0x5C56B4")]
	private void Start()
	{
	}

	[Token(Token = "0x600015A")]
	[Address(RVA = "0x5C57CC", Offset = "0x5C57CC", VA = "0x5C57CC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600015B")]
	[Address(RVA = "0x5C5A5C", Offset = "0x5C5A5C", VA = "0x5C5A5C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600015C")]
	[Address(RVA = "0x5C5B48", Offset = "0x5C5B48", VA = "0x5C5B48")]
	private void Update()
	{
	}

	[Token(Token = "0x600015D")]
	[Address(RVA = "0x5C5B4C", Offset = "0x5C5B4C", VA = "0x5C5B4C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600015E")]
	[Address(RVA = "0x5C5C38", Offset = "0x5C5C38", VA = "0x5C5C38")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600015F")]
	[Address(RVA = "0x5C5D30", Offset = "0x5C5D30", VA = "0x5C5D30")]
	public CameraFilterPack_Blend2Camera_LinearDodge()
	{
	}
}
