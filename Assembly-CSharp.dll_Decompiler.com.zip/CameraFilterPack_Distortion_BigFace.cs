using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000072")]
public class CameraFilterPack_Distortion_BigFace : MonoBehaviour
{
	[Token(Token = "0x40003A7")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003A8")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003A9")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003AA")]
	[FieldOffset(Offset = "0x30")]
	public float _Size;

	[Token(Token = "0x40003AB")]
	[FieldOffset(Offset = "0x34")]
	public float Distortion;

	[Token(Token = "0x17000073")]
	private Material material
	{
		[Token(Token = "0x60002DF")]
		[Address(RVA = "0x6723D8", Offset = "0x6723D8", VA = "0x6723D8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002E0")]
	[Address(RVA = "0x67249C", Offset = "0x67249C", VA = "0x67249C")]
	private void Start()
	{
	}

	[Token(Token = "0x60002E1")]
	[Address(RVA = "0x672518", Offset = "0x672518", VA = "0x672518")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002E2")]
	[Address(RVA = "0x672754", Offset = "0x672754", VA = "0x672754")]
	private void Update()
	{
	}

	[Token(Token = "0x60002E3")]
	[Address(RVA = "0x672758", Offset = "0x672758", VA = "0x672758")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002E4")]
	[Address(RVA = "0x672808", Offset = "0x672808", VA = "0x672808")]
	public CameraFilterPack_Distortion_BigFace()
	{
	}
}
