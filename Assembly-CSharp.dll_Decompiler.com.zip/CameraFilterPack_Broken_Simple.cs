using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000056")]
public class CameraFilterPack_Broken_Simple : MonoBehaviour
{
	[Token(Token = "0x4000300")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000301")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000302")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000303")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x4000304")]
	[FieldOffset(Offset = "0x34")]
	public float _Broke1;

	[Token(Token = "0x4000305")]
	[FieldOffset(Offset = "0x38")]
	public float _Broke2;

	[Token(Token = "0x4000306")]
	[FieldOffset(Offset = "0x3C")]
	public float _PosX;

	[Token(Token = "0x4000307")]
	[FieldOffset(Offset = "0x40")]
	public float _PosY;

	[Token(Token = "0x17000057")]
	private Material material
	{
		[Token(Token = "0x6000235")]
		[Address(RVA = "0x66A080", Offset = "0x66A080", VA = "0x66A080")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000236")]
	[Address(RVA = "0x66A144", Offset = "0x66A144", VA = "0x66A144")]
	private void Start()
	{
	}

	[Token(Token = "0x6000237")]
	[Address(RVA = "0x66A1C0", Offset = "0x66A1C0", VA = "0x66A1C0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000238")]
	[Address(RVA = "0x66A468", Offset = "0x66A468", VA = "0x66A468")]
	private void Update()
	{
	}

	[Token(Token = "0x6000239")]
	[Address(RVA = "0x66A46C", Offset = "0x66A46C", VA = "0x66A46C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600023A")]
	[Address(RVA = "0x66A51C", Offset = "0x66A51C", VA = "0x66A51C")]
	public CameraFilterPack_Broken_Simple()
	{
	}
}
