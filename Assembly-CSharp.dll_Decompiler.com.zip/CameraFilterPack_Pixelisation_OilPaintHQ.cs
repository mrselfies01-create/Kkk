using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F9")]
public class CameraFilterPack_Pixelisation_OilPaintHQ : MonoBehaviour
{
	[Token(Token = "0x4000736")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000737")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000738")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000739")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000FA")]
	private Material material
	{
		[Token(Token = "0x600062C")]
		[Address(RVA = "0x631640", Offset = "0x631640", VA = "0x631640")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600062D")]
	[Address(RVA = "0x631704", Offset = "0x631704", VA = "0x631704")]
	private void Start()
	{
	}

	[Token(Token = "0x600062E")]
	[Address(RVA = "0x631780", Offset = "0x631780", VA = "0x631780")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600062F")]
	[Address(RVA = "0x631998", Offset = "0x631998", VA = "0x631998")]
	private void Update()
	{
	}

	[Token(Token = "0x6000630")]
	[Address(RVA = "0x63199C", Offset = "0x63199C", VA = "0x63199C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000631")]
	[Address(RVA = "0x631A4C", Offset = "0x631A4C", VA = "0x631A4C")]
	public CameraFilterPack_Pixelisation_OilPaintHQ()
	{
	}
}
