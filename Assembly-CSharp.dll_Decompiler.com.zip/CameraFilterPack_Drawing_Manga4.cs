using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000091")]
public class CameraFilterPack_Drawing_Manga4 : MonoBehaviour
{
	[Token(Token = "0x4000456")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000457")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000458")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000459")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x17000092")]
	private Material material
	{
		[Token(Token = "0x6000399")]
		[Address(RVA = "0x690BC8", Offset = "0x690BC8", VA = "0x690BC8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600039A")]
	[Address(RVA = "0x690C8C", Offset = "0x690C8C", VA = "0x690C8C")]
	private void Start()
	{
	}

	[Token(Token = "0x600039B")]
	[Address(RVA = "0x690D08", Offset = "0x690D08", VA = "0x690D08")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600039C")]
	[Address(RVA = "0x690E8C", Offset = "0x690E8C", VA = "0x690E8C")]
	private void Update()
	{
	}

	[Token(Token = "0x600039D")]
	[Address(RVA = "0x690E90", Offset = "0x690E90", VA = "0x690E90")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600039E")]
	[Address(RVA = "0x690F40", Offset = "0x690F40", VA = "0x690F40")]
	public CameraFilterPack_Drawing_Manga4()
	{
	}
}
