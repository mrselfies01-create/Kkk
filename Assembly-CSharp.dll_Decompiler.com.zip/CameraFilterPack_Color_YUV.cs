using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000064")]
public class CameraFilterPack_Color_YUV : MonoBehaviour
{
	[Token(Token = "0x400034C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400034D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400034E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400034F")]
	[FieldOffset(Offset = "0x30")]
	public float _Y;

	[Token(Token = "0x4000350")]
	[FieldOffset(Offset = "0x34")]
	public float _U;

	[Token(Token = "0x4000351")]
	[FieldOffset(Offset = "0x38")]
	public float _V;

	[Token(Token = "0x17000065")]
	private Material material
	{
		[Token(Token = "0x6000289")]
		[Address(RVA = "0x66DDA8", Offset = "0x66DDA8", VA = "0x66DDA8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600028A")]
	[Address(RVA = "0x66DE6C", Offset = "0x66DE6C", VA = "0x66DE6C")]
	private void Start()
	{
	}

	[Token(Token = "0x600028B")]
	[Address(RVA = "0x66DEE8", Offset = "0x66DEE8", VA = "0x66DEE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600028C")]
	[Address(RVA = "0x66E148", Offset = "0x66E148", VA = "0x66E148")]
	private void Update()
	{
	}

	[Token(Token = "0x600028D")]
	[Address(RVA = "0x66E14C", Offset = "0x66E14C", VA = "0x66E14C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600028E")]
	[Address(RVA = "0x66E1FC", Offset = "0x66E1FC", VA = "0x66E1FC")]
	public CameraFilterPack_Color_YUV()
	{
	}
}
