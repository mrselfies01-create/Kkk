using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000003")]
public static class CommonColorBuffer
{
	[Token(Token = "0x4000002")]
	[FieldOffset(Offset = "0x0")]
	public static Color value;

	[Token(Token = "0x6000002")]
	[Address(RVA = "0x38568C", Offset = "0x38568C", VA = "0x38568C")]
	public static string ColorToString(Color32 color)
	{
		return null;
	}

	[Token(Token = "0x6000003")]
	[Address(RVA = "0x38574C", Offset = "0x38574C", VA = "0x38574C")]
	public static Color32 StringToColor(string colorString)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Color32);
	}
}
