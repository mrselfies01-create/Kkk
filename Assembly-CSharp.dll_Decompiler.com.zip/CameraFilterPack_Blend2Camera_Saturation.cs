using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003D")]
public class CameraFilterPack_Blend2Camera_Saturation : MonoBehaviour
{
	[Token(Token = "0x4000247")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000248")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000249")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x400024A")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400024B")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400024C")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400024D")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400024E")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003E")]
	private Material material
	{
		[Token(Token = "0x6000191")]
		[Address(RVA = "0x661630", Offset = "0x661630", VA = "0x661630")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000192")]
	[Address(RVA = "0x6616F4", Offset = "0x6616F4", VA = "0x6616F4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000193")]
	[Address(RVA = "0x66180C", Offset = "0x66180C", VA = "0x66180C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000194")]
	[Address(RVA = "0x661A9C", Offset = "0x661A9C", VA = "0x661A9C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000195")]
	[Address(RVA = "0x661B88", Offset = "0x661B88", VA = "0x661B88")]
	private void Update()
	{
	}

	[Token(Token = "0x6000196")]
	[Address(RVA = "0x661B8C", Offset = "0x661B8C", VA = "0x661B8C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000197")]
	[Address(RVA = "0x661C78", Offset = "0x661C78", VA = "0x661C78")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000198")]
	[Address(RVA = "0x661D70", Offset = "0x661D70", VA = "0x661D70")]
	public CameraFilterPack_Blend2Camera_Saturation()
	{
	}
}
