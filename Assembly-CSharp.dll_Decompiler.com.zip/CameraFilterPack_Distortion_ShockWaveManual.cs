using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007F")]
public class CameraFilterPack_Distortion_ShockWaveManual : MonoBehaviour
{
	[Token(Token = "0x40003EC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003ED")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003EE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003EF")]
	[FieldOffset(Offset = "0x30")]
	public float PosX;

	[Token(Token = "0x40003F0")]
	[FieldOffset(Offset = "0x34")]
	public float PosY;

	[Token(Token = "0x40003F1")]
	[FieldOffset(Offset = "0x38")]
	public float Value;

	[Token(Token = "0x40003F2")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x17000080")]
	private Material material
	{
		[Token(Token = "0x600032D")]
		[Address(RVA = "0x675B10", Offset = "0x675B10", VA = "0x675B10")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600032E")]
	[Address(RVA = "0x675BD4", Offset = "0x675BD4", VA = "0x675BD4")]
	private void Start()
	{
	}

	[Token(Token = "0x600032F")]
	[Address(RVA = "0x675C50", Offset = "0x675C50", VA = "0x675C50")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000330")]
	[Address(RVA = "0x675ED4", Offset = "0x675ED4", VA = "0x675ED4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000331")]
	[Address(RVA = "0x675ED8", Offset = "0x675ED8", VA = "0x675ED8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000332")]
	[Address(RVA = "0x675F88", Offset = "0x675F88", VA = "0x675F88")]
	public CameraFilterPack_Distortion_ShockWaveManual()
	{
	}
}
