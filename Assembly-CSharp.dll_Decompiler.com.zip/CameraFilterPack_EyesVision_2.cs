using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A5")]
public class CameraFilterPack_EyesVision_2 : MonoBehaviour
{
	[Token(Token = "0x40004DC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004DD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004DE")]
	[FieldOffset(Offset = "0x24")]
	public float _EyeWave;

	[Token(Token = "0x40004DF")]
	[FieldOffset(Offset = "0x28")]
	public float _EyeSpeed;

	[Token(Token = "0x40004E0")]
	[FieldOffset(Offset = "0x2C")]
	public float _EyeMove;

	[Token(Token = "0x40004E1")]
	[FieldOffset(Offset = "0x30")]
	public float _EyeBlink;

	[Token(Token = "0x40004E2")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40004E3")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000A6")]
	private Material material
	{
		[Token(Token = "0x6000412")]
		[Address(RVA = "0x6964F4", Offset = "0x6964F4", VA = "0x6964F4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000413")]
	[Address(RVA = "0x6965B8", Offset = "0x6965B8", VA = "0x6965B8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000414")]
	[Address(RVA = "0x696670", Offset = "0x696670", VA = "0x696670")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000415")]
	[Address(RVA = "0x696884", Offset = "0x696884", VA = "0x696884")]
	private void Update()
	{
	}

	[Token(Token = "0x6000416")]
	[Address(RVA = "0x696888", Offset = "0x696888", VA = "0x696888")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000417")]
	[Address(RVA = "0x696938", Offset = "0x696938", VA = "0x696938")]
	public CameraFilterPack_EyesVision_2()
	{
	}
}
