using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DF")]
public class CameraFilterPack_Lut_Plus : MonoBehaviour
{
	[Token(Token = "0x4000675")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000676")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000677")]
	[FieldOffset(Offset = "0x24")]
	private Vector4 ScreenResolution;

	[Token(Token = "0x4000678")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000679")]
	[FieldOffset(Offset = "0x40")]
	public Texture2D LutTexture;

	[Token(Token = "0x400067A")]
	[FieldOffset(Offset = "0x48")]
	private Texture3D converted3DLut;

	[Token(Token = "0x400067B")]
	[FieldOffset(Offset = "0x50")]
	public float Blend;

	[Token(Token = "0x400067C")]
	[FieldOffset(Offset = "0x58")]
	private string MemoPath;

	[Token(Token = "0x170000E0")]
	private Material material
	{
		[Token(Token = "0x600057E")]
		[Address(RVA = "0x6A8B64", Offset = "0x6A8B64", VA = "0x6A8B64")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600057F")]
	[Address(RVA = "0x6A8C28", Offset = "0x6A8C28", VA = "0x6A8C28")]
	private void Start()
	{
	}

	[Token(Token = "0x6000580")]
	[Address(RVA = "0x6A8CA4", Offset = "0x6A8CA4", VA = "0x6A8CA4")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x6000581")]
	[Address(RVA = "0x6A8E90", Offset = "0x6A8E90", VA = "0x6A8E90")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x6000582")]
	[Address(RVA = "0x6A8F84", Offset = "0x6A8F84", VA = "0x6A8F84")]
	public void Convert(Texture2D temp2DTex)
	{
	}

	[Token(Token = "0x6000583")]
	[Address(RVA = "0x6A9254", Offset = "0x6A9254", VA = "0x6A9254")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000584")]
	[Address(RVA = "0x6A9454", Offset = "0x6A9454", VA = "0x6A9454")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000585")]
	[Address(RVA = "0x6A9458", Offset = "0x6A9458", VA = "0x6A9458")]
	private void Update()
	{
	}

	[Token(Token = "0x6000586")]
	[Address(RVA = "0x6A945C", Offset = "0x6A945C", VA = "0x6A945C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000587")]
	[Address(RVA = "0x6A950C", Offset = "0x6A950C", VA = "0x6A950C")]
	public CameraFilterPack_Lut_Plus()
	{
	}
}
