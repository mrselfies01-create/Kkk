using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D7")]
public class CameraFilterPack_Light_Rainbow : MonoBehaviour
{
	[Token(Token = "0x4000631")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000632")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000633")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000634")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000D8")]
	private Material material
	{
		[Token(Token = "0x600053E")]
		[Address(RVA = "0x6A4DA0", Offset = "0x6A4DA0", VA = "0x6A4DA0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600053F")]
	[Address(RVA = "0x6A4E64", Offset = "0x6A4E64", VA = "0x6A4E64")]
	private void Start()
	{
	}

	[Token(Token = "0x6000540")]
	[Address(RVA = "0x6A4EE0", Offset = "0x6A4EE0", VA = "0x6A4EE0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000541")]
	[Address(RVA = "0x6A50F8", Offset = "0x6A50F8", VA = "0x6A50F8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000542")]
	[Address(RVA = "0x6A50FC", Offset = "0x6A50FC", VA = "0x6A50FC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000543")]
	[Address(RVA = "0x6A51AC", Offset = "0x6A51AC", VA = "0x6A51AC")]
	public CameraFilterPack_Light_Rainbow()
	{
	}
}
