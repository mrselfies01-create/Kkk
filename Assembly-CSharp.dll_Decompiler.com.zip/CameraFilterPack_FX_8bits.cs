using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A6")]
public class CameraFilterPack_FX_8bits : MonoBehaviour
{
	[Token(Token = "0x40004E4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004E5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004E6")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004E7")]
	[FieldOffset(Offset = "0x30")]
	public float Brightness;

	[Token(Token = "0x40004E8")]
	[FieldOffset(Offset = "0x34")]
	public int ResolutionX;

	[Token(Token = "0x40004E9")]
	[FieldOffset(Offset = "0x38")]
	public int ResolutionY;

	[Token(Token = "0x170000A7")]
	private Material material
	{
		[Token(Token = "0x6000418")]
		[Address(RVA = "0x696954", Offset = "0x696954", VA = "0x696954")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000419")]
	[Address(RVA = "0x696A18", Offset = "0x696A18", VA = "0x696A18")]
	private void Start()
	{
	}

	[Token(Token = "0x600041A")]
	[Address(RVA = "0x696A94", Offset = "0x696A94", VA = "0x696A94")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600041B")]
	[Address(RVA = "0x696C74", Offset = "0x696C74", VA = "0x696C74")]
	private void Update()
	{
	}

	[Token(Token = "0x600041C")]
	[Address(RVA = "0x696C78", Offset = "0x696C78", VA = "0x696C78")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600041D")]
	[Address(RVA = "0x696D28", Offset = "0x696D28", VA = "0x696D28")]
	public CameraFilterPack_FX_8bits()
	{
	}
}
