using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003C")]
public class CameraFilterPack_Blend2Camera_PinLight : MonoBehaviour
{
	[Token(Token = "0x400023F")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000240")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000241")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000242")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000243")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000244")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000245")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000246")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700003D")]
	private Material material
	{
		[Token(Token = "0x6000189")]
		[Address(RVA = "0x660E88", Offset = "0x660E88", VA = "0x660E88")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600018A")]
	[Address(RVA = "0x660F4C", Offset = "0x660F4C", VA = "0x660F4C")]
	private void Start()
	{
	}

	[Token(Token = "0x600018B")]
	[Address(RVA = "0x661064", Offset = "0x661064", VA = "0x661064")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600018C")]
	[Address(RVA = "0x6612F4", Offset = "0x6612F4", VA = "0x6612F4")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600018D")]
	[Address(RVA = "0x6613E0", Offset = "0x6613E0", VA = "0x6613E0")]
	private void Update()
	{
	}

	[Token(Token = "0x600018E")]
	[Address(RVA = "0x6613E4", Offset = "0x6613E4", VA = "0x6613E4")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600018F")]
	[Address(RVA = "0x6614D0", Offset = "0x6614D0", VA = "0x6614D0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000190")]
	[Address(RVA = "0x6615C8", Offset = "0x6615C8", VA = "0x6615C8")]
	public CameraFilterPack_Blend2Camera_PinLight()
	{
	}
}
