using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DD")]
public class CameraFilterPack_Lut_Mask : MonoBehaviour
{
	[Token(Token = "0x4000661")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000662")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000663")]
	[FieldOffset(Offset = "0x24")]
	private Vector4 ScreenResolution;

	[Token(Token = "0x4000664")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000665")]
	[FieldOffset(Offset = "0x40")]
	public Texture2D LutTexture;

	[Token(Token = "0x4000666")]
	[FieldOffset(Offset = "0x48")]
	private Texture3D converted3DLut;

	[Token(Token = "0x4000667")]
	[FieldOffset(Offset = "0x50")]
	public float Blend;

	[Token(Token = "0x4000668")]
	[FieldOffset(Offset = "0x58")]
	public Texture2D Mask;

	[Token(Token = "0x4000669")]
	[FieldOffset(Offset = "0x60")]
	public float Inverse;

	[Token(Token = "0x400066A")]
	[FieldOffset(Offset = "0x68")]
	private string MemoPath;

	[Token(Token = "0x170000DE")]
	private Material material
	{
		[Token(Token = "0x600056A")]
		[Address(RVA = "0x6A7730", Offset = "0x6A7730", VA = "0x6A7730")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600056B")]
	[Address(RVA = "0x6A77F4", Offset = "0x6A77F4", VA = "0x6A77F4")]
	private void Start()
	{
	}

	[Token(Token = "0x600056C")]
	[Address(RVA = "0x6A7870", Offset = "0x6A7870", VA = "0x6A7870")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x600056D")]
	[Address(RVA = "0x6A7A5C", Offset = "0x6A7A5C", VA = "0x6A7A5C")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x600056E")]
	[Address(RVA = "0x6A7B50", Offset = "0x6A7B50", VA = "0x6A7B50")]
	public void Convert(Texture2D temp2DTex)
	{
	}

	[Token(Token = "0x600056F")]
	[Address(RVA = "0x6A7E20", Offset = "0x6A7E20", VA = "0x6A7E20")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000570")]
	[Address(RVA = "0x6A8068", Offset = "0x6A8068", VA = "0x6A8068")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000571")]
	[Address(RVA = "0x6A806C", Offset = "0x6A806C", VA = "0x6A806C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000572")]
	[Address(RVA = "0x6A8070", Offset = "0x6A8070", VA = "0x6A8070")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000573")]
	[Address(RVA = "0x6A8120", Offset = "0x6A8120", VA = "0x6A8120")]
	public CameraFilterPack_Lut_Mask()
	{
	}
}
