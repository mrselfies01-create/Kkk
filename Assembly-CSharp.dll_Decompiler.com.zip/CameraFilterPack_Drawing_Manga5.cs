using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000092")]
public class CameraFilterPack_Drawing_Manga5 : MonoBehaviour
{
	[Token(Token = "0x400045A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400045B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400045C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400045D")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x17000093")]
	private Material material
	{
		[Token(Token = "0x600039F")]
		[Address(RVA = "0x690F5C", Offset = "0x690F5C", VA = "0x690F5C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003A0")]
	[Address(RVA = "0x691020", Offset = "0x691020", VA = "0x691020")]
	private void Start()
	{
	}

	[Token(Token = "0x60003A1")]
	[Address(RVA = "0x69109C", Offset = "0x69109C", VA = "0x69109C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003A2")]
	[Address(RVA = "0x691220", Offset = "0x691220", VA = "0x691220")]
	private void Update()
	{
	}

	[Token(Token = "0x60003A3")]
	[Address(RVA = "0x691224", Offset = "0x691224", VA = "0x691224")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003A4")]
	[Address(RVA = "0x6912D4", Offset = "0x6912D4", VA = "0x6912D4")]
	public CameraFilterPack_Drawing_Manga5()
	{
	}
}
