using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005A")]
public class CameraFilterPack_Color_BrightContrastSaturation : MonoBehaviour
{
	[Token(Token = "0x4000320")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000321")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000322")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000323")]
	[FieldOffset(Offset = "0x30")]
	public float Brightness;

	[Token(Token = "0x4000324")]
	[FieldOffset(Offset = "0x34")]
	public float Saturation;

	[Token(Token = "0x4000325")]
	[FieldOffset(Offset = "0x38")]
	public float Contrast;

	[Token(Token = "0x1700005B")]
	private Material material
	{
		[Token(Token = "0x600024D")]
		[Address(RVA = "0x66B358", Offset = "0x66B358", VA = "0x66B358")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600024E")]
	[Address(RVA = "0x66B41C", Offset = "0x66B41C", VA = "0x66B41C")]
	private void Start()
	{
	}

	[Token(Token = "0x600024F")]
	[Address(RVA = "0x66B498", Offset = "0x66B498", VA = "0x66B498")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000250")]
	[Address(RVA = "0x66B6F8", Offset = "0x66B6F8", VA = "0x66B6F8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000251")]
	[Address(RVA = "0x66B6FC", Offset = "0x66B6FC", VA = "0x66B6FC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000252")]
	[Address(RVA = "0x66B7AC", Offset = "0x66B7AC", VA = "0x66B7AC")]
	public CameraFilterPack_Color_BrightContrastSaturation()
	{
	}
}
