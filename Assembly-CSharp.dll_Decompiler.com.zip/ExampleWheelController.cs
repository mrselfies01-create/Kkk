using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200013A")]
public class ExampleWheelController : MonoBehaviour
{
	[Token(Token = "0x20001F9")]
	private static class Uniforms
	{
		[Token(Token = "0x4000D8A")]
		[FieldOffset(Offset = "0x0")]
		internal static readonly int _MotionAmount;
	}

	[Token(Token = "0x40008E7")]
	[FieldOffset(Offset = "0x18")]
	public float acceleration;

	[Token(Token = "0x40008E8")]
	[FieldOffset(Offset = "0x20")]
	public Renderer motionVectorRenderer;

	[Token(Token = "0x40008E9")]
	[FieldOffset(Offset = "0x28")]
	private Rigidbody m_Rigidbody;

	[Token(Token = "0x60007AC")]
	[Address(RVA = "0x388190", Offset = "0x388190", VA = "0x388190")]
	private void Start()
	{
	}

	[Token(Token = "0x60007AD")]
	[Address(RVA = "0x3881FC", Offset = "0x3881FC", VA = "0x3881FC")]
	private void Update()
	{
	}

	[Token(Token = "0x60007AE")]
	[Address(RVA = "0x388390", Offset = "0x388390", VA = "0x388390")]
	public ExampleWheelController()
	{
	}
}
