using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D8")]
public class CameraFilterPack_Light_Rainbow2 : MonoBehaviour
{
	[Token(Token = "0x4000635")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000636")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000637")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000638")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000D9")]
	private Material material
	{
		[Token(Token = "0x6000544")]
		[Address(RVA = "0x6A51C4", Offset = "0x6A51C4", VA = "0x6A51C4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000545")]
	[Address(RVA = "0x6A5288", Offset = "0x6A5288", VA = "0x6A5288")]
	private void Start()
	{
	}

	[Token(Token = "0x6000546")]
	[Address(RVA = "0x6A5304", Offset = "0x6A5304", VA = "0x6A5304")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000547")]
	[Address(RVA = "0x6A551C", Offset = "0x6A551C", VA = "0x6A551C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000548")]
	[Address(RVA = "0x6A5520", Offset = "0x6A5520", VA = "0x6A5520")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000549")]
	[Address(RVA = "0x6A55D0", Offset = "0x6A55D0", VA = "0x6A55D0")]
	public CameraFilterPack_Light_Rainbow2()
	{
	}
}
