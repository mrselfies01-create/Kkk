using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000008")]
public class CameraFilterPack_3D_Binary : MonoBehaviour
{
	[Token(Token = "0x4000021")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000022")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000023")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000024")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000025")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000026")]
	[FieldOffset(Offset = "0x34")]
	public float LightIntensity;

	[Token(Token = "0x4000027")]
	[FieldOffset(Offset = "0x38")]
	public float MatrixSize;

	[Token(Token = "0x4000028")]
	[FieldOffset(Offset = "0x3C")]
	public float MatrixSpeed;

	[Token(Token = "0x4000029")]
	[FieldOffset(Offset = "0x40")]
	public float Fade;

	[Token(Token = "0x400002A")]
	[FieldOffset(Offset = "0x44")]
	public float FadeFromBinary;

	[Token(Token = "0x400002B")]
	[FieldOffset(Offset = "0x48")]
	public Color _MatrixColor;

	[Token(Token = "0x400002C")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x400002D")]
	[FieldOffset(Offset = "0x58")]
	private Texture2D Texture2;

	[Token(Token = "0x17000009")]
	private Material material
	{
		[Token(Token = "0x6000022")]
		[Address(RVA = "0x5B2F94", Offset = "0x5B2F94", VA = "0x5B2F94")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000023")]
	[Address(RVA = "0x5B3058", Offset = "0x5B3058", VA = "0x5B3058")]
	private void Start()
	{
	}

	[Token(Token = "0x6000024")]
	[Address(RVA = "0x5B3110", Offset = "0x5B3110", VA = "0x5B3110")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000025")]
	[Address(RVA = "0x5B34CC", Offset = "0x5B34CC", VA = "0x5B34CC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000026")]
	[Address(RVA = "0x5B34D0", Offset = "0x5B34D0", VA = "0x5B34D0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000027")]
	[Address(RVA = "0x5B3580", Offset = "0x5B3580", VA = "0x5B3580")]
	public CameraFilterPack_3D_Binary()
	{
	}
}
