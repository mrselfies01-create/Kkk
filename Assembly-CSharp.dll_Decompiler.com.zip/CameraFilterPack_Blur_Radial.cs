using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004E")]
public class CameraFilterPack_Blur_Radial : MonoBehaviour
{
	[Token(Token = "0x40002C9")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002CA")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002CB")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002CC")]
	[FieldOffset(Offset = "0x30")]
	public float Intensity;

	[Token(Token = "0x40002CD")]
	[FieldOffset(Offset = "0x34")]
	public float MovX;

	[Token(Token = "0x40002CE")]
	[FieldOffset(Offset = "0x38")]
	public float MovY;

	[Token(Token = "0x40002CF")]
	[FieldOffset(Offset = "0x3C")]
	private float blurWidth;

	[Token(Token = "0x1700004F")]
	private Material material
	{
		[Token(Token = "0x6000205")]
		[Address(RVA = "0x667864", Offset = "0x667864", VA = "0x667864")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000206")]
	[Address(RVA = "0x667928", Offset = "0x667928", VA = "0x667928")]
	private void Start()
	{
	}

	[Token(Token = "0x6000207")]
	[Address(RVA = "0x6679A4", Offset = "0x6679A4", VA = "0x6679A4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000208")]
	[Address(RVA = "0x667C28", Offset = "0x667C28", VA = "0x667C28")]
	private void Update()
	{
	}

	[Token(Token = "0x6000209")]
	[Address(RVA = "0x667C2C", Offset = "0x667C2C", VA = "0x667C2C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600020A")]
	[Address(RVA = "0x667CDC", Offset = "0x667CDC", VA = "0x667CDC")]
	public CameraFilterPack_Blur_Radial()
	{
	}
}
