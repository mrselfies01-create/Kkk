using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001F")]
public class CameraFilterPack_Atmosphere_Fog : MonoBehaviour
{
	[Token(Token = "0x400012F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000130")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000131")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000132")]
	[FieldOffset(Offset = "0x30")]
	public float _Near;

	[Token(Token = "0x4000133")]
	[FieldOffset(Offset = "0x34")]
	public float _Far;

	[Token(Token = "0x4000134")]
	[FieldOffset(Offset = "0x38")]
	public Color FogColor;

	[Token(Token = "0x4000135")]
	[FieldOffset(Offset = "0x48")]
	public float Fade;

	[Token(Token = "0x4000136")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x4000137")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x17000020")]
	private Material material
	{
		[Token(Token = "0x60000AC")]
		[Address(RVA = "0x5BB2CC", Offset = "0x5BB2CC", VA = "0x5BB2CC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000AD")]
	[Address(RVA = "0x5BB390", Offset = "0x5BB390", VA = "0x5BB390")]
	private void Start()
	{
	}

	[Token(Token = "0x60000AE")]
	[Address(RVA = "0x5BB448", Offset = "0x5BB448", VA = "0x5BB448")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000AF")]
	[Address(RVA = "0x5BB718", Offset = "0x5BB718", VA = "0x5BB718")]
	private void Update()
	{
	}

	[Token(Token = "0x60000B0")]
	[Address(RVA = "0x5BB71C", Offset = "0x5BB71C", VA = "0x5BB71C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000B1")]
	[Address(RVA = "0x5BB7CC", Offset = "0x5BB7CC", VA = "0x5BB7CC")]
	public CameraFilterPack_Atmosphere_Fog()
	{
	}
}
