using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000065")]
public class CameraFilterPack_Colors_Adjust_ColorRGB : MonoBehaviour
{
	[Token(Token = "0x4000352")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000353")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000354")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000355")]
	[FieldOffset(Offset = "0x30")]
	public float Red;

	[Token(Token = "0x4000356")]
	[FieldOffset(Offset = "0x34")]
	public float Green;

	[Token(Token = "0x4000357")]
	[FieldOffset(Offset = "0x38")]
	public float Blue;

	[Token(Token = "0x4000358")]
	[FieldOffset(Offset = "0x3C")]
	public float Brightness;

	[Token(Token = "0x17000066")]
	private Material material
	{
		[Token(Token = "0x600028F")]
		[Address(RVA = "0x66E20C", Offset = "0x66E20C", VA = "0x66E20C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000290")]
	[Address(RVA = "0x66E2D0", Offset = "0x66E2D0", VA = "0x66E2D0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000291")]
	[Address(RVA = "0x66E34C", Offset = "0x66E34C", VA = "0x66E34C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000292")]
	[Address(RVA = "0x66E5D0", Offset = "0x66E5D0", VA = "0x66E5D0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000293")]
	[Address(RVA = "0x66E5D4", Offset = "0x66E5D4", VA = "0x66E5D4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000294")]
	[Address(RVA = "0x66E684", Offset = "0x66E684", VA = "0x66E684")]
	public CameraFilterPack_Colors_Adjust_ColorRGB()
	{
	}
}
