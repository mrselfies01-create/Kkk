using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D0")]
public class CameraFilterPack_Gradients_FireGradient : MonoBehaviour
{
	[Token(Token = "0x4000607")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000608")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x4000609")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x400060A")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x400060B")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x400060C")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D1")]
	private Material material
	{
		[Token(Token = "0x6000514")]
		[Address(RVA = "0x6A2EAC", Offset = "0x6A2EAC", VA = "0x6A2EAC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000515")]
	[Address(RVA = "0x6A2F70", Offset = "0x6A2F70", VA = "0x6A2F70")]
	private void Start()
	{
	}

	[Token(Token = "0x6000516")]
	[Address(RVA = "0x6A2FC0", Offset = "0x6A2FC0", VA = "0x6A2FC0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000517")]
	[Address(RVA = "0x6A31FC", Offset = "0x6A31FC", VA = "0x6A31FC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000518")]
	[Address(RVA = "0x6A3200", Offset = "0x6A3200", VA = "0x6A3200")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000519")]
	[Address(RVA = "0x6A32B0", Offset = "0x6A32B0", VA = "0x6A32B0")]
	public CameraFilterPack_Gradients_FireGradient()
	{
	}
}
