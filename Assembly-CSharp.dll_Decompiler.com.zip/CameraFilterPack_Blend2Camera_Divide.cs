using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002D")]
public class CameraFilterPack_Blend2Camera_Divide : MonoBehaviour
{
	[Token(Token = "0x40001BF")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001C0")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001C1")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001C2")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001C3")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001C4")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001C5")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001C6")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700002E")]
	private Material material
	{
		[Token(Token = "0x6000111")]
		[Address(RVA = "0x5C122C", Offset = "0x5C122C", VA = "0x5C122C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000112")]
	[Address(RVA = "0x5C12F0", Offset = "0x5C12F0", VA = "0x5C12F0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000113")]
	[Address(RVA = "0x5C1408", Offset = "0x5C1408", VA = "0x5C1408")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000114")]
	[Address(RVA = "0x5C1698", Offset = "0x5C1698", VA = "0x5C1698")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000115")]
	[Address(RVA = "0x5C1784", Offset = "0x5C1784", VA = "0x5C1784")]
	private void Update()
	{
	}

	[Token(Token = "0x6000116")]
	[Address(RVA = "0x5C1788", Offset = "0x5C1788", VA = "0x5C1788")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000117")]
	[Address(RVA = "0x5C1874", Offset = "0x5C1874", VA = "0x5C1874")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000118")]
	[Address(RVA = "0x5C196C", Offset = "0x5C196C", VA = "0x5C196C")]
	public CameraFilterPack_Blend2Camera_Divide()
	{
	}
}
