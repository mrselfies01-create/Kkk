using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000028")]
public class CameraFilterPack_Blend2Camera_ColorDodge : MonoBehaviour
{
	[Token(Token = "0x4000190")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000191")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000192")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000193")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000194")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000195")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000196")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000197")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000029")]
	private Material material
	{
		[Token(Token = "0x60000EA")]
		[Address(RVA = "0x5BECE0", Offset = "0x5BECE0", VA = "0x5BECE0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000EB")]
	[Address(RVA = "0x5BEDA4", Offset = "0x5BEDA4", VA = "0x5BEDA4")]
	private void Start()
	{
	}

	[Token(Token = "0x60000EC")]
	[Address(RVA = "0x5BEEBC", Offset = "0x5BEEBC", VA = "0x5BEEBC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000ED")]
	[Address(RVA = "0x5BF14C", Offset = "0x5BF14C", VA = "0x5BF14C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000EE")]
	[Address(RVA = "0x5BF238", Offset = "0x5BF238", VA = "0x5BF238")]
	private void Update()
	{
	}

	[Token(Token = "0x60000EF")]
	[Address(RVA = "0x5BF23C", Offset = "0x5BF23C", VA = "0x5BF23C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000F0")]
	[Address(RVA = "0x5BF328", Offset = "0x5BF328", VA = "0x5BF328")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000F1")]
	[Address(RVA = "0x5BF420", Offset = "0x5BF420", VA = "0x5BF420")]
	public CameraFilterPack_Blend2Camera_ColorDodge()
	{
	}
}
