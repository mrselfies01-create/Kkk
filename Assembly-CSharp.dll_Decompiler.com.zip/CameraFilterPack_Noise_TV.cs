using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000EB")]
public class CameraFilterPack_Noise_TV : MonoBehaviour
{
	[Token(Token = "0x40006D3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006D4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006D5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006D6")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x40006D7")]
	[FieldOffset(Offset = "0x34")]
	private float Value2;

	[Token(Token = "0x40006D8")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x40006D9")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x40006DA")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000EC")]
	private Material material
	{
		[Token(Token = "0x60005D4")]
		[Address(RVA = "0x62D03C", Offset = "0x62D03C", VA = "0x62D03C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005D5")]
	[Address(RVA = "0x62D100", Offset = "0x62D100", VA = "0x62D100")]
	private void Start()
	{
	}

	[Token(Token = "0x60005D6")]
	[Address(RVA = "0x62D1B8", Offset = "0x62D1B8", VA = "0x62D1B8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005D7")]
	[Address(RVA = "0x62D460", Offset = "0x62D460", VA = "0x62D460")]
	private void Update()
	{
	}

	[Token(Token = "0x60005D8")]
	[Address(RVA = "0x62D464", Offset = "0x62D464", VA = "0x62D464")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005D9")]
	[Address(RVA = "0x62D514", Offset = "0x62D514", VA = "0x62D514")]
	public CameraFilterPack_Noise_TV()
	{
	}
}
