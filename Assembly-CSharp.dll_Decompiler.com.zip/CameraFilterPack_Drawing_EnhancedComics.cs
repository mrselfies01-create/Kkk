using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008A")]
public class CameraFilterPack_Drawing_EnhancedComics : MonoBehaviour
{
	[Token(Token = "0x4000430")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000431")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000432")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000433")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x4000434")]
	[FieldOffset(Offset = "0x34")]
	public float _ColorR;

	[Token(Token = "0x4000435")]
	[FieldOffset(Offset = "0x38")]
	public float _ColorG;

	[Token(Token = "0x4000436")]
	[FieldOffset(Offset = "0x3C")]
	public float _ColorB;

	[Token(Token = "0x4000437")]
	[FieldOffset(Offset = "0x40")]
	public float _Blood;

	[Token(Token = "0x4000438")]
	[FieldOffset(Offset = "0x44")]
	public float _SmoothStart;

	[Token(Token = "0x4000439")]
	[FieldOffset(Offset = "0x48")]
	public float _SmoothEnd;

	[Token(Token = "0x400043A")]
	[FieldOffset(Offset = "0x4C")]
	public Color ColorRGB;

	[Token(Token = "0x1700008B")]
	private Material material
	{
		[Token(Token = "0x600036F")]
		[Address(RVA = "0x678B78", Offset = "0x678B78", VA = "0x678B78")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000370")]
	[Address(RVA = "0x678C3C", Offset = "0x678C3C", VA = "0x678C3C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000371")]
	[Address(RVA = "0x678CB8", Offset = "0x678CB8", VA = "0x678CB8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000372")]
	[Address(RVA = "0x678F3C", Offset = "0x678F3C", VA = "0x678F3C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000373")]
	[Address(RVA = "0x678F40", Offset = "0x678F40", VA = "0x678F40")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000374")]
	[Address(RVA = "0x678FF0", Offset = "0x678FF0", VA = "0x678FF0")]
	public CameraFilterPack_Drawing_EnhancedComics()
	{
	}
}
