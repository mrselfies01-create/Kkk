using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011F")]
public class CameraFilterPack_TV_WideScreenHV : MonoBehaviour
{
	[Token(Token = "0x400081A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400081B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400081C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400081D")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400081E")]
	[FieldOffset(Offset = "0x34")]
	public float Smooth;

	[Token(Token = "0x400081F")]
	[FieldOffset(Offset = "0x38")]
	private float StretchX;

	[Token(Token = "0x4000820")]
	[FieldOffset(Offset = "0x3C")]
	private float StretchY;

	[Token(Token = "0x17000120")]
	private Material material
	{
		[Token(Token = "0x6000711")]
		[Address(RVA = "0x63BFBC", Offset = "0x63BFBC", VA = "0x63BFBC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000712")]
	[Address(RVA = "0x63C080", Offset = "0x63C080", VA = "0x63C080")]
	private void Start()
	{
	}

	[Token(Token = "0x6000713")]
	[Address(RVA = "0x63C0FC", Offset = "0x63C0FC", VA = "0x63C0FC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000714")]
	[Address(RVA = "0x63C380", Offset = "0x63C380", VA = "0x63C380")]
	private void Update()
	{
	}

	[Token(Token = "0x6000715")]
	[Address(RVA = "0x63C384", Offset = "0x63C384", VA = "0x63C384")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000716")]
	[Address(RVA = "0x63C434", Offset = "0x63C434", VA = "0x63C434")]
	public CameraFilterPack_TV_WideScreenHV()
	{
	}
}
