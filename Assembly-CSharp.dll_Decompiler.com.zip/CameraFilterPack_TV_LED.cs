using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010D")]
public class CameraFilterPack_TV_LED : MonoBehaviour
{
	[Token(Token = "0x40007BC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007BD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007BE")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40007BF")]
	[FieldOffset(Offset = "0x28")]
	private float Distortion;

	[Token(Token = "0x40007C0")]
	[FieldOffset(Offset = "0x2C")]
	public int Size;

	[Token(Token = "0x40007C1")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x1700010E")]
	private Material material
	{
		[Token(Token = "0x60006A5")]
		[Address(RVA = "0x637538", Offset = "0x637538", VA = "0x637538")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006A6")]
	[Address(RVA = "0x6375FC", Offset = "0x6375FC", VA = "0x6375FC")]
	private void Start()
	{
	}

	[Token(Token = "0x60006A7")]
	[Address(RVA = "0x637678", Offset = "0x637678", VA = "0x637678")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006A8")]
	[Address(RVA = "0x6378DC", Offset = "0x6378DC", VA = "0x6378DC")]
	private void Update()
	{
	}

	[Token(Token = "0x60006A9")]
	[Address(RVA = "0x6378E0", Offset = "0x6378E0", VA = "0x6378E0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006AA")]
	[Address(RVA = "0x637990", Offset = "0x637990", VA = "0x637990")]
	public CameraFilterPack_TV_LED()
	{
	}
}
