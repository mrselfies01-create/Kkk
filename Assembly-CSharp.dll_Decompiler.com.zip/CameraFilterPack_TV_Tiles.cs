using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000116")]
public class CameraFilterPack_TV_Tiles : MonoBehaviour
{
	[Token(Token = "0x40007E8")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007E9")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007EA")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007EB")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x40007EC")]
	[FieldOffset(Offset = "0x34")]
	public float Intensity;

	[Token(Token = "0x40007ED")]
	[FieldOffset(Offset = "0x38")]
	public float StretchX;

	[Token(Token = "0x40007EE")]
	[FieldOffset(Offset = "0x3C")]
	public float StretchY;

	[Token(Token = "0x40007EF")]
	[FieldOffset(Offset = "0x40")]
	public float Fade;

	[Token(Token = "0x17000117")]
	private Material material
	{
		[Token(Token = "0x60006DB")]
		[Address(RVA = "0x6399E8", Offset = "0x6399E8", VA = "0x6399E8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006DC")]
	[Address(RVA = "0x639AAC", Offset = "0x639AAC", VA = "0x639AAC")]
	private void Start()
	{
	}

	[Token(Token = "0x60006DD")]
	[Address(RVA = "0x639B28", Offset = "0x639B28", VA = "0x639B28")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006DE")]
	[Address(RVA = "0x639DD0", Offset = "0x639DD0", VA = "0x639DD0")]
	private void Update()
	{
	}

	[Token(Token = "0x60006DF")]
	[Address(RVA = "0x639DD4", Offset = "0x639DD4", VA = "0x639DD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006E0")]
	[Address(RVA = "0x639E84", Offset = "0x639E84", VA = "0x639E84")]
	public CameraFilterPack_TV_Tiles()
	{
	}
}
