using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FF")]
public class CameraFilterPack_Special_Bubble : MonoBehaviour
{
	[Token(Token = "0x400075E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400075F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000760")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000761")]
	[FieldOffset(Offset = "0x30")]
	public float X;

	[Token(Token = "0x4000762")]
	[FieldOffset(Offset = "0x34")]
	public float Y;

	[Token(Token = "0x4000763")]
	[FieldOffset(Offset = "0x38")]
	public float Rate;

	[Token(Token = "0x4000764")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000100")]
	private Material material
	{
		[Token(Token = "0x6000651")]
		[Address(RVA = "0x633514", Offset = "0x633514", VA = "0x633514")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000652")]
	[Address(RVA = "0x6335D8", Offset = "0x6335D8", VA = "0x6335D8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000653")]
	[Address(RVA = "0x633654", Offset = "0x633654", VA = "0x633654")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000654")]
	[Address(RVA = "0x6338D8", Offset = "0x6338D8", VA = "0x6338D8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000655")]
	[Address(RVA = "0x6338DC", Offset = "0x6338DC", VA = "0x6338DC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000656")]
	[Address(RVA = "0x63398C", Offset = "0x63398C", VA = "0x63398C")]
	public CameraFilterPack_Special_Bubble()
	{
	}
}
