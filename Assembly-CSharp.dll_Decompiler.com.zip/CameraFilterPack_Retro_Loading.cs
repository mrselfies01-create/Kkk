using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FD")]
public class CameraFilterPack_Retro_Loading : MonoBehaviour
{
	[Token(Token = "0x4000755")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000756")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000757")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000758")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x170000FE")]
	private Material material
	{
		[Token(Token = "0x6000645")]
		[Address(RVA = "0x632CA8", Offset = "0x632CA8", VA = "0x632CA8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000646")]
	[Address(RVA = "0x632D6C", Offset = "0x632D6C", VA = "0x632D6C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000647")]
	[Address(RVA = "0x632DE8", Offset = "0x632DE8", VA = "0x632DE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000648")]
	[Address(RVA = "0x633000", Offset = "0x633000", VA = "0x633000")]
	private void Update()
	{
	}

	[Token(Token = "0x6000649")]
	[Address(RVA = "0x633004", Offset = "0x633004", VA = "0x633004")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600064A")]
	[Address(RVA = "0x6330B4", Offset = "0x6330B4", VA = "0x6330B4")]
	public CameraFilterPack_Retro_Loading()
	{
	}
}
