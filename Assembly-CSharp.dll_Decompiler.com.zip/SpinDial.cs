using System;
using System.Collections;
using System.Collections.Generic;
using DuloGames.UI;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[Token(Token = "0x2000140")]
public class SpinDial : MonoBehaviour, IDisposable, IContentHandler, IComparer<Contraction>, IEqualityComparer
{
	[Token(Token = "0x4000972")]
	[FieldOffset(Offset = "0x18")]
	public bool dragOnSurfaces;

	[Token(Token = "0x4000973")]
	[FieldOffset(Offset = "0x20")]
	private GameObject m_DraggingIcon;

	[Token(Token = "0x4000974")]
	[FieldOffset(Offset = "0x28")]
	private RectTransform m_DraggingPlane;

	[Token(Token = "0x4000975")]
	[FieldOffset(Offset = "0x30")]
	private Vector2 lastPos;

	[Token(Token = "0x4000976")]
	[FieldOffset(Offset = "0x38")]
	public Image glow;

	[Token(Token = "0x4000977")]
	[FieldOffset(Offset = "0x40")]
	private float maskmin;

	[Token(Token = "0x4000978")]
	[FieldOffset(Offset = "0x44")]
	private float maskmax;

	[Token(Token = "0x4000979")]
	[FieldOffset(Offset = "0x48")]
	public float value;

	[Token(Token = "0x400097A")]
	[FieldOffset(Offset = "0x4C")]
	public float minvalue;

	[Token(Token = "0x400097B")]
	[FieldOffset(Offset = "0x50")]
	public float maxvalue;

	[Token(Token = "0x400097C")]
	[FieldOffset(Offset = "0x54")]
	private float minrot;

	[Token(Token = "0x400097D")]
	[FieldOffset(Offset = "0x58")]
	private float maxrot;

	[Token(Token = "0x400097E")]
	[FieldOffset(Offset = "0x60")]
	private UIJoystick joystick;

	[Token(Token = "0x400097F")]
	[FieldOffset(Offset = "0x68")]
	public bool UseJoystick;

	[Token(Token = "0x4000980")]
	[FieldOffset(Offset = "0x70")]
	public RectTransform top;

	[Token(Token = "0x4000981")]
	[FieldOffset(Offset = "0x78")]
	public Camera cam;

	[Token(Token = "0x4000982")]
	[FieldOffset(Offset = "0x80")]
	private Vector3 pointerStart;

	[Token(Token = "0x4000983")]
	[FieldOffset(Offset = "0x8C")]
	private Vector3 curPointer;

	[Token(Token = "0x4000984")]
	[FieldOffset(Offset = "0x98")]
	private bool isPointerDown;

	[Token(Token = "0x60007D7")]
	[Address(RVA = "0x3DD51C", Offset = "0x3DD51C", VA = "0x3DD51C", Slot = "4")]
	public void OnBeginDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x60007D8")]
	[Address(RVA = "0x3DD594", Offset = "0x3DD594", VA = "0x3DD594", Slot = "5")]
	public void OnDrag(PointerEventData data)
	{
	}

	[Token(Token = "0x60007D9")]
	[Address(RVA = "0x3DD708", Offset = "0x3DD708", VA = "0x3DD708", Slot = "6")]
	public void OnEndDrag(PointerEventData eventData)
	{
	}

	[Token(Token = "0x60007DA")]
	[Address(RVA = "0x3DD77C", Offset = "0x3DD77C", VA = "0x3DD77C")]
	private void Start()
	{
	}

	[Token(Token = "0x60007DB")]
	[Address(RVA = "0x3DD8A8", Offset = "0x3DD8A8", VA = "0x3DD8A8")]
	private void Update()
	{
	}

	[Token(Token = "0x60007DC")]
	[Address(RVA = "0x3DDB28", Offset = "0x3DDB28", VA = "0x3DDB28")]
	public void OnPointerDown(PointerEventData eventData)
	{
	}

	[Token(Token = "0x60007DD")]
	[Address(RVA = "0x3DDBE0", Offset = "0x3DDBE0", VA = "0x3DDBE0")]
	public void OnMove(AxisEventData eventData)
	{
	}

	[Token(Token = "0x60007DE")]
	[Address(RVA = "0x3DDD7C", Offset = "0x3DDD7C", VA = "0x3DDD7C")]
	public void OnPointerUp(PointerEventData eventData)
	{
	}

	[Token(Token = "0x60007DF")]
	[Address(RVA = "0x3DDDF0", Offset = "0x3DDDF0", VA = "0x3DDDF0")]
	public SpinDial()
	{
	}
}
