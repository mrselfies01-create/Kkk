using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007E")]
public class CameraFilterPack_Distortion_ShockWave : MonoBehaviour
{
	[Token(Token = "0x40003E5")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003E6")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003E7")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003E8")]
	[FieldOffset(Offset = "0x30")]
	public float PosX;

	[Token(Token = "0x40003E9")]
	[FieldOffset(Offset = "0x34")]
	public float PosY;

	[Token(Token = "0x40003EA")]
	[FieldOffset(Offset = "0x38")]
	public float Speed;

	[Token(Token = "0x40003EB")]
	[FieldOffset(Offset = "0x3C")]
	private float Size;

	[Token(Token = "0x1700007F")]
	private Material material
	{
		[Token(Token = "0x6000327")]
		[Address(RVA = "0x67567C", Offset = "0x67567C", VA = "0x67567C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000328")]
	[Address(RVA = "0x675740", Offset = "0x675740", VA = "0x675740")]
	private void Start()
	{
	}

	[Token(Token = "0x6000329")]
	[Address(RVA = "0x6757BC", Offset = "0x6757BC", VA = "0x6757BC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600032A")]
	[Address(RVA = "0x675A40", Offset = "0x675A40", VA = "0x675A40")]
	private void Update()
	{
	}

	[Token(Token = "0x600032B")]
	[Address(RVA = "0x675A44", Offset = "0x675A44", VA = "0x675A44")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600032C")]
	[Address(RVA = "0x675AF4", Offset = "0x675AF4", VA = "0x675AF4")]
	public CameraFilterPack_Distortion_ShockWave()
	{
	}
}
