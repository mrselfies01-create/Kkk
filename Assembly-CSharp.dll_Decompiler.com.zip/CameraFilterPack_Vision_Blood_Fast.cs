using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000126")]
public class CameraFilterPack_Vision_Blood_Fast : MonoBehaviour
{
	[Token(Token = "0x400084A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400084B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400084C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400084D")]
	[FieldOffset(Offset = "0x30")]
	public float HoleSize;

	[Token(Token = "0x400084E")]
	[FieldOffset(Offset = "0x34")]
	public float HoleSmooth;

	[Token(Token = "0x400084F")]
	[FieldOffset(Offset = "0x38")]
	public float Color1;

	[Token(Token = "0x4000850")]
	[FieldOffset(Offset = "0x3C")]
	public float Color2;

	[Token(Token = "0x17000127")]
	private Material material
	{
		[Token(Token = "0x600073B")]
		[Address(RVA = "0x63E05C", Offset = "0x63E05C", VA = "0x63E05C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600073C")]
	[Address(RVA = "0x63E120", Offset = "0x63E120", VA = "0x63E120")]
	private void Start()
	{
	}

	[Token(Token = "0x600073D")]
	[Address(RVA = "0x63E19C", Offset = "0x63E19C", VA = "0x63E19C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600073E")]
	[Address(RVA = "0x63E420", Offset = "0x63E420", VA = "0x63E420")]
	private void Update()
	{
	}

	[Token(Token = "0x600073F")]
	[Address(RVA = "0x63E424", Offset = "0x63E424", VA = "0x63E424")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000740")]
	[Address(RVA = "0x63E4D4", Offset = "0x63E4D4", VA = "0x63E4D4")]
	public CameraFilterPack_Vision_Blood_Fast()
	{
	}
}
