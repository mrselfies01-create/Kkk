using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AA")]
public class CameraFilterPack_FX_DigitalMatrix : MonoBehaviour
{
	[Token(Token = "0x40004FC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004FD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004FE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004FF")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000500")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000501")]
	[FieldOffset(Offset = "0x38")]
	public float ColorR;

	[Token(Token = "0x4000502")]
	[FieldOffset(Offset = "0x3C")]
	public float ColorG;

	[Token(Token = "0x4000503")]
	[FieldOffset(Offset = "0x40")]
	public float ColorB;

	[Token(Token = "0x170000AB")]
	private Material material
	{
		[Token(Token = "0x6000430")]
		[Address(RVA = "0x697A60", Offset = "0x697A60", VA = "0x697A60")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000431")]
	[Address(RVA = "0x697B24", Offset = "0x697B24", VA = "0x697B24")]
	private void Start()
	{
	}

	[Token(Token = "0x6000432")]
	[Address(RVA = "0x697BA0", Offset = "0x697BA0", VA = "0x697BA0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000433")]
	[Address(RVA = "0x697E48", Offset = "0x697E48", VA = "0x697E48")]
	private void Update()
	{
	}

	[Token(Token = "0x6000434")]
	[Address(RVA = "0x697E4C", Offset = "0x697E4C", VA = "0x697E4C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000435")]
	[Address(RVA = "0x697EFC", Offset = "0x697EFC", VA = "0x697EFC")]
	public CameraFilterPack_FX_DigitalMatrix()
	{
	}
}
