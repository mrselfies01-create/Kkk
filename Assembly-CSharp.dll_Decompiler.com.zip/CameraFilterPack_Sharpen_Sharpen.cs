using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FE")]
public class CameraFilterPack_Sharpen_Sharpen : MonoBehaviour
{
	[Token(Token = "0x4000759")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400075A")]
	[FieldOffset(Offset = "0x20")]
	public float Value;

	[Token(Token = "0x400075B")]
	[FieldOffset(Offset = "0x24")]
	public float Value2;

	[Token(Token = "0x400075C")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x400075D")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x170000FF")]
	private Material material
	{
		[Token(Token = "0x600064B")]
		[Address(RVA = "0x6330C8", Offset = "0x6330C8", VA = "0x6330C8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600064C")]
	[Address(RVA = "0x63318C", Offset = "0x63318C", VA = "0x63318C")]
	private void Start()
	{
	}

	[Token(Token = "0x600064D")]
	[Address(RVA = "0x633208", Offset = "0x633208", VA = "0x633208")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600064E")]
	[Address(RVA = "0x633444", Offset = "0x633444", VA = "0x633444")]
	private void Update()
	{
	}

	[Token(Token = "0x600064F")]
	[Address(RVA = "0x633448", Offset = "0x633448", VA = "0x633448")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000650")]
	[Address(RVA = "0x6334F8", Offset = "0x6334F8", VA = "0x6334F8")]
	public CameraFilterPack_Sharpen_Sharpen()
	{
	}
}
