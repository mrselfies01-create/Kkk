using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000077")]
public class CameraFilterPack_Distortion_FishEye : MonoBehaviour
{
	[Token(Token = "0x40003C3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003C4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003C5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003C6")]
	[FieldOffset(Offset = "0x30")]
	public float Distortion;

	[Token(Token = "0x17000078")]
	private Material material
	{
		[Token(Token = "0x60002FD")]
		[Address(RVA = "0x673910", Offset = "0x673910", VA = "0x673910")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002FE")]
	[Address(RVA = "0x6739D4", Offset = "0x6739D4", VA = "0x6739D4")]
	private void Start()
	{
	}

	[Token(Token = "0x60002FF")]
	[Address(RVA = "0x673A50", Offset = "0x673A50", VA = "0x673A50")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000300")]
	[Address(RVA = "0x673C68", Offset = "0x673C68", VA = "0x673C68")]
	private void Update()
	{
	}

	[Token(Token = "0x6000301")]
	[Address(RVA = "0x673C6C", Offset = "0x673C6C", VA = "0x673C6C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000302")]
	[Address(RVA = "0x673D1C", Offset = "0x673D1C", VA = "0x673D1C")]
	public CameraFilterPack_Distortion_FishEye()
	{
	}
}
