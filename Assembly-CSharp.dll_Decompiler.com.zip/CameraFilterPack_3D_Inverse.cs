using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000E")]
public class CameraFilterPack_3D_Inverse : MonoBehaviour
{
	[Token(Token = "0x400006F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000070")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000071")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000072")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000073")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000074")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x4000075")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x4000076")]
	[FieldOffset(Offset = "0x3C")]
	public float LightIntensity;

	[Token(Token = "0x4000077")]
	[FieldOffset(Offset = "0x40")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x4000078")]
	[FieldOffset(Offset = "0x44")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x4000079")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x1700000F")]
	private Material material
	{
		[Token(Token = "0x6000046")]
		[Address(RVA = "0x5B5410", Offset = "0x5B5410", VA = "0x5B5410")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000047")]
	[Address(RVA = "0x5B54D4", Offset = "0x5B54D4", VA = "0x5B54D4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000048")]
	[Address(RVA = "0x5B5550", Offset = "0x5B5550", VA = "0x5B5550")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000049")]
	[Address(RVA = "0x5B58BC", Offset = "0x5B58BC", VA = "0x5B58BC")]
	private void Update()
	{
	}

	[Token(Token = "0x600004A")]
	[Address(RVA = "0x5B58C0", Offset = "0x5B58C0", VA = "0x5B58C0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600004B")]
	[Address(RVA = "0x5B5970", Offset = "0x5B5970", VA = "0x5B5970")]
	public CameraFilterPack_3D_Inverse()
	{
	}
}
