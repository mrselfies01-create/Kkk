using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200013C")]
public class RhythmVisualizatorPro : MonoBehaviour
{
	[Token(Token = "0x20001FA")]
	public enum ScaleFrom
	{
		[Token(Token = "0x4000D8C")]
		Center,
		[Token(Token = "0x4000D8D")]
		Downside
	}

	[Token(Token = "0x20001FB")]
	public enum Visualizations
	{
		[Token(Token = "0x4000D8F")]
		Line,
		[Token(Token = "0x4000D90")]
		Circle,
		[Token(Token = "0x4000D91")]
		ExpansibleCircle,
		[Token(Token = "0x4000D92")]
		Sphere,
		[Token(Token = "0x4000D93")]
		Square
	}

	[Token(Token = "0x20001FC")]
	public enum Channels
	{
		[Token(Token = "0x4000D95")]
		n512,
		[Token(Token = "0x4000D96")]
		n1024,
		[Token(Token = "0x4000D97")]
		n2048,
		[Token(Token = "0x4000D98")]
		n4096,
		[Token(Token = "0x4000D99")]
		n8192
	}

	[Token(Token = "0x40008EA")]
	[FieldOffset(Offset = "0x18")]
	public GameObject soundBarPrefabCenter;

	[Token(Token = "0x40008EB")]
	[FieldOffset(Offset = "0x20")]
	public GameObject soundBarPrefabDownside;

	[Token(Token = "0x40008EC")]
	[FieldOffset(Offset = "0x28")]
	public Transform soundBarsTransform;

	[Token(Token = "0x40008ED")]
	[FieldOffset(Offset = "0x30")]
	public bool listenAllSounds;

	[Token(Token = "0x40008EE")]
	[FieldOffset(Offset = "0x38")]
	public AudioSource audioSource;

	[Token(Token = "0x40008EF")]
	[FieldOffset(Offset = "0x40")]
	public int soundBarsQuantity;

	[Token(Token = "0x40008F0")]
	[FieldOffset(Offset = "0x48")]
	private List<GameObject> soundBars;

	[Token(Token = "0x40008F1")]
	[FieldOffset(Offset = "0x50")]
	private int usedSoundBars;

	[Token(Token = "0x40008F2")]
	[FieldOffset(Offset = "0x54")]
	public ScaleFrom scaleFrom;

	[Token(Token = "0x40008F3")]
	[FieldOffset(Offset = "0x58")]
	public float soundBarsWidth;

	[Token(Token = "0x40008F4")]
	[FieldOffset(Offset = "0x5C")]
	public float soundBarsDepth;

	[Token(Token = "0x40008F5")]
	[FieldOffset(Offset = "0x60")]
	public Transform center;

	[Token(Token = "0x40008F6")]
	[FieldOffset(Offset = "0x68")]
	public bool cameraControl;

	[Token(Token = "0x40008F7")]
	[FieldOffset(Offset = "0x69")]
	public bool rotateCamera;

	[Token(Token = "0x40008F8")]
	[FieldOffset(Offset = "0x6A")]
	public bool useDefaultValues;

	[Token(Token = "0x40008F9")]
	[FieldOffset(Offset = "0x6C")]
	public float velocity;

	[Token(Token = "0x40008FA")]
	[FieldOffset(Offset = "0x70")]
	public float height;

	[Token(Token = "0x40008FB")]
	[FieldOffset(Offset = "0x74")]
	public float orbitDistance;

	[Token(Token = "0x40008FC")]
	[FieldOffset(Offset = "0x78")]
	public int fieldOfView;

	[Token(Token = "0x40008FD")]
	[FieldOffset(Offset = "0x7C")]
	public bool mirror;

	[Token(Token = "0x40008FE")]
	[FieldOffset(Offset = "0x7D")]
	public bool scaleByRhythm;

	[Token(Token = "0x40008FF")]
	[FieldOffset(Offset = "0x80")]
	public float length;

	[Token(Token = "0x4000900")]
	[FieldOffset(Offset = "0x84")]
	public Visualizations visualization;

	[Token(Token = "0x4000901")]
	[FieldOffset(Offset = "0x88")]
	public float extraScaleVelocity;

	[Token(Token = "0x4000902")]
	[FieldOffset(Offset = "0x8C")]
	public float globalScale;

	[Token(Token = "0x4000903")]
	[FieldOffset(Offset = "0x90")]
	public float minHeight;

	[Token(Token = "0x4000904")]
	[FieldOffset(Offset = "0x94")]
	public int smoothVelocity;

	[Token(Token = "0x4000905")]
	[FieldOffset(Offset = "0x98")]
	public Channels channels;

	[Token(Token = "0x4000906")]
	[FieldOffset(Offset = "0x9C")]
	public FFTWindow method;

	[Token(Token = "0x4000907")]
	[FieldOffset(Offset = "0xA0")]
	private int channelValue;

	[Token(Token = "0x4000908")]
	[FieldOffset(Offset = "0xA8")]
	public ParticleSystem rhythmParticleSystem;

	[Token(Token = "0x4000909")]
	[FieldOffset(Offset = "0xB0")]
	public bool autoRhythmParticles;

	[Token(Token = "0x400090A")]
	[FieldOffset(Offset = "0xB4")]
	public float rhythmSensibility;

	[Token(Token = "0x400090B")]
	private const float minRhythmSensibility = 1.5f;

	[Token(Token = "0x400090C")]
	[FieldOffset(Offset = "0xB8")]
	public int amountToEmit;

	[Token(Token = "0x400090D")]
	[FieldOffset(Offset = "0xBC")]
	public float rhythmParticlesMaxInterval;

	[Token(Token = "0x400090E")]
	[FieldOffset(Offset = "0xC0")]
	private float remainingRhythmParticlesTime;

	[Token(Token = "0x400090F")]
	[FieldOffset(Offset = "0xC4")]
	private bool rhythmSurpassed;

	[Token(Token = "0x4000910")]
	[FieldOffset(Offset = "0xC8")]
	public float bassSensibility;

	[Token(Token = "0x4000911")]
	[FieldOffset(Offset = "0xCC")]
	public float bassHeight;

	[Token(Token = "0x4000912")]
	[FieldOffset(Offset = "0xD0")]
	public int bassHorizontalScale;

	[Token(Token = "0x4000913")]
	[FieldOffset(Offset = "0xD4")]
	public int bassOffset;

	[Token(Token = "0x4000914")]
	[FieldOffset(Offset = "0xD8")]
	public float trebleSensibility;

	[Token(Token = "0x4000915")]
	[FieldOffset(Offset = "0xDC")]
	public float trebleHeight;

	[Token(Token = "0x4000916")]
	[FieldOffset(Offset = "0xE0")]
	public int trebleHorizontalScale;

	[Token(Token = "0x4000917")]
	[FieldOffset(Offset = "0xE4")]
	public int trebleOffset;

	[Token(Token = "0x4000918")]
	[FieldOffset(Offset = "0xE8")]
	public bool soundBarsParticles;

	[Token(Token = "0x4000919")]
	[FieldOffset(Offset = "0xEC")]
	public float particlesMaxInterval;

	[Token(Token = "0x400091A")]
	[FieldOffset(Offset = "0xF0")]
	private float remainingParticlesTime;

	[Token(Token = "0x400091B")]
	[FieldOffset(Offset = "0xF4")]
	private bool surpassed;

	[Token(Token = "0x400091C")]
	[FieldOffset(Offset = "0xF8")]
	public float minParticleSensibility;

	[Token(Token = "0x400091D")]
	[FieldOffset(Offset = "0xFC")]
	public bool lerpColor;

	[Token(Token = "0x400091E")]
	[FieldOffset(Offset = "0x100")]
	public Color[] colors;

	[Token(Token = "0x400091F")]
	[FieldOffset(Offset = "0x108")]
	public float colorIntervalTime;

	[Token(Token = "0x4000920")]
	[FieldOffset(Offset = "0x10C")]
	public float colorLerpTime;

	[Token(Token = "0x4000921")]
	[FieldOffset(Offset = "0x110")]
	public bool useGradient;

	[Token(Token = "0x4000922")]
	[FieldOffset(Offset = "0x118")]
	public Gradient gradient;

	[Token(Token = "0x4000923")]
	[FieldOffset(Offset = "0x120")]
	public Color rhythmParticleSystemColor;

	[Token(Token = "0x4000924")]
	[FieldOffset(Offset = "0x130")]
	public float raysLength;

	[Token(Token = "0x4000925")]
	[FieldOffset(Offset = "0x134")]
	public float raysAlpha;

	[Token(Token = "0x4000926")]
	[FieldOffset(Offset = "0x138")]
	private int posColor;

	[Token(Token = "0x4000927")]
	[FieldOffset(Offset = "0x13C")]
	public Color actualColor;

	[Token(Token = "0x4000928")]
	[FieldOffset(Offset = "0x14C")]
	private Vector3 prevLeftScale;

	[Token(Token = "0x4000929")]
	[FieldOffset(Offset = "0x158")]
	private Vector3 prevRightScale;

	[Token(Token = "0x400092A")]
	[FieldOffset(Offset = "0x164")]
	private Vector3 rightScale;

	[Token(Token = "0x400092B")]
	[FieldOffset(Offset = "0x170")]
	private Vector3 leftScale;

	[Token(Token = "0x400092C")]
	[FieldOffset(Offset = "0x17C")]
	private float timeChange;

	[Token(Token = "0x400092D")]
	[FieldOffset(Offset = "0x180")]
	private int halfBarsValue;

	[Token(Token = "0x400092E")]
	[FieldOffset(Offset = "0x184")]
	private int visualizationNumber;

	[Token(Token = "0x400092F")]
	[FieldOffset(Offset = "0x188")]
	private float newLeftScale;

	[Token(Token = "0x4000930")]
	[FieldOffset(Offset = "0x18C")]
	private float newRightScale;

	[Token(Token = "0x4000931")]
	[FieldOffset(Offset = "0x190")]
	private float rhythmAverage;

	[Token(Token = "0x4000932")]
	[FieldOffset(Offset = "0x194")]
	private Visualizations lastVisualizationForm;

	[Token(Token = "0x4000933")]
	[FieldOffset(Offset = "0x198")]
	private bool visualizationsCanBeUpdated;

	[Token(Token = "0x4000934")]
	[FieldOffset(Offset = "0x19C")]
	private Color currentColor;

	[Token(Token = "0x4000935")]
	[FieldOffset(Offset = "0x1AC")]
	private bool colorUpdated;

	[Token(Token = "0x60007B1")]
	[Address(RVA = "0x397EE4", Offset = "0x397EE4", VA = "0x397EE4")]
	public void EmitIfThereAreRhythm()
	{
	}

	[Token(Token = "0x60007B2")]
	[Address(RVA = "0x398078", Offset = "0x398078", VA = "0x398078")]
	public void Restart()
	{
	}

	[Token(Token = "0x60007B3")]
	[Address(RVA = "0x398800", Offset = "0x398800", VA = "0x398800")]
	private void Awake()
	{
	}

	[Token(Token = "0x60007B4")]
	[Address(RVA = "0x398274", Offset = "0x398274", VA = "0x398274")]
	private void CreateCubes()
	{
	}

	[Token(Token = "0x60007B5")]
	[Address(RVA = "0x399170", Offset = "0x399170", VA = "0x399170")]
	public void NextForm(bool next)
	{
	}

	[Token(Token = "0x60007B6")]
	[Address(RVA = "0x3991EC", Offset = "0x3991EC", VA = "0x3991EC")]
	private void UpdateChannels()
	{
	}

	[Token(Token = "0x60007B7")]
	[Address(RVA = "0x39920C", Offset = "0x39920C", VA = "0x39920C")]
	private void CameraPosition()
	{
	}

	[Token(Token = "0x60007B8")]
	[Address(RVA = "0x39957C", Offset = "0x39957C", VA = "0x39957C")]
	private void SetVisualizationPredefinedValues()
	{
	}

	[Token(Token = "0x60007B9")]
	[Address(RVA = "0x399628", Offset = "0x399628", VA = "0x399628")]
	private void CameraMovement()
	{
	}

	[Token(Token = "0x60007BA")]
	[Address(RVA = "0x399844", Offset = "0x399844", VA = "0x399844")]
	private void ChangeColor()
	{
	}

	[Token(Token = "0x60007BB")]
	[Address(RVA = "0x399C44", Offset = "0x399C44", VA = "0x399C44")]
	private void NextColor()
	{
	}

	[Token(Token = "0x60007BC")]
	[Address(RVA = "0x398804", Offset = "0x398804", VA = "0x398804")]
	public void UpdateVisualizations()
	{
	}

	[Token(Token = "0x60007BD")]
	[Address(RVA = "0x399E4C", Offset = "0x399E4C", VA = "0x399E4C")]
	private Vector3[] UniformPointsOnSquare(float separation, int size)
	{
		return null;
	}

	[Token(Token = "0x60007BE")]
	[Address(RVA = "0x399C88", Offset = "0x399C88", VA = "0x399C88")]
	private Vector3[] UniformPointsOnSphere(float verticlesNum, float scale)
	{
		return null;
	}

	[Token(Token = "0x60007BF")]
	[Address(RVA = "0x399FFC", Offset = "0x399FFC", VA = "0x399FFC")]
	private void LateUpdate()
	{
	}

	[Token(Token = "0x60007C0")]
	[Address(RVA = "0x39AC84", Offset = "0x39AC84", VA = "0x39AC84")]
	private void EmitParticle(int index, float spectrumValue)
	{
	}

	[Token(Token = "0x60007C1")]
	[Address(RVA = "0x39AD54", Offset = "0x39AD54", VA = "0x39AD54")]
	public RhythmVisualizatorPro()
	{
	}
}
