using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000136")]
public class ActivateSong : MonoBehaviour
{
	[Token(Token = "0x40008C6")]
	[FieldOffset(Offset = "0x18")]
	public int pos;

	[Token(Token = "0x40008C7")]
	[FieldOffset(Offset = "0x20")]
	public Text songName;

	[Token(Token = "0x40008C8")]
	[FieldOffset(Offset = "0x28")]
	public Text duration;

	[Token(Token = "0x40008C9")]
	[FieldOffset(Offset = "0x30")]
	public Image activeSongImage;

	[Token(Token = "0x40008CA")]
	[FieldOffset(Offset = "0x38")]
	private MusicPlayer musicPlayer;

	[Token(Token = "0x6000792")]
	[Address(RVA = "0x5AF10C", Offset = "0x5AF10C", VA = "0x5AF10C")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000793")]
	[Address(RVA = "0x5AF164", Offset = "0x5AF164", VA = "0x5AF164")]
	public void ChangeToThisSong()
	{
	}

	[Token(Token = "0x6000794")]
	[Address(RVA = "0x5AF188", Offset = "0x5AF188", VA = "0x5AF188")]
	public void ShowSongData(string _artist, string _songName, int _pos, int minutes, int seconds)
	{
	}

	[Token(Token = "0x6000795")]
	[Address(RVA = "0x5AF398", Offset = "0x5AF398", VA = "0x5AF398")]
	public ActivateSong()
	{
	}
}
