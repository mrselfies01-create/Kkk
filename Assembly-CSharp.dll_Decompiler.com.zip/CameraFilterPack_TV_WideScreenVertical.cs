using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000121")]
public class CameraFilterPack_TV_WideScreenVertical : MonoBehaviour
{
	[Token(Token = "0x4000828")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000829")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400082A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400082B")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400082C")]
	[FieldOffset(Offset = "0x34")]
	public float Smooth;

	[Token(Token = "0x400082D")]
	[FieldOffset(Offset = "0x38")]
	private float StretchX;

	[Token(Token = "0x400082E")]
	[FieldOffset(Offset = "0x3C")]
	private float StretchY;

	[Token(Token = "0x17000122")]
	private Material material
	{
		[Token(Token = "0x600071D")]
		[Address(RVA = "0x63C8E4", Offset = "0x63C8E4", VA = "0x63C8E4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600071E")]
	[Address(RVA = "0x63C9A8", Offset = "0x63C9A8", VA = "0x63C9A8")]
	private void Start()
	{
	}

	[Token(Token = "0x600071F")]
	[Address(RVA = "0x63CA24", Offset = "0x63CA24", VA = "0x63CA24")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000720")]
	[Address(RVA = "0x63CCA8", Offset = "0x63CCA8", VA = "0x63CCA8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000721")]
	[Address(RVA = "0x63CCAC", Offset = "0x63CCAC", VA = "0x63CCAC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000722")]
	[Address(RVA = "0x63CD5C", Offset = "0x63CD5C", VA = "0x63CD5C")]
	public CameraFilterPack_TV_WideScreenVertical()
	{
	}
}
