using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000CC")]
public class CameraFilterPack_Glow_Glow_Color : MonoBehaviour
{
	[Token(Token = "0x40005EC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005ED")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005EE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40005EF")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40005F0")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x40005F1")]
	[FieldOffset(Offset = "0x38")]
	public float Threshold;

	[Token(Token = "0x40005F2")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x40005F3")]
	[FieldOffset(Offset = "0x40")]
	public float Precision;

	[Token(Token = "0x40005F4")]
	[FieldOffset(Offset = "0x44")]
	public Color GlowColor;

	[Token(Token = "0x170000CD")]
	private Material material
	{
		[Token(Token = "0x60004FC")]
		[Address(RVA = "0x6A1A74", Offset = "0x6A1A74", VA = "0x6A1A74")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004FD")]
	[Address(RVA = "0x6A1B38", Offset = "0x6A1B38", VA = "0x6A1B38")]
	private void Start()
	{
	}

	[Token(Token = "0x60004FE")]
	[Address(RVA = "0x6A1BB4", Offset = "0x6A1BB4", VA = "0x6A1BB4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004FF")]
	[Address(RVA = "0x6A202C", Offset = "0x6A202C", VA = "0x6A202C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000500")]
	[Address(RVA = "0x6A2030", Offset = "0x6A2030", VA = "0x6A2030")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000501")]
	[Address(RVA = "0x6A20E0", Offset = "0x6A20E0", VA = "0x6A20E0")]
	public CameraFilterPack_Glow_Glow_Color()
	{
	}
}
