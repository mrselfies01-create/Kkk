using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200009A")]
public class CameraFilterPack_Drawing_Paper3 : MonoBehaviour
{
	[Token(Token = "0x400049A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400049B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400049C")]
	[FieldOffset(Offset = "0x24")]
	public Color Pencil_Color;

	[Token(Token = "0x400049D")]
	[FieldOffset(Offset = "0x34")]
	public float Pencil_Size;

	[Token(Token = "0x400049E")]
	[FieldOffset(Offset = "0x38")]
	public float Pencil_Correction;

	[Token(Token = "0x400049F")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x40004A0")]
	[FieldOffset(Offset = "0x40")]
	public float Speed_Animation;

	[Token(Token = "0x40004A1")]
	[FieldOffset(Offset = "0x44")]
	public float Corner_Lose;

	[Token(Token = "0x40004A2")]
	[FieldOffset(Offset = "0x48")]
	public float Fade_Paper_to_BackColor;

	[Token(Token = "0x40004A3")]
	[FieldOffset(Offset = "0x4C")]
	public float Fade_With_Original;

	[Token(Token = "0x40004A4")]
	[FieldOffset(Offset = "0x50")]
	public Color Back_Color;

	[Token(Token = "0x40004A5")]
	[FieldOffset(Offset = "0x60")]
	private Material SCMaterial;

	[Token(Token = "0x40004A6")]
	[FieldOffset(Offset = "0x68")]
	private Texture2D Texture2;

	[Token(Token = "0x1700009B")]
	private Material material
	{
		[Token(Token = "0x60003CF")]
		[Address(RVA = "0x6934E0", Offset = "0x6934E0", VA = "0x6934E0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003D0")]
	[Address(RVA = "0x6935A4", Offset = "0x6935A4", VA = "0x6935A4")]
	private void Start()
	{
	}

	[Token(Token = "0x60003D1")]
	[Address(RVA = "0x69365C", Offset = "0x69365C", VA = "0x69365C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003D2")]
	[Address(RVA = "0x69392C", Offset = "0x69392C", VA = "0x69392C")]
	private void Update()
	{
	}

	[Token(Token = "0x60003D3")]
	[Address(RVA = "0x693930", Offset = "0x693930", VA = "0x693930")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003D4")]
	[Address(RVA = "0x6939E0", Offset = "0x6939E0", VA = "0x6939E0")]
	public CameraFilterPack_Drawing_Paper3()
	{
	}
}
