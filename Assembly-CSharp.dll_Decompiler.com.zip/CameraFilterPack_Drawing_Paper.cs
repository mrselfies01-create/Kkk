using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000098")]
public class CameraFilterPack_Drawing_Paper : MonoBehaviour
{
	[Token(Token = "0x4000480")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000481")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000482")]
	[FieldOffset(Offset = "0x24")]
	public Color Pencil_Color;

	[Token(Token = "0x4000483")]
	[FieldOffset(Offset = "0x34")]
	public float Pencil_Size;

	[Token(Token = "0x4000484")]
	[FieldOffset(Offset = "0x38")]
	public float Pencil_Correction;

	[Token(Token = "0x4000485")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000486")]
	[FieldOffset(Offset = "0x40")]
	public float Speed_Animation;

	[Token(Token = "0x4000487")]
	[FieldOffset(Offset = "0x44")]
	public float Corner_Lose;

	[Token(Token = "0x4000488")]
	[FieldOffset(Offset = "0x48")]
	public float Fade_Paper_to_BackColor;

	[Token(Token = "0x4000489")]
	[FieldOffset(Offset = "0x4C")]
	public float Fade_With_Original;

	[Token(Token = "0x400048A")]
	[FieldOffset(Offset = "0x50")]
	public Color Back_Color;

	[Token(Token = "0x400048B")]
	[FieldOffset(Offset = "0x60")]
	private Material SCMaterial;

	[Token(Token = "0x400048C")]
	[FieldOffset(Offset = "0x68")]
	private Texture2D Texture2;

	[Token(Token = "0x17000099")]
	private Material material
	{
		[Token(Token = "0x60003C3")]
		[Address(RVA = "0x692970", Offset = "0x692970", VA = "0x692970")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003C4")]
	[Address(RVA = "0x692A34", Offset = "0x692A34", VA = "0x692A34")]
	private void Start()
	{
	}

	[Token(Token = "0x60003C5")]
	[Address(RVA = "0x692AEC", Offset = "0x692AEC", VA = "0x692AEC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003C6")]
	[Address(RVA = "0x692DBC", Offset = "0x692DBC", VA = "0x692DBC")]
	private void Update()
	{
	}

	[Token(Token = "0x60003C7")]
	[Address(RVA = "0x692DC0", Offset = "0x692DC0", VA = "0x692DC0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003C8")]
	[Address(RVA = "0x692E70", Offset = "0x692E70", VA = "0x692E70")]
	public CameraFilterPack_Drawing_Paper()
	{
	}
}
