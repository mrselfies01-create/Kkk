using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000019")]
public class CameraFilterPack_AAA_SuperComputer : MonoBehaviour
{
	[Token(Token = "0x40000FF")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000100")]
	[FieldOffset(Offset = "0x20")]
	public float _AlphaHexa;

	[Token(Token = "0x4000101")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000102")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000103")]
	[FieldOffset(Offset = "0x30")]
	public float ShapeFormula;

	[Token(Token = "0x4000104")]
	[FieldOffset(Offset = "0x34")]
	public float Shape;

	[Token(Token = "0x4000105")]
	[FieldOffset(Offset = "0x38")]
	public float _BorderSize;

	[Token(Token = "0x4000106")]
	[FieldOffset(Offset = "0x3C")]
	public Color _BorderColor;

	[Token(Token = "0x4000107")]
	[FieldOffset(Offset = "0x4C")]
	public float _SpotSize;

	[Token(Token = "0x4000108")]
	[FieldOffset(Offset = "0x50")]
	public Vector2 center;

	[Token(Token = "0x4000109")]
	[FieldOffset(Offset = "0x58")]
	public float Radius;

	[Token(Token = "0x1700001A")]
	private Material material
	{
		[Token(Token = "0x6000088")]
		[Address(RVA = "0x5B95F4", Offset = "0x5B95F4", VA = "0x5B95F4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000089")]
	[Address(RVA = "0x5B96B8", Offset = "0x5B96B8", VA = "0x5B96B8")]
	private void Start()
	{
	}

	[Token(Token = "0x600008A")]
	[Address(RVA = "0x5B9734", Offset = "0x5B9734", VA = "0x5B9734")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600008B")]
	[Address(RVA = "0x5B9A78", Offset = "0x5B9A78", VA = "0x5B9A78")]
	private void Update()
	{
	}

	[Token(Token = "0x600008C")]
	[Address(RVA = "0x5B9A7C", Offset = "0x5B9A7C", VA = "0x5B9A7C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600008D")]
	[Address(RVA = "0x5B9B2C", Offset = "0x5B9B2C", VA = "0x5B9B2C")]
	public CameraFilterPack_AAA_SuperComputer()
	{
	}
}
