using DuloGames.UI;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000133")]
public class HideWhenTogglePressed : MonoBehaviour
{
	[Token(Token = "0x40008A7")]
	[FieldOffset(Offset = "0x18")]
	public UITab[] borderTabs;

	[Token(Token = "0x40008A8")]
	[FieldOffset(Offset = "0x20")]
	private Image img;

	[Token(Token = "0x6000784")]
	[Address(RVA = "0x38C1EC", Offset = "0x38C1EC", VA = "0x38C1EC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000785")]
	[Address(RVA = "0x38C244", Offset = "0x38C244", VA = "0x38C244")]
	private void Update()
	{
	}

	[Token(Token = "0x6000786")]
	[Address(RVA = "0x38C2C4", Offset = "0x38C2C4", VA = "0x38C2C4")]
	public HideWhenTogglePressed()
	{
	}
}
