using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000068")]
public class CameraFilterPack_Colors_BleachBypass : MonoBehaviour
{
	[Token(Token = "0x400036F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000370")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000371")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000372")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x17000069")]
	private Material material
	{
		[Token(Token = "0x60002A3")]
		[Address(RVA = "0x66FB5C", Offset = "0x66FB5C", VA = "0x66FB5C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002A4")]
	[Address(RVA = "0x66FC20", Offset = "0x66FC20", VA = "0x66FC20")]
	private void Start()
	{
	}

	[Token(Token = "0x60002A5")]
	[Address(RVA = "0x66FC9C", Offset = "0x66FC9C", VA = "0x66FC9C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002A6")]
	[Address(RVA = "0x66FEB4", Offset = "0x66FEB4", VA = "0x66FEB4")]
	private void Update()
	{
	}

	[Token(Token = "0x60002A7")]
	[Address(RVA = "0x66FEB8", Offset = "0x66FEB8", VA = "0x66FEB8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002A8")]
	[Address(RVA = "0x66FF68", Offset = "0x66FF68", VA = "0x66FF68")]
	public CameraFilterPack_Colors_BleachBypass()
	{
	}
}
