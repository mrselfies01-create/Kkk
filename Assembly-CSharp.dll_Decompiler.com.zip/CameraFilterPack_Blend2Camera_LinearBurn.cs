using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000035")]
public class CameraFilterPack_Blend2Camera_LinearBurn : MonoBehaviour
{
	[Token(Token = "0x4000205")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000206")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000207")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000208")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000209")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400020A")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400020B")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400020C")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000036")]
	private Material material
	{
		[Token(Token = "0x6000150")]
		[Address(RVA = "0x5C4E48", Offset = "0x5C4E48", VA = "0x5C4E48")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000151")]
	[Address(RVA = "0x5C4F0C", Offset = "0x5C4F0C", VA = "0x5C4F0C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000152")]
	[Address(RVA = "0x5C5024", Offset = "0x5C5024", VA = "0x5C5024")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000153")]
	[Address(RVA = "0x5C52B4", Offset = "0x5C52B4", VA = "0x5C52B4")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000154")]
	[Address(RVA = "0x5C53A0", Offset = "0x5C53A0", VA = "0x5C53A0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000155")]
	[Address(RVA = "0x5C53A4", Offset = "0x5C53A4", VA = "0x5C53A4")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000156")]
	[Address(RVA = "0x5C5490", Offset = "0x5C5490", VA = "0x5C5490")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000157")]
	[Address(RVA = "0x5C5588", Offset = "0x5C5588", VA = "0x5C5588")]
	public CameraFilterPack_Blend2Camera_LinearBurn()
	{
	}
}
