using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B8")]
public class CameraFilterPack_FX_InverChromiLum : MonoBehaviour
{
	[Token(Token = "0x400054D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400054E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400054F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000B9")]
	private Material material
	{
		[Token(Token = "0x6000484")]
		[Address(RVA = "0x69B738", Offset = "0x69B738", VA = "0x69B738")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000485")]
	[Address(RVA = "0x69B7FC", Offset = "0x69B7FC", VA = "0x69B7FC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000486")]
	[Address(RVA = "0x69B878", Offset = "0x69B878", VA = "0x69B878")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000487")]
	[Address(RVA = "0x69BA6C", Offset = "0x69BA6C", VA = "0x69BA6C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000488")]
	[Address(RVA = "0x69BA70", Offset = "0x69BA70", VA = "0x69BA70")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000489")]
	[Address(RVA = "0x69BB20", Offset = "0x69BB20", VA = "0x69BB20")]
	public CameraFilterPack_FX_InverChromiLum()
	{
	}
}
