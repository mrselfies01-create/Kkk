using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000080")]
public class CameraFilterPack_Distortion_Twist : MonoBehaviour
{
	[Token(Token = "0x40003F3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003F4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003F5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003F6")]
	[FieldOffset(Offset = "0x30")]
	public float CenterX;

	[Token(Token = "0x40003F7")]
	[FieldOffset(Offset = "0x34")]
	public float CenterY;

	[Token(Token = "0x40003F8")]
	[FieldOffset(Offset = "0x38")]
	public float Distortion;

	[Token(Token = "0x40003F9")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x17000081")]
	private Material material
	{
		[Token(Token = "0x6000333")]
		[Address(RVA = "0x675FA4", Offset = "0x675FA4", VA = "0x675FA4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000334")]
	[Address(RVA = "0x676068", Offset = "0x676068", VA = "0x676068")]
	private void Start()
	{
	}

	[Token(Token = "0x6000335")]
	[Address(RVA = "0x6760E4", Offset = "0x6760E4", VA = "0x6760E4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000336")]
	[Address(RVA = "0x676358", Offset = "0x676358", VA = "0x676358")]
	private void Update()
	{
	}

	[Token(Token = "0x6000337")]
	[Address(RVA = "0x67635C", Offset = "0x67635C", VA = "0x67635C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000338")]
	[Address(RVA = "0x67640C", Offset = "0x67640C", VA = "0x67640C")]
	public CameraFilterPack_Distortion_Twist()
	{
	}
}
