using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000107")]
public class CameraFilterPack_TV_BrokenGlass2 : MonoBehaviour
{
	[Token(Token = "0x4000790")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000791")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000792")]
	[FieldOffset(Offset = "0x24")]
	public float Bullet_1;

	[Token(Token = "0x4000793")]
	[FieldOffset(Offset = "0x28")]
	public float Bullet_2;

	[Token(Token = "0x4000794")]
	[FieldOffset(Offset = "0x2C")]
	public float Bullet_3;

	[Token(Token = "0x4000795")]
	[FieldOffset(Offset = "0x30")]
	public float Bullet_4;

	[Token(Token = "0x4000796")]
	[FieldOffset(Offset = "0x34")]
	public float Bullet_5;

	[Token(Token = "0x4000797")]
	[FieldOffset(Offset = "0x38")]
	public float Bullet_6;

	[Token(Token = "0x4000798")]
	[FieldOffset(Offset = "0x3C")]
	public float Bullet_7;

	[Token(Token = "0x4000799")]
	[FieldOffset(Offset = "0x40")]
	public float Bullet_8;

	[Token(Token = "0x400079A")]
	[FieldOffset(Offset = "0x44")]
	public float Bullet_9;

	[Token(Token = "0x400079B")]
	[FieldOffset(Offset = "0x48")]
	public float Bullet_10;

	[Token(Token = "0x400079C")]
	[FieldOffset(Offset = "0x4C")]
	public float Bullet_11;

	[Token(Token = "0x400079D")]
	[FieldOffset(Offset = "0x50")]
	public float Bullet_12;

	[Token(Token = "0x400079E")]
	[FieldOffset(Offset = "0x58")]
	private Material SCMaterial;

	[Token(Token = "0x400079F")]
	[FieldOffset(Offset = "0x60")]
	private Texture2D Texture2;

	[Token(Token = "0x17000108")]
	private Material material
	{
		[Token(Token = "0x6000681")]
		[Address(RVA = "0x6358A4", Offset = "0x6358A4", VA = "0x6358A4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000682")]
	[Address(RVA = "0x635968", Offset = "0x635968", VA = "0x635968")]
	private void Start()
	{
	}

	[Token(Token = "0x6000683")]
	[Address(RVA = "0x635A20", Offset = "0x635A20", VA = "0x635A20")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000684")]
	[Address(RVA = "0x635F08", Offset = "0x635F08", VA = "0x635F08")]
	private void Update()
	{
	}

	[Token(Token = "0x6000685")]
	[Address(RVA = "0x635F0C", Offset = "0x635F0C", VA = "0x635F0C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000686")]
	[Address(RVA = "0x635FBC", Offset = "0x635FBC", VA = "0x635FBC")]
	public CameraFilterPack_TV_BrokenGlass2()
	{
	}
}
