using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A7")]
public class CameraFilterPack_FX_8bits_gb : MonoBehaviour
{
	[Token(Token = "0x40004EA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004EB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004EC")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004ED")]
	[FieldOffset(Offset = "0x30")]
	public float Brightness;

	[Token(Token = "0x170000A8")]
	private Material material
	{
		[Token(Token = "0x600041E")]
		[Address(RVA = "0x696D44", Offset = "0x696D44", VA = "0x696D44")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600041F")]
	[Address(RVA = "0x696E08", Offset = "0x696E08", VA = "0x696E08")]
	private void Start()
	{
	}

	[Token(Token = "0x6000420")]
	[Address(RVA = "0x696E84", Offset = "0x696E84", VA = "0x696E84")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000421")]
	[Address(RVA = "0x697068", Offset = "0x697068", VA = "0x697068")]
	private void Update()
	{
	}

	[Token(Token = "0x6000422")]
	[Address(RVA = "0x69706C", Offset = "0x69706C", VA = "0x69706C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000423")]
	[Address(RVA = "0x69711C", Offset = "0x69711C", VA = "0x69711C")]
	public CameraFilterPack_FX_8bits_gb()
	{
	}
}
