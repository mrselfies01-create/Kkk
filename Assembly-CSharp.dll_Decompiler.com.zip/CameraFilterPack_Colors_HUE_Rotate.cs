using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006C")]
public class CameraFilterPack_Colors_HUE_Rotate : MonoBehaviour
{
	[Token(Token = "0x4000382")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000383")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000384")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000385")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x1700006D")]
	private Material material
	{
		[Token(Token = "0x60002BB")]
		[Address(RVA = "0x670A88", Offset = "0x670A88", VA = "0x670A88")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002BC")]
	[Address(RVA = "0x670B4C", Offset = "0x670B4C", VA = "0x670B4C")]
	private void Start()
	{
	}

	[Token(Token = "0x60002BD")]
	[Address(RVA = "0x670BC8", Offset = "0x670BC8", VA = "0x670BC8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002BE")]
	[Address(RVA = "0x670DD0", Offset = "0x670DD0", VA = "0x670DD0")]
	private void Update()
	{
	}

	[Token(Token = "0x60002BF")]
	[Address(RVA = "0x670DD4", Offset = "0x670DD4", VA = "0x670DD4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002C0")]
	[Address(RVA = "0x670E84", Offset = "0x670E84", VA = "0x670E84")]
	public CameraFilterPack_Colors_HUE_Rotate()
	{
	}
}
