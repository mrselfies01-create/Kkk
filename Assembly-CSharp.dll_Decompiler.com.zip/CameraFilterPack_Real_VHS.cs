using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FC")]
public class CameraFilterPack_Real_VHS : MonoBehaviour
{
	[Token(Token = "0x400074B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400074C")]
	[FieldOffset(Offset = "0x20")]
	private Material SCMaterial;

	[Token(Token = "0x400074D")]
	[FieldOffset(Offset = "0x28")]
	private Texture2D VHS;

	[Token(Token = "0x400074E")]
	[FieldOffset(Offset = "0x30")]
	private Texture2D VHS2;

	[Token(Token = "0x400074F")]
	[FieldOffset(Offset = "0x38")]
	public float TRACKING;

	[Token(Token = "0x4000750")]
	[FieldOffset(Offset = "0x3C")]
	public float JITTER;

	[Token(Token = "0x4000751")]
	[FieldOffset(Offset = "0x40")]
	public float GLITCH;

	[Token(Token = "0x4000752")]
	[FieldOffset(Offset = "0x44")]
	public float NOISE;

	[Token(Token = "0x4000753")]
	[FieldOffset(Offset = "0x48")]
	public float Brightness;

	[Token(Token = "0x4000754")]
	[FieldOffset(Offset = "0x4C")]
	public float Constrast;

	[Token(Token = "0x170000FD")]
	private Material material
	{
		[Token(Token = "0x600063E")]
		[Address(RVA = "0x6326EC", Offset = "0x6326EC", VA = "0x6326EC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600063F")]
	[Address(RVA = "0x6327B0", Offset = "0x6327B0", VA = "0x6327B0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000640")]
	[Address(RVA = "0x6328A4", Offset = "0x6328A4", VA = "0x6328A4")]
	public static Texture2D GetRTPixels(Texture2D t, RenderTexture rt, int sx, int sy)
	{
		return null;
	}

	[Token(Token = "0x6000641")]
	[Address(RVA = "0x632964", Offset = "0x632964", VA = "0x632964")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000642")]
	[Address(RVA = "0x632BD8", Offset = "0x632BD8", VA = "0x632BD8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000643")]
	[Address(RVA = "0x632BDC", Offset = "0x632BDC", VA = "0x632BDC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000644")]
	[Address(RVA = "0x632C8C", Offset = "0x632C8C", VA = "0x632C8C")]
	public CameraFilterPack_Real_VHS()
	{
	}
}
