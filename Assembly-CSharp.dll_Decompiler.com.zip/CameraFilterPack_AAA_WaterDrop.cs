using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001B")]
public class CameraFilterPack_AAA_WaterDrop : MonoBehaviour
{
	[Token(Token = "0x4000115")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000116")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000117")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x4000118")]
	[FieldOffset(Offset = "0x28")]
	public float SizeX;

	[Token(Token = "0x4000119")]
	[FieldOffset(Offset = "0x2C")]
	public float SizeY;

	[Token(Token = "0x400011A")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x400011B")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400011C")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x1700001C")]
	private Material material
	{
		[Token(Token = "0x6000094")]
		[Address(RVA = "0x5BA190", Offset = "0x5BA190", VA = "0x5BA190")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000095")]
	[Address(RVA = "0x5BA254", Offset = "0x5BA254", VA = "0x5BA254")]
	private void Start()
	{
	}

	[Token(Token = "0x6000096")]
	[Address(RVA = "0x5BA30C", Offset = "0x5BA30C", VA = "0x5BA30C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000097")]
	[Address(RVA = "0x5BA520", Offset = "0x5BA520", VA = "0x5BA520")]
	private void Update()
	{
	}

	[Token(Token = "0x6000098")]
	[Address(RVA = "0x5BA524", Offset = "0x5BA524", VA = "0x5BA524")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000099")]
	[Address(RVA = "0x5BA5D4", Offset = "0x5BA5D4", VA = "0x5BA5D4")]
	public CameraFilterPack_AAA_WaterDrop()
	{
	}
}
