using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000AE")]
public class CameraFilterPack_FX_Drunk2 : MonoBehaviour
{
	[Token(Token = "0x400051C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400051D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400051E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400051F")]
	[FieldOffset(Offset = "0x30")]
	private float Value;

	[Token(Token = "0x4000520")]
	[FieldOffset(Offset = "0x34")]
	private float Value2;

	[Token(Token = "0x4000521")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x4000522")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x170000AF")]
	private Material material
	{
		[Token(Token = "0x6000448")]
		[Address(RVA = "0x698D5C", Offset = "0x698D5C", VA = "0x698D5C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000449")]
	[Address(RVA = "0x698E20", Offset = "0x698E20", VA = "0x698E20")]
	private void Start()
	{
	}

	[Token(Token = "0x600044A")]
	[Address(RVA = "0x698E9C", Offset = "0x698E9C", VA = "0x698E9C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600044B")]
	[Address(RVA = "0x699120", Offset = "0x699120", VA = "0x699120")]
	private void Update()
	{
	}

	[Token(Token = "0x600044C")]
	[Address(RVA = "0x699124", Offset = "0x699124", VA = "0x699124")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600044D")]
	[Address(RVA = "0x6991D4", Offset = "0x6991D4", VA = "0x6991D4")]
	public CameraFilterPack_FX_Drunk2()
	{
	}
}
