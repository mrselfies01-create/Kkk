using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000099")]
public class CameraFilterPack_Drawing_Paper2 : MonoBehaviour
{
	[Token(Token = "0x400048D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400048E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400048F")]
	[FieldOffset(Offset = "0x24")]
	public Color Pencil_Color;

	[Token(Token = "0x4000490")]
	[FieldOffset(Offset = "0x34")]
	public float Pencil_Size;

	[Token(Token = "0x4000491")]
	[FieldOffset(Offset = "0x38")]
	public float Pencil_Correction;

	[Token(Token = "0x4000492")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000493")]
	[FieldOffset(Offset = "0x40")]
	public float Speed_Animation;

	[Token(Token = "0x4000494")]
	[FieldOffset(Offset = "0x44")]
	public float Corner_Lose;

	[Token(Token = "0x4000495")]
	[FieldOffset(Offset = "0x48")]
	public float Fade_Paper_to_BackColor;

	[Token(Token = "0x4000496")]
	[FieldOffset(Offset = "0x4C")]
	public float Fade_With_Original;

	[Token(Token = "0x4000497")]
	[FieldOffset(Offset = "0x50")]
	public Color Back_Color;

	[Token(Token = "0x4000498")]
	[FieldOffset(Offset = "0x60")]
	private Material SCMaterial;

	[Token(Token = "0x4000499")]
	[FieldOffset(Offset = "0x68")]
	private Texture2D Texture2;

	[Token(Token = "0x1700009A")]
	private Material material
	{
		[Token(Token = "0x60003C9")]
		[Address(RVA = "0x692F28", Offset = "0x692F28", VA = "0x692F28")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003CA")]
	[Address(RVA = "0x692FEC", Offset = "0x692FEC", VA = "0x692FEC")]
	private void Start()
	{
	}

	[Token(Token = "0x60003CB")]
	[Address(RVA = "0x6930A4", Offset = "0x6930A4", VA = "0x6930A4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003CC")]
	[Address(RVA = "0x693374", Offset = "0x693374", VA = "0x693374")]
	private void Update()
	{
	}

	[Token(Token = "0x60003CD")]
	[Address(RVA = "0x693378", Offset = "0x693378", VA = "0x693378")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003CE")]
	[Address(RVA = "0x693428", Offset = "0x693428", VA = "0x693428")]
	public CameraFilterPack_Drawing_Paper2()
	{
	}
}
