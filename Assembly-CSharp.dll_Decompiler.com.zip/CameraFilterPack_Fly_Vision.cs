using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C3")]
public class CameraFilterPack_Fly_Vision : MonoBehaviour
{
	[Token(Token = "0x4000581")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000582")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000583")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000584")]
	[FieldOffset(Offset = "0x30")]
	public float Zoom;

	[Token(Token = "0x4000585")]
	[FieldOffset(Offset = "0x34")]
	public float Distortion;

	[Token(Token = "0x4000586")]
	[FieldOffset(Offset = "0x38")]
	public float Fade;

	[Token(Token = "0x4000587")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x4000588")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C4")]
	private Material material
	{
		[Token(Token = "0x60004C6")]
		[Address(RVA = "0x69E5C0", Offset = "0x69E5C0", VA = "0x69E5C0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004C7")]
	[Address(RVA = "0x69E684", Offset = "0x69E684", VA = "0x69E684")]
	private void Start()
	{
	}

	[Token(Token = "0x60004C8")]
	[Address(RVA = "0x69E73C", Offset = "0x69E73C", VA = "0x69E73C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004C9")]
	[Address(RVA = "0x69E9E4", Offset = "0x69E9E4", VA = "0x69E9E4")]
	private void Update()
	{
	}

	[Token(Token = "0x60004CA")]
	[Address(RVA = "0x69E9E8", Offset = "0x69E9E8", VA = "0x69E9E8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004CB")]
	[Address(RVA = "0x69EA98", Offset = "0x69EA98", VA = "0x69EA98")]
	public CameraFilterPack_Fly_Vision()
	{
	}
}
