using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002A")]
public class CameraFilterPack_Blend2Camera_Darken : MonoBehaviour
{
	[Token(Token = "0x40001A7")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001A8")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001A9")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001AA")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001AB")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001AC")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001AD")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001AE")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700002B")]
	private Material material
	{
		[Token(Token = "0x60000F9")]
		[Address(RVA = "0x5BFB34", Offset = "0x5BFB34", VA = "0x5BFB34")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000FA")]
	[Address(RVA = "0x5BFBF8", Offset = "0x5BFBF8", VA = "0x5BFBF8")]
	private void Start()
	{
	}

	[Token(Token = "0x60000FB")]
	[Address(RVA = "0x5BFD10", Offset = "0x5BFD10", VA = "0x5BFD10")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000FC")]
	[Address(RVA = "0x5BFFA0", Offset = "0x5BFFA0", VA = "0x5BFFA0")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000FD")]
	[Address(RVA = "0x5C008C", Offset = "0x5C008C", VA = "0x5C008C")]
	private void Update()
	{
	}

	[Token(Token = "0x60000FE")]
	[Address(RVA = "0x5C0090", Offset = "0x5C0090", VA = "0x5C0090")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000FF")]
	[Address(RVA = "0x5C017C", Offset = "0x5C017C", VA = "0x5C017C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000100")]
	[Address(RVA = "0x5C0274", Offset = "0x5C0274", VA = "0x5C0274")]
	public CameraFilterPack_Blend2Camera_Darken()
	{
	}
}
