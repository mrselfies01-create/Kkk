using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004D")]
public class CameraFilterPack_Blur_Noise : MonoBehaviour
{
	[Token(Token = "0x40002C4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002C5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002C6")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002C7")]
	[FieldOffset(Offset = "0x30")]
	public int Level;

	[Token(Token = "0x40002C8")]
	[FieldOffset(Offset = "0x34")]
	public Vector2 Distance;

	[Token(Token = "0x1700004E")]
	private Material material
	{
		[Token(Token = "0x60001FF")]
		[Address(RVA = "0x6673D0", Offset = "0x6673D0", VA = "0x6673D0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000200")]
	[Address(RVA = "0x667494", Offset = "0x667494", VA = "0x667494")]
	private void Start()
	{
	}

	[Token(Token = "0x6000201")]
	[Address(RVA = "0x667510", Offset = "0x667510", VA = "0x667510")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000202")]
	[Address(RVA = "0x66778C", Offset = "0x66778C", VA = "0x66778C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000203")]
	[Address(RVA = "0x667790", Offset = "0x667790", VA = "0x667790")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000204")]
	[Address(RVA = "0x667840", Offset = "0x667840", VA = "0x667840")]
	public CameraFilterPack_Blur_Noise()
	{
	}
}
