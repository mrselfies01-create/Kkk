using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012A")]
public class CameraFilterPack_Vision_Plasma : MonoBehaviour
{
	[Token(Token = "0x400086A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400086B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400086C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400086D")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x400086E")]
	[FieldOffset(Offset = "0x34")]
	public float Value2;

	[Token(Token = "0x400086F")]
	[FieldOffset(Offset = "0x38")]
	public float Intensity;

	[Token(Token = "0x4000870")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700012B")]
	private Material material
	{
		[Token(Token = "0x6000753")]
		[Address(RVA = "0x63F39C", Offset = "0x63F39C", VA = "0x63F39C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000754")]
	[Address(RVA = "0x63F460", Offset = "0x63F460", VA = "0x63F460")]
	private void Start()
	{
	}

	[Token(Token = "0x6000755")]
	[Address(RVA = "0x63F4DC", Offset = "0x63F4DC", VA = "0x63F4DC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000756")]
	[Address(RVA = "0x63F760", Offset = "0x63F760", VA = "0x63F760")]
	private void Update()
	{
	}

	[Token(Token = "0x6000757")]
	[Address(RVA = "0x63F764", Offset = "0x63F764", VA = "0x63F764")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000758")]
	[Address(RVA = "0x63F814", Offset = "0x63F814", VA = "0x63F814")]
	public CameraFilterPack_Vision_Plasma()
	{
	}
}
