using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000060")]
public class CameraFilterPack_Color_Noise : MonoBehaviour
{
	[Token(Token = "0x400033C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400033D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400033E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400033F")]
	[FieldOffset(Offset = "0x30")]
	public float Noise;

	[Token(Token = "0x17000061")]
	private Material material
	{
		[Token(Token = "0x6000271")]
		[Address(RVA = "0x66CCD0", Offset = "0x66CCD0", VA = "0x66CCD0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000272")]
	[Address(RVA = "0x66CD94", Offset = "0x66CD94", VA = "0x66CD94")]
	private void Start()
	{
	}

	[Token(Token = "0x6000273")]
	[Address(RVA = "0x66CE10", Offset = "0x66CE10", VA = "0x66CE10")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000274")]
	[Address(RVA = "0x66D028", Offset = "0x66D028", VA = "0x66D028")]
	private void Update()
	{
	}

	[Token(Token = "0x6000275")]
	[Address(RVA = "0x66D02C", Offset = "0x66D02C", VA = "0x66D02C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000276")]
	[Address(RVA = "0x66D0DC", Offset = "0x66D0DC", VA = "0x66D0DC")]
	public CameraFilterPack_Color_Noise()
	{
	}
}
