using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000015")]
public class CameraFilterPack_AAA_Blood : MonoBehaviour
{
	[Token(Token = "0x40000CA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000CB")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40000CC")]
	[FieldOffset(Offset = "0x24")]
	public float Blood1;

	[Token(Token = "0x40000CD")]
	[FieldOffset(Offset = "0x28")]
	public float Blood2;

	[Token(Token = "0x40000CE")]
	[FieldOffset(Offset = "0x2C")]
	public float Blood3;

	[Token(Token = "0x40000CF")]
	[FieldOffset(Offset = "0x30")]
	public float Blood4;

	[Token(Token = "0x40000D0")]
	[FieldOffset(Offset = "0x34")]
	public float LightReflect;

	[Token(Token = "0x40000D1")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40000D2")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x17000016")]
	private Material material
	{
		[Token(Token = "0x6000070")]
		[Address(RVA = "0x5B7E20", Offset = "0x5B7E20", VA = "0x5B7E20")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000071")]
	[Address(RVA = "0x5B7EE4", Offset = "0x5B7EE4", VA = "0x5B7EE4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000072")]
	[Address(RVA = "0x5B7F9C", Offset = "0x5B7F9C", VA = "0x5B7F9C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000073")]
	[Address(RVA = "0x5B81D4", Offset = "0x5B81D4", VA = "0x5B81D4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000074")]
	[Address(RVA = "0x5B81D8", Offset = "0x5B81D8", VA = "0x5B81D8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000075")]
	[Address(RVA = "0x5B8288", Offset = "0x5B8288", VA = "0x5B8288")]
	public CameraFilterPack_AAA_Blood()
	{
	}
}
