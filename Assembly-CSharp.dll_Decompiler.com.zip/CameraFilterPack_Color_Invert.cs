using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005F")]
public class CameraFilterPack_Color_Invert : MonoBehaviour
{
	[Token(Token = "0x4000338")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000339")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400033A")]
	[FieldOffset(Offset = "0x24")]
	public float _Fade;

	[Token(Token = "0x400033B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000060")]
	private Material material
	{
		[Token(Token = "0x600026B")]
		[Address(RVA = "0x66C8B4", Offset = "0x66C8B4", VA = "0x66C8B4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600026C")]
	[Address(RVA = "0x66C978", Offset = "0x66C978", VA = "0x66C978")]
	private void Start()
	{
	}

	[Token(Token = "0x600026D")]
	[Address(RVA = "0x66C9F4", Offset = "0x66C9F4", VA = "0x66C9F4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600026E")]
	[Address(RVA = "0x66CC0C", Offset = "0x66CC0C", VA = "0x66CC0C")]
	private void Update()
	{
	}

	[Token(Token = "0x600026F")]
	[Address(RVA = "0x66CC10", Offset = "0x66CC10", VA = "0x66CC10")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000270")]
	[Address(RVA = "0x66CCC0", Offset = "0x66CCC0", VA = "0x66CCC0")]
	public CameraFilterPack_Color_Invert()
	{
	}
}
