using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008D")]
public class CameraFilterPack_Drawing_Lines : MonoBehaviour
{
	[Token(Token = "0x4000443")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000444")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000445")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000446")]
	[FieldOffset(Offset = "0x30")]
	public float Number;

	[Token(Token = "0x4000447")]
	[FieldOffset(Offset = "0x34")]
	public float Random;

	[Token(Token = "0x4000448")]
	[FieldOffset(Offset = "0x38")]
	private float PositionY;

	[Token(Token = "0x4000449")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700008E")]
	private Material material
	{
		[Token(Token = "0x6000381")]
		[Address(RVA = "0x68FC78", Offset = "0x68FC78", VA = "0x68FC78")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000382")]
	[Address(RVA = "0x68FD3C", Offset = "0x68FD3C", VA = "0x68FD3C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000383")]
	[Address(RVA = "0x68FDB8", Offset = "0x68FDB8", VA = "0x68FDB8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000384")]
	[Address(RVA = "0x69003C", Offset = "0x69003C", VA = "0x69003C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000385")]
	[Address(RVA = "0x690040", Offset = "0x690040", VA = "0x690040")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000386")]
	[Address(RVA = "0x6900F0", Offset = "0x6900F0", VA = "0x6900F0")]
	public CameraFilterPack_Drawing_Lines()
	{
	}
}
