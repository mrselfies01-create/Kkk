using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DE")]
public class CameraFilterPack_Lut_PlayWith : MonoBehaviour
{
	[Token(Token = "0x400066B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400066C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400066D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400066E")]
	[FieldOffset(Offset = "0x30")]
	public Texture2D LutTexture;

	[Token(Token = "0x400066F")]
	[FieldOffset(Offset = "0x38")]
	private Texture3D converted3DLut;

	[Token(Token = "0x4000670")]
	[FieldOffset(Offset = "0x40")]
	public float Blend;

	[Token(Token = "0x4000671")]
	[FieldOffset(Offset = "0x44")]
	public float OriginalIntensity;

	[Token(Token = "0x4000672")]
	[FieldOffset(Offset = "0x48")]
	public float ResultIntensity;

	[Token(Token = "0x4000673")]
	[FieldOffset(Offset = "0x4C")]
	public float FinalIntensity;

	[Token(Token = "0x4000674")]
	[FieldOffset(Offset = "0x50")]
	private string MemoPath;

	[Token(Token = "0x170000DF")]
	private Material material
	{
		[Token(Token = "0x6000574")]
		[Address(RVA = "0x6A8138", Offset = "0x6A8138", VA = "0x6A8138")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000575")]
	[Address(RVA = "0x6A81FC", Offset = "0x6A81FC", VA = "0x6A81FC")]
	private void Start()
	{
	}

	[Token(Token = "0x6000576")]
	[Address(RVA = "0x6A8278", Offset = "0x6A8278", VA = "0x6A8278")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x6000577")]
	[Address(RVA = "0x6A8464", Offset = "0x6A8464", VA = "0x6A8464")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x6000578")]
	[Address(RVA = "0x6A8558", Offset = "0x6A8558", VA = "0x6A8558")]
	public void Convert(Texture2D temp2DTex)
	{
	}

	[Token(Token = "0x6000579")]
	[Address(RVA = "0x6A8828", Offset = "0x6A8828", VA = "0x6A8828")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600057A")]
	[Address(RVA = "0x6A8A94", Offset = "0x6A8A94", VA = "0x6A8A94")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600057B")]
	[Address(RVA = "0x6A8A98", Offset = "0x6A8A98", VA = "0x6A8A98")]
	private void Update()
	{
	}

	[Token(Token = "0x600057C")]
	[Address(RVA = "0x6A8A9C", Offset = "0x6A8A9C", VA = "0x6A8A9C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600057D")]
	[Address(RVA = "0x6A8B4C", Offset = "0x6A8B4C", VA = "0x6A8B4C")]
	public CameraFilterPack_Lut_PlayWith()
	{
	}
}
