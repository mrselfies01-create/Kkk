using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200012E")]
public class CameraFilterPack_Vision_Tunnel : MonoBehaviour
{
	[Token(Token = "0x400088F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000890")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000891")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000892")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x4000893")]
	[FieldOffset(Offset = "0x34")]
	public float Value2;

	[Token(Token = "0x4000894")]
	[FieldOffset(Offset = "0x38")]
	public float Intensity;

	[Token(Token = "0x4000895")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700012F")]
	private Material material
	{
		[Token(Token = "0x600076B")]
		[Address(RVA = "0x640794", Offset = "0x640794", VA = "0x640794")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600076C")]
	[Address(RVA = "0x640858", Offset = "0x640858", VA = "0x640858")]
	private void Start()
	{
	}

	[Token(Token = "0x600076D")]
	[Address(RVA = "0x6408D4", Offset = "0x6408D4", VA = "0x6408D4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600076E")]
	[Address(RVA = "0x640B58", Offset = "0x640B58", VA = "0x640B58")]
	private void Update()
	{
	}

	[Token(Token = "0x600076F")]
	[Address(RVA = "0x640B5C", Offset = "0x640B5C", VA = "0x640B5C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000770")]
	[Address(RVA = "0x640C0C", Offset = "0x640C0C", VA = "0x640C0C")]
	public CameraFilterPack_Vision_Tunnel()
	{
	}
}
