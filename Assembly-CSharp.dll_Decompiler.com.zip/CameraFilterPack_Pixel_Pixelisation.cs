using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F5")]
public class CameraFilterPack_Pixel_Pixelisation : MonoBehaviour
{
	[Token(Token = "0x400071B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400071C")]
	[FieldOffset(Offset = "0x20")]
	public float _Pixelisation;

	[Token(Token = "0x400071D")]
	[FieldOffset(Offset = "0x24")]
	public float _SizeX;

	[Token(Token = "0x400071E")]
	[FieldOffset(Offset = "0x28")]
	public float _SizeY;

	[Token(Token = "0x400071F")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x170000F6")]
	private Material material
	{
		[Token(Token = "0x6000614")]
		[Address(RVA = "0x630484", Offset = "0x630484", VA = "0x630484")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000615")]
	[Address(RVA = "0x630548", Offset = "0x630548", VA = "0x630548")]
	private void Start()
	{
	}

	[Token(Token = "0x6000616")]
	[Address(RVA = "0x6305C4", Offset = "0x6305C4", VA = "0x6305C4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000617")]
	[Address(RVA = "0x630738", Offset = "0x630738", VA = "0x630738")]
	private void Update()
	{
	}

	[Token(Token = "0x6000618")]
	[Address(RVA = "0x63073C", Offset = "0x63073C", VA = "0x63073C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000619")]
	[Address(RVA = "0x6307EC", Offset = "0x6307EC", VA = "0x6307EC")]
	public CameraFilterPack_Pixel_Pixelisation()
	{
	}
}
