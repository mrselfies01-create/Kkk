using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005D")]
public class CameraFilterPack_Color_Contrast : MonoBehaviour
{
	[Token(Token = "0x4000330")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000331")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000332")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000333")]
	[FieldOffset(Offset = "0x30")]
	public float Contrast;

	[Token(Token = "0x1700005E")]
	private Material material
	{
		[Token(Token = "0x600025F")]
		[Address(RVA = "0x66C074", Offset = "0x66C074", VA = "0x66C074")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000260")]
	[Address(RVA = "0x66C138", Offset = "0x66C138", VA = "0x66C138")]
	private void Start()
	{
	}

	[Token(Token = "0x6000261")]
	[Address(RVA = "0x66C1B4", Offset = "0x66C1B4", VA = "0x66C1B4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000262")]
	[Address(RVA = "0x66C3CC", Offset = "0x66C3CC", VA = "0x66C3CC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000263")]
	[Address(RVA = "0x66C3D0", Offset = "0x66C3D0", VA = "0x66C3D0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000264")]
	[Address(RVA = "0x66C480", Offset = "0x66C480", VA = "0x66C480")]
	public CameraFilterPack_Color_Contrast()
	{
	}
}
