using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000109")]
public class CameraFilterPack_TV_Chromatical2 : MonoBehaviour
{
	[Token(Token = "0x40007A6")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007A7")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007A8")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007A9")]
	[FieldOffset(Offset = "0x30")]
	public float Aberration;

	[Token(Token = "0x40007AA")]
	[FieldOffset(Offset = "0x34")]
	public float Fade;

	[Token(Token = "0x40007AB")]
	[FieldOffset(Offset = "0x38")]
	public float ZoomFade;

	[Token(Token = "0x40007AC")]
	[FieldOffset(Offset = "0x3C")]
	public float ZoomSpeed;

	[Token(Token = "0x1700010A")]
	private Material material
	{
		[Token(Token = "0x600068D")]
		[Address(RVA = "0x636428", Offset = "0x636428", VA = "0x636428")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600068E")]
	[Address(RVA = "0x6364EC", Offset = "0x6364EC", VA = "0x6364EC")]
	private void Start()
	{
	}

	[Token(Token = "0x600068F")]
	[Address(RVA = "0x636568", Offset = "0x636568", VA = "0x636568")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000690")]
	[Address(RVA = "0x6367EC", Offset = "0x6367EC", VA = "0x6367EC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000691")]
	[Address(RVA = "0x6367F0", Offset = "0x6367F0", VA = "0x6367F0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000692")]
	[Address(RVA = "0x6368A0", Offset = "0x6368A0", VA = "0x6368A0")]
	public CameraFilterPack_TV_Chromatical2()
	{
	}
}
