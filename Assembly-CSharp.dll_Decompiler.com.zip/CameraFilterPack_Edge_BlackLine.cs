using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200009E")]
public class CameraFilterPack_Edge_BlackLine : MonoBehaviour
{
	[Token(Token = "0x40004BD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004BE")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004BF")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700009F")]
	private Material material
	{
		[Token(Token = "0x60003E8")]
		[Address(RVA = "0x69484C", Offset = "0x69484C", VA = "0x69484C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003E9")]
	[Address(RVA = "0x694910", Offset = "0x694910", VA = "0x694910")]
	private void Start()
	{
	}

	[Token(Token = "0x60003EA")]
	[Address(RVA = "0x69498C", Offset = "0x69498C", VA = "0x69498C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003EB")]
	[Address(RVA = "0x694B70", Offset = "0x694B70", VA = "0x694B70")]
	private void Update()
	{
	}

	[Token(Token = "0x60003EC")]
	[Address(RVA = "0x694B74", Offset = "0x694B74", VA = "0x694B74")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003ED")]
	[Address(RVA = "0x694C24", Offset = "0x694C24", VA = "0x694C24")]
	public CameraFilterPack_Edge_BlackLine()
	{
	}
}
