using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000047")]
public class CameraFilterPack_Blur_Blurry : MonoBehaviour
{
	[Token(Token = "0x40002A4")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002A5")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002A6")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002A7")]
	[FieldOffset(Offset = "0x30")]
	public float Amount;

	[Token(Token = "0x40002A8")]
	[FieldOffset(Offset = "0x34")]
	public int FastFilter;

	[Token(Token = "0x17000048")]
	private Material material
	{
		[Token(Token = "0x60001DB")]
		[Address(RVA = "0x665764", Offset = "0x665764", VA = "0x665764")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001DC")]
	[Address(RVA = "0x665828", Offset = "0x665828", VA = "0x665828")]
	private void Start()
	{
	}

	[Token(Token = "0x60001DD")]
	[Address(RVA = "0x6658A4", Offset = "0x6658A4", VA = "0x6658A4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001DE")]
	[Address(RVA = "0x665B88", Offset = "0x665B88", VA = "0x665B88")]
	private void Update()
	{
	}

	[Token(Token = "0x60001DF")]
	[Address(RVA = "0x665B8C", Offset = "0x665B8C", VA = "0x665B8C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001E0")]
	[Address(RVA = "0x665C3C", Offset = "0x665C3C", VA = "0x665C3C")]
	public CameraFilterPack_Blur_Blurry()
	{
	}
}
