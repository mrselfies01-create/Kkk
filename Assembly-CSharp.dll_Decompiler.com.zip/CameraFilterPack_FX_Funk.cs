using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B0")]
public class CameraFilterPack_FX_Funk : MonoBehaviour
{
	[Token(Token = "0x400052A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400052B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400052C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000B1")]
	private Material material
	{
		[Token(Token = "0x6000454")]
		[Address(RVA = "0x699680", Offset = "0x699680", VA = "0x699680")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000455")]
	[Address(RVA = "0x699744", Offset = "0x699744", VA = "0x699744")]
	private void Start()
	{
	}

	[Token(Token = "0x6000456")]
	[Address(RVA = "0x6997C0", Offset = "0x6997C0", VA = "0x6997C0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000457")]
	[Address(RVA = "0x6999B4", Offset = "0x6999B4", VA = "0x6999B4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000458")]
	[Address(RVA = "0x6999B8", Offset = "0x6999B8", VA = "0x6999B8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000459")]
	[Address(RVA = "0x699A68", Offset = "0x699A68", VA = "0x699A68")]
	public CameraFilterPack_FX_Funk()
	{
	}
}
