using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000135")]
public class RandomVisualChanges : MonoBehaviour
{
	[Token(Token = "0x40008B2")]
	[FieldOffset(Offset = "0x18")]
	public CameraFilterPack_Blend2Camera_Blend blend;

	[Token(Token = "0x40008B3")]
	[FieldOffset(Offset = "0x20")]
	public CameraFilterPack_Distortion_ShockWave[] waves;

	[Token(Token = "0x40008B4")]
	[FieldOffset(Offset = "0x28")]
	public CameraFilterPack_Real_VHS brightness;

	[Token(Token = "0x40008B5")]
	[FieldOffset(Offset = "0x30")]
	public float maxSpeed;

	[Token(Token = "0x40008B6")]
	[FieldOffset(Offset = "0x34")]
	public float minSpeed;

	[Token(Token = "0x40008B7")]
	[FieldOffset(Offset = "0x38")]
	public float minBlend;

	[Token(Token = "0x40008B8")]
	[FieldOffset(Offset = "0x3C")]
	public float maxBlend;

	[Token(Token = "0x40008B9")]
	[FieldOffset(Offset = "0x40")]
	private float blendTime;

	[Token(Token = "0x40008BA")]
	[FieldOffset(Offset = "0x44")]
	public float minBrightness;

	[Token(Token = "0x40008BB")]
	[FieldOffset(Offset = "0x48")]
	public float maxBrightness;

	[Token(Token = "0x40008BC")]
	[FieldOffset(Offset = "0x4C")]
	public float minBrightnessChangeSpeed;

	[Token(Token = "0x40008BD")]
	[FieldOffset(Offset = "0x50")]
	public float maxBrightnessChangeSpeed;

	[Token(Token = "0x40008BE")]
	[FieldOffset(Offset = "0x54")]
	private float brightnessTime;

	[Token(Token = "0x40008BF")]
	[FieldOffset(Offset = "0x58")]
	public float maxWaveChangeSpeed;

	[Token(Token = "0x40008C0")]
	[FieldOffset(Offset = "0x5C")]
	public float minWaveChangeSpeed;

	[Token(Token = "0x40008C1")]
	[FieldOffset(Offset = "0x60")]
	public float minWaveX;

	[Token(Token = "0x40008C2")]
	[FieldOffset(Offset = "0x64")]
	public float maxWaveX;

	[Token(Token = "0x40008C3")]
	[FieldOffset(Offset = "0x68")]
	public float minWaveY;

	[Token(Token = "0x40008C4")]
	[FieldOffset(Offset = "0x6C")]
	public float maxWaveY;

	[Token(Token = "0x40008C5")]
	[FieldOffset(Offset = "0x70")]
	private float[] waveTime;

	[Token(Token = "0x600078F")]
	[Address(RVA = "0x3973DC", Offset = "0x3973DC", VA = "0x3973DC")]
	public void Start()
	{
	}

	[Token(Token = "0x6000790")]
	[Address(RVA = "0x397440", Offset = "0x397440", VA = "0x397440")]
	private void Update()
	{
	}

	[Token(Token = "0x6000791")]
	[Address(RVA = "0x397688", Offset = "0x397688", VA = "0x397688")]
	public RandomVisualChanges()
	{
	}
}
