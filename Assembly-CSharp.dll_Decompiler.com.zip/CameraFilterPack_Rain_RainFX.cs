using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000FB")]
public class CameraFilterPack_Rain_RainFX : MonoBehaviour
{
	[Token(Token = "0x4000741")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000742")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000743")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000744")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x4000745")]
	[FieldOffset(Offset = "0x34")]
	public float Fade;

	[Token(Token = "0x4000746")]
	[FieldOffset(Offset = "0x38")]
	public int Count;

	[Token(Token = "0x4000747")]
	[FieldOffset(Offset = "0x40")]
	private Vector4[] Coord;

	[Token(Token = "0x4000748")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x4000749")]
	[FieldOffset(Offset = "0x48")]
	private Texture2D Texture2;

	[Token(Token = "0x400074A")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture3;

	[Token(Token = "0x170000FC")]
	private Material material
	{
		[Token(Token = "0x6000638")]
		[Address(RVA = "0x631EA4", Offset = "0x631EA4", VA = "0x631EA4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000639")]
	[Address(RVA = "0x631F68", Offset = "0x631F68", VA = "0x631F68")]
	private void Start()
	{
	}

	[Token(Token = "0x600063A")]
	[Address(RVA = "0x63205C", Offset = "0x63205C", VA = "0x63205C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600063B")]
	[Address(RVA = "0x6325C8", Offset = "0x6325C8", VA = "0x6325C8")]
	private void Update()
	{
	}

	[Token(Token = "0x600063C")]
	[Address(RVA = "0x6325CC", Offset = "0x6325CC", VA = "0x6325CC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600063D")]
	[Address(RVA = "0x63267C", Offset = "0x63267C", VA = "0x63267C")]
	public CameraFilterPack_Rain_RainFX()
	{
	}
}
