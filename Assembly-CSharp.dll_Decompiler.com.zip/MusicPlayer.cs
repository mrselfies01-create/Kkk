using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;
using UnityEngine.UI;

[Token(Token = "0x2000137")]
public class MusicPlayer : MonoBehaviour
{
	[Token(Token = "0x20001F7")]
	private sealed class _003CHideAnimation_003Ed__30 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D82")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D83")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D84")]
		[FieldOffset(Offset = "0x20")]
		public MusicPlayer _003C_003E4__this;

		[Token(Token = "0x17000246")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D4F")]
			[Address(RVA = "0x78EF80", Offset = "0x78EF80", VA = "0x78EF80", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000247")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D51")]
			[Address(RVA = "0x78EFE8", Offset = "0x78EFE8", VA = "0x78EFE8", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D4C")]
		[Address(RVA = "0x78EDDC", Offset = "0x78EDDC", VA = "0x78EDDC")]
		public _003CHideAnimation_003Ed__30(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D4D")]
		[Address(RVA = "0x78EE08", Offset = "0x78EE08", VA = "0x78EE08", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D4E")]
		[Address(RVA = "0x78EE0C", Offset = "0x78EE0C", VA = "0x78EE0C", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D50")]
		[Address(RVA = "0x78EF88", Offset = "0x78EF88", VA = "0x78EF88", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x20001F8")]
	private sealed class _003CLoadSong_003Ed__41 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D85")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D86")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D87")]
		[FieldOffset(Offset = "0x20")]
		public SongData song;

		[Token(Token = "0x4000D88")]
		[FieldOffset(Offset = "0x28")]
		public MusicPlayer _003C_003E4__this;

		[Token(Token = "0x4000D89")]
		[FieldOffset(Offset = "0x30")]
		private AudioClip _003Ca_003E5__2;

		[Token(Token = "0x17000248")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D55")]
			[Address(RVA = "0x78F1F4", Offset = "0x78F1F4", VA = "0x78F1F4", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000249")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D57")]
			[Address(RVA = "0x78F25C", Offset = "0x78F25C", VA = "0x78F25C", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D52")]
		[Address(RVA = "0x78EFF0", Offset = "0x78EFF0", VA = "0x78EFF0")]
		public _003CLoadSong_003Ed__41(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D53")]
		[Address(RVA = "0x78F01C", Offset = "0x78F01C", VA = "0x78F01C", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D54")]
		[Address(RVA = "0x78F020", Offset = "0x78F020", VA = "0x78F020", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D56")]
		[Address(RVA = "0x78F1FC", Offset = "0x78F1FC", VA = "0x78F1FC", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x40008CB")]
	[FieldOffset(Offset = "0x18")]
	public bool PrimaryMusicPlayer;

	[Token(Token = "0x40008CC")]
	[FieldOffset(Offset = "0x20")]
	public SongData actualSong;

	[Token(Token = "0x40008CD")]
	[FieldOffset(Offset = "0x28")]
	public AudioSource audioSource;

	[Token(Token = "0x40008CE")]
	[FieldOffset(Offset = "0x30")]
	public Sprite playSprite;

	[Token(Token = "0x40008CF")]
	[FieldOffset(Offset = "0x38")]
	public Sprite pauseSprite;

	[Token(Token = "0x40008D0")]
	[FieldOffset(Offset = "0x40")]
	public InputField searchSong;

	[Token(Token = "0x40008D1")]
	[FieldOffset(Offset = "0x48")]
	public Image playPauseButton;

	[Token(Token = "0x40008D2")]
	[FieldOffset(Offset = "0x50")]
	public Text songName;

	[Token(Token = "0x40008D3")]
	[FieldOffset(Offset = "0x58")]
	public Image playerBar;

	[Token(Token = "0x40008D4")]
	[FieldOffset(Offset = "0x60")]
	public Slider sliderBar;

	[Token(Token = "0x40008D5")]
	[FieldOffset(Offset = "0x68")]
	public Text actualTime;

	[Token(Token = "0x40008D6")]
	[FieldOffset(Offset = "0x70")]
	public Text totalTime;

	[Token(Token = "0x40008D7")]
	[FieldOffset(Offset = "0x78")]
	public GameObject songList;

	[Token(Token = "0x40008D8")]
	[FieldOffset(Offset = "0x80")]
	public List<SongData> songs;

	[Token(Token = "0x40008D9")]
	[FieldOffset(Offset = "0x88")]
	public List<GameObject> songSearchList;

	[Token(Token = "0x40008DA")]
	[FieldOffset(Offset = "0x90")]
	public GameObject songPrefab;

	[Token(Token = "0x40008DB")]
	[FieldOffset(Offset = "0x98")]
	public GameObject songSelectionPanel;

	[Token(Token = "0x40008DC")]
	[FieldOffset(Offset = "0xA0")]
	public Transform songsSelectionTransform;

	[Token(Token = "0x40008DD")]
	[FieldOffset(Offset = "0xA8")]
	private int actualPos;

	[Token(Token = "0x40008DE")]
	[FieldOffset(Offset = "0xAC")]
	private float amount;

	[Token(Token = "0x40008DF")]
	[FieldOffset(Offset = "0xB0")]
	private bool playing;

	[Token(Token = "0x40008E0")]
	[FieldOffset(Offset = "0xB1")]
	private bool active;

	[Token(Token = "0x40008E1")]
	[FieldOffset(Offset = "0xB2")]
	public bool animateSearch;

	[Token(Token = "0x40008E2")]
	[FieldOffset(Offset = "0xB8")]
	public Animator contentAnim;

	[Token(Token = "0x40008E3")]
	[FieldOffset(Offset = "0x0")]
	public static MusicPlayer instance;

	[Token(Token = "0x6000796")]
	[Address(RVA = "0x390CCC", Offset = "0x390CCC", VA = "0x390CCC")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000797")]
	[Address(RVA = "0x390F2C", Offset = "0x390F2C", VA = "0x390F2C")]
	private void CreateSongSelectionList()
	{
	}

	[Token(Token = "0x6000798")]
	[Address(RVA = "0x3913B0", Offset = "0x3913B0", VA = "0x3913B0")]
	public void SearchSongByName()
	{
	}

	[Token(Token = "0x6000799")]
	[Address(RVA = "0x391538", Offset = "0x391538", VA = "0x391538")]
	public void OrderList()
	{
	}

	[Token(Token = "0x600079A")]
	[Address(RVA = "0x3917A0", Offset = "0x3917A0", VA = "0x3917A0")]
	public void ActivateOrDeactivate()
	{
	}

	[Token(Token = "0x600079B")]
	[Address(RVA = "0x3918A0", Offset = "0x3918A0", VA = "0x3918A0")]
	private IEnumerator HideAnimation()
	{
		return null;
	}

	[Token(Token = "0x600079C")]
	[Address(RVA = "0x391910", Offset = "0x391910", VA = "0x391910")]
	private void SetActiveSongImage()
	{
	}

	[Token(Token = "0x600079D")]
	[Address(RVA = "0x391248", Offset = "0x391248", VA = "0x391248")]
	public void ChangeSong(int pos)
	{
	}

	[Token(Token = "0x600079E")]
	[Address(RVA = "0x391C94", Offset = "0x391C94", VA = "0x391C94")]
	private void Update()
	{
	}

	[Token(Token = "0x600079F")]
	[Address(RVA = "0x392078", Offset = "0x392078", VA = "0x392078")]
	private void CalculateActualTime()
	{
	}

	[Token(Token = "0x60007A0")]
	[Address(RVA = "0x392230", Offset = "0x392230", VA = "0x392230")]
	public void ChangePosition()
	{
	}

	[Token(Token = "0x60007A1")]
	[Address(RVA = "0x391AA4", Offset = "0x391AA4", VA = "0x391AA4")]
	public void StopSong()
	{
	}

	[Token(Token = "0x60007A2")]
	[Address(RVA = "0x391F90", Offset = "0x391F90", VA = "0x391F90")]
	public void PlayOrPauseSong()
	{
	}

	[Token(Token = "0x60007A3")]
	[Address(RVA = "0x39217C", Offset = "0x39217C", VA = "0x39217C")]
	public void NextSong()
	{
	}

	[Token(Token = "0x60007A4")]
	[Address(RVA = "0x392364", Offset = "0x392364", VA = "0x392364")]
	public void PreviousSong()
	{
	}

	[Token(Token = "0x60007A5")]
	[Address(RVA = "0x391BF0", Offset = "0x391BF0", VA = "0x391BF0")]
	private void PrepareToLoadSong(int pos)
	{
	}

	[Token(Token = "0x60007A6")]
	[Address(RVA = "0x392410", Offset = "0x392410", VA = "0x392410")]
	private IEnumerator LoadSong(SongData song)
	{
		return null;
	}

	[Token(Token = "0x60007A7")]
	[Address(RVA = "0x39248C", Offset = "0x39248C", VA = "0x39248C")]
	public MusicPlayer()
	{
	}
}
