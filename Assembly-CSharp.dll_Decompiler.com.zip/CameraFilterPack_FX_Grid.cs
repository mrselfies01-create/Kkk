using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B4")]
public class CameraFilterPack_FX_Grid : MonoBehaviour
{
	[Token(Token = "0x400053A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400053B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400053C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400053D")]
	[FieldOffset(Offset = "0x30")]
	public float Distortion;

	[Token(Token = "0x400053E")]
	[FieldOffset(Offset = "0x0")]
	public static float ChangeDistortion;

	[Token(Token = "0x170000B5")]
	private Material material
	{
		[Token(Token = "0x600046C")]
		[Address(RVA = "0x69A700", Offset = "0x69A700", VA = "0x69A700")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600046D")]
	[Address(RVA = "0x69A7C4", Offset = "0x69A7C4", VA = "0x69A7C4")]
	private void Start()
	{
	}

	[Token(Token = "0x600046E")]
	[Address(RVA = "0x69A840", Offset = "0x69A840", VA = "0x69A840")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600046F")]
	[Address(RVA = "0x69A9C4", Offset = "0x69A9C4", VA = "0x69A9C4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000470")]
	[Address(RVA = "0x69A9C8", Offset = "0x69A9C8", VA = "0x69A9C8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000471")]
	[Address(RVA = "0x69AA78", Offset = "0x69AA78", VA = "0x69AA78")]
	public CameraFilterPack_FX_Grid()
	{
	}
}
