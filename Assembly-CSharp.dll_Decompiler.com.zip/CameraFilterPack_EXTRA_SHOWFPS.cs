using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;

[Token(Token = "0x200009D")]
public class CameraFilterPack_EXTRA_SHOWFPS : MonoBehaviour
{
	[Token(Token = "0x20001F2")]
	private sealed class _003CFPSX_003Ed__14 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D6A")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D6B")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D6C")]
		[FieldOffset(Offset = "0x20")]
		public CameraFilterPack_EXTRA_SHOWFPS _003C_003E4__this;

		[Token(Token = "0x1700023E")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D37")]
			[Address(RVA = "0x47BD70", Offset = "0x47BD70", VA = "0x47BD70", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x1700023F")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D39")]
			[Address(RVA = "0x47BDD8", Offset = "0x47BDD8", VA = "0x47BDD8", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D34")]
		[Address(RVA = "0x47BC88", Offset = "0x47BC88", VA = "0x47BC88")]
		public _003CFPSX_003Ed__14(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D35")]
		[Address(RVA = "0x47BCB4", Offset = "0x47BCB4", VA = "0x47BCB4", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D36")]
		[Address(RVA = "0x47BCB8", Offset = "0x47BCB8", VA = "0x47BCB8", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D38")]
		[Address(RVA = "0x47BD78", Offset = "0x47BD78", VA = "0x47BD78", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x40004B3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004B4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004B5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004B6")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x40004B7")]
	[FieldOffset(Offset = "0x34")]
	private int FPS;

	[Token(Token = "0x40004B8")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x40004B9")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x40004BA")]
	[FieldOffset(Offset = "0x40")]
	private float accum;

	[Token(Token = "0x40004BB")]
	[FieldOffset(Offset = "0x44")]
	private int frames;

	[Token(Token = "0x40004BC")]
	[FieldOffset(Offset = "0x48")]
	public float frequency;

	[Token(Token = "0x1700009E")]
	private Material material
	{
		[Token(Token = "0x60003E1")]
		[Address(RVA = "0x6942C8", Offset = "0x6942C8", VA = "0x6942C8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003E2")]
	[Address(RVA = "0x69438C", Offset = "0x69438C", VA = "0x69438C")]
	private void Start()
	{
	}

	[Token(Token = "0x60003E3")]
	[Address(RVA = "0x694494", Offset = "0x694494", VA = "0x694494")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003E4")]
	[Address(RVA = "0x694424", Offset = "0x694424", VA = "0x694424")]
	private IEnumerator FPSX()
	{
		return null;
	}

	[Token(Token = "0x60003E5")]
	[Address(RVA = "0x69471C", Offset = "0x69471C", VA = "0x69471C")]
	private void Update()
	{
	}

	[Token(Token = "0x60003E6")]
	[Address(RVA = "0x694770", Offset = "0x694770", VA = "0x694770")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003E7")]
	[Address(RVA = "0x694820", Offset = "0x694820", VA = "0x694820")]
	public CameraFilterPack_EXTRA_SHOWFPS()
	{
	}
}
