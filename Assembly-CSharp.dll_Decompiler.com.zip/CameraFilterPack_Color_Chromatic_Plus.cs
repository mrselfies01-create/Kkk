using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005C")]
public class CameraFilterPack_Color_Chromatic_Plus : MonoBehaviour
{
	[Token(Token = "0x400032A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400032B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400032C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400032D")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400032E")]
	[FieldOffset(Offset = "0x34")]
	public float Smooth;

	[Token(Token = "0x400032F")]
	[FieldOffset(Offset = "0x38")]
	public float Offset;

	[Token(Token = "0x1700005D")]
	private Material material
	{
		[Token(Token = "0x6000259")]
		[Address(RVA = "0x66BBF8", Offset = "0x66BBF8", VA = "0x66BBF8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600025A")]
	[Address(RVA = "0x66BCBC", Offset = "0x66BCBC", VA = "0x66BCBC")]
	private void Start()
	{
	}

	[Token(Token = "0x600025B")]
	[Address(RVA = "0x66BD38", Offset = "0x66BD38", VA = "0x66BD38")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600025C")]
	[Address(RVA = "0x66BF98", Offset = "0x66BF98", VA = "0x66BF98")]
	private void Update()
	{
	}

	[Token(Token = "0x600025D")]
	[Address(RVA = "0x66BF9C", Offset = "0x66BF9C", VA = "0x66BF9C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600025E")]
	[Address(RVA = "0x66C04C", Offset = "0x66C04C", VA = "0x66C04C")]
	public CameraFilterPack_Color_Chromatic_Plus()
	{
	}
}
