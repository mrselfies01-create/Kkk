using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200009F")]
public class CameraFilterPack_Edge_Edge_filter : MonoBehaviour
{
	[Token(Token = "0x40004C0")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004C1")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004C2")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004C3")]
	[FieldOffset(Offset = "0x30")]
	public float RedAmplifier;

	[Token(Token = "0x40004C4")]
	[FieldOffset(Offset = "0x34")]
	public float GreenAmplifier;

	[Token(Token = "0x40004C5")]
	[FieldOffset(Offset = "0x38")]
	public float BlueAmplifier;

	[Token(Token = "0x170000A0")]
	private Material material
	{
		[Token(Token = "0x60003EE")]
		[Address(RVA = "0x694C34", Offset = "0x694C34", VA = "0x694C34")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003EF")]
	[Address(RVA = "0x694CF8", Offset = "0x694CF8", VA = "0x694CF8")]
	private void Start()
	{
	}

	[Token(Token = "0x60003F0")]
	[Address(RVA = "0x694D74", Offset = "0x694D74", VA = "0x694D74")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003F1")]
	[Address(RVA = "0x694FC4", Offset = "0x694FC4", VA = "0x694FC4")]
	private void Update()
	{
	}

	[Token(Token = "0x60003F2")]
	[Address(RVA = "0x694FC8", Offset = "0x694FC8", VA = "0x694FC8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003F3")]
	[Address(RVA = "0x695078", Offset = "0x695078", VA = "0x695078")]
	public CameraFilterPack_Edge_Edge_filter()
	{
	}
}
