using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000DA")]
public class CameraFilterPack_Light_Water2 : MonoBehaviour
{
	[Token(Token = "0x4000640")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000641")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000642")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000643")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x4000644")]
	[FieldOffset(Offset = "0x34")]
	public float Speed_X;

	[Token(Token = "0x4000645")]
	[FieldOffset(Offset = "0x38")]
	public float Speed_Y;

	[Token(Token = "0x4000646")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x170000DB")]
	private Material material
	{
		[Token(Token = "0x6000550")]
		[Address(RVA = "0x6A5A60", Offset = "0x6A5A60", VA = "0x6A5A60")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000551")]
	[Address(RVA = "0x6A5B24", Offset = "0x6A5B24", VA = "0x6A5B24")]
	private void Start()
	{
	}

	[Token(Token = "0x6000552")]
	[Address(RVA = "0x6A5BA0", Offset = "0x6A5BA0", VA = "0x6A5BA0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000553")]
	[Address(RVA = "0x6A5E24", Offset = "0x6A5E24", VA = "0x6A5E24")]
	private void Update()
	{
	}

	[Token(Token = "0x6000554")]
	[Address(RVA = "0x6A5E28", Offset = "0x6A5E28", VA = "0x6A5E28")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000555")]
	[Address(RVA = "0x6A5ED8", Offset = "0x6A5ED8", VA = "0x6A5ED8")]
	public CameraFilterPack_Light_Water2()
	{
	}
}
