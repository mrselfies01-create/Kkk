using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000022")]
public class CameraFilterPack_Atmosphere_Rain_Pro_3D : MonoBehaviour
{
	[Token(Token = "0x400014F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000150")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x4000151")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000152")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000153")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000154")]
	[FieldOffset(Offset = "0x34")]
	public float Fade;

	[Token(Token = "0x4000155")]
	[FieldOffset(Offset = "0x38")]
	public float Intensity;

	[Token(Token = "0x4000156")]
	[FieldOffset(Offset = "0x3C")]
	public bool DirectionFollowCameraZ;

	[Token(Token = "0x4000157")]
	[FieldOffset(Offset = "0x40")]
	public float DirectionX;

	[Token(Token = "0x4000158")]
	[FieldOffset(Offset = "0x44")]
	public float Size;

	[Token(Token = "0x4000159")]
	[FieldOffset(Offset = "0x48")]
	public float Speed;

	[Token(Token = "0x400015A")]
	[FieldOffset(Offset = "0x4C")]
	public float Distortion;

	[Token(Token = "0x400015B")]
	[FieldOffset(Offset = "0x50")]
	public float StormFlashOnOff;

	[Token(Token = "0x400015C")]
	[FieldOffset(Offset = "0x54")]
	public float DropOnOff;

	[Token(Token = "0x400015D")]
	[FieldOffset(Offset = "0x58")]
	public float Drop_Near;

	[Token(Token = "0x400015E")]
	[FieldOffset(Offset = "0x5C")]
	public float Drop_Far;

	[Token(Token = "0x400015F")]
	[FieldOffset(Offset = "0x60")]
	public float Drop_With_Obj;

	[Token(Token = "0x4000160")]
	[FieldOffset(Offset = "0x64")]
	public float Myst;

	[Token(Token = "0x4000161")]
	[FieldOffset(Offset = "0x68")]
	public float Drop_Floor_Fluid;

	[Token(Token = "0x4000162")]
	[FieldOffset(Offset = "0x6C")]
	public Color Myst_Color;

	[Token(Token = "0x4000163")]
	[FieldOffset(Offset = "0x80")]
	private Texture2D Texture2;

	[Token(Token = "0x17000023")]
	private Material material
	{
		[Token(Token = "0x60000BE")]
		[Address(RVA = "0x5BC344", Offset = "0x5BC344", VA = "0x5BC344")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000BF")]
	[Address(RVA = "0x5BC408", Offset = "0x5BC408", VA = "0x5BC408")]
	private void Start()
	{
	}

	[Token(Token = "0x60000C0")]
	[Address(RVA = "0x5BC4C0", Offset = "0x5BC4C0", VA = "0x5BC4C0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000C1")]
	[Address(RVA = "0x5BC9EC", Offset = "0x5BC9EC", VA = "0x5BC9EC")]
	private void Update()
	{
	}

	[Token(Token = "0x60000C2")]
	[Address(RVA = "0x5BC9F0", Offset = "0x5BC9F0", VA = "0x5BC9F0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000C3")]
	[Address(RVA = "0x5BCAA0", Offset = "0x5BCAA0", VA = "0x5BCAA0")]
	public CameraFilterPack_Atmosphere_Rain_Pro_3D()
	{
	}
}
