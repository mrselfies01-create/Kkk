using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200003F")]
public class CameraFilterPack_Blend2Camera_SoftLight : MonoBehaviour
{
	[Token(Token = "0x4000257")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000258")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000259")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x400025A")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400025B")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400025C")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400025D")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400025E")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000040")]
	private Material material
	{
		[Token(Token = "0x60001A1")]
		[Address(RVA = "0x662580", Offset = "0x662580", VA = "0x662580")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001A2")]
	[Address(RVA = "0x662644", Offset = "0x662644", VA = "0x662644")]
	private void Start()
	{
	}

	[Token(Token = "0x60001A3")]
	[Address(RVA = "0x66275C", Offset = "0x66275C", VA = "0x66275C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001A4")]
	[Address(RVA = "0x6629EC", Offset = "0x6629EC", VA = "0x6629EC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60001A5")]
	[Address(RVA = "0x662AD8", Offset = "0x662AD8", VA = "0x662AD8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001A6")]
	[Address(RVA = "0x662ADC", Offset = "0x662ADC", VA = "0x662ADC")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60001A7")]
	[Address(RVA = "0x662BC8", Offset = "0x662BC8", VA = "0x662BC8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001A8")]
	[Address(RVA = "0x662CC0", Offset = "0x662CC0", VA = "0x662CC0")]
	public CameraFilterPack_Blend2Camera_SoftLight()
	{
	}
}
