using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000112")]
public class CameraFilterPack_TV_Old_Movie_2 : MonoBehaviour
{
	[Token(Token = "0x40007D2")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007D3")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007D4")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007D5")]
	[FieldOffset(Offset = "0x30")]
	public float FramePerSecond;

	[Token(Token = "0x40007D6")]
	[FieldOffset(Offset = "0x34")]
	public float Contrast;

	[Token(Token = "0x40007D7")]
	[FieldOffset(Offset = "0x38")]
	public float Burn;

	[Token(Token = "0x40007D8")]
	[FieldOffset(Offset = "0x3C")]
	public float SceneCut;

	[Token(Token = "0x40007D9")]
	[FieldOffset(Offset = "0x40")]
	public float Fade;

	[Token(Token = "0x17000113")]
	private Material material
	{
		[Token(Token = "0x60006C3")]
		[Address(RVA = "0x63890C", Offset = "0x63890C", VA = "0x63890C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006C4")]
	[Address(RVA = "0x6389D0", Offset = "0x6389D0", VA = "0x6389D0")]
	private void Start()
	{
	}

	[Token(Token = "0x60006C5")]
	[Address(RVA = "0x638A4C", Offset = "0x638A4C", VA = "0x638A4C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006C6")]
	[Address(RVA = "0x638CF4", Offset = "0x638CF4", VA = "0x638CF4")]
	private void Update()
	{
	}

	[Token(Token = "0x60006C7")]
	[Address(RVA = "0x638CF8", Offset = "0x638CF8", VA = "0x638CF8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006C8")]
	[Address(RVA = "0x638DA8", Offset = "0x638DA8", VA = "0x638DA8")]
	public CameraFilterPack_TV_Old_Movie_2()
	{
	}
}
