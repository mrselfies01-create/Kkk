using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200006D")]
public class CameraFilterPack_Colors_NewPosterize : MonoBehaviour
{
	[Token(Token = "0x4000386")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000387")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000388")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000389")]
	[FieldOffset(Offset = "0x30")]
	public float Gamma;

	[Token(Token = "0x400038A")]
	[FieldOffset(Offset = "0x34")]
	public float Colors;

	[Token(Token = "0x400038B")]
	[FieldOffset(Offset = "0x38")]
	public float Green_Mod;

	[Token(Token = "0x400038C")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700006E")]
	private Material material
	{
		[Token(Token = "0x60002C1")]
		[Address(RVA = "0x670E9C", Offset = "0x670E9C", VA = "0x670E9C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002C2")]
	[Address(RVA = "0x670F60", Offset = "0x670F60", VA = "0x670F60")]
	private void Start()
	{
	}

	[Token(Token = "0x60002C3")]
	[Address(RVA = "0x670FDC", Offset = "0x670FDC", VA = "0x670FDC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002C4")]
	[Address(RVA = "0x671260", Offset = "0x671260", VA = "0x671260")]
	private void Update()
	{
	}

	[Token(Token = "0x60002C5")]
	[Address(RVA = "0x671264", Offset = "0x671264", VA = "0x671264")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002C6")]
	[Address(RVA = "0x671314", Offset = "0x671314", VA = "0x671314")]
	public CameraFilterPack_Colors_NewPosterize()
	{
	}
}
