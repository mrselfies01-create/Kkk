using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E0")]
public class CameraFilterPack_Lut_Simple : MonoBehaviour
{
	[Token(Token = "0x400067D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400067E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400067F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000680")]
	[FieldOffset(Offset = "0x30")]
	public Texture2D LutTexture;

	[Token(Token = "0x4000681")]
	[FieldOffset(Offset = "0x38")]
	private Texture3D converted3DLut;

	[Token(Token = "0x4000682")]
	[FieldOffset(Offset = "0x40")]
	private string MemoPath;

	[Token(Token = "0x170000E1")]
	private Material material
	{
		[Token(Token = "0x6000588")]
		[Address(RVA = "0x628C14", Offset = "0x628C14", VA = "0x628C14")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000589")]
	[Address(RVA = "0x628CD8", Offset = "0x628CD8", VA = "0x628CD8")]
	private void Start()
	{
	}

	[Token(Token = "0x600058A")]
	[Address(RVA = "0x628D54", Offset = "0x628D54", VA = "0x628D54")]
	public void SetIdentityLut()
	{
	}

	[Token(Token = "0x600058B")]
	[Address(RVA = "0x628F40", Offset = "0x628F40", VA = "0x628F40")]
	public bool ValidDimensions(Texture2D tex2d)
	{
		return default(bool);
	}

	[Token(Token = "0x600058C")]
	[Address(RVA = "0x629034", Offset = "0x629034", VA = "0x629034")]
	public void Convert(Texture2D temp2DTex)
	{
	}

	[Token(Token = "0x600058D")]
	[Address(RVA = "0x629304", Offset = "0x629304", VA = "0x629304")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600058E")]
	[Address(RVA = "0x6294E0", Offset = "0x6294E0", VA = "0x6294E0")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600058F")]
	[Address(RVA = "0x6294E4", Offset = "0x6294E4", VA = "0x6294E4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000590")]
	[Address(RVA = "0x6294E8", Offset = "0x6294E8", VA = "0x6294E8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000591")]
	[Address(RVA = "0x629598", Offset = "0x629598", VA = "0x629598")]
	public CameraFilterPack_Lut_Simple()
	{
	}
}
