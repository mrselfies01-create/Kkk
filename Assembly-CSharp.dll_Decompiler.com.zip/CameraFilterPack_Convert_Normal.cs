using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000070")]
public class CameraFilterPack_Convert_Normal : MonoBehaviour
{
	[Token(Token = "0x400039C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400039D")]
	[FieldOffset(Offset = "0x20")]
	public float _Heigh;

	[Token(Token = "0x400039E")]
	[FieldOffset(Offset = "0x24")]
	public float _Intervale;

	[Token(Token = "0x400039F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x17000071")]
	private Material material
	{
		[Token(Token = "0x60002D3")]
		[Address(RVA = "0x671BE4", Offset = "0x671BE4", VA = "0x671BE4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002D4")]
	[Address(RVA = "0x671CA8", Offset = "0x671CA8", VA = "0x671CA8")]
	private void Start()
	{
	}

	[Token(Token = "0x60002D5")]
	[Address(RVA = "0x671D24", Offset = "0x671D24", VA = "0x671D24")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002D6")]
	[Address(RVA = "0x671E74", Offset = "0x671E74", VA = "0x671E74")]
	private void Update()
	{
	}

	[Token(Token = "0x60002D7")]
	[Address(RVA = "0x671E78", Offset = "0x671E78", VA = "0x671E78")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002D8")]
	[Address(RVA = "0x671F28", Offset = "0x671F28", VA = "0x671F28")]
	public CameraFilterPack_Convert_Normal()
	{
	}
}
