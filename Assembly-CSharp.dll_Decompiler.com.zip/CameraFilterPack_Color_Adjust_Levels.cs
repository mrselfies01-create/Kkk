using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000059")]
public class CameraFilterPack_Color_Adjust_Levels : MonoBehaviour
{
	[Token(Token = "0x4000318")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000319")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400031A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400031B")]
	[FieldOffset(Offset = "0x30")]
	public float levelMinimum;

	[Token(Token = "0x400031C")]
	[FieldOffset(Offset = "0x34")]
	public float levelMiddle;

	[Token(Token = "0x400031D")]
	[FieldOffset(Offset = "0x38")]
	public float levelMaximum;

	[Token(Token = "0x400031E")]
	[FieldOffset(Offset = "0x3C")]
	public float minOutput;

	[Token(Token = "0x400031F")]
	[FieldOffset(Offset = "0x40")]
	public float maxOutput;

	[Token(Token = "0x1700005A")]
	private Material material
	{
		[Token(Token = "0x6000247")]
		[Address(RVA = "0x66AEC0", Offset = "0x66AEC0", VA = "0x66AEC0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000248")]
	[Address(RVA = "0x66AF84", Offset = "0x66AF84", VA = "0x66AF84")]
	private void Start()
	{
	}

	[Token(Token = "0x6000249")]
	[Address(RVA = "0x66B000", Offset = "0x66B000", VA = "0x66B000")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600024A")]
	[Address(RVA = "0x66B284", Offset = "0x66B284", VA = "0x66B284")]
	private void Update()
	{
	}

	[Token(Token = "0x600024B")]
	[Address(RVA = "0x66B288", Offset = "0x66B288", VA = "0x66B288")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600024C")]
	[Address(RVA = "0x66B338", Offset = "0x66B338", VA = "0x66B338")]
	public CameraFilterPack_Color_Adjust_Levels()
	{
	}
}
