using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200002B")]
public class CameraFilterPack_Blend2Camera_DarkerColor : MonoBehaviour
{
	[Token(Token = "0x40001AF")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001B0")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001B1")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001B2")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001B3")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001B4")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001B5")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001B6")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x1700002C")]
	private Material material
	{
		[Token(Token = "0x6000101")]
		[Address(RVA = "0x5C02DC", Offset = "0x5C02DC", VA = "0x5C02DC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000102")]
	[Address(RVA = "0x5C03A0", Offset = "0x5C03A0", VA = "0x5C03A0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000103")]
	[Address(RVA = "0x5C04B8", Offset = "0x5C04B8", VA = "0x5C04B8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000104")]
	[Address(RVA = "0x5C0748", Offset = "0x5C0748", VA = "0x5C0748")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000105")]
	[Address(RVA = "0x5C0834", Offset = "0x5C0834", VA = "0x5C0834")]
	private void Update()
	{
	}

	[Token(Token = "0x6000106")]
	[Address(RVA = "0x5C0838", Offset = "0x5C0838", VA = "0x5C0838")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000107")]
	[Address(RVA = "0x5C0924", Offset = "0x5C0924", VA = "0x5C0924")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000108")]
	[Address(RVA = "0x5C0A1C", Offset = "0x5C0A1C", VA = "0x5C0A1C")]
	public CameraFilterPack_Blend2Camera_DarkerColor()
	{
	}
}
