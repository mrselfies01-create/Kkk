using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000088")]
public class CameraFilterPack_Drawing_Crosshatch : MonoBehaviour
{
	[Token(Token = "0x4000428")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000429")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400042A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400042B")]
	[FieldOffset(Offset = "0x30")]
	public float Width;

	[Token(Token = "0x17000089")]
	private Material material
	{
		[Token(Token = "0x6000363")]
		[Address(RVA = "0x678334", Offset = "0x678334", VA = "0x678334")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000364")]
	[Address(RVA = "0x6783F8", Offset = "0x6783F8", VA = "0x6783F8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000365")]
	[Address(RVA = "0x678474", Offset = "0x678474", VA = "0x678474")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000366")]
	[Address(RVA = "0x67868C", Offset = "0x67868C", VA = "0x67868C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000367")]
	[Address(RVA = "0x678690", Offset = "0x678690", VA = "0x678690")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000368")]
	[Address(RVA = "0x678740", Offset = "0x678740", VA = "0x678740")]
	public CameraFilterPack_Drawing_Crosshatch()
	{
	}
}
