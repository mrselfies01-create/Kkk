using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A8")]
public class CameraFilterPack_FX_Ascii : MonoBehaviour
{
	[Token(Token = "0x40004EE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004EF")]
	[FieldOffset(Offset = "0x20")]
	public float Value;

	[Token(Token = "0x40004F0")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40004F1")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x40004F2")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x170000A9")]
	private Material material
	{
		[Token(Token = "0x6000424")]
		[Address(RVA = "0x69712C", Offset = "0x69712C", VA = "0x69712C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000425")]
	[Address(RVA = "0x6971F0", Offset = "0x6971F0", VA = "0x6971F0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000426")]
	[Address(RVA = "0x69726C", Offset = "0x69726C", VA = "0x69726C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000427")]
	[Address(RVA = "0x6974A8", Offset = "0x6974A8", VA = "0x6974A8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000428")]
	[Address(RVA = "0x6974AC", Offset = "0x6974AC", VA = "0x6974AC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000429")]
	[Address(RVA = "0x69755C", Offset = "0x69755C", VA = "0x69755C")]
	public CameraFilterPack_FX_Ascii()
	{
	}
}
