using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using Mono.Globalization.Unicode;
using Mono.Xml;
using UnityEngine;

[Token(Token = "0x2000134")]
public class MicControl : MonoBehaviour
{
	[Token(Token = "0x20001F5")]
	private sealed class _003CStart_003Ed__2 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D7C")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D7D")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D7E")]
		[FieldOffset(Offset = "0x20")]
		public MicControl _003C_003E4__this;

		[Token(Token = "0x17000242")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D43")]
			[Address(RVA = "0x78D094", Offset = "0x78D094", VA = "0x78D094", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000243")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D45")]
			[Address(RVA = "0x78D0FC", Offset = "0x78D0FC", VA = "0x78D0FC", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D40")]
		[Address(RVA = "0x78CF20", Offset = "0x78CF20", VA = "0x78CF20")]
		public _003CStart_003Ed__2(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D41")]
		[Address(RVA = "0x78CF4C", Offset = "0x78CF4C", VA = "0x78CF4C", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D42")]
		[Address(RVA = "0x78CF50", Offset = "0x78CF50", VA = "0x78CF50", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D44")]
		[Address(RVA = "0x78D09C", Offset = "0x78D09C", VA = "0x78D09C", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x20001F6")]
	private sealed class _003CDelayPlay_003Ed__12 : IDisposable, IContentHandler, IComparer<Contraction>
	{
		[Token(Token = "0x4000D7F")]
		[FieldOffset(Offset = "0x10")]
		private int _003C_003E1__state;

		[Token(Token = "0x4000D80")]
		[FieldOffset(Offset = "0x18")]
		private object _003C_003E2__current;

		[Token(Token = "0x4000D81")]
		[FieldOffset(Offset = "0x20")]
		public MicControl _003C_003E4__this;

		[Token(Token = "0x17000244")]
		private object System_002ECollections_002EGeneric_002EIEnumerator_003CSystem_002EObject_003E_002ECurrent
		{
			[Token(Token = "0x6000D49")]
			[Address(RVA = "0x78CEB0", Offset = "0x78CEB0", VA = "0x78CEB0", Slot = "4")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x17000245")]
		private object System_002ECollections_002EIEnumerator_002ECurrent
		{
			[Token(Token = "0x6000D4B")]
			[Address(RVA = "0x78CF18", Offset = "0x78CF18", VA = "0x78CF18", Slot = "7")]
			get
			{
				return null;
			}
		}

		[Token(Token = "0x6000D46")]
		[Address(RVA = "0x78CDC0", Offset = "0x78CDC0", VA = "0x78CDC0")]
		public _003CDelayPlay_003Ed__12(int _003C_003E1__state)
		{
		}

		[Token(Token = "0x6000D47")]
		[Address(RVA = "0x78CDEC", Offset = "0x78CDEC", VA = "0x78CDEC", Slot = "5")]
		private void System_002EIDisposable_002EDispose()
		{
		}

		[Token(Token = "0x6000D48")]
		[Address(RVA = "0x78CDF0", Offset = "0x78CDF0", VA = "0x78CDF0", Slot = "6")]
		private bool MoveNext()
		{
			return default(bool);
		}

		[Token(Token = "0x6000D4A")]
		[Address(RVA = "0x78CEB8", Offset = "0x78CEB8", VA = "0x78CEB8", Slot = "8")]
		private void System_002ECollections_002EIEnumerator_002EReset()
		{
		}
	}

	[Token(Token = "0x40008A9")]
	[FieldOffset(Offset = "0x18")]
	public bool AllowMic;

	[Token(Token = "0x40008AA")]
	[FieldOffset(Offset = "0x20")]
	private AudioSource audioSource;

	[Token(Token = "0x40008AB")]
	[FieldOffset(Offset = "0x28")]
	public SpinDial delayDial;

	[Token(Token = "0x40008AC")]
	[FieldOffset(Offset = "0x30")]
	public SpinDial volDial;

	[Token(Token = "0x40008AD")]
	[FieldOffset(Offset = "0x38")]
	private float lastdelay;

	[Token(Token = "0x40008AE")]
	[FieldOffset(Offset = "0x3C")]
	private float lastvol;

	[Token(Token = "0x40008AF")]
	[FieldOffset(Offset = "0x40")]
	public float MicDelay;

	[Token(Token = "0x40008B0")]
	[FieldOffset(Offset = "0x48")]
	private Coroutine crt1;

	[Token(Token = "0x40008B1")]
	[FieldOffset(Offset = "0x50")]
	private bool micIsOn;

	[Token(Token = "0x6000787")]
	[Address(RVA = "0x38E390", Offset = "0x38E390", VA = "0x38E390")]
	private IEnumerator Start()
	{
		return null;
	}

	[Token(Token = "0x6000788")]
	[Address(RVA = "0x38E400", Offset = "0x38E400", VA = "0x38E400")]
	public bool almostEqual(float a, float b)
	{
		return default(bool);
	}

	[Token(Token = "0x6000789")]
	[Address(RVA = "0x38E428", Offset = "0x38E428", VA = "0x38E428")]
	private void Update()
	{
	}

	[Token(Token = "0x600078A")]
	[Address(RVA = "0x38E5C8", Offset = "0x38E5C8", VA = "0x38E5C8")]
	private void findMicrophones()
	{
	}

	[Token(Token = "0x600078B")]
	[Address(RVA = "0x38E57C", Offset = "0x38E57C", VA = "0x38E57C")]
	private void UpdateMicDelayRoutine()
	{
	}

	[Token(Token = "0x600078C")]
	[Address(RVA = "0x38E6B0", Offset = "0x38E6B0", VA = "0x38E6B0")]
	private IEnumerator DelayPlay(float sec)
	{
		return null;
	}

	[Token(Token = "0x600078D")]
	[Address(RVA = "0x38E720", Offset = "0x38E720", VA = "0x38E720")]
	public void StartMic(bool MicOn)
	{
	}

	[Token(Token = "0x600078E")]
	[Address(RVA = "0x38E7CC", Offset = "0x38E7CC", VA = "0x38E7CC")]
	public MicControl()
	{
	}
}
