using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000040")]
public class CameraFilterPack_Blend2Camera_SplitScreen : MonoBehaviour
{
	[Token(Token = "0x400025F")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000260")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000261")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000262")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000263")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000264")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000265")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000266")]
	[FieldOffset(Offset = "0x48")]
	public float SplitX;

	[Token(Token = "0x4000267")]
	[FieldOffset(Offset = "0x4C")]
	public float SplitY;

	[Token(Token = "0x4000268")]
	[FieldOffset(Offset = "0x50")]
	public float Smooth;

	[Token(Token = "0x4000269")]
	[FieldOffset(Offset = "0x54")]
	public float Rotation;

	[Token(Token = "0x400026A")]
	[FieldOffset(Offset = "0x58")]
	private bool ForceYSwap;

	[Token(Token = "0x400026B")]
	[FieldOffset(Offset = "0x60")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x400026C")]
	[FieldOffset(Offset = "0x68")]
	private Vector2 ScreenSize;

	[Token(Token = "0x17000041")]
	private Material material
	{
		[Token(Token = "0x60001A9")]
		[Address(RVA = "0x662D28", Offset = "0x662D28", VA = "0x662D28")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001AA")]
	[Address(RVA = "0x662DEC", Offset = "0x662DEC", VA = "0x662DEC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60001AB")]
	[Address(RVA = "0x662E28", Offset = "0x662E28", VA = "0x662E28")]
	private void Start()
	{
	}

	[Token(Token = "0x60001AC")]
	[Address(RVA = "0x662F28", Offset = "0x662F28", VA = "0x662F28")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001AD")]
	[Address(RVA = "0x6631E8", Offset = "0x6631E8", VA = "0x6631E8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001AE")]
	[Address(RVA = "0x663224", Offset = "0x663224", VA = "0x663224")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60001AF")]
	[Address(RVA = "0x663228", Offset = "0x663228", VA = "0x663228")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001B0")]
	[Address(RVA = "0x663320", Offset = "0x663320", VA = "0x663320")]
	public CameraFilterPack_Blend2Camera_SplitScreen()
	{
	}
}
