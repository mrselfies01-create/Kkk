using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000042")]
public class CameraFilterPack_Blend2Camera_Subtract : MonoBehaviour
{
	[Token(Token = "0x400027E")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x400027F")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000280")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000281")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000282")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000283")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000284")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000285")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000043")]
	private Material material
	{
		[Token(Token = "0x60001B9")]
		[Address(RVA = "0x663AB0", Offset = "0x663AB0", VA = "0x663AB0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001BA")]
	[Address(RVA = "0x663B74", Offset = "0x663B74", VA = "0x663B74")]
	private void Start()
	{
	}

	[Token(Token = "0x60001BB")]
	[Address(RVA = "0x663C8C", Offset = "0x663C8C", VA = "0x663C8C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001BC")]
	[Address(RVA = "0x663F1C", Offset = "0x663F1C", VA = "0x663F1C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60001BD")]
	[Address(RVA = "0x664008", Offset = "0x664008", VA = "0x664008")]
	private void Update()
	{
	}

	[Token(Token = "0x60001BE")]
	[Address(RVA = "0x66400C", Offset = "0x66400C", VA = "0x66400C")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60001BF")]
	[Address(RVA = "0x6640F8", Offset = "0x6640F8", VA = "0x6640F8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001C0")]
	[Address(RVA = "0x6641F0", Offset = "0x6641F0", VA = "0x6641F0")]
	public CameraFilterPack_Blend2Camera_Subtract()
	{
	}
}
