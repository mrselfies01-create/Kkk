using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E2")]
public class CameraFilterPack_NewGlitch1 : MonoBehaviour
{
	[Token(Token = "0x400068E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400068F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000690")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000691")]
	[FieldOffset(Offset = "0x30")]
	public float _Seed;

	[Token(Token = "0x4000692")]
	[FieldOffset(Offset = "0x34")]
	public float _Size;

	[Token(Token = "0x170000E3")]
	private Material material
	{
		[Token(Token = "0x600059C")]
		[Address(RVA = "0x62A000", Offset = "0x62A000", VA = "0x62A000")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600059D")]
	[Address(RVA = "0x62A0C4", Offset = "0x62A0C4", VA = "0x62A0C4")]
	private void Start()
	{
	}

	[Token(Token = "0x600059E")]
	[Address(RVA = "0x62A140", Offset = "0x62A140", VA = "0x62A140")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600059F")]
	[Address(RVA = "0x62A37C", Offset = "0x62A37C", VA = "0x62A37C")]
	private void Update()
	{
	}

	[Token(Token = "0x60005A0")]
	[Address(RVA = "0x62A380", Offset = "0x62A380", VA = "0x62A380")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005A1")]
	[Address(RVA = "0x62A430", Offset = "0x62A430", VA = "0x62A430")]
	public CameraFilterPack_NewGlitch1()
	{
	}
}
