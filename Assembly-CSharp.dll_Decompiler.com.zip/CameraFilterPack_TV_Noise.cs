using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200010F")]
public class CameraFilterPack_TV_Noise : MonoBehaviour
{
	[Token(Token = "0x40007C6")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007C7")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40007C8")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40007C9")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x17000110")]
	private Material material
	{
		[Token(Token = "0x60006B1")]
		[Address(RVA = "0x637DD4", Offset = "0x637DD4", VA = "0x637DD4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006B2")]
	[Address(RVA = "0x637E98", Offset = "0x637E98", VA = "0x637E98")]
	private void Start()
	{
	}

	[Token(Token = "0x60006B3")]
	[Address(RVA = "0x637F14", Offset = "0x637F14", VA = "0x637F14")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006B4")]
	[Address(RVA = "0x63812C", Offset = "0x63812C", VA = "0x63812C")]
	private void Update()
	{
	}

	[Token(Token = "0x60006B5")]
	[Address(RVA = "0x638130", Offset = "0x638130", VA = "0x638130")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006B6")]
	[Address(RVA = "0x6381E0", Offset = "0x6381E0", VA = "0x6381E0")]
	public CameraFilterPack_TV_Noise()
	{
	}
}
