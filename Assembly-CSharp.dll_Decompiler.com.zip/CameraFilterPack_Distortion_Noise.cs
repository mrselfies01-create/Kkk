using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200007D")]
public class CameraFilterPack_Distortion_Noise : MonoBehaviour
{
	[Token(Token = "0x40003E1")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003E2")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003E3")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003E4")]
	[FieldOffset(Offset = "0x30")]
	public float Distortion;

	[Token(Token = "0x1700007E")]
	private Material material
	{
		[Token(Token = "0x6000321")]
		[Address(RVA = "0x67526C", Offset = "0x67526C", VA = "0x67526C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000322")]
	[Address(RVA = "0x675330", Offset = "0x675330", VA = "0x675330")]
	private void Start()
	{
	}

	[Token(Token = "0x6000323")]
	[Address(RVA = "0x6753AC", Offset = "0x6753AC", VA = "0x6753AC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000324")]
	[Address(RVA = "0x6755B4", Offset = "0x6755B4", VA = "0x6755B4")]
	private void Update()
	{
	}

	[Token(Token = "0x6000325")]
	[Address(RVA = "0x6755B8", Offset = "0x6755B8", VA = "0x6755B8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000326")]
	[Address(RVA = "0x675668", Offset = "0x675668", VA = "0x675668")]
	public CameraFilterPack_Distortion_Noise()
	{
	}
}
