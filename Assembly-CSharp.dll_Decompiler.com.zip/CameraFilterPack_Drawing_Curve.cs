using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000089")]
public class CameraFilterPack_Drawing_Curve : MonoBehaviour
{
	[Token(Token = "0x400042C")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400042D")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400042E")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400042F")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x1700008A")]
	private Material material
	{
		[Token(Token = "0x6000369")]
		[Address(RVA = "0x678758", Offset = "0x678758", VA = "0x678758")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600036A")]
	[Address(RVA = "0x67881C", Offset = "0x67881C", VA = "0x67881C")]
	private void Start()
	{
	}

	[Token(Token = "0x600036B")]
	[Address(RVA = "0x678898", Offset = "0x678898", VA = "0x678898")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600036C")]
	[Address(RVA = "0x678AB0", Offset = "0x678AB0", VA = "0x678AB0")]
	private void Update()
	{
	}

	[Token(Token = "0x600036D")]
	[Address(RVA = "0x678AB4", Offset = "0x678AB4", VA = "0x678AB4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600036E")]
	[Address(RVA = "0x678B64", Offset = "0x678B64", VA = "0x678B64")]
	public CameraFilterPack_Drawing_Curve()
	{
	}
}
