using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000C7")]
public class CameraFilterPack_Glasses_On_4 : MonoBehaviour
{
	[Token(Token = "0x40005B3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40005B4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40005B5")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x40005B6")]
	[FieldOffset(Offset = "0x28")]
	public float VisionBlur;

	[Token(Token = "0x40005B7")]
	[FieldOffset(Offset = "0x2C")]
	public Color GlassesColor;

	[Token(Token = "0x40005B8")]
	[FieldOffset(Offset = "0x3C")]
	public Color GlassesColor2;

	[Token(Token = "0x40005B9")]
	[FieldOffset(Offset = "0x4C")]
	public float GlassDistortion;

	[Token(Token = "0x40005BA")]
	[FieldOffset(Offset = "0x50")]
	public float GlassAberration;

	[Token(Token = "0x40005BB")]
	[FieldOffset(Offset = "0x54")]
	public float UseFinalGlassColor;

	[Token(Token = "0x40005BC")]
	[FieldOffset(Offset = "0x58")]
	public float UseScanLine;

	[Token(Token = "0x40005BD")]
	[FieldOffset(Offset = "0x5C")]
	public float UseScanLineSize;

	[Token(Token = "0x40005BE")]
	[FieldOffset(Offset = "0x60")]
	public Color GlassColor;

	[Token(Token = "0x40005BF")]
	[FieldOffset(Offset = "0x70")]
	private Material SCMaterial;

	[Token(Token = "0x40005C0")]
	[FieldOffset(Offset = "0x78")]
	private Texture2D Texture2;

	[Token(Token = "0x170000C8")]
	private Material material
	{
		[Token(Token = "0x60004DE")]
		[Address(RVA = "0x69FCFC", Offset = "0x69FCFC", VA = "0x69FCFC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004DF")]
	[Address(RVA = "0x69FDC0", Offset = "0x69FDC0", VA = "0x69FDC0")]
	private void Start()
	{
	}

	[Token(Token = "0x60004E0")]
	[Address(RVA = "0x69FE78", Offset = "0x69FE78", VA = "0x69FE78")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004E1")]
	[Address(RVA = "0x6A0170", Offset = "0x6A0170", VA = "0x6A0170")]
	private void Update()
	{
	}

	[Token(Token = "0x60004E2")]
	[Address(RVA = "0x6A0174", Offset = "0x6A0174", VA = "0x6A0174")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004E3")]
	[Address(RVA = "0x6A0224", Offset = "0x6A0224", VA = "0x6A0224")]
	public CameraFilterPack_Glasses_On_4()
	{
	}
}
