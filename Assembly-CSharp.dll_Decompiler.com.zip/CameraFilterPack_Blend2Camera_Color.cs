using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000026")]
public class CameraFilterPack_Blend2Camera_Color : MonoBehaviour
{
	[Token(Token = "0x4000180")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000181")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000182")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000183")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000184")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000185")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000186")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000187")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000027")]
	private Material material
	{
		[Token(Token = "0x60000DA")]
		[Address(RVA = "0x5BDD90", Offset = "0x5BDD90", VA = "0x5BDD90")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000DB")]
	[Address(RVA = "0x5BDE54", Offset = "0x5BDE54", VA = "0x5BDE54")]
	private void Start()
	{
	}

	[Token(Token = "0x60000DC")]
	[Address(RVA = "0x5BDF6C", Offset = "0x5BDF6C", VA = "0x5BDF6C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000DD")]
	[Address(RVA = "0x5BE1FC", Offset = "0x5BE1FC", VA = "0x5BE1FC")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000DE")]
	[Address(RVA = "0x5BE2E8", Offset = "0x5BE2E8", VA = "0x5BE2E8")]
	private void Update()
	{
	}

	[Token(Token = "0x60000DF")]
	[Address(RVA = "0x5BE2EC", Offset = "0x5BE2EC", VA = "0x5BE2EC")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000E0")]
	[Address(RVA = "0x5BE3D8", Offset = "0x5BE3D8", VA = "0x5BE3D8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000E1")]
	[Address(RVA = "0x5BE4D0", Offset = "0x5BE4D0", VA = "0x5BE4D0")]
	public CameraFilterPack_Blend2Camera_Color()
	{
	}
}
