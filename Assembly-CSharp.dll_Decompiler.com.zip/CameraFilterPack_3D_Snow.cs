using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000014")]
public class CameraFilterPack_3D_Snow : MonoBehaviour
{
	[Token(Token = "0x40000BD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000BE")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x40000BF")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x40000C0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40000C1")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x40000C2")]
	[FieldOffset(Offset = "0x34")]
	public float Snow_Near;

	[Token(Token = "0x40000C3")]
	[FieldOffset(Offset = "0x38")]
	public float Snow_Far;

	[Token(Token = "0x40000C4")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x40000C5")]
	[FieldOffset(Offset = "0x40")]
	public float Intensity;

	[Token(Token = "0x40000C6")]
	[FieldOffset(Offset = "0x44")]
	public float Size;

	[Token(Token = "0x40000C7")]
	[FieldOffset(Offset = "0x48")]
	public float Speed;

	[Token(Token = "0x40000C8")]
	[FieldOffset(Offset = "0x4C")]
	public float SnowWithoutObject;

	[Token(Token = "0x40000C9")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x17000015")]
	private Material material
	{
		[Token(Token = "0x600006A")]
		[Address(RVA = "0x5B7834", Offset = "0x5B7834", VA = "0x5B7834")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600006B")]
	[Address(RVA = "0x5B78F8", Offset = "0x5B78F8", VA = "0x5B78F8")]
	private void Start()
	{
	}

	[Token(Token = "0x600006C")]
	[Address(RVA = "0x5B79B0", Offset = "0x5B79B0", VA = "0x5B79B0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600006D")]
	[Address(RVA = "0x5B7D48", Offset = "0x5B7D48", VA = "0x5B7D48")]
	private void Update()
	{
	}

	[Token(Token = "0x600006E")]
	[Address(RVA = "0x5B7D4C", Offset = "0x5B7D4C", VA = "0x5B7D4C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600006F")]
	[Address(RVA = "0x5B7DFC", Offset = "0x5B7DFC", VA = "0x5B7DFC")]
	public CameraFilterPack_3D_Snow()
	{
	}
}
