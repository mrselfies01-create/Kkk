using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000017")]
public class CameraFilterPack_AAA_Blood_Hit : MonoBehaviour
{
	[Token(Token = "0x40000DD")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000DE")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40000DF")]
	[FieldOffset(Offset = "0x24")]
	public float Hit_Left;

	[Token(Token = "0x40000E0")]
	[FieldOffset(Offset = "0x28")]
	public float Hit_Up;

	[Token(Token = "0x40000E1")]
	[FieldOffset(Offset = "0x2C")]
	public float Hit_Right;

	[Token(Token = "0x40000E2")]
	[FieldOffset(Offset = "0x30")]
	public float Hit_Down;

	[Token(Token = "0x40000E3")]
	[FieldOffset(Offset = "0x34")]
	public float Blood_Hit_Left;

	[Token(Token = "0x40000E4")]
	[FieldOffset(Offset = "0x38")]
	public float Blood_Hit_Up;

	[Token(Token = "0x40000E5")]
	[FieldOffset(Offset = "0x3C")]
	public float Blood_Hit_Right;

	[Token(Token = "0x40000E6")]
	[FieldOffset(Offset = "0x40")]
	public float Blood_Hit_Down;

	[Token(Token = "0x40000E7")]
	[FieldOffset(Offset = "0x44")]
	public float Hit_Full;

	[Token(Token = "0x40000E8")]
	[FieldOffset(Offset = "0x48")]
	public float Blood_Hit_Full_1;

	[Token(Token = "0x40000E9")]
	[FieldOffset(Offset = "0x4C")]
	public float Blood_Hit_Full_2;

	[Token(Token = "0x40000EA")]
	[FieldOffset(Offset = "0x50")]
	public float Blood_Hit_Full_3;

	[Token(Token = "0x40000EB")]
	[FieldOffset(Offset = "0x54")]
	public float LightReflect;

	[Token(Token = "0x40000EC")]
	[FieldOffset(Offset = "0x58")]
	private Material SCMaterial;

	[Token(Token = "0x40000ED")]
	[FieldOffset(Offset = "0x60")]
	private Texture2D Texture2;

	[Token(Token = "0x17000018")]
	private Material material
	{
		[Token(Token = "0x600007C")]
		[Address(RVA = "0x5B8824", Offset = "0x5B8824", VA = "0x5B8824")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600007D")]
	[Address(RVA = "0x5B88E8", Offset = "0x5B88E8", VA = "0x5B88E8")]
	private void Start()
	{
	}

	[Token(Token = "0x600007E")]
	[Address(RVA = "0x5B89A0", Offset = "0x5B89A0", VA = "0x5B89A0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600007F")]
	[Address(RVA = "0x5B8E40", Offset = "0x5B8E40", VA = "0x5B8E40")]
	private void Update()
	{
	}

	[Token(Token = "0x6000080")]
	[Address(RVA = "0x5B8E44", Offset = "0x5B8E44", VA = "0x5B8E44")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000081")]
	[Address(RVA = "0x5B8EF4", Offset = "0x5B8EF4", VA = "0x5B8EF4")]
	public CameraFilterPack_AAA_Blood_Hit()
	{
	}
}
