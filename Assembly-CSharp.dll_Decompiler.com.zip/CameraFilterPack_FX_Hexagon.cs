using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B5")]
public class CameraFilterPack_FX_Hexagon : MonoBehaviour
{
	[Token(Token = "0x400053F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000540")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000541")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x170000B6")]
	private Material material
	{
		[Token(Token = "0x6000472")]
		[Address(RVA = "0x69AA8C", Offset = "0x69AA8C", VA = "0x69AA8C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000473")]
	[Address(RVA = "0x69AB50", Offset = "0x69AB50", VA = "0x69AB50")]
	private void Start()
	{
	}

	[Token(Token = "0x6000474")]
	[Address(RVA = "0x69ABCC", Offset = "0x69ABCC", VA = "0x69ABCC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000475")]
	[Address(RVA = "0x69ADC0", Offset = "0x69ADC0", VA = "0x69ADC0")]
	private void Update()
	{
	}

	[Token(Token = "0x6000476")]
	[Address(RVA = "0x69ADC4", Offset = "0x69ADC4", VA = "0x69ADC4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000477")]
	[Address(RVA = "0x69AE74", Offset = "0x69AE74", VA = "0x69AE74")]
	public CameraFilterPack_FX_Hexagon()
	{
	}
}
