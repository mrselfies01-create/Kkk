using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000082")]
public class CameraFilterPack_Distortion_Water_Drop : MonoBehaviour
{
	[Token(Token = "0x4000401")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000402")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000403")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000404")]
	[FieldOffset(Offset = "0x30")]
	public float CenterX;

	[Token(Token = "0x4000405")]
	[FieldOffset(Offset = "0x34")]
	public float CenterY;

	[Token(Token = "0x4000406")]
	[FieldOffset(Offset = "0x38")]
	public float WaveIntensity;

	[Token(Token = "0x4000407")]
	[FieldOffset(Offset = "0x3C")]
	public int NumberOfWaves;

	[Token(Token = "0x17000083")]
	private Material material
	{
		[Token(Token = "0x600033F")]
		[Address(RVA = "0x6768AC", Offset = "0x6768AC", VA = "0x6768AC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000340")]
	[Address(RVA = "0x676970", Offset = "0x676970", VA = "0x676970")]
	private void Start()
	{
	}

	[Token(Token = "0x6000341")]
	[Address(RVA = "0x6769EC", Offset = "0x6769EC", VA = "0x6769EC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000342")]
	[Address(RVA = "0x676C60", Offset = "0x676C60", VA = "0x676C60")]
	private void Update()
	{
	}

	[Token(Token = "0x6000343")]
	[Address(RVA = "0x676C64", Offset = "0x676C64", VA = "0x676C64")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000344")]
	[Address(RVA = "0x676D14", Offset = "0x676D14", VA = "0x676D14")]
	public CameraFilterPack_Distortion_Water_Drop()
	{
	}
}
