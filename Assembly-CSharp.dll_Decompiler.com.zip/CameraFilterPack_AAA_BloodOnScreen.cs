using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000016")]
public class CameraFilterPack_AAA_BloodOnScreen : MonoBehaviour
{
	[Token(Token = "0x40000D3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40000D4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40000D5")]
	[FieldOffset(Offset = "0x24")]
	public float Blood_On_Screen;

	[Token(Token = "0x40000D6")]
	[FieldOffset(Offset = "0x28")]
	public Color Blood_Color;

	[Token(Token = "0x40000D7")]
	[FieldOffset(Offset = "0x38")]
	public float Blood_Intensify;

	[Token(Token = "0x40000D8")]
	[FieldOffset(Offset = "0x3C")]
	public float Blood_Darkness;

	[Token(Token = "0x40000D9")]
	[FieldOffset(Offset = "0x40")]
	public float Blood_Distortion_Speed;

	[Token(Token = "0x40000DA")]
	[FieldOffset(Offset = "0x44")]
	public float Blood_Fade;

	[Token(Token = "0x40000DB")]
	[FieldOffset(Offset = "0x48")]
	private Material SCMaterial;

	[Token(Token = "0x40000DC")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x17000017")]
	private Material material
	{
		[Token(Token = "0x6000076")]
		[Address(RVA = "0x5B82A4", Offset = "0x5B82A4", VA = "0x5B82A4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000077")]
	[Address(RVA = "0x5B8368", Offset = "0x5B8368", VA = "0x5B8368")]
	private void Start()
	{
	}

	[Token(Token = "0x6000078")]
	[Address(RVA = "0x5B8420", Offset = "0x5B8420", VA = "0x5B8420")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000079")]
	[Address(RVA = "0x5B8728", Offset = "0x5B8728", VA = "0x5B8728")]
	private void Update()
	{
	}

	[Token(Token = "0x600007A")]
	[Address(RVA = "0x5B872C", Offset = "0x5B872C", VA = "0x5B872C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600007B")]
	[Address(RVA = "0x5B87DC", Offset = "0x5B87DC", VA = "0x5B87DC")]
	public CameraFilterPack_AAA_BloodOnScreen()
	{
	}
}
