using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BD")]
public class CameraFilterPack_FX_Screens : MonoBehaviour
{
	[Token(Token = "0x4000562")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000563")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000564")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000565")]
	[FieldOffset(Offset = "0x30")]
	public float Tiles;

	[Token(Token = "0x4000566")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000567")]
	[FieldOffset(Offset = "0x38")]
	public Color color;

	[Token(Token = "0x4000568")]
	[FieldOffset(Offset = "0x48")]
	public float PosX;

	[Token(Token = "0x4000569")]
	[FieldOffset(Offset = "0x4C")]
	public float PosY;

	[Token(Token = "0x170000BE")]
	private Material material
	{
		[Token(Token = "0x60004A2")]
		[Address(RVA = "0x69CB68", Offset = "0x69CB68", VA = "0x69CB68")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004A3")]
	[Address(RVA = "0x69CC2C", Offset = "0x69CC2C", VA = "0x69CC2C")]
	private void Start()
	{
	}

	[Token(Token = "0x60004A4")]
	[Address(RVA = "0x69CCA8", Offset = "0x69CCA8", VA = "0x69CCA8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004A5")]
	[Address(RVA = "0x69CF54", Offset = "0x69CF54", VA = "0x69CF54")]
	private void Update()
	{
	}

	[Token(Token = "0x60004A6")]
	[Address(RVA = "0x69CF58", Offset = "0x69CF58", VA = "0x69CF58")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004A7")]
	[Address(RVA = "0x69D008", Offset = "0x69D008", VA = "0x69D008")]
	public CameraFilterPack_FX_Screens()
	{
	}
}
