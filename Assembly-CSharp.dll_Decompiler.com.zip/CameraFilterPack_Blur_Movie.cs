using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200004C")]
public class CameraFilterPack_Blur_Movie : MonoBehaviour
{
	[Token(Token = "0x40002BE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002BF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002C0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002C1")]
	[FieldOffset(Offset = "0x30")]
	public float Radius;

	[Token(Token = "0x40002C2")]
	[FieldOffset(Offset = "0x34")]
	public float Factor;

	[Token(Token = "0x40002C3")]
	[FieldOffset(Offset = "0x38")]
	public int FastFilter;

	[Token(Token = "0x1700004D")]
	private Material material
	{
		[Token(Token = "0x60001F9")]
		[Address(RVA = "0x666EB8", Offset = "0x666EB8", VA = "0x666EB8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001FA")]
	[Address(RVA = "0x666F7C", Offset = "0x666F7C", VA = "0x666F7C")]
	private void Start()
	{
	}

	[Token(Token = "0x60001FB")]
	[Address(RVA = "0x666FF8", Offset = "0x666FF8", VA = "0x666FF8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001FC")]
	[Address(RVA = "0x6672F8", Offset = "0x6672F8", VA = "0x6672F8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001FD")]
	[Address(RVA = "0x6672FC", Offset = "0x6672FC", VA = "0x6672FC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001FE")]
	[Address(RVA = "0x6673AC", Offset = "0x6673AC", VA = "0x6673AC")]
	public CameraFilterPack_Blur_Movie()
	{
	}
}
