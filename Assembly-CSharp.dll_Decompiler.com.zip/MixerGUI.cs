using System;
using System.Collections.Generic;
using Audial;
using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000004")]
public class MixerGUI : MonoBehaviour
{
	[Serializable]
	[Token(Token = "0x20001EF")]
	private sealed class _003C_003Ec
	{
		[Token(Token = "0x4000D2C")]
		[FieldOffset(Offset = "0x0")]
		public static readonly _003C_003Ec _003C_003E9;

		[Token(Token = "0x4000D2D")]
		[FieldOffset(Offset = "0x8")]
		public static Action<MonoBehaviour> _003C_003E9__9_0;

		[Token(Token = "0x4000D2E")]
		[FieldOffset(Offset = "0x10")]
		public static Action<MonoBehaviour> _003C_003E9__10_0;

		[Token(Token = "0x6000D31")]
		[Address(RVA = "0x78D168", Offset = "0x78D168", VA = "0x78D168")]
		public _003C_003Ec()
		{
		}

		[Token(Token = "0x6000D32")]
		[Address(RVA = "0x78D170", Offset = "0x78D170", VA = "0x78D170")]
		internal void _003CDrawInstrument_003Eb__9_0(MonoBehaviour component)
		{
		}

		[Token(Token = "0x6000D33")]
		[Address(RVA = "0x78D1B0", Offset = "0x78D1B0", VA = "0x78D1B0")]
		internal void _003COnGUI_003Eb__10_0(MonoBehaviour component)
		{
		}
	}

	[Token(Token = "0x4000003")]
	[FieldOffset(Offset = "0x18")]
	private GameObject drums;

	[Token(Token = "0x4000004")]
	[FieldOffset(Offset = "0x20")]
	private GameObject bass;

	[Token(Token = "0x4000005")]
	[FieldOffset(Offset = "0x28")]
	private GameObject piano;

	[Token(Token = "0x4000006")]
	[FieldOffset(Offset = "0x30")]
	private GameObject master;

	[Token(Token = "0x4000007")]
	[FieldOffset(Offset = "0x38")]
	private Fader[] faders;

	[Token(Token = "0x4000008")]
	[FieldOffset(Offset = "0x40")]
	private Crusher masterCrusher;

	[Token(Token = "0x4000009")]
	[FieldOffset(Offset = "0x48")]
	private List<MonoBehaviour>[] audialComponents;

	[Token(Token = "0x6000005")]
	[Address(RVA = "0x38E908", Offset = "0x38E908", VA = "0x38E908")]
	private void Awake()
	{
	}

	[Token(Token = "0x6000006")]
	[Address(RVA = "0x38F120", Offset = "0x38F120", VA = "0x38F120")]
	private void Update()
	{
	}

	[Token(Token = "0x6000007")]
	[Address(RVA = "0x38F124", Offset = "0x38F124", VA = "0x38F124")]
	private void DrawInstrument(string name, int index)
	{
	}

	[Token(Token = "0x6000008")]
	[Address(RVA = "0x38F808", Offset = "0x38F808", VA = "0x38F808")]
	private void OnGUI()
	{
	}

	[Token(Token = "0x6000009")]
	[Address(RVA = "0x390318", Offset = "0x390318", VA = "0x390318")]
	public MixerGUI()
	{
	}
}
