using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D1")]
public class CameraFilterPack_Gradients_Hue : MonoBehaviour
{
	[Token(Token = "0x400060D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400060E")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x400060F")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x4000610")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x4000611")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x4000612")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D2")]
	private Material material
	{
		[Token(Token = "0x600051A")]
		[Address(RVA = "0x6A3318", Offset = "0x6A3318", VA = "0x6A3318")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600051B")]
	[Address(RVA = "0x6A33DC", Offset = "0x6A33DC", VA = "0x6A33DC")]
	private void Start()
	{
	}

	[Token(Token = "0x600051C")]
	[Address(RVA = "0x6A342C", Offset = "0x6A342C", VA = "0x6A342C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600051D")]
	[Address(RVA = "0x6A3668", Offset = "0x6A3668", VA = "0x6A3668")]
	private void Update()
	{
	}

	[Token(Token = "0x600051E")]
	[Address(RVA = "0x6A366C", Offset = "0x6A366C", VA = "0x6A366C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600051F")]
	[Address(RVA = "0x6A371C", Offset = "0x6A371C", VA = "0x6A371C")]
	public CameraFilterPack_Gradients_Hue()
	{
	}
}
