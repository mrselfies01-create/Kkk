using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000027")]
public class CameraFilterPack_Blend2Camera_ColorBurn : MonoBehaviour
{
	[Token(Token = "0x4000188")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000189")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x400018A")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x400018B")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400018C")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400018D")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400018E")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400018F")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000028")]
	private Material material
	{
		[Token(Token = "0x60000E2")]
		[Address(RVA = "0x5BE538", Offset = "0x5BE538", VA = "0x5BE538")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000E3")]
	[Address(RVA = "0x5BE5FC", Offset = "0x5BE5FC", VA = "0x5BE5FC")]
	private void Start()
	{
	}

	[Token(Token = "0x60000E4")]
	[Address(RVA = "0x5BE714", Offset = "0x5BE714", VA = "0x5BE714")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000E5")]
	[Address(RVA = "0x5BE9A4", Offset = "0x5BE9A4", VA = "0x5BE9A4")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000E6")]
	[Address(RVA = "0x5BEA90", Offset = "0x5BEA90", VA = "0x5BEA90")]
	private void Update()
	{
	}

	[Token(Token = "0x60000E7")]
	[Address(RVA = "0x5BEA94", Offset = "0x5BEA94", VA = "0x5BEA94")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000E8")]
	[Address(RVA = "0x5BEB80", Offset = "0x5BEB80", VA = "0x5BEB80")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000E9")]
	[Address(RVA = "0x5BEC78", Offset = "0x5BEC78", VA = "0x5BEC78")]
	public CameraFilterPack_Blend2Camera_ColorBurn()
	{
	}
}
