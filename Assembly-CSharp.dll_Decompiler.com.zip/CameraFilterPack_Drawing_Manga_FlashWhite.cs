using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000095")]
public class CameraFilterPack_Drawing_Manga_FlashWhite : MonoBehaviour
{
	[Token(Token = "0x400046B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400046C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400046D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400046E")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400046F")]
	[FieldOffset(Offset = "0x34")]
	public int Speed;

	[Token(Token = "0x4000470")]
	[FieldOffset(Offset = "0x38")]
	public float PosX;

	[Token(Token = "0x4000471")]
	[FieldOffset(Offset = "0x3C")]
	public float PosY;

	[Token(Token = "0x4000472")]
	[FieldOffset(Offset = "0x40")]
	public float Intensity;

	[Token(Token = "0x17000096")]
	private Material material
	{
		[Token(Token = "0x60003B1")]
		[Address(RVA = "0x691B4C", Offset = "0x691B4C", VA = "0x691B4C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003B2")]
	[Address(RVA = "0x691C10", Offset = "0x691C10", VA = "0x691C10")]
	private void Start()
	{
	}

	[Token(Token = "0x60003B3")]
	[Address(RVA = "0x691C8C", Offset = "0x691C8C", VA = "0x691C8C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003B4")]
	[Address(RVA = "0x691F38", Offset = "0x691F38", VA = "0x691F38")]
	private void Update()
	{
	}

	[Token(Token = "0x60003B5")]
	[Address(RVA = "0x691F3C", Offset = "0x691F3C", VA = "0x691F3C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003B6")]
	[Address(RVA = "0x691FEC", Offset = "0x691FEC", VA = "0x691FEC")]
	public CameraFilterPack_Drawing_Manga_FlashWhite()
	{
	}
}
