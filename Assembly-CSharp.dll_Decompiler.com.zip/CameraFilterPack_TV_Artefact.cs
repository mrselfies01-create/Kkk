using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000105")]
public class CameraFilterPack_TV_Artefact : MonoBehaviour
{
	[Token(Token = "0x4000780")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000781")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000782")]
	[FieldOffset(Offset = "0x24")]
	public float Fade;

	[Token(Token = "0x4000783")]
	[FieldOffset(Offset = "0x28")]
	public float Colorisation;

	[Token(Token = "0x4000784")]
	[FieldOffset(Offset = "0x2C")]
	public float Parasite;

	[Token(Token = "0x4000785")]
	[FieldOffset(Offset = "0x30")]
	public float Noise;

	[Token(Token = "0x4000786")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x17000106")]
	private Material material
	{
		[Token(Token = "0x6000675")]
		[Address(RVA = "0x634F90", Offset = "0x634F90", VA = "0x634F90")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000676")]
	[Address(RVA = "0x635054", Offset = "0x635054", VA = "0x635054")]
	private void Start()
	{
	}

	[Token(Token = "0x6000677")]
	[Address(RVA = "0x6350D0", Offset = "0x6350D0", VA = "0x6350D0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000678")]
	[Address(RVA = "0x635354", Offset = "0x635354", VA = "0x635354")]
	private void Update()
	{
	}

	[Token(Token = "0x6000679")]
	[Address(RVA = "0x635358", Offset = "0x635358", VA = "0x635358")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600067A")]
	[Address(RVA = "0x635408", Offset = "0x635408", VA = "0x635408")]
	public CameraFilterPack_TV_Artefact()
	{
	}
}
