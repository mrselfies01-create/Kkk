using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000046")]
public class CameraFilterPack_Blur_BlurHole : MonoBehaviour
{
	[Token(Token = "0x400029A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400029B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400029C")]
	[FieldOffset(Offset = "0x24")]
	public float Size;

	[Token(Token = "0x400029D")]
	[FieldOffset(Offset = "0x28")]
	public float _Radius;

	[Token(Token = "0x400029E")]
	[FieldOffset(Offset = "0x2C")]
	public float _SpotSize;

	[Token(Token = "0x400029F")]
	[FieldOffset(Offset = "0x30")]
	public float _CenterX;

	[Token(Token = "0x40002A0")]
	[FieldOffset(Offset = "0x34")]
	public float _CenterY;

	[Token(Token = "0x40002A1")]
	[FieldOffset(Offset = "0x38")]
	public float _AlphaBlur;

	[Token(Token = "0x40002A2")]
	[FieldOffset(Offset = "0x3C")]
	public float _AlphaBlurInside;

	[Token(Token = "0x40002A3")]
	[FieldOffset(Offset = "0x40")]
	private Material SCMaterial;

	[Token(Token = "0x17000047")]
	private Material material
	{
		[Token(Token = "0x60001D5")]
		[Address(RVA = "0x66526C", Offset = "0x66526C", VA = "0x66526C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001D6")]
	[Address(RVA = "0x665330", Offset = "0x665330", VA = "0x665330")]
	private void Start()
	{
	}

	[Token(Token = "0x60001D7")]
	[Address(RVA = "0x6653AC", Offset = "0x6653AC", VA = "0x6653AC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001D8")]
	[Address(RVA = "0x66568C", Offset = "0x66568C", VA = "0x66568C")]
	private void Update()
	{
	}

	[Token(Token = "0x60001D9")]
	[Address(RVA = "0x665690", Offset = "0x665690", VA = "0x665690")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001DA")]
	[Address(RVA = "0x665740", Offset = "0x665740", VA = "0x665740")]
	public CameraFilterPack_Blur_BlurHole()
	{
	}
}
