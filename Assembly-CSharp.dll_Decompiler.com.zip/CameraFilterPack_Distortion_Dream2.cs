using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000076")]
public class CameraFilterPack_Distortion_Dream2 : MonoBehaviour
{
	[Token(Token = "0x40003BE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003BF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003C0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003C1")]
	[FieldOffset(Offset = "0x30")]
	public float Distortion;

	[Token(Token = "0x40003C2")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x17000077")]
	private Material material
	{
		[Token(Token = "0x60002F7")]
		[Address(RVA = "0x6734C4", Offset = "0x6734C4", VA = "0x6734C4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002F8")]
	[Address(RVA = "0x673588", Offset = "0x673588", VA = "0x673588")]
	private void Start()
	{
	}

	[Token(Token = "0x60002F9")]
	[Address(RVA = "0x673604", Offset = "0x673604", VA = "0x673604")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002FA")]
	[Address(RVA = "0x673840", Offset = "0x673840", VA = "0x673840")]
	private void Update()
	{
	}

	[Token(Token = "0x60002FB")]
	[Address(RVA = "0x673844", Offset = "0x673844", VA = "0x673844")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002FC")]
	[Address(RVA = "0x6738F4", Offset = "0x6738F4", VA = "0x6738F4")]
	public CameraFilterPack_Distortion_Dream2()
	{
	}
}
