using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000066")]
public class CameraFilterPack_Colors_Adjust_FullColors : MonoBehaviour
{
	[Token(Token = "0x4000359")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400035A")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400035B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400035C")]
	[FieldOffset(Offset = "0x30")]
	public float Red_R;

	[Token(Token = "0x400035D")]
	[FieldOffset(Offset = "0x34")]
	public float Red_G;

	[Token(Token = "0x400035E")]
	[FieldOffset(Offset = "0x38")]
	public float Red_B;

	[Token(Token = "0x400035F")]
	[FieldOffset(Offset = "0x3C")]
	public float Red_Constant;

	[Token(Token = "0x4000360")]
	[FieldOffset(Offset = "0x40")]
	public float Green_R;

	[Token(Token = "0x4000361")]
	[FieldOffset(Offset = "0x44")]
	public float Green_G;

	[Token(Token = "0x4000362")]
	[FieldOffset(Offset = "0x48")]
	public float Green_B;

	[Token(Token = "0x4000363")]
	[FieldOffset(Offset = "0x4C")]
	public float Green_Constant;

	[Token(Token = "0x4000364")]
	[FieldOffset(Offset = "0x50")]
	public float Blue_R;

	[Token(Token = "0x4000365")]
	[FieldOffset(Offset = "0x54")]
	public float Blue_G;

	[Token(Token = "0x4000366")]
	[FieldOffset(Offset = "0x58")]
	public float Blue_B;

	[Token(Token = "0x4000367")]
	[FieldOffset(Offset = "0x5C")]
	public float Blue_Constant;

	[Token(Token = "0x17000067")]
	private Material material
	{
		[Token(Token = "0x6000295")]
		[Address(RVA = "0x66E694", Offset = "0x66E694", VA = "0x66E694")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000296")]
	[Address(RVA = "0x66E758", Offset = "0x66E758", VA = "0x66E758")]
	private void Start()
	{
	}

	[Token(Token = "0x6000297")]
	[Address(RVA = "0x66E7D4", Offset = "0x66E7D4", VA = "0x66E7D4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000298")]
	[Address(RVA = "0x66EBA8", Offset = "0x66EBA8", VA = "0x66EBA8")]
	private void Update()
	{
	}

	[Token(Token = "0x6000299")]
	[Address(RVA = "0x66EBB0", Offset = "0x66EBB0", VA = "0x66EBB0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600029A")]
	[Address(RVA = "0x66EC60", Offset = "0x66EC60", VA = "0x66EC60")]
	public CameraFilterPack_Colors_Adjust_FullColors()
	{
	}
}
