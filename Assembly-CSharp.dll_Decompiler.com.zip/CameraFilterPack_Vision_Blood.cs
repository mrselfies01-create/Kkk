using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000125")]
public class CameraFilterPack_Vision_Blood : MonoBehaviour
{
	[Token(Token = "0x4000843")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000844")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000845")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000846")]
	[FieldOffset(Offset = "0x30")]
	public float HoleSize;

	[Token(Token = "0x4000847")]
	[FieldOffset(Offset = "0x34")]
	public float HoleSmooth;

	[Token(Token = "0x4000848")]
	[FieldOffset(Offset = "0x38")]
	public float Color1;

	[Token(Token = "0x4000849")]
	[FieldOffset(Offset = "0x3C")]
	public float Color2;

	[Token(Token = "0x17000126")]
	private Material material
	{
		[Token(Token = "0x6000735")]
		[Address(RVA = "0x63DBC8", Offset = "0x63DBC8", VA = "0x63DBC8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000736")]
	[Address(RVA = "0x63DC8C", Offset = "0x63DC8C", VA = "0x63DC8C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000737")]
	[Address(RVA = "0x63DD08", Offset = "0x63DD08", VA = "0x63DD08")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000738")]
	[Address(RVA = "0x63DF8C", Offset = "0x63DF8C", VA = "0x63DF8C")]
	private void Update()
	{
	}

	[Token(Token = "0x6000739")]
	[Address(RVA = "0x63DF90", Offset = "0x63DF90", VA = "0x63DF90")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600073A")]
	[Address(RVA = "0x63E040", Offset = "0x63E040", VA = "0x63E040")]
	public CameraFilterPack_Vision_Blood()
	{
	}
}
