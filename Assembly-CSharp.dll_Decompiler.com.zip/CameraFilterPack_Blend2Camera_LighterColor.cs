using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000034")]
public class CameraFilterPack_Blend2Camera_LighterColor : MonoBehaviour
{
	[Token(Token = "0x40001FD")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001FE")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001FF")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000200")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000201")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000202")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x4000203")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x4000204")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000035")]
	private Material material
	{
		[Token(Token = "0x6000148")]
		[Address(RVA = "0x5C46A0", Offset = "0x5C46A0", VA = "0x5C46A0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000149")]
	[Address(RVA = "0x5C4764", Offset = "0x5C4764", VA = "0x5C4764")]
	private void Start()
	{
	}

	[Token(Token = "0x600014A")]
	[Address(RVA = "0x5C487C", Offset = "0x5C487C", VA = "0x5C487C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600014B")]
	[Address(RVA = "0x5C4B0C", Offset = "0x5C4B0C", VA = "0x5C4B0C")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x600014C")]
	[Address(RVA = "0x5C4BF8", Offset = "0x5C4BF8", VA = "0x5C4BF8")]
	private void Update()
	{
	}

	[Token(Token = "0x600014D")]
	[Address(RVA = "0x5C4BFC", Offset = "0x5C4BFC", VA = "0x5C4BFC")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x600014E")]
	[Address(RVA = "0x5C4CE8", Offset = "0x5C4CE8", VA = "0x5C4CE8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600014F")]
	[Address(RVA = "0x5C4DE0", Offset = "0x5C4DE0", VA = "0x5C4DE0")]
	public CameraFilterPack_Blend2Camera_LighterColor()
	{
	}
}
