using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E5")]
public class CameraFilterPack_NewGlitch4 : MonoBehaviour
{
	[Token(Token = "0x400069D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400069E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400069F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006A0")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x40006A1")]
	[FieldOffset(Offset = "0x34")]
	public float _Fade;

	[Token(Token = "0x170000E6")]
	private Material material
	{
		[Token(Token = "0x60005AE")]
		[Address(RVA = "0x62ACD8", Offset = "0x62ACD8", VA = "0x62ACD8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005AF")]
	[Address(RVA = "0x62AD9C", Offset = "0x62AD9C", VA = "0x62AD9C")]
	private void Start()
	{
	}

	[Token(Token = "0x60005B0")]
	[Address(RVA = "0x62AE18", Offset = "0x62AE18", VA = "0x62AE18")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005B1")]
	[Address(RVA = "0x62B054", Offset = "0x62B054", VA = "0x62B054")]
	private void Update()
	{
	}

	[Token(Token = "0x60005B2")]
	[Address(RVA = "0x62B058", Offset = "0x62B058", VA = "0x62B058")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005B3")]
	[Address(RVA = "0x62B108", Offset = "0x62B108", VA = "0x62B108")]
	public CameraFilterPack_NewGlitch4()
	{
	}
}
