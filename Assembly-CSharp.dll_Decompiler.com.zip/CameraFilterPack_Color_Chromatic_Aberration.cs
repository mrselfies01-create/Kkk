using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200005B")]
public class CameraFilterPack_Color_Chromatic_Aberration : MonoBehaviour
{
	[Token(Token = "0x4000326")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000327")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000328")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000329")]
	[FieldOffset(Offset = "0x30")]
	public float Offset;

	[Token(Token = "0x1700005C")]
	private Material material
	{
		[Token(Token = "0x6000253")]
		[Address(RVA = "0x66B7D0", Offset = "0x66B7D0", VA = "0x66B7D0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000254")]
	[Address(RVA = "0x66B894", Offset = "0x66B894", VA = "0x66B894")]
	private void Start()
	{
	}

	[Token(Token = "0x6000255")]
	[Address(RVA = "0x66B910", Offset = "0x66B910", VA = "0x66B910")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000256")]
	[Address(RVA = "0x66BB28", Offset = "0x66BB28", VA = "0x66BB28")]
	private void Update()
	{
	}

	[Token(Token = "0x6000257")]
	[Address(RVA = "0x66BB2C", Offset = "0x66BB2C", VA = "0x66BB2C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000258")]
	[Address(RVA = "0x66BBDC", Offset = "0x66BBDC", VA = "0x66BBDC")]
	public CameraFilterPack_Color_Chromatic_Aberration()
	{
	}
}
