using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000D3")]
public class CameraFilterPack_Gradients_Rainbow : MonoBehaviour
{
	[Token(Token = "0x4000619")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400061A")]
	[FieldOffset(Offset = "0x20")]
	private string ShaderName;

	[Token(Token = "0x400061B")]
	[FieldOffset(Offset = "0x28")]
	private float TimeX;

	[Token(Token = "0x400061C")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x400061D")]
	[FieldOffset(Offset = "0x38")]
	public float Switch;

	[Token(Token = "0x400061E")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x170000D4")]
	private Material material
	{
		[Token(Token = "0x6000526")]
		[Address(RVA = "0x6A3BF0", Offset = "0x6A3BF0", VA = "0x6A3BF0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000527")]
	[Address(RVA = "0x6A3CB4", Offset = "0x6A3CB4", VA = "0x6A3CB4")]
	private void Start()
	{
	}

	[Token(Token = "0x6000528")]
	[Address(RVA = "0x6A3D04", Offset = "0x6A3D04", VA = "0x6A3D04")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000529")]
	[Address(RVA = "0x6A3F40", Offset = "0x6A3F40", VA = "0x6A3F40")]
	private void Update()
	{
	}

	[Token(Token = "0x600052A")]
	[Address(RVA = "0x6A3F44", Offset = "0x6A3F44", VA = "0x6A3F44")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600052B")]
	[Address(RVA = "0x6A3FF4", Offset = "0x6A3FF4", VA = "0x6A3FF4")]
	public CameraFilterPack_Gradients_Rainbow()
	{
	}
}
