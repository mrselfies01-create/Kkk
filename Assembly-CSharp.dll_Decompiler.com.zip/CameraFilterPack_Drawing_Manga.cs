using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008E")]
public class CameraFilterPack_Drawing_Manga : MonoBehaviour
{
	[Token(Token = "0x400044A")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400044B")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400044C")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400044D")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x1700008F")]
	private Material material
	{
		[Token(Token = "0x6000387")]
		[Address(RVA = "0x69010C", Offset = "0x69010C", VA = "0x69010C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000388")]
	[Address(RVA = "0x6901D0", Offset = "0x6901D0", VA = "0x6901D0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000389")]
	[Address(RVA = "0x69024C", Offset = "0x69024C", VA = "0x69024C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600038A")]
	[Address(RVA = "0x6903D0", Offset = "0x6903D0", VA = "0x6903D0")]
	private void Update()
	{
	}

	[Token(Token = "0x600038B")]
	[Address(RVA = "0x6903D4", Offset = "0x6903D4", VA = "0x6903D4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600038C")]
	[Address(RVA = "0x690484", Offset = "0x690484", VA = "0x690484")]
	public CameraFilterPack_Drawing_Manga()
	{
	}
}
