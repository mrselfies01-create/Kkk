using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000086")]
public class CameraFilterPack_Drawing_CellShading2 : MonoBehaviour
{
	[Token(Token = "0x400041E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400041F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000420")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000421")]
	[FieldOffset(Offset = "0x30")]
	public float EdgeSize;

	[Token(Token = "0x4000422")]
	[FieldOffset(Offset = "0x34")]
	public float ColorLevel;

	[Token(Token = "0x4000423")]
	[FieldOffset(Offset = "0x38")]
	public float Blur;

	[Token(Token = "0x17000087")]
	private Material material
	{
		[Token(Token = "0x6000357")]
		[Address(RVA = "0x677B40", Offset = "0x677B40", VA = "0x677B40")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000358")]
	[Address(RVA = "0x677C04", Offset = "0x677C04", VA = "0x677C04")]
	private void Start()
	{
	}

	[Token(Token = "0x6000359")]
	[Address(RVA = "0x677C80", Offset = "0x677C80", VA = "0x677C80")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600035A")]
	[Address(RVA = "0x677ED0", Offset = "0x677ED0", VA = "0x677ED0")]
	private void Update()
	{
	}

	[Token(Token = "0x600035B")]
	[Address(RVA = "0x677ED4", Offset = "0x677ED4", VA = "0x677ED4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600035C")]
	[Address(RVA = "0x677F84", Offset = "0x677F84", VA = "0x677F84")]
	public CameraFilterPack_Drawing_CellShading2()
	{
	}
}
