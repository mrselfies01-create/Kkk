using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000021")]
public class CameraFilterPack_Atmosphere_Rain_Pro : MonoBehaviour
{
	[Token(Token = "0x4000143")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000144")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000145")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000146")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x4000147")]
	[FieldOffset(Offset = "0x34")]
	public float Intensity;

	[Token(Token = "0x4000148")]
	[FieldOffset(Offset = "0x38")]
	public float DirectionX;

	[Token(Token = "0x4000149")]
	[FieldOffset(Offset = "0x3C")]
	public float Size;

	[Token(Token = "0x400014A")]
	[FieldOffset(Offset = "0x40")]
	public float Speed;

	[Token(Token = "0x400014B")]
	[FieldOffset(Offset = "0x44")]
	public float Distortion;

	[Token(Token = "0x400014C")]
	[FieldOffset(Offset = "0x48")]
	public float StormFlashOnOff;

	[Token(Token = "0x400014D")]
	[FieldOffset(Offset = "0x4C")]
	public float DropOnOff;

	[Token(Token = "0x400014E")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x17000022")]
	private Material material
	{
		[Token(Token = "0x60000B8")]
		[Address(RVA = "0x5BBDB8", Offset = "0x5BBDB8", VA = "0x5BBDB8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000B9")]
	[Address(RVA = "0x5BBE7C", Offset = "0x5BBE7C", VA = "0x5BBE7C")]
	private void Start()
	{
	}

	[Token(Token = "0x60000BA")]
	[Address(RVA = "0x5BBF34", Offset = "0x5BBF34", VA = "0x5BBF34")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000BB")]
	[Address(RVA = "0x5BC26C", Offset = "0x5BC26C", VA = "0x5BC26C")]
	private void Update()
	{
	}

	[Token(Token = "0x60000BC")]
	[Address(RVA = "0x5BC270", Offset = "0x5BC270", VA = "0x5BC270")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000BD")]
	[Address(RVA = "0x5BC320", Offset = "0x5BC320", VA = "0x5BC320")]
	public CameraFilterPack_Atmosphere_Rain_Pro()
	{
	}
}
