using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000094")]
public class CameraFilterPack_Drawing_Manga_Flash : MonoBehaviour
{
	[Token(Token = "0x4000463")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000464")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000465")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000466")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000467")]
	[FieldOffset(Offset = "0x34")]
	public int Speed;

	[Token(Token = "0x4000468")]
	[FieldOffset(Offset = "0x38")]
	public float PosX;

	[Token(Token = "0x4000469")]
	[FieldOffset(Offset = "0x3C")]
	public float PosY;

	[Token(Token = "0x400046A")]
	[FieldOffset(Offset = "0x40")]
	public float Intensity;

	[Token(Token = "0x17000095")]
	private Material material
	{
		[Token(Token = "0x60003AB")]
		[Address(RVA = "0x691684", Offset = "0x691684", VA = "0x691684")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003AC")]
	[Address(RVA = "0x691748", Offset = "0x691748", VA = "0x691748")]
	private void Start()
	{
	}

	[Token(Token = "0x60003AD")]
	[Address(RVA = "0x6917C4", Offset = "0x6917C4", VA = "0x6917C4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003AE")]
	[Address(RVA = "0x691A70", Offset = "0x691A70", VA = "0x691A70")]
	private void Update()
	{
	}

	[Token(Token = "0x60003AF")]
	[Address(RVA = "0x691A74", Offset = "0x691A74", VA = "0x691A74")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003B0")]
	[Address(RVA = "0x691B24", Offset = "0x691B24", VA = "0x691B24")]
	public CameraFilterPack_Drawing_Manga_Flash()
	{
	}
}
