using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000128")]
public class CameraFilterPack_Vision_Drost : MonoBehaviour
{
	[Token(Token = "0x4000858")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000859")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400085A")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400085B")]
	[FieldOffset(Offset = "0x30")]
	public float Intensity;

	[Token(Token = "0x400085C")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x400085D")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x400085E")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000129")]
	private Material material
	{
		[Token(Token = "0x6000747")]
		[Address(RVA = "0x63E980", Offset = "0x63E980", VA = "0x63E980")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000748")]
	[Address(RVA = "0x63EA44", Offset = "0x63EA44", VA = "0x63EA44")]
	private void Start()
	{
	}

	[Token(Token = "0x6000749")]
	[Address(RVA = "0x63EAC0", Offset = "0x63EAC0", VA = "0x63EAC0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600074A")]
	[Address(RVA = "0x63ED44", Offset = "0x63ED44", VA = "0x63ED44")]
	private void Update()
	{
	}

	[Token(Token = "0x600074B")]
	[Address(RVA = "0x63ED48", Offset = "0x63ED48", VA = "0x63ED48")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600074C")]
	[Address(RVA = "0x63EDF8", Offset = "0x63EDF8", VA = "0x63EDF8")]
	public CameraFilterPack_Vision_Drost()
	{
	}
}
