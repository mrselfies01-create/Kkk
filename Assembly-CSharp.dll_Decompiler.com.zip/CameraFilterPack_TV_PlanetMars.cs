using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000113")]
public class CameraFilterPack_TV_PlanetMars : MonoBehaviour
{
	[Token(Token = "0x40007DA")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40007DB")]
	[FieldOffset(Offset = "0x20")]
	public float Fade;

	[Token(Token = "0x40007DC")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x40007DD")]
	[FieldOffset(Offset = "0x28")]
	public float Distortion;

	[Token(Token = "0x40007DE")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x17000114")]
	private Material material
	{
		[Token(Token = "0x60006C9")]
		[Address(RVA = "0x638DCC", Offset = "0x638DCC", VA = "0x638DCC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006CA")]
	[Address(RVA = "0x638E90", Offset = "0x638E90", VA = "0x638E90")]
	private void Start()
	{
	}

	[Token(Token = "0x60006CB")]
	[Address(RVA = "0x638F0C", Offset = "0x638F0C", VA = "0x638F0C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006CC")]
	[Address(RVA = "0x639148", Offset = "0x639148", VA = "0x639148")]
	private void Update()
	{
	}

	[Token(Token = "0x60006CD")]
	[Address(RVA = "0x63914C", Offset = "0x63914C", VA = "0x63914C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006CE")]
	[Address(RVA = "0x6391FC", Offset = "0x6391FC", VA = "0x6391FC")]
	public CameraFilterPack_TV_PlanetMars()
	{
	}
}
