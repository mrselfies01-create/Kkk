using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000A1")]
public class CameraFilterPack_Edge_Neon : MonoBehaviour
{
	[Token(Token = "0x40004C9")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004CA")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004CB")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004CC")]
	[FieldOffset(Offset = "0x30")]
	public float EdgeWeight;

	[Token(Token = "0x170000A2")]
	private Material material
	{
		[Token(Token = "0x60003FA")]
		[Address(RVA = "0x695478", Offset = "0x695478", VA = "0x695478")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003FB")]
	[Address(RVA = "0x69553C", Offset = "0x69553C", VA = "0x69553C")]
	private void Start()
	{
	}

	[Token(Token = "0x60003FC")]
	[Address(RVA = "0x6955B8", Offset = "0x6955B8", VA = "0x6955B8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003FD")]
	[Address(RVA = "0x6957C0", Offset = "0x6957C0", VA = "0x6957C0")]
	private void Update()
	{
	}

	[Token(Token = "0x60003FE")]
	[Address(RVA = "0x6957C4", Offset = "0x6957C4", VA = "0x6957C4")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003FF")]
	[Address(RVA = "0x695874", Offset = "0x695874", VA = "0x695874")]
	public CameraFilterPack_Edge_Neon()
	{
	}
}
