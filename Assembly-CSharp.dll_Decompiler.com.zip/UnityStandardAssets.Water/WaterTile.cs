using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x200014B")]
public class WaterTile : MonoBehaviour
{
	[Token(Token = "0x40009BD")]
	[FieldOffset(Offset = "0x18")]
	public PlanarReflection reflection;

	[Token(Token = "0x40009BE")]
	[FieldOffset(Offset = "0x20")]
	public WaterBase waterBase;

	[Token(Token = "0x6000816")]
	[Address(RVA = "0x47AE14", Offset = "0x47AE14", VA = "0x47AE14")]
	public void Start()
	{
	}

	[Token(Token = "0x6000817")]
	[Address(RVA = "0x47AE18", Offset = "0x47AE18", VA = "0x47AE18")]
	private void AcquireComponents()
	{
	}

	[Token(Token = "0x6000818")]
	[Address(RVA = "0x47AFBC", Offset = "0x47AFBC", VA = "0x47AFBC")]
	public void OnWillRenderObject()
	{
	}

	[Token(Token = "0x6000819")]
	[Address(RVA = "0x47B0D0", Offset = "0x47B0D0", VA = "0x47B0D0")]
	public WaterTile()
	{
	}
}
