using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000143")]
public class Displace : MonoBehaviour
{
	[Token(Token = "0x60007EE")]
	[Address(RVA = "0x38762C", Offset = "0x38762C", VA = "0x38762C")]
	public void Awake()
	{
	}

	[Token(Token = "0x60007EF")]
	[Address(RVA = "0x387650", Offset = "0x387650", VA = "0x387650")]
	public void OnEnable()
	{
	}

	[Token(Token = "0x60007F0")]
	[Address(RVA = "0x3876B0", Offset = "0x3876B0", VA = "0x3876B0")]
	public void OnDisable()
	{
	}

	[Token(Token = "0x60007F1")]
	[Address(RVA = "0x387710", Offset = "0x387710", VA = "0x387710")]
	public Displace()
	{
	}
}
