using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000147")]
public class SpecularLighting : MonoBehaviour
{
	[Token(Token = "0x40009A6")]
	[FieldOffset(Offset = "0x18")]
	public Transform specularLight;

	[Token(Token = "0x40009A7")]
	[FieldOffset(Offset = "0x20")]
	private WaterBase m_WaterBase;

	[Token(Token = "0x6000805")]
	[Address(RVA = "0x3DD200", Offset = "0x3DD200", VA = "0x3DD200")]
	public void Start()
	{
	}

	[Token(Token = "0x6000806")]
	[Address(RVA = "0x3DD2EC", Offset = "0x3DD2EC", VA = "0x3DD2EC")]
	public void Update()
	{
	}

	[Token(Token = "0x6000807")]
	[Address(RVA = "0x3DD514", Offset = "0x3DD514", VA = "0x3DD514")]
	public SpecularLighting()
	{
	}
}
