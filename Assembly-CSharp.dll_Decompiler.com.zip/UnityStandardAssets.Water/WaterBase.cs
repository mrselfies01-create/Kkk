using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x200014A")]
public class WaterBase : MonoBehaviour
{
	[Token(Token = "0x40009BA")]
	[FieldOffset(Offset = "0x18")]
	public Material sharedMaterial;

	[Token(Token = "0x40009BB")]
	[FieldOffset(Offset = "0x20")]
	public WaterQuality waterQuality;

	[Token(Token = "0x40009BC")]
	[FieldOffset(Offset = "0x24")]
	public bool edgeBlend;

	[Token(Token = "0x6000812")]
	[Address(RVA = "0x47AB44", Offset = "0x47AB44", VA = "0x47AB44")]
	public void UpdateShader()
	{
	}

	[Token(Token = "0x6000813")]
	[Address(RVA = "0x47ACC4", Offset = "0x47ACC4", VA = "0x47ACC4")]
	public void WaterTileBeingRendered(Transform tr, Camera currentCam)
	{
	}

	[Token(Token = "0x6000814")]
	[Address(RVA = "0x47AD78", Offset = "0x47AD78", VA = "0x47AD78")]
	public void Update()
	{
	}

	[Token(Token = "0x6000815")]
	[Address(RVA = "0x47ADFC", Offset = "0x47ADFC", VA = "0x47ADFC")]
	public WaterBase()
	{
	}
}
