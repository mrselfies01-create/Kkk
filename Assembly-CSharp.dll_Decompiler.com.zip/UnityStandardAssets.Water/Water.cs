using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000148")]
public class Water : MonoBehaviour
{
	[Token(Token = "0x20001FE")]
	public enum WaterMode
	{
		[Token(Token = "0x4000D9F")]
		Simple,
		[Token(Token = "0x4000DA0")]
		Reflective,
		[Token(Token = "0x4000DA1")]
		Refractive
	}

	[Token(Token = "0x40009A8")]
	[FieldOffset(Offset = "0x18")]
	public WaterMode waterMode;

	[Token(Token = "0x40009A9")]
	[FieldOffset(Offset = "0x1C")]
	public bool disablePixelLights;

	[Token(Token = "0x40009AA")]
	[FieldOffset(Offset = "0x20")]
	public int textureSize;

	[Token(Token = "0x40009AB")]
	[FieldOffset(Offset = "0x24")]
	public float clipPlaneOffset;

	[Token(Token = "0x40009AC")]
	[FieldOffset(Offset = "0x28")]
	public LayerMask reflectLayers;

	[Token(Token = "0x40009AD")]
	[FieldOffset(Offset = "0x2C")]
	public LayerMask refractLayers;

	[Token(Token = "0x40009AE")]
	[FieldOffset(Offset = "0x30")]
	private Dictionary<Camera, Camera> m_ReflectionCameras;

	[Token(Token = "0x40009AF")]
	[FieldOffset(Offset = "0x38")]
	private Dictionary<Camera, Camera> m_RefractionCameras;

	[Token(Token = "0x40009B0")]
	[FieldOffset(Offset = "0x40")]
	private RenderTexture m_ReflectionTexture;

	[Token(Token = "0x40009B1")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture m_RefractionTexture;

	[Token(Token = "0x40009B2")]
	[FieldOffset(Offset = "0x50")]
	private WaterMode m_HardwareWaterSupport;

	[Token(Token = "0x40009B3")]
	[FieldOffset(Offset = "0x54")]
	private int m_OldReflectionTextureSize;

	[Token(Token = "0x40009B4")]
	[FieldOffset(Offset = "0x58")]
	private int m_OldRefractionTextureSize;

	[Token(Token = "0x40009B5")]
	[FieldOffset(Offset = "0x0")]
	private static bool s_InsideWater;

	[Token(Token = "0x6000808")]
	[Address(RVA = "0x4789CC", Offset = "0x4789CC", VA = "0x4789CC")]
	public void OnWillRenderObject()
	{
	}

	[Token(Token = "0x6000809")]
	[Address(RVA = "0x47A4F0", Offset = "0x47A4F0", VA = "0x47A4F0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600080A")]
	[Address(RVA = "0x47A7DC", Offset = "0x47A7DC", VA = "0x47A7DC")]
	private void Update()
	{
	}

	[Token(Token = "0x600080B")]
	[Address(RVA = "0x479E5C", Offset = "0x479E5C", VA = "0x479E5C")]
	private void UpdateCameraModes(Camera src, Camera dest)
	{
	}

	[Token(Token = "0x600080C")]
	[Address(RVA = "0x479454", Offset = "0x479454", VA = "0x479454")]
	private void CreateWaterObjects(Camera currentCamera, out Camera reflectionCamera, out Camera refractionCamera)
	{
	}

	[Token(Token = "0x600080D")]
	[Address(RVA = "0x479440", Offset = "0x479440", VA = "0x479440")]
	private WaterMode GetWaterMode()
	{
		return default(WaterMode);
	}

	[Token(Token = "0x600080E")]
	[Address(RVA = "0x4792F8", Offset = "0x4792F8", VA = "0x4792F8")]
	private WaterMode FindHardwareWaterSupport()
	{
		return default(WaterMode);
	}

	[Token(Token = "0x600080F")]
	[Address(RVA = "0x47A35C", Offset = "0x47A35C", VA = "0x47A35C")]
	private Vector4 CameraSpacePlane(Camera cam, Vector3 pos, Vector3 normal, float sideSign)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector4);
	}

	[Token(Token = "0x6000810")]
	[Address(RVA = "0x47A0B8", Offset = "0x47A0B8", VA = "0x47A0B8")]
	private static void CalculateReflectionMatrix(ref Matrix4x4 reflectionMat, Vector4 plane)
	{
	}

	[Token(Token = "0x6000811")]
	[Address(RVA = "0x47AA68", Offset = "0x47AA68", VA = "0x47AA68")]
	public Water()
	{
	}
}
