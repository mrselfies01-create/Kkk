using Il2CppDummyDll;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000144")]
public class GerstnerDisplace : Displace
{
	[Token(Token = "0x60007F2")]
	[Address(RVA = "0x38B26C", Offset = "0x38B26C", VA = "0x38B26C")]
	public GerstnerDisplace()
	{
	}
}
