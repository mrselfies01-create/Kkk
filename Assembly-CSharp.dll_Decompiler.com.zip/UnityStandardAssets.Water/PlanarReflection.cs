using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000146")]
public class PlanarReflection : MonoBehaviour
{
	[Token(Token = "0x400099D")]
	[FieldOffset(Offset = "0x18")]
	public LayerMask reflectionMask;

	[Token(Token = "0x400099E")]
	[FieldOffset(Offset = "0x1C")]
	public bool reflectSkybox;

	[Token(Token = "0x400099F")]
	[FieldOffset(Offset = "0x20")]
	public Color clearColor;

	[Token(Token = "0x40009A0")]
	[FieldOffset(Offset = "0x30")]
	public string reflectionSampler;

	[Token(Token = "0x40009A1")]
	[FieldOffset(Offset = "0x38")]
	public float clipPlaneOffset;

	[Token(Token = "0x40009A2")]
	[FieldOffset(Offset = "0x3C")]
	private Vector3 m_Oldpos;

	[Token(Token = "0x40009A3")]
	[FieldOffset(Offset = "0x48")]
	private Camera m_ReflectionCamera;

	[Token(Token = "0x40009A4")]
	[FieldOffset(Offset = "0x50")]
	private Material m_SharedMaterial;

	[Token(Token = "0x40009A5")]
	[FieldOffset(Offset = "0x58")]
	private Dictionary<Camera, bool> m_HelperCameras;

	[Token(Token = "0x60007F5")]
	[Address(RVA = "0x393CC4", Offset = "0x393CC4", VA = "0x393CC4")]
	public void Start()
	{
	}

	[Token(Token = "0x60007F6")]
	[Address(RVA = "0x393DB4", Offset = "0x393DB4", VA = "0x393DB4")]
	private Camera CreateReflectionCameraFor(Camera cam)
	{
		return null;
	}

	[Token(Token = "0x60007F7")]
	[Address(RVA = "0x3940BC", Offset = "0x3940BC", VA = "0x3940BC")]
	private void SetStandardCameraParameter(Camera cam, LayerMask mask)
	{
	}

	[Token(Token = "0x60007F8")]
	[Address(RVA = "0x394170", Offset = "0x394170", VA = "0x394170")]
	private RenderTexture CreateTextureFor(Camera cam)
	{
		return null;
	}

	[Token(Token = "0x60007F9")]
	[Address(RVA = "0x394278", Offset = "0x394278", VA = "0x394278")]
	public void RenderHelpCameras(Camera currentCam)
	{
	}

	[Token(Token = "0x60007FA")]
	[Address(RVA = "0x394AE8", Offset = "0x394AE8", VA = "0x394AE8")]
	public void LateUpdate()
	{
	}

	[Token(Token = "0x60007FB")]
	[Address(RVA = "0x394B48", Offset = "0x394B48", VA = "0x394B48")]
	public void WaterTileBeingRendered(Transform tr, Camera currentCam)
	{
	}

	[Token(Token = "0x60007FC")]
	[Address(RVA = "0x394C40", Offset = "0x394C40", VA = "0x394C40")]
	public void OnEnable()
	{
	}

	[Token(Token = "0x60007FD")]
	[Address(RVA = "0x394CA0", Offset = "0x394CA0", VA = "0x394CA0")]
	public void OnDisable()
	{
	}

	[Token(Token = "0x60007FE")]
	[Address(RVA = "0x3943E0", Offset = "0x3943E0", VA = "0x3943E0")]
	private void RenderReflectionFor(Camera cam, Camera reflectCamera)
	{
	}

	[Token(Token = "0x60007FF")]
	[Address(RVA = "0x394D00", Offset = "0x394D00", VA = "0x394D00")]
	private void SaneCameraSettings(Camera helperCam)
	{
	}

	[Token(Token = "0x6000800")]
	[Address(RVA = "0x3951B0", Offset = "0x3951B0", VA = "0x3951B0")]
	private static Matrix4x4 CalculateObliqueMatrix(Matrix4x4 projection, Vector4 clipPlane)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Matrix4x4);
	}

	[Token(Token = "0x6000801")]
	[Address(RVA = "0x394D64", Offset = "0x394D64", VA = "0x394D64")]
	private static Matrix4x4 CalculateReflectionMatrix(Matrix4x4 reflectionMat, Vector4 plane)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Matrix4x4);
	}

	[Token(Token = "0x6000802")]
	[Address(RVA = "0x3953E8", Offset = "0x3953E8", VA = "0x3953E8")]
	private static float Sgn(float a)
	{
		return default(float);
	}

	[Token(Token = "0x6000803")]
	[Address(RVA = "0x39501C", Offset = "0x39501C", VA = "0x39501C")]
	private Vector4 CameraSpacePlane(Camera cam, Vector3 pos, Vector3 normal, float sideSign)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return default(Vector4);
	}

	[Token(Token = "0x6000804")]
	[Address(RVA = "0x395408", Offset = "0x395408", VA = "0x395408")]
	public PlanarReflection()
	{
	}
}
