using Il2CppDummyDll;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000149")]
public enum WaterQuality
{
	[Token(Token = "0x40009B7")]
	High = 2,
	[Token(Token = "0x40009B8")]
	Medium = 1,
	[Token(Token = "0x40009B9")]
	Low = 0
}
