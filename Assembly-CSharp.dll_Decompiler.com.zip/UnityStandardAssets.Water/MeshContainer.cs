using Il2CppDummyDll;
using UnityEngine;

namespace UnityStandardAssets.Water;

[Token(Token = "0x2000145")]
public class MeshContainer
{
	[Token(Token = "0x400099A")]
	[FieldOffset(Offset = "0x10")]
	public Mesh mesh;

	[Token(Token = "0x400099B")]
	[FieldOffset(Offset = "0x18")]
	public Vector3[] vertices;

	[Token(Token = "0x400099C")]
	[FieldOffset(Offset = "0x20")]
	public Vector3[] normals;

	[Token(Token = "0x60007F3")]
	[Address(RVA = "0x38E2F8", Offset = "0x38E2F8", VA = "0x38E2F8")]
	public MeshContainer(Mesh m)
	{
	}

	[Token(Token = "0x60007F4")]
	[Address(RVA = "0x38E34C", Offset = "0x38E34C", VA = "0x38E34C")]
	public void Update()
	{
	}
}
