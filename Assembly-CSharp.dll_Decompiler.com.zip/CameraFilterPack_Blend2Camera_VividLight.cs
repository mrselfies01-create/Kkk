using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000043")]
public class CameraFilterPack_Blend2Camera_VividLight : MonoBehaviour
{
	[Token(Token = "0x4000286")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000287")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000288")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000289")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x400028A")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x400028B")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x400028C")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x400028D")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000044")]
	private Material material
	{
		[Token(Token = "0x60001C1")]
		[Address(RVA = "0x664258", Offset = "0x664258", VA = "0x664258")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001C2")]
	[Address(RVA = "0x66431C", Offset = "0x66431C", VA = "0x66431C")]
	private void Start()
	{
	}

	[Token(Token = "0x60001C3")]
	[Address(RVA = "0x664434", Offset = "0x664434", VA = "0x664434")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001C4")]
	[Address(RVA = "0x6646C4", Offset = "0x6646C4", VA = "0x6646C4")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60001C5")]
	[Address(RVA = "0x6647B0", Offset = "0x6647B0", VA = "0x6647B0")]
	private void Update()
	{
	}

	[Token(Token = "0x60001C6")]
	[Address(RVA = "0x6647B4", Offset = "0x6647B4", VA = "0x6647B4")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60001C7")]
	[Address(RVA = "0x6648A0", Offset = "0x6648A0", VA = "0x6648A0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001C8")]
	[Address(RVA = "0x664998", Offset = "0x664998", VA = "0x664998")]
	public CameraFilterPack_Blend2Camera_VividLight()
	{
	}
}
