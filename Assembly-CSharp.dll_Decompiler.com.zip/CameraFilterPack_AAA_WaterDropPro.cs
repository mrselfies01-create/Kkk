using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200001C")]
public class CameraFilterPack_AAA_WaterDropPro : MonoBehaviour
{
	[Token(Token = "0x400011D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400011E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400011F")]
	[FieldOffset(Offset = "0x24")]
	public float Distortion;

	[Token(Token = "0x4000120")]
	[FieldOffset(Offset = "0x28")]
	public float SizeX;

	[Token(Token = "0x4000121")]
	[FieldOffset(Offset = "0x2C")]
	public float SizeY;

	[Token(Token = "0x4000122")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x4000123")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000124")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x1700001D")]
	private Material material
	{
		[Token(Token = "0x600009A")]
		[Address(RVA = "0x5BA5F0", Offset = "0x5BA5F0", VA = "0x5BA5F0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600009B")]
	[Address(RVA = "0x5BA6B4", Offset = "0x5BA6B4", VA = "0x5BA6B4")]
	private void Start()
	{
	}

	[Token(Token = "0x600009C")]
	[Address(RVA = "0x5BA76C", Offset = "0x5BA76C", VA = "0x5BA76C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600009D")]
	[Address(RVA = "0x5BA980", Offset = "0x5BA980", VA = "0x5BA980")]
	private void Update()
	{
	}

	[Token(Token = "0x600009E")]
	[Address(RVA = "0x5BA984", Offset = "0x5BA984", VA = "0x5BA984")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600009F")]
	[Address(RVA = "0x5BAA34", Offset = "0x5BAA34", VA = "0x5BAA34")]
	public CameraFilterPack_AAA_WaterDropPro()
	{
	}
}
