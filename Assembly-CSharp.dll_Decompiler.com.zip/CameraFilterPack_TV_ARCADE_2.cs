using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000103")]
public class CameraFilterPack_TV_ARCADE_2 : MonoBehaviour
{
	[Token(Token = "0x4000771")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000772")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000773")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000774")]
	[FieldOffset(Offset = "0x30")]
	public float Interferance_Size;

	[Token(Token = "0x4000775")]
	[FieldOffset(Offset = "0x34")]
	public float Interferance_Speed;

	[Token(Token = "0x4000776")]
	[FieldOffset(Offset = "0x38")]
	public float Contrast;

	[Token(Token = "0x4000777")]
	[FieldOffset(Offset = "0x3C")]
	public float Fade;

	[Token(Token = "0x17000104")]
	private Material material
	{
		[Token(Token = "0x6000669")]
		[Address(RVA = "0x634608", Offset = "0x634608", VA = "0x634608")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600066A")]
	[Address(RVA = "0x6346CC", Offset = "0x6346CC", VA = "0x6346CC")]
	private void Start()
	{
	}

	[Token(Token = "0x600066B")]
	[Address(RVA = "0x634748", Offset = "0x634748", VA = "0x634748")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600066C")]
	[Address(RVA = "0x6349CC", Offset = "0x6349CC", VA = "0x6349CC")]
	private void Update()
	{
	}

	[Token(Token = "0x600066D")]
	[Address(RVA = "0x6349D0", Offset = "0x6349D0", VA = "0x6349D0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600066E")]
	[Address(RVA = "0x634A80", Offset = "0x634A80", VA = "0x634A80")]
	public CameraFilterPack_TV_ARCADE_2()
	{
	}
}
