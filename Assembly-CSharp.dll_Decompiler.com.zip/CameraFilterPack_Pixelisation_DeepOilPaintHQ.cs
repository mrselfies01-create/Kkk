using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000F6")]
public class CameraFilterPack_Pixelisation_DeepOilPaintHQ : MonoBehaviour
{
	[Token(Token = "0x4000720")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000721")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000722")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000723")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000724")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000725")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x4000726")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x4000727")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000728")]
	[FieldOffset(Offset = "0x40")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x4000729")]
	[FieldOffset(Offset = "0x44")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x400072A")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x170000F7")]
	private Material material
	{
		[Token(Token = "0x600061A")]
		[Address(RVA = "0x630808", Offset = "0x630808", VA = "0x630808")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600061B")]
	[Address(RVA = "0x6308CC", Offset = "0x6308CC", VA = "0x6308CC")]
	private void Start()
	{
	}

	[Token(Token = "0x600061C")]
	[Address(RVA = "0x630948", Offset = "0x630948", VA = "0x630948")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600061D")]
	[Address(RVA = "0x630CB4", Offset = "0x630CB4", VA = "0x630CB4")]
	private void Update()
	{
	}

	[Token(Token = "0x600061E")]
	[Address(RVA = "0x630CB8", Offset = "0x630CB8", VA = "0x630CB8")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600061F")]
	[Address(RVA = "0x630D68", Offset = "0x630D68", VA = "0x630D68")]
	public CameraFilterPack_Pixelisation_DeepOilPaintHQ()
	{
	}
}
