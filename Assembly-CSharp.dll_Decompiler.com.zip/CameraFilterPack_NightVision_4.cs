using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000EA")]
public class CameraFilterPack_NightVision_4 : MonoBehaviour
{
	[Token(Token = "0x40006CD")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40006CE")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40006CF")]
	[FieldOffset(Offset = "0x28")]
	public float FadeFX;

	[Token(Token = "0x40006D0")]
	[FieldOffset(Offset = "0x2C")]
	private float TimeX;

	[Token(Token = "0x40006D1")]
	[FieldOffset(Offset = "0x30")]
	private Material SCMaterial;

	[Token(Token = "0x40006D2")]
	[FieldOffset(Offset = "0x38")]
	private float[] Matrix9;

	[Token(Token = "0x170000EB")]
	private Material material
	{
		[Token(Token = "0x60005CC")]
		[Address(RVA = "0x62C8AC", Offset = "0x62C8AC", VA = "0x62C8AC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005CD")]
	[Address(RVA = "0x62C970", Offset = "0x62C970", VA = "0x62C970")]
	private void ChangeFilters()
	{
	}

	[Token(Token = "0x60005CE")]
	[Address(RVA = "0x62C9E0", Offset = "0x62C9E0", VA = "0x62C9E0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005CF")]
	[Address(RVA = "0x62CA34", Offset = "0x62CA34", VA = "0x62CA34")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005D0")]
	[Address(RVA = "0x62CF24", Offset = "0x62CF24", VA = "0x62CF24")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60005D1")]
	[Address(RVA = "0x62CF28", Offset = "0x62CF28", VA = "0x62CF28")]
	private void Update()
	{
	}

	[Token(Token = "0x60005D2")]
	[Address(RVA = "0x62CF2C", Offset = "0x62CF2C", VA = "0x62CF2C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005D3")]
	[Address(RVA = "0x62CFDC", Offset = "0x62CFDC", VA = "0x62CFDC")]
	public CameraFilterPack_NightVision_4()
	{
	}
}
