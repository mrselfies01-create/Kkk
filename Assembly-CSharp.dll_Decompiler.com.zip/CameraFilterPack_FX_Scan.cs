using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BC")]
public class CameraFilterPack_FX_Scan : MonoBehaviour
{
	[Token(Token = "0x400055B")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400055C")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400055D")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400055E")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x400055F")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000560")]
	[FieldOffset(Offset = "0x38")]
	private float Value3;

	[Token(Token = "0x4000561")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x170000BD")]
	private Material material
	{
		[Token(Token = "0x600049C")]
		[Address(RVA = "0x69C6D4", Offset = "0x69C6D4", VA = "0x69C6D4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600049D")]
	[Address(RVA = "0x69C798", Offset = "0x69C798", VA = "0x69C798")]
	private void Start()
	{
	}

	[Token(Token = "0x600049E")]
	[Address(RVA = "0x69C814", Offset = "0x69C814", VA = "0x69C814")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600049F")]
	[Address(RVA = "0x69CA98", Offset = "0x69CA98", VA = "0x69CA98")]
	private void Update()
	{
	}

	[Token(Token = "0x60004A0")]
	[Address(RVA = "0x69CA9C", Offset = "0x69CA9C", VA = "0x69CA9C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004A1")]
	[Address(RVA = "0x69CB4C", Offset = "0x69CB4C", VA = "0x69CB4C")]
	public CameraFilterPack_FX_Scan()
	{
	}
}
