using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000031")]
public class CameraFilterPack_Blend2Camera_HardMix : MonoBehaviour
{
	[Token(Token = "0x40001E5")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x40001E6")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x40001E7")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x40001E8")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x40001E9")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x40001EA")]
	[FieldOffset(Offset = "0x40")]
	public float SwitchCameraToCamera2;

	[Token(Token = "0x40001EB")]
	[FieldOffset(Offset = "0x44")]
	public float BlendFX;

	[Token(Token = "0x40001EC")]
	[FieldOffset(Offset = "0x48")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x17000032")]
	private Material material
	{
		[Token(Token = "0x6000130")]
		[Address(RVA = "0x5C2FA8", Offset = "0x5C2FA8", VA = "0x5C2FA8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000131")]
	[Address(RVA = "0x5C306C", Offset = "0x5C306C", VA = "0x5C306C")]
	private void Start()
	{
	}

	[Token(Token = "0x6000132")]
	[Address(RVA = "0x5C3184", Offset = "0x5C3184", VA = "0x5C3184")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000133")]
	[Address(RVA = "0x5C3414", Offset = "0x5C3414", VA = "0x5C3414")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x6000134")]
	[Address(RVA = "0x5C3500", Offset = "0x5C3500", VA = "0x5C3500")]
	private void Update()
	{
	}

	[Token(Token = "0x6000135")]
	[Address(RVA = "0x5C3504", Offset = "0x5C3504", VA = "0x5C3504")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x6000136")]
	[Address(RVA = "0x5C35F0", Offset = "0x5C35F0", VA = "0x5C35F0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000137")]
	[Address(RVA = "0x5C36E8", Offset = "0x5C36E8", VA = "0x5C36E8")]
	public CameraFilterPack_Blend2Camera_HardMix()
	{
	}
}
