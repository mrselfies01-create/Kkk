using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200013B")]
public class MicInput : MonoBehaviour
{
	[Token(Token = "0x60007AF")]
	[Address(RVA = "0x38E7E4", Offset = "0x38E7E4", VA = "0x38E7E4")]
	private void Start()
	{
	}

	[Token(Token = "0x60007B0")]
	[Address(RVA = "0x38E8CC", Offset = "0x38E8CC", VA = "0x38E8CC")]
	public MicInput()
	{
	}
}
