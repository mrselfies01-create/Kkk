using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000085")]
public class CameraFilterPack_Drawing_CellShading : MonoBehaviour
{
	[Token(Token = "0x4000419")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400041A")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400041B")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400041C")]
	[FieldOffset(Offset = "0x30")]
	public float EdgeSize;

	[Token(Token = "0x400041D")]
	[FieldOffset(Offset = "0x34")]
	public float ColorLevel;

	[Token(Token = "0x17000086")]
	private Material material
	{
		[Token(Token = "0x6000351")]
		[Address(RVA = "0x677704", Offset = "0x677704", VA = "0x677704")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000352")]
	[Address(RVA = "0x6777C8", Offset = "0x6777C8", VA = "0x6777C8")]
	private void Start()
	{
	}

	[Token(Token = "0x6000353")]
	[Address(RVA = "0x677844", Offset = "0x677844", VA = "0x677844")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000354")]
	[Address(RVA = "0x677A70", Offset = "0x677A70", VA = "0x677A70")]
	private void Update()
	{
	}

	[Token(Token = "0x6000355")]
	[Address(RVA = "0x677A74", Offset = "0x677A74", VA = "0x677A74")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000356")]
	[Address(RVA = "0x677B24", Offset = "0x677B24", VA = "0x677B24")]
	public CameraFilterPack_Drawing_CellShading()
	{
	}
}
