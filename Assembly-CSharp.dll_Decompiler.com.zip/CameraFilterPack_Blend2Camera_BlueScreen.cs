using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000025")]
public class CameraFilterPack_Blend2Camera_BlueScreen : MonoBehaviour
{
	[Token(Token = "0x4000172")]
	[FieldOffset(Offset = "0x18")]
	private string ShaderName;

	[Token(Token = "0x4000173")]
	[FieldOffset(Offset = "0x20")]
	public Shader SCShader;

	[Token(Token = "0x4000174")]
	[FieldOffset(Offset = "0x28")]
	public Camera Camera2;

	[Token(Token = "0x4000175")]
	[FieldOffset(Offset = "0x30")]
	private float TimeX;

	[Token(Token = "0x4000176")]
	[FieldOffset(Offset = "0x38")]
	private Material SCMaterial;

	[Token(Token = "0x4000177")]
	[FieldOffset(Offset = "0x40")]
	public float BlendFX;

	[Token(Token = "0x4000178")]
	[FieldOffset(Offset = "0x44")]
	public float Adjust;

	[Token(Token = "0x4000179")]
	[FieldOffset(Offset = "0x48")]
	public float Precision;

	[Token(Token = "0x400017A")]
	[FieldOffset(Offset = "0x4C")]
	public float Luminosity;

	[Token(Token = "0x400017B")]
	[FieldOffset(Offset = "0x50")]
	public float Change_Red;

	[Token(Token = "0x400017C")]
	[FieldOffset(Offset = "0x54")]
	public float Change_Green;

	[Token(Token = "0x400017D")]
	[FieldOffset(Offset = "0x58")]
	public float Change_Blue;

	[Token(Token = "0x400017E")]
	[FieldOffset(Offset = "0x60")]
	private RenderTexture Camera2tex;

	[Token(Token = "0x400017F")]
	[FieldOffset(Offset = "0x68")]
	private Vector2 ScreenSize;

	[Token(Token = "0x17000026")]
	private Material material
	{
		[Token(Token = "0x60000D2")]
		[Address(RVA = "0x5BD734", Offset = "0x5BD734", VA = "0x5BD734")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60000D3")]
	[Address(RVA = "0x5BD7F8", Offset = "0x5BD7F8", VA = "0x5BD7F8")]
	private void OnValidate()
	{
	}

	[Token(Token = "0x60000D4")]
	[Address(RVA = "0x5BD834", Offset = "0x5BD834", VA = "0x5BD834")]
	private void Start()
	{
	}

	[Token(Token = "0x60000D5")]
	[Address(RVA = "0x5BD934", Offset = "0x5BD934", VA = "0x5BD934")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60000D6")]
	[Address(RVA = "0x5BDBF0", Offset = "0x5BDBF0", VA = "0x5BDBF0")]
	private void Update()
	{
	}

	[Token(Token = "0x60000D7")]
	[Address(RVA = "0x5BDC30", Offset = "0x5BDC30", VA = "0x5BDC30")]
	private void OnEnable()
	{
	}

	[Token(Token = "0x60000D8")]
	[Address(RVA = "0x5BDC34", Offset = "0x5BDC34", VA = "0x5BDC34")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60000D9")]
	[Address(RVA = "0x5BDD2C", Offset = "0x5BDD2C", VA = "0x5BDD2C")]
	public CameraFilterPack_Blend2Camera_BlueScreen()
	{
	}
}
