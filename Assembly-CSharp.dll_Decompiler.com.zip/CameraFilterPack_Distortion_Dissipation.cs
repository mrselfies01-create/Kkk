using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000074")]
public class CameraFilterPack_Distortion_Dissipation : MonoBehaviour
{
	[Token(Token = "0x40003B3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003B4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003B5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003B6")]
	[FieldOffset(Offset = "0x30")]
	public float Dissipation;

	[Token(Token = "0x40003B7")]
	[FieldOffset(Offset = "0x34")]
	private float Colors;

	[Token(Token = "0x40003B8")]
	[FieldOffset(Offset = "0x38")]
	private float Green_Mod;

	[Token(Token = "0x40003B9")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000075")]
	private Material material
	{
		[Token(Token = "0x60002EB")]
		[Address(RVA = "0x672CA8", Offset = "0x672CA8", VA = "0x672CA8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60002EC")]
	[Address(RVA = "0x672D6C", Offset = "0x672D6C", VA = "0x672D6C")]
	private void Start()
	{
	}

	[Token(Token = "0x60002ED")]
	[Address(RVA = "0x672DE8", Offset = "0x672DE8", VA = "0x672DE8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60002EE")]
	[Address(RVA = "0x67306C", Offset = "0x67306C", VA = "0x67306C")]
	private void Update()
	{
	}

	[Token(Token = "0x60002EF")]
	[Address(RVA = "0x673070", Offset = "0x673070", VA = "0x673070")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60002F0")]
	[Address(RVA = "0x673120", Offset = "0x673120", VA = "0x673120")]
	public CameraFilterPack_Distortion_Dissipation()
	{
	}
}
