using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000B7")]
public class CameraFilterPack_FX_Hypno : MonoBehaviour
{
	[Token(Token = "0x4000546")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000547")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000548")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000549")]
	[FieldOffset(Offset = "0x30")]
	public float Speed;

	[Token(Token = "0x400054A")]
	[FieldOffset(Offset = "0x34")]
	public float Red;

	[Token(Token = "0x400054B")]
	[FieldOffset(Offset = "0x38")]
	public float Green;

	[Token(Token = "0x400054C")]
	[FieldOffset(Offset = "0x3C")]
	public float Blue;

	[Token(Token = "0x170000B8")]
	private Material material
	{
		[Token(Token = "0x600047E")]
		[Address(RVA = "0x69B2A4", Offset = "0x69B2A4", VA = "0x69B2A4")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600047F")]
	[Address(RVA = "0x69B368", Offset = "0x69B368", VA = "0x69B368")]
	private void Start()
	{
	}

	[Token(Token = "0x6000480")]
	[Address(RVA = "0x69B3E4", Offset = "0x69B3E4", VA = "0x69B3E4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000481")]
	[Address(RVA = "0x69B668", Offset = "0x69B668", VA = "0x69B668")]
	private void Update()
	{
	}

	[Token(Token = "0x6000482")]
	[Address(RVA = "0x69B66C", Offset = "0x69B66C", VA = "0x69B66C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000483")]
	[Address(RVA = "0x69B71C", Offset = "0x69B71C", VA = "0x69B71C")]
	public CameraFilterPack_FX_Hypno()
	{
	}
}
