using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000079")]
public class CameraFilterPack_Distortion_Flush : MonoBehaviour
{
	[Token(Token = "0x40003CC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40003CD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40003CE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40003CF")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x1700007A")]
	private Material material
	{
		[Token(Token = "0x6000309")]
		[Address(RVA = "0x674144", Offset = "0x674144", VA = "0x674144")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600030A")]
	[Address(RVA = "0x674208", Offset = "0x674208", VA = "0x674208")]
	private void Start()
	{
	}

	[Token(Token = "0x600030B")]
	[Address(RVA = "0x674284", Offset = "0x674284", VA = "0x674284")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600030C")]
	[Address(RVA = "0x67449C", Offset = "0x67449C", VA = "0x67449C")]
	private void Update()
	{
	}

	[Token(Token = "0x600030D")]
	[Address(RVA = "0x6744A0", Offset = "0x6744A0", VA = "0x6744A0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600030E")]
	[Address(RVA = "0x674550", Offset = "0x674550", VA = "0x674550")]
	public CameraFilterPack_Distortion_Flush()
	{
	}
}
