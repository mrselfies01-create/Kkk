using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011E")]
public class CameraFilterPack_TV_WideScreenCircle : MonoBehaviour
{
	[Token(Token = "0x4000813")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000814")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000815")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000816")]
	[FieldOffset(Offset = "0x30")]
	public float Size;

	[Token(Token = "0x4000817")]
	[FieldOffset(Offset = "0x34")]
	public float Smooth;

	[Token(Token = "0x4000818")]
	[FieldOffset(Offset = "0x38")]
	private float StretchX;

	[Token(Token = "0x4000819")]
	[FieldOffset(Offset = "0x3C")]
	private float StretchY;

	[Token(Token = "0x1700011F")]
	private Material material
	{
		[Token(Token = "0x600070B")]
		[Address(RVA = "0x63BB28", Offset = "0x63BB28", VA = "0x63BB28")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600070C")]
	[Address(RVA = "0x63BBEC", Offset = "0x63BBEC", VA = "0x63BBEC")]
	private void Start()
	{
	}

	[Token(Token = "0x600070D")]
	[Address(RVA = "0x63BC68", Offset = "0x63BC68", VA = "0x63BC68")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600070E")]
	[Address(RVA = "0x63BEEC", Offset = "0x63BEEC", VA = "0x63BEEC")]
	private void Update()
	{
	}

	[Token(Token = "0x600070F")]
	[Address(RVA = "0x63BEF0", Offset = "0x63BEF0", VA = "0x63BEF0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000710")]
	[Address(RVA = "0x63BFA0", Offset = "0x63BFA0", VA = "0x63BFA0")]
	public CameraFilterPack_TV_WideScreenCircle()
	{
	}
}
