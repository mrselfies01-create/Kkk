using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200009C")]
public class CameraFilterPack_EXTRA_Rotation : MonoBehaviour
{
	[Token(Token = "0x40004AC")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40004AD")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40004AE")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40004AF")]
	[FieldOffset(Offset = "0x30")]
	public float Rotation;

	[Token(Token = "0x40004B0")]
	[FieldOffset(Offset = "0x34")]
	public float PositionX;

	[Token(Token = "0x40004B1")]
	[FieldOffset(Offset = "0x38")]
	public float PositionY;

	[Token(Token = "0x40004B2")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x1700009D")]
	private Material material
	{
		[Token(Token = "0x60003DB")]
		[Address(RVA = "0x693E30", Offset = "0x693E30", VA = "0x693E30")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60003DC")]
	[Address(RVA = "0x693EF4", Offset = "0x693EF4", VA = "0x693EF4")]
	private void Start()
	{
	}

	[Token(Token = "0x60003DD")]
	[Address(RVA = "0x693F70", Offset = "0x693F70", VA = "0x693F70")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60003DE")]
	[Address(RVA = "0x6941F8", Offset = "0x6941F8", VA = "0x6941F8")]
	private void Update()
	{
	}

	[Token(Token = "0x60003DF")]
	[Address(RVA = "0x6941FC", Offset = "0x6941FC", VA = "0x6941FC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60003E0")]
	[Address(RVA = "0x6942AC", Offset = "0x6942AC", VA = "0x6942AC")]
	public CameraFilterPack_EXTRA_Rotation()
	{
	}
}
