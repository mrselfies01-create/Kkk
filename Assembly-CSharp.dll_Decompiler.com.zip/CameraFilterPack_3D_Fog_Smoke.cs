using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000C")]
public class CameraFilterPack_3D_Fog_Smoke : MonoBehaviour
{
	[Token(Token = "0x4000053")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000054")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x4000055")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000056")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000057")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000058")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x4000059")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x400005A")]
	[FieldOffset(Offset = "0x3C")]
	public float DistortionLevel;

	[Token(Token = "0x400005B")]
	[FieldOffset(Offset = "0x40")]
	public float DistortionSize;

	[Token(Token = "0x400005C")]
	[FieldOffset(Offset = "0x44")]
	public float LightIntensity;

	[Token(Token = "0x400005D")]
	[FieldOffset(Offset = "0x48")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x400005E")]
	[FieldOffset(Offset = "0x4C")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x400005F")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x4000060")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x1700000D")]
	private Material material
	{
		[Token(Token = "0x600003A")]
		[Address(RVA = "0x5B47D8", Offset = "0x5B47D8", VA = "0x5B47D8")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600003B")]
	[Address(RVA = "0x5B489C", Offset = "0x5B489C", VA = "0x5B489C")]
	private void Start()
	{
	}

	[Token(Token = "0x600003C")]
	[Address(RVA = "0x5B4954", Offset = "0x5B4954", VA = "0x5B4954")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600003D")]
	[Address(RVA = "0x5B4D48", Offset = "0x5B4D48", VA = "0x5B4D48")]
	private void Update()
	{
	}

	[Token(Token = "0x600003E")]
	[Address(RVA = "0x5B4D4C", Offset = "0x5B4D4C", VA = "0x5B4D4C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600003F")]
	[Address(RVA = "0x5B4DFC", Offset = "0x5B4DFC", VA = "0x5B4DFC")]
	public CameraFilterPack_3D_Fog_Smoke()
	{
	}
}
