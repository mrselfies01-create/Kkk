using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000123")]
public class CameraFilterPack_Vision_Aura : MonoBehaviour
{
	[Token(Token = "0x4000833")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000834")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000835")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000836")]
	[FieldOffset(Offset = "0x30")]
	public float Twist;

	[Token(Token = "0x4000837")]
	[FieldOffset(Offset = "0x34")]
	public float Speed;

	[Token(Token = "0x4000838")]
	[FieldOffset(Offset = "0x38")]
	public Color Color;

	[Token(Token = "0x4000839")]
	[FieldOffset(Offset = "0x48")]
	public float PosX;

	[Token(Token = "0x400083A")]
	[FieldOffset(Offset = "0x4C")]
	public float PosY;

	[Token(Token = "0x17000124")]
	private Material material
	{
		[Token(Token = "0x6000729")]
		[Address(RVA = "0x63D198", Offset = "0x63D198", VA = "0x63D198")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600072A")]
	[Address(RVA = "0x63D25C", Offset = "0x63D25C", VA = "0x63D25C")]
	private void Start()
	{
	}

	[Token(Token = "0x600072B")]
	[Address(RVA = "0x63D2D8", Offset = "0x63D2D8", VA = "0x63D2D8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600072C")]
	[Address(RVA = "0x63D584", Offset = "0x63D584", VA = "0x63D584")]
	private void Update()
	{
	}

	[Token(Token = "0x600072D")]
	[Address(RVA = "0x63D588", Offset = "0x63D588", VA = "0x63D588")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600072E")]
	[Address(RVA = "0x63D638", Offset = "0x63D638", VA = "0x63D638")]
	public CameraFilterPack_Vision_Aura()
	{
	}
}
