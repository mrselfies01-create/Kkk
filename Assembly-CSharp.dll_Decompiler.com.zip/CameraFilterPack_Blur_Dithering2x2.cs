using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000049")]
public class CameraFilterPack_Blur_Dithering2x2 : MonoBehaviour
{
	[Token(Token = "0x40002AE")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40002AF")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40002B0")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40002B1")]
	[FieldOffset(Offset = "0x30")]
	public int Level;

	[Token(Token = "0x40002B2")]
	[FieldOffset(Offset = "0x34")]
	public Vector2 Distance;

	[Token(Token = "0x1700004A")]
	private Material material
	{
		[Token(Token = "0x60001E7")]
		[Address(RVA = "0x6660EC", Offset = "0x6660EC", VA = "0x6660EC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60001E8")]
	[Address(RVA = "0x6661B0", Offset = "0x6661B0", VA = "0x6661B0")]
	private void Start()
	{
	}

	[Token(Token = "0x60001E9")]
	[Address(RVA = "0x66622C", Offset = "0x66622C", VA = "0x66622C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60001EA")]
	[Address(RVA = "0x6664A8", Offset = "0x6664A8", VA = "0x6664A8")]
	private void Update()
	{
	}

	[Token(Token = "0x60001EB")]
	[Address(RVA = "0x6664AC", Offset = "0x6664AC", VA = "0x6664AC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60001EC")]
	[Address(RVA = "0x66655C", Offset = "0x66655C", VA = "0x66655C")]
	public CameraFilterPack_Blur_Dithering2x2()
	{
	}
}
