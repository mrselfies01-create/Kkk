using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200000B")]
public class CameraFilterPack_3D_Distortion : MonoBehaviour
{
	[Token(Token = "0x4000046")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000047")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000048")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000049")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x400004A")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x400004B")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x400004C")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x400004D")]
	[FieldOffset(Offset = "0x3C")]
	public float DistortionLevel;

	[Token(Token = "0x400004E")]
	[FieldOffset(Offset = "0x40")]
	public float DistortionSize;

	[Token(Token = "0x400004F")]
	[FieldOffset(Offset = "0x44")]
	public float LightIntensity;

	[Token(Token = "0x4000050")]
	[FieldOffset(Offset = "0x48")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x4000051")]
	[FieldOffset(Offset = "0x4C")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x4000052")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x1700000C")]
	private Material material
	{
		[Token(Token = "0x6000034")]
		[Address(RVA = "0x5B41DC", Offset = "0x5B41DC", VA = "0x5B41DC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000035")]
	[Address(RVA = "0x5B42A0", Offset = "0x5B42A0", VA = "0x5B42A0")]
	private void Start()
	{
	}

	[Token(Token = "0x6000036")]
	[Address(RVA = "0x5B431C", Offset = "0x5B431C", VA = "0x5B431C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000037")]
	[Address(RVA = "0x5B46EC", Offset = "0x5B46EC", VA = "0x5B46EC")]
	private void Update()
	{
	}

	[Token(Token = "0x6000038")]
	[Address(RVA = "0x5B46F0", Offset = "0x5B46F0", VA = "0x5B46F0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000039")]
	[Address(RVA = "0x5B47A0", Offset = "0x5B47A0", VA = "0x5B47A0")]
	public CameraFilterPack_3D_Distortion()
	{
	}
}
