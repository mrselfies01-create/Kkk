using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000ED")]
public class CameraFilterPack_Noise_TV_3 : MonoBehaviour
{
	[Token(Token = "0x40006E3")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006E4")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006E5")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006E6")]
	[FieldOffset(Offset = "0x30")]
	public float Fade;

	[Token(Token = "0x40006E7")]
	[FieldOffset(Offset = "0x34")]
	public float Fade_Additive;

	[Token(Token = "0x40006E8")]
	[FieldOffset(Offset = "0x38")]
	public float Fade_Distortion;

	[Token(Token = "0x40006E9")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x40006EA")]
	[FieldOffset(Offset = "0x40")]
	private Texture2D Texture2;

	[Token(Token = "0x170000EE")]
	private Material material
	{
		[Token(Token = "0x60005E0")]
		[Address(RVA = "0x62DA1C", Offset = "0x62DA1C", VA = "0x62DA1C")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005E1")]
	[Address(RVA = "0x62DAE0", Offset = "0x62DAE0", VA = "0x62DAE0")]
	private void Start()
	{
	}

	[Token(Token = "0x60005E2")]
	[Address(RVA = "0x62DB98", Offset = "0x62DB98", VA = "0x62DB98")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005E3")]
	[Address(RVA = "0x62DE40", Offset = "0x62DE40", VA = "0x62DE40")]
	private void Update()
	{
	}

	[Token(Token = "0x60005E4")]
	[Address(RVA = "0x62DE44", Offset = "0x62DE44", VA = "0x62DE44")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005E5")]
	[Address(RVA = "0x62DEF4", Offset = "0x62DEF4", VA = "0x62DEF4")]
	public CameraFilterPack_Noise_TV_3()
	{
	}
}
