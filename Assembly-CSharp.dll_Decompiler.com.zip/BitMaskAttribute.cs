using System;
using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000002")]
public class BitMaskAttribute : PropertyAttribute
{
	[Token(Token = "0x4000001")]
	[FieldOffset(Offset = "0x10")]
	public Type propType;

	[Token(Token = "0x6000001")]
	[Address(RVA = "0x5B0EBC", Offset = "0x5B0EBC", VA = "0x5B0EBC")]
	public BitMaskAttribute(Type aType)
	{
	}
}
