using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000BF")]
public class CameraFilterPack_FX_ZebraColor : MonoBehaviour
{
	[Token(Token = "0x400056F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000570")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000571")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000572")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x170000C0")]
	private Material material
	{
		[Token(Token = "0x60004AE")]
		[Address(RVA = "0x69D4EC", Offset = "0x69D4EC", VA = "0x69D4EC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60004AF")]
	[Address(RVA = "0x69D5B0", Offset = "0x69D5B0", VA = "0x69D5B0")]
	private void Start()
	{
	}

	[Token(Token = "0x60004B0")]
	[Address(RVA = "0x69D62C", Offset = "0x69D62C", VA = "0x69D62C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60004B1")]
	[Address(RVA = "0x69D844", Offset = "0x69D844", VA = "0x69D844")]
	private void Update()
	{
	}

	[Token(Token = "0x60004B2")]
	[Address(RVA = "0x69D848", Offset = "0x69D848", VA = "0x69D848")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60004B3")]
	[Address(RVA = "0x69D8F8", Offset = "0x69D8F8", VA = "0x69D8F8")]
	public CameraFilterPack_FX_ZebraColor()
	{
	}
}
