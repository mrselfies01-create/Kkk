using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x20000E8")]
public class CameraFilterPack_NewGlitch7 : MonoBehaviour
{
	[Token(Token = "0x40006B2")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x40006B3")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x40006B4")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40006B5")]
	[FieldOffset(Offset = "0x30")]
	public float __Speed;

	[Token(Token = "0x40006B6")]
	[FieldOffset(Offset = "0x34")]
	public float _LightMin;

	[Token(Token = "0x40006B7")]
	[FieldOffset(Offset = "0x38")]
	public float _LightMax;

	[Token(Token = "0x170000E9")]
	private Material material
	{
		[Token(Token = "0x60005C0")]
		[Address(RVA = "0x62BA98", Offset = "0x62BA98", VA = "0x62BA98")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60005C1")]
	[Address(RVA = "0x62BB5C", Offset = "0x62BB5C", VA = "0x62BB5C")]
	private void Start()
	{
	}

	[Token(Token = "0x60005C2")]
	[Address(RVA = "0x62BBD8", Offset = "0x62BBD8", VA = "0x62BBD8")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60005C3")]
	[Address(RVA = "0x62BE38", Offset = "0x62BE38", VA = "0x62BE38")]
	private void Update()
	{
	}

	[Token(Token = "0x60005C4")]
	[Address(RVA = "0x62BE3C", Offset = "0x62BE3C", VA = "0x62BE3C")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60005C5")]
	[Address(RVA = "0x62BEEC", Offset = "0x62BEEC", VA = "0x62BEEC")]
	public CameraFilterPack_NewGlitch7()
	{
	}
}
