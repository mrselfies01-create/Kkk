using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000009")]
public class CameraFilterPack_3D_BlackHole : MonoBehaviour
{
	[Token(Token = "0x400002E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400002F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000030")]
	[FieldOffset(Offset = "0x24")]
	public bool _Visualize;

	[Token(Token = "0x4000031")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000032")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000033")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x4000034")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x4000035")]
	[FieldOffset(Offset = "0x3C")]
	public float DistortionLevel;

	[Token(Token = "0x4000036")]
	[FieldOffset(Offset = "0x40")]
	public float DistortionSize;

	[Token(Token = "0x4000037")]
	[FieldOffset(Offset = "0x44")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x4000038")]
	[FieldOffset(Offset = "0x48")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x4000039")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x1700000A")]
	private Material material
	{
		[Token(Token = "0x6000028")]
		[Address(RVA = "0x5B35FC", Offset = "0x5B35FC", VA = "0x5B35FC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000029")]
	[Address(RVA = "0x5B36C0", Offset = "0x5B36C0", VA = "0x5B36C0")]
	private void Start()
	{
	}

	[Token(Token = "0x600002A")]
	[Address(RVA = "0x5B373C", Offset = "0x5B373C", VA = "0x5B373C")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600002B")]
	[Address(RVA = "0x5B3ACC", Offset = "0x5B3ACC", VA = "0x5B3ACC")]
	private void Update()
	{
	}

	[Token(Token = "0x600002C")]
	[Address(RVA = "0x5B3AD0", Offset = "0x5B3AD0", VA = "0x5B3AD0")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600002D")]
	[Address(RVA = "0x5B3B80", Offset = "0x5B3B80", VA = "0x5B3B80")]
	public CameraFilterPack_3D_BlackHole()
	{
	}
}
