using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000129")]
public class CameraFilterPack_Vision_Hell_Blood : MonoBehaviour
{
	[Token(Token = "0x400085F")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000860")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000861")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000862")]
	[FieldOffset(Offset = "0x30")]
	public float Hole_Size;

	[Token(Token = "0x4000863")]
	[FieldOffset(Offset = "0x34")]
	public float Hole_Smooth;

	[Token(Token = "0x4000864")]
	[FieldOffset(Offset = "0x38")]
	public float Hole_Speed;

	[Token(Token = "0x4000865")]
	[FieldOffset(Offset = "0x3C")]
	public float Intensity;

	[Token(Token = "0x4000866")]
	[FieldOffset(Offset = "0x40")]
	public Color ColorBlood;

	[Token(Token = "0x4000867")]
	[FieldOffset(Offset = "0x50")]
	public float BloodAlternative1;

	[Token(Token = "0x4000868")]
	[FieldOffset(Offset = "0x54")]
	public float BloodAlternative2;

	[Token(Token = "0x4000869")]
	[FieldOffset(Offset = "0x58")]
	public float BloodAlternative3;

	[Token(Token = "0x1700012A")]
	private Material material
	{
		[Token(Token = "0x600074D")]
		[Address(RVA = "0x63EE14", Offset = "0x63EE14", VA = "0x63EE14")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600074E")]
	[Address(RVA = "0x63EED8", Offset = "0x63EED8", VA = "0x63EED8")]
	private void Start()
	{
	}

	[Token(Token = "0x600074F")]
	[Address(RVA = "0x63EF54", Offset = "0x63EF54", VA = "0x63EF54")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000750")]
	[Address(RVA = "0x63F274", Offset = "0x63F274", VA = "0x63F274")]
	private void Update()
	{
	}

	[Token(Token = "0x6000751")]
	[Address(RVA = "0x63F278", Offset = "0x63F278", VA = "0x63F278")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000752")]
	[Address(RVA = "0x63F328", Offset = "0x63F328", VA = "0x63F328")]
	public CameraFilterPack_Vision_Hell_Blood()
	{
	}
}
