using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000011")]
public class CameraFilterPack_3D_Myst : MonoBehaviour
{
	[Token(Token = "0x4000092")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000093")]
	[FieldOffset(Offset = "0x20")]
	public bool _Visualize;

	[Token(Token = "0x4000094")]
	[FieldOffset(Offset = "0x24")]
	private float TimeX;

	[Token(Token = "0x4000095")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000096")]
	[FieldOffset(Offset = "0x30")]
	public float _FixDistance;

	[Token(Token = "0x4000097")]
	[FieldOffset(Offset = "0x34")]
	public float _Distance;

	[Token(Token = "0x4000098")]
	[FieldOffset(Offset = "0x38")]
	public float _Size;

	[Token(Token = "0x4000099")]
	[FieldOffset(Offset = "0x3C")]
	public float DistortionLevel;

	[Token(Token = "0x400009A")]
	[FieldOffset(Offset = "0x40")]
	public float DistortionSize;

	[Token(Token = "0x400009B")]
	[FieldOffset(Offset = "0x44")]
	public float LightIntensity;

	[Token(Token = "0x400009C")]
	[FieldOffset(Offset = "0x48")]
	public bool AutoAnimatedNear;

	[Token(Token = "0x400009D")]
	[FieldOffset(Offset = "0x4C")]
	public float AutoAnimatedNearSpeed;

	[Token(Token = "0x400009E")]
	[FieldOffset(Offset = "0x50")]
	private Texture2D Texture2;

	[Token(Token = "0x400009F")]
	[FieldOffset(Offset = "0x0")]
	public static Color ChangeColorRGB;

	[Token(Token = "0x17000012")]
	private Material material
	{
		[Token(Token = "0x6000058")]
		[Address(RVA = "0x5B6578", Offset = "0x5B6578", VA = "0x5B6578")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000059")]
	[Address(RVA = "0x5B663C", Offset = "0x5B663C", VA = "0x5B663C")]
	private void Start()
	{
	}

	[Token(Token = "0x600005A")]
	[Address(RVA = "0x5B66F4", Offset = "0x5B66F4", VA = "0x5B66F4")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600005B")]
	[Address(RVA = "0x5B6AE8", Offset = "0x5B6AE8", VA = "0x5B6AE8")]
	private void Update()
	{
	}

	[Token(Token = "0x600005C")]
	[Address(RVA = "0x5B6AEC", Offset = "0x5B6AEC", VA = "0x5B6AEC")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600005D")]
	[Address(RVA = "0x5B6B9C", Offset = "0x5B6B9C", VA = "0x5B6B9C")]
	public CameraFilterPack_3D_Myst()
	{
	}
}
