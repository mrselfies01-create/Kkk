using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200008F")]
public class CameraFilterPack_Drawing_Manga2 : MonoBehaviour
{
	[Token(Token = "0x400044E")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400044F")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000450")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x4000451")]
	[FieldOffset(Offset = "0x30")]
	public float DotSize;

	[Token(Token = "0x17000090")]
	private Material material
	{
		[Token(Token = "0x600038D")]
		[Address(RVA = "0x6904A0", Offset = "0x6904A0", VA = "0x6904A0")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x600038E")]
	[Address(RVA = "0x690564", Offset = "0x690564", VA = "0x690564")]
	private void Start()
	{
	}

	[Token(Token = "0x600038F")]
	[Address(RVA = "0x6905E0", Offset = "0x6905E0", VA = "0x6905E0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x6000390")]
	[Address(RVA = "0x690764", Offset = "0x690764", VA = "0x690764")]
	private void Update()
	{
	}

	[Token(Token = "0x6000391")]
	[Address(RVA = "0x690768", Offset = "0x690768", VA = "0x690768")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x6000392")]
	[Address(RVA = "0x690818", Offset = "0x690818", VA = "0x690818")]
	public CameraFilterPack_Drawing_Manga2()
	{
	}
}
