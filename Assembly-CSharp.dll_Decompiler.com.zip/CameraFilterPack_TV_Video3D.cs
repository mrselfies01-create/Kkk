using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x200011A")]
public class CameraFilterPack_TV_Video3D : MonoBehaviour
{
	[Token(Token = "0x4000802")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x4000803")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x4000804")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x1700011B")]
	private Material material
	{
		[Token(Token = "0x60006F3")]
		[Address(RVA = "0x63AB60", Offset = "0x63AB60", VA = "0x63AB60")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x60006F4")]
	[Address(RVA = "0x63AC24", Offset = "0x63AC24", VA = "0x63AC24")]
	private void Start()
	{
	}

	[Token(Token = "0x60006F5")]
	[Address(RVA = "0x63ACA0", Offset = "0x63ACA0", VA = "0x63ACA0")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x60006F6")]
	[Address(RVA = "0x63AE94", Offset = "0x63AE94", VA = "0x63AE94")]
	private void Update()
	{
	}

	[Token(Token = "0x60006F7")]
	[Address(RVA = "0x63AE98", Offset = "0x63AE98", VA = "0x63AE98")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x60006F8")]
	[Address(RVA = "0x63AF48", Offset = "0x63AF48", VA = "0x63AF48")]
	public CameraFilterPack_TV_Video3D()
	{
	}
}
