using Il2CppDummyDll;
using UnityEngine;

[Token(Token = "0x2000130")]
public class CameraFilterPack_Vision_Warp2 : MonoBehaviour
{
	[Token(Token = "0x400089D")]
	[FieldOffset(Offset = "0x18")]
	public Shader SCShader;

	[Token(Token = "0x400089E")]
	[FieldOffset(Offset = "0x20")]
	private float TimeX;

	[Token(Token = "0x400089F")]
	[FieldOffset(Offset = "0x28")]
	private Material SCMaterial;

	[Token(Token = "0x40008A0")]
	[FieldOffset(Offset = "0x30")]
	public float Value;

	[Token(Token = "0x40008A1")]
	[FieldOffset(Offset = "0x34")]
	public float Value2;

	[Token(Token = "0x40008A2")]
	[FieldOffset(Offset = "0x38")]
	public float Intensity;

	[Token(Token = "0x40008A3")]
	[FieldOffset(Offset = "0x3C")]
	private float Value4;

	[Token(Token = "0x17000131")]
	private Material material
	{
		[Token(Token = "0x6000777")]
		[Address(RVA = "0x6410BC", Offset = "0x6410BC", VA = "0x6410BC")]
		get
		{
			return null;
		}
	}

	[Token(Token = "0x6000778")]
	[Address(RVA = "0x641180", Offset = "0x641180", VA = "0x641180")]
	private void Start()
	{
	}

	[Token(Token = "0x6000779")]
	[Address(RVA = "0x6411FC", Offset = "0x6411FC", VA = "0x6411FC")]
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
	}

	[Token(Token = "0x600077A")]
	[Address(RVA = "0x641480", Offset = "0x641480", VA = "0x641480")]
	private void Update()
	{
	}

	[Token(Token = "0x600077B")]
	[Address(RVA = "0x641484", Offset = "0x641484", VA = "0x641484")]
	private void OnDisable()
	{
	}

	[Token(Token = "0x600077C")]
	[Address(RVA = "0x641534", Offset = "0x641534", VA = "0x641534")]
	public CameraFilterPack_Vision_Warp2()
	{
	}
}
