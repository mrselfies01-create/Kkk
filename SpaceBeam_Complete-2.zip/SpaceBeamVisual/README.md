# SpaceBeam — Full Source

Real-time visual synthesizer for Android. OpenGL ES 2.0 GLSL shader pipeline.

## Architecture

```
Sources → Mixer → CameraTransform → Color → EdgeDetect →
Kaleidoscope → MasterTransform → Tunnel → Swirl →
SpiritVisual → AtmosphereThreshold → MotionRipple → Screen
```

## Module Map

| Package | Contents |
|---------|----------|
| `engine/` | GlProgram, Fbo, QuadRenderer |
| `effects/` | EffectChain (full GL renderer) |
| `sources/` | CameraSource, RtspSource, GenerativeSource, FeedbackSource |
| `modulation/` | Param (LFO+sensor+smooth), ParamStore |
| `dsp/` | DspPassthrough (mic→IIR filters→gate→speaker) |
| `midi/` | MidiController (BT MIDI learn+map) |
| `ui/` | MainActivity |
| `assets/shaders/` | All GLSL shaders |

## Build Requirements

- Android Studio Hedgehog or newer
- Android SDK 35
- Gradle 8.10.2 / AGP 8.8.0 / Kotlin 2.1.21
- Physical device (OpenGL ES 2.0 required)

## Key Features

- **12 effects** via GLSL: Kaleidoscope, Tunnel, Swirl, Edge, Color, Spirit Visual,
  Atmosphere Threshold, Motion Ripple, RGB Shift, Pixel Grid, Laser Grid, Parallax
- **4 source types**: Camera (CameraX OES), RTSP (ExoPlayer), Generative, Feedback loop
- **LFO** per parameter: Sine, Triangle, Ramp, Wobble, Random — BPM-syncable
- **Sensor modulation**: Pitch, Roll, Yaw, Accel X/Y/Z per parameter
- **9 preset slots** with smooth transitions
- **Bluetooth MIDI** CC learn & map
- **DSP audio passthrough**: mic → LP/HP IIR filters → noise gate → atmosphere guard → speaker
- **Two-finger gestures** → Master Transform (zoom/rotate/pan)
- **MediaCodec H.264** recording to Movies/SpaceBeam
- **Auto-play** cycling through presets
