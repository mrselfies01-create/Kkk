precision highp float;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vTexCoord;
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
void main(){
    vec2 uv=vTexCoord*uResolution/min(uResolution.x,uResolution.y);
    float v=sin(uv.x*3.+uTime)+sin(uv.y*3.+uTime)+sin((uv.x+uv.y)*2.+uTime)+sin(sqrt(dot(uv,uv))*4.+uTime);
    gl_FragColor=vec4(hsv2rgb(vec3(v*.25+.5,.9,1.)),1.);
}
