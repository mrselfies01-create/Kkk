precision highp float;
uniform float uTime;
varying vec2 vTexCoord;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){
    vec2 uv=vTexCoord-.5;
    float z=fract(hash(floor(uv*20.))*uTime*.1+uTime*.05);
    float r=hash(floor(uv*20.)+1.);
    float star=smoothstep(.97,.99,r)*smoothstep(z,0.,length(fract(uv*20.)-.5)*.5);
    gl_FragColor=vec4(vec3(star),1.);
}
