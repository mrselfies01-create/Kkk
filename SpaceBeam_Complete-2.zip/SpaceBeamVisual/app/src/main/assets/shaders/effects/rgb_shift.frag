precision mediump float;
uniform sampler2D uTex;
uniform float uShift;
varying vec2 vTexCoord;
void main(){
    float r=texture2D(uTex,vTexCoord+vec2(uShift,0.)).r;
    float g=texture2D(uTex,vTexCoord).g;
    float b=texture2D(uTex,vTexCoord-vec2(uShift,0.)).b;
    gl_FragColor=vec4(r,g,b,1.);
}
