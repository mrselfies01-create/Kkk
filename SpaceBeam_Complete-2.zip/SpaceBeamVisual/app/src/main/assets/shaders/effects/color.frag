precision mediump float;
uniform sampler2D uTex;
uniform sampler2D uBlurTex;
uniform float uBrightness;
uniform float uContrast;
uniform float uSaturation;
uniform float uHueShift;
uniform float uNegative;
uniform float uGlow;
varying vec2 vTexCoord;
vec3 rgb2hsv(vec3 c){
    vec4 K=vec4(0.,-1./3.,2./3.,-1.);
    vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));
    vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));
    float d=q.x-min(q.w,q.y),e=1e-10;
    return vec3(abs(q.z+(q.w-q.y)/(6.*d+e)),d/(q.x+e),q.x);
}
vec3 hsv2rgb(vec3 c){
    vec4 K=vec4(1.,2./3.,1./3.,3.);
    vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);
    return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);
}
void main(){
    vec4 col=texture2D(uTex,vTexCoord);
    col.rgb=(col.rgb-0.5)*uContrast+0.5+uBrightness;
    vec3 hsv=rgb2hsv(col.rgb);
    hsv.x=fract(hsv.x+uHueShift);
    hsv.y=clamp(hsv.y*uSaturation,0.,1.);
    col.rgb=hsv2rgb(hsv);
    col.rgb=mix(col.rgb,1.-col.rgb,uNegative);
    col.rgb+=texture2D(uBlurTex,vTexCoord).rgb*uGlow*0.6;
    gl_FragColor=vec4(clamp(col.rgb,0.,1.),1.);
}
