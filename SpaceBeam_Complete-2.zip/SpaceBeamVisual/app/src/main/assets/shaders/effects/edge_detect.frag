precision mediump float;
uniform sampler2D uTex;
uniform float uAmount,uThreshold,uHue,uSaturation;
uniform vec2 uTexelSize;
varying vec2 vTexCoord;
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
float lum(vec3 c){return dot(c,vec3(.299,.587,.114));}
void main(){
    vec2 t=uTexelSize;
    float tl=lum(texture2D(uTex,vTexCoord+vec2(-t.x,t.y)).rgb);
    float tm=lum(texture2D(uTex,vTexCoord+vec2(0.,t.y)).rgb);
    float tr=lum(texture2D(uTex,vTexCoord+vec2(t.x,t.y)).rgb);
    float ml=lum(texture2D(uTex,vTexCoord+vec2(-t.x,0.)).rgb);
    float mr=lum(texture2D(uTex,vTexCoord+vec2(t.x,0.)).rgb);
    float bl=lum(texture2D(uTex,vTexCoord+vec2(-t.x,-t.y)).rgb);
    float bm=lum(texture2D(uTex,vTexCoord+vec2(0.,-t.y)).rgb);
    float br=lum(texture2D(uTex,vTexCoord+vec2(t.x,-t.y)).rgb);
    float gx=-tl-2.*ml-bl+tr+2.*mr+br;
    float gy=-tl-2.*tm-tr+bl+2.*bm+br;
    float edge=smoothstep(uThreshold*.3,uThreshold*.6,sqrt(gx*gx+gy*gy));
    vec3 src=texture2D(uTex,vTexCoord).rgb;
    vec3 ec=hsv2rgb(vec3(uHue,uSaturation,edge));
    gl_FragColor=vec4(mix(src,ec,uAmount),1.);
}
