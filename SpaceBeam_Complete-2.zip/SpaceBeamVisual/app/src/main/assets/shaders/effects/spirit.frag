precision highp float;
uniform sampler2D uCurrent,uPrevious,uTrail;
uniform float uSensitivity,uTrailDecay,uHue,uStrength,uFocusIntensity;
varying vec2 vTexCoord;
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
void main(){
    vec3 cur=texture2D(uCurrent,vTexCoord).rgb;
    vec3 prev=texture2D(uPrevious,vTexCoord).rgb;
    vec3 trail=texture2D(uTrail,vTexCoord).rgb;
    float diff=length(cur-prev);
    float eff=clamp(uSensitivity*(1.-uFocusIntensity*.6),.002,1.);
    float energy=clamp((diff-eff)*(3.+uFocusIntensity*2.),0.,1.);
    vec3 sc=hsv2rgb(vec3(uHue,.86,energy));
    vec3 newTrail=clamp(trail*uTrailDecay+sc*(1.-uTrailDecay)*(1.+uFocusIntensity),0.,1.);
    vec3 out_col=clamp(cur*.3+newTrail*uStrength*(1.+uFocusIntensity*.5),0.,1.);
    gl_FragColor=vec4(out_col,1.);
}
