precision mediump float;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform float uRadius;
varying vec2 vTexCoord;
void main(){
    vec4 col=vec4(0.);float total=0.;
    for(float i=-8.;i<=8.;i+=1.){
        float w=exp(-.5*(i/max(uRadius,1.))*(i/max(uRadius,1.)));
        col+=texture2D(uTex,vTexCoord+uDirection*i)*w;total+=w;
    }
    gl_FragColor=col/total;
}
