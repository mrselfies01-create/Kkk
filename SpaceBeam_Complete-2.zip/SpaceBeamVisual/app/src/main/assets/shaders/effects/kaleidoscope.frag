precision highp float;
uniform sampler2D uTex;
uniform float uAxes,uAmount,uKZoom,uAngleOffset;
varying vec2 vTexCoord;
void main(){
    vec2 uv=vTexCoord-0.5;
    float r=length(uv)*uKZoom;
    float a=atan(uv.y,uv.x)+uAngleOffset;
    float slice=3.14159265/uAxes;
    float ka=mod(a,2.*slice);
    if(ka>slice)ka=2.*slice-ka;
    vec2 kUV=vec2(cos(ka),sin(ka))*r+0.5;
    vec4 orig=texture2D(uTex,vTexCoord);
    vec4 kale=texture2D(uTex,kUV);
    gl_FragColor=mix(orig,kale,uAmount);
}
