precision highp float;
uniform sampler2D uTex;
uniform float uStrength,uWideness,uActivity,uSpeed,uTime,uFogDist,uFogSoft;
uniform vec3 uFogColor;
varying vec2 vTexCoord;
void main(){
    if(uStrength<.01){gl_FragColor=texture2D(uTex,vTexCoord);return;}
    vec2 uv=vTexCoord-.5;
    float r=length(uv);
    float sway=1.+uActivity*sin(uTime*2.);
    float twist=uStrength*6.*exp(-r/(uWideness*.7+.01))*sway;
    float angle=atan(uv.y,uv.x)+twist;
    vec2 warped=clamp(vec2(cos(angle),sin(angle))*r+.5,0.,1.);
    vec3 col=texture2D(uTex,warped).rgb;
    if(uFogDist>.01)col=mix(col,uFogColor,uFogDist*uFogSoft*smoothstep(0.,1.,r*2.));
    gl_FragColor=vec4(col,1.);
}
