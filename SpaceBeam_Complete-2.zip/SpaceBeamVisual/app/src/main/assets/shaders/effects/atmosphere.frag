precision highp float;
uniform sampler2D uTex,uBlurTex;
uniform float uThreshold,uStrength,uHue,uBlur,uFocusIntensity,uTime;
varying vec2 vTexCoord;
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
void main(){
    vec4 src=texture2D(uTex,vTexCoord);
    float lum=dot(src.rgb,vec3(.299,.587,.114));
    float thr=clamp(uThreshold*(1.-uFocusIntensity*.5),.04,.98);
    float mask=smoothstep(thr,thr+.1,lum);
    vec3 auraCol=hsv2rgb(vec3(uHue,.86,1.));
    vec3 blurred=texture2D(uBlurTex,vTexCoord).rgb;
    float pulse=.5+.5*sin(uTime*2.5);
    vec3 aura=mix(auraCol*mask,blurred*mask,uBlur)*(.7+.3*pulse);
    gl_FragColor=vec4(clamp(src.rgb+aura*uStrength,0.,1.),1.);
}
