precision highp float;
uniform sampler2D uTex,uMotionMask;
uniform float uRippleStr,uRippleFreq,uTime,uFocusIntensity;
varying vec2 vTexCoord;
void main(){
    float mw=texture2D(uMotionMask,vTexCoord).r;
    vec2 d=vTexCoord-vec2(.5);
    float r=length(d)*uRippleFreq*40.;
    float str=uRippleStr*.03*mw*(.5+uFocusIntensity*.5);
    vec2 offset=normalize(d+vec2(1e-6))*str*sin(r-uTime*6.28318);
    gl_FragColor=texture2D(uTex,clamp(vTexCoord+offset,0.,1.));
}
