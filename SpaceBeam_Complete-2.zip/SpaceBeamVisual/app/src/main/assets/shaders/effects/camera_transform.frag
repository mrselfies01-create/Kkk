precision highp float;
uniform sampler2D uTex;
uniform float uAngle;
uniform float uZoom;
uniform vec2  uMove;
uniform vec2  uTilt;
uniform float uBend;
uniform float uWobble;
uniform float uTime;
varying vec2 vTexCoord;
vec2 rot2(vec2 uv, float a) {
    float c=cos(a),s=sin(a);
    return vec2(c*uv.x-s*uv.y, s*uv.x+c*uv.y);
}
void main() {
    vec2 uv = vTexCoord - 0.5;
    uv.x += uWobble*0.04*sin(uv.y*12.0+uTime*3.0);
    uv.y += uWobble*0.04*sin(uv.x*12.0+uTime*2.3);
    uv.x *= 1.0+uTilt.x*uv.y;
    uv.y *= 1.0+uTilt.y*uv.x;
    uv *= 1.0+uBend*dot(uv,uv);
    uv = rot2(uv,uAngle)/max(uZoom,0.05);
    uv += uMove*0.3 + 0.5;
    uv = abs(fract(uv*0.5)*2.0-1.0);
    gl_FragColor = texture2D(uTex, uv);
}
