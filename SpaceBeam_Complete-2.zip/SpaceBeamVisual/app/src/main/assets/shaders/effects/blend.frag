precision mediump float;
uniform sampler2D uTexA,uTexB;
uniform float uAlpha;
uniform int uBlendMode;
varying vec2 vTexCoord;
vec3 blendOverlay(vec3 a,vec3 b){return mix(2.*a*b,1.-2.*(1.-a)*(1.-b),step(.5,a));}
void main(){
    vec3 a=texture2D(uTexA,vTexCoord).rgb;
    vec3 b=texture2D(uTexB,vTexCoord).rgb;
    vec3 r;
    if(uBlendMode==1)r=a+b;
    else if(uBlendMode==2)r=1.-(1.-a)*(1.-b);
    else if(uBlendMode==3)r=a*b;
    else if(uBlendMode==4)r=abs(a-b);
    else if(uBlendMode==5)r=blendOverlay(a,b);
    else if(uBlendMode==6)r=max(a,b);
    else if(uBlendMode==7)r=min(a,b);
    else if(uBlendMode==8)r=max(a-b,vec3(0.));
    else{gl_FragColor=vec4(mix(a,b,uAlpha),1.);return;}
    gl_FragColor=vec4(clamp(mix(a,r,uAlpha),0.,1.),1.);
}
