precision highp float;
uniform sampler2D uTex;
uniform float uStrength,uShape,uFisheye,uSpeed,uTime;
uniform float uFogDist,uRainbowStr,uWaveStr,uCurve,uVortex;
uniform vec3 uFogColor;
varying vec2 vTexCoord;
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
void main(){
    vec2 uv=vTexCoord-0.5;
    float vr=length(uv);
    float va=atan(uv.y,uv.x)+uVortex*2.*exp(-vr*3.)*sin(uTime*.5);
    uv=vec2(cos(va),sin(va))*vr;
    uv.x+=uCurve*uv.y*uv.y*.5;
    float r=length(uv);
    if(uFisheye>0.){float k=uFisheye*2.;r=r*(1.+k*r*r)/(1.+k);}
    float ang=atan(uv.y,uv.x);
    float t=uStrength>0.?fract(1./(r+.001+uStrength)+uTime*uSpeed*uStrength):r;
    float sq=max(abs(uv.x),abs(uv.y))*2.;
    t=mix(t,fract(sq*.5+uTime*uSpeed*.5),uShape);
    t+=uWaveStr*.15*sin(t*20.+uTime*2.);
    vec3 col=texture2D(uTex,vec2(ang/(6.28318)+.5,t)).rgb;
    if(uRainbowStr>0.)col=mix(col,col*hsv2rgb(vec3(fract(t+uTime*.1),.9,1.)),uRainbowStr);
    col=mix(col,uFogColor,smoothstep(0.,uFogDist+.001,1.-t)*uFogDist);
    gl_FragColor=vec4(col,1.);
}
