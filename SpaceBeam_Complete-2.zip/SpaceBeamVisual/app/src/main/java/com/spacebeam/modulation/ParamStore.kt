package com.spacebeam.modulation

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/** Central registry of all effect parameters. */
object ParamStore : SensorEventListener {

    // Sensor values (normalised -1..1)
    private val sensorVals = mutableMapOf<SensorAxis, Float>()

    val all = linkedMapOf<String, Param>()

    init { buildParams() }

    private fun buildParams() {
        fun p(key: String, label: String, min: Float = 0f, max: Float = 1000f, default: Float = 500f, locked: Boolean = false) =
            all.put(key, Param(key, label, min, max, default, locked))

        // ── MIXER ──────────────────────────────────────────────────────────
        p("CAMERA",    "Camera",       default=1000f)
        // ── CAMERA TRANSFORM ──────────────────────────────────────────────
        p("CAM_ANGLE", "Angle",        default=0f)
        p("CAM_ZOOM",  "Zoom",         default=700f)
        p("MOVE_X",    "Move X",       default=500f)
        p("MOVE_Y",    "Move Y",       default=500f)
        p("TILT_X",    "Tilt X",       default=500f)
        p("TILT_Y",    "Tilt Y",       default=500f)
        p("BEND",      "Bend",         default=500f)
        p("WOBBLE",    "Wobble",       default=0f)
        p("DISTORT",   "Distort",      default=0f)
        p("RGB_SHIFT", "RGB Shift",    default=0f)
        // ── COLOR ─────────────────────────────────────────────────────────
        p("BRIGHTNESS","Brightness",   default=500f)
        p("HUE",       "Hue",         default=0f)
        p("NEGATIVE",  "Negative",    default=0f)
        p("GLOW",      "Glow",        default=0f)
        p("CONTRAST",  "Contrast",    default=500f)
        p("SATURATION","Saturation",  default=500f)
        // ── EDGE DETECT ───────────────────────────────────────────────────
        p("EDGE_AMOUNT","Amount",     default=0f)
        p("EDGE_THRESH","Threshold",  default=300f)
        p("EDGE_HUE",   "Edge Hue",  default=0f)
        p("EDGE_SAT",   "Edge Sat",  default=1000f)
        // ── KALEIDOSCOPE ──────────────────────────────────────────────────
        p("K_AXIS",    "Axes",        min=1f, max=25f, default=2f, locked=true)
        p("K_AMOUNT",  "Amount",      default=1000f)
        p("K_ZOOM",    "K-Zoom",      default=0f)
        p("K_ANGLE",   "Angle Offset",default=0f)
        // ── MASTER TRANSFORM ──────────────────────────────────────────────
        p("M_ANGLE",   "M Angle",     default=0f)
        p("M_ZOOM",    "M Zoom",      default=700f)
        p("M_MOVE_X",  "M Move X",   default=500f)
        p("M_MOVE_Y",  "M Move Y",   default=500f)
        // ── 3D TUNNEL ─────────────────────────────────────────────────────
        p("T_STRENGTH","Strength",   default=0f)
        p("T_SHAPE",   "Shape",      default=0f)
        p("FISHEYE",   "Fisheye",    default=905f)
        p("T_SPEED",   "Speed",      default=500f)
        p("T_FOG_DIST","Fog Dist",   default=0f)
        p("T_FOG_HUE", "Fog Hue",   default=0f)
        p("T_FOG_SAT", "Fog Sat",   default=0f)
        p("T_FOG_BRIT","Fog Brit",   default=1000f)
        p("RAINBOW_STR","Rainbow",   default=0f)
        p("RAINBOW_POS","Rain Pos",  default=0f)
        p("WAVE_STR",  "Wave",       default=0f)
        p("WAVE_POS",  "Wave Pos",   default=0f)
        p("CURVE",     "Curve",      default=500f)
        p("VORTEX",    "Vortex",     default=434f)
        p("FLUX",      "Flux",       default=0f)
        // ── SWIRL ─────────────────────────────────────────────────────────
        p("S_STRENGTH","Strength",   default=0f)
        p("S_WIDENESS","Wideness",   default=500f)
        p("S_ACTIVITY","Activity",   default=200f)
        p("S_SPEED",   "Speed",      default=500f)
        p("S_FOG_DIST","Fog Dist",   default=100f)
        p("S_FOG_SOFT","Fog Soft",   default=150f)
        p("S_FOG_HUE", "Fog Hue",   default=0f)
        p("S_FOG_SAT", "Fog Sat",   default=0f)
        p("S_FOG_BRIT","Fog Brit",   default=0f)
        // ── SHIELD & RIPPLE ────────────────────────────────────────────────
        p("SHIELD_STR",   "Shield",     default=0f)
        p("SHIELD_RADIUS","Sh Radius",  default=500f)
        p("RIPPLE_STR",   "Ripple",     default=0f)
        p("RIPPLE_SPEED", "Rip Speed",  default=500f)
        p("RIPPLE_FREQ",  "Rip Freq",   default=300f)
        p("NATURE_STR",   "Nature",     default=0f)
        p("NATURE_BLUR",  "Nat Blur",   default=200f)
        p("ATMOS_HUE",    "Atm Hue",    default=120f)
        p("ATMOS_SAT",    "Atm Sat",    default=400f)
        p("ATMOS_GLOW",   "Atm Glow",   default=0f)
        p("BPM",          "BPM",        min=40f, max=300f, default=120f)
        // ── SPIRIT VISUAL ─────────────────────────────────────────────────
        p("SPIRIT_SENS",  "Sensitivity",default=300f)
        p("SPIRIT_TRAIL", "Trail",      default=400f)
        p("SPIRIT_HUE",   "Hue",        default=270f)
        p("SPIRIT_STR",   "Strength",   default=500f)
        // ── ATMOSPHERE THRESHOLD ──────────────────────────────────────────
        p("ATM_THRESH",   "Threshold",  default=300f)
        p("ATM_STR",      "Strength",   default=600f)
        p("ATM_HUE",      "Hue",        default=90f)
        p("ATM_BLUR",     "Blur",       default=400f)
        // ── FOCUS / BRAIN ─────────────────────────────────────────────────
        p("FOCUS_DRIVE",  "Drive",      default=600f)
        p("FOCUS_MANUAL", "Manual",     default=500f)
        // ── MOTION ZONE ───────────────────────────────────────────────────
        p("MZ_RIPPLE_STR","MZ Ripple",  default=500f)
        p("MZ_RIPPLE_FREQ","MZ Freq",   default=400f)
        p("MZ_SMOOTH_STR","MZ Smooth",  default=400f)
        // ── DSP AUDIO PASSTHROUGH ─────────────────────────────────────────
        p("DSP_ENABLE",   "Enable",     default=0f)
        p("DSP_GAIN",     "Gain",       default=800f)
        p("DSP_LP_FREQ",  "LP Freq",    default=800f)
        p("DSP_HP_FREQ",  "HP Freq",    default=50f)
        p("DSP_GATE",     "Gate",       default=100f)
        p("DSP_GUARD",    "Atm Guard",  default=700f)
        // ── GPU ───────────────────────────────────────────────────────────
        p("GPU_QUALITY",  "Quality",    default=500f)
    }

    operator fun get(key: String): Param = all[key] ?: error("Unknown param: $key")
    fun norm(key: String) = all[key]?.norm ?: 0f
    fun raw(key: String)  = all[key]?.rawValue ?: 0f
    fun actual(key: String) = all[key]?.actualValue ?: 0f

    fun tick(dt: Float) {
        val bpm = actual("BPM")
        for (p in all.values) p.tick(dt, bpm, sensorVals[p.sensorAxis] ?: 0f)
    }

    // ── Preset system ─────────────────────────────────────────────────────────
    data class Preset(val values: Map<String, Float>)

    val presets = Array<Preset?>(9) { null }

    fun savePreset(slot: Int) {
        presets[slot] = Preset(all.mapValues { it.value.rawValue })
    }

    /** Loads preset; locked params stay untouched. */
    fun loadPreset(slot: Int) {
        val p = presets[slot] ?: return
        p.values.forEach { (k, v) ->
            val param = all[k] ?: return@forEach
            if (!param.isLocked) param.rawValue = v
        }
    }

    fun toJson(): String {
        val sb = StringBuilder("{\"presets\":[")
        presets.forEachIndexed { i, pr ->
            if (i > 0) sb.append(",")
            if (pr == null) { sb.append("null"); return@forEachIndexed }
            sb.append("{")
            pr.values.entries.forEachIndexed { j, (k, v) ->
                if (j > 0) sb.append(",")
                sb.append("\"$k\":$v")
            }
            sb.append("}")
        }
        sb.append("]}")
        return sb.toString()
    }

    // ── Sensor ────────────────────────────────────────────────────────────────
    fun registerSensors(sm: SensorManager) {
        listOf(Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_ACCELEROMETER).forEach { type ->
            sm.getDefaultSensor(type)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
    }
    fun unregisterSensors(sm: SensorManager) = sm.unregisterListener(this)

    override fun onSensorChanged(ev: SensorEvent) {
        when (ev.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                val r = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(r, ev.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(r, orientation)
                sensorVals[SensorAxis.YAW]   = orientation[0] / Math.PI.toFloat()
                sensorVals[SensorAxis.PITCH] = orientation[1] / (Math.PI.toFloat() / 2)
                sensorVals[SensorAxis.ROLL]  = orientation[2] / (Math.PI.toFloat() / 2)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                sensorVals[SensorAxis.ACCEL_X] = (ev.values[0] / SensorManager.GRAVITY_EARTH).coerceIn(-1f, 1f)
                sensorVals[SensorAxis.ACCEL_Y] = (ev.values[1] / SensorManager.GRAVITY_EARTH).coerceIn(-1f, 1f)
                sensorVals[SensorAxis.ACCEL_Z] = (ev.values[2] / SensorManager.GRAVITY_EARTH).coerceIn(-1f, 1f)
            }
        }
    }
    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
}
