package com.spacebeam.sources

import com.spacebeam.sources.InjectionPoint

/** FeedbackSource re-uses a texture produced by the EffectChain as its input.
 *  The EffectChain sets [feedTexId] each frame before the mixer runs. */
class FeedbackSource(var tapPoint: InjectionPoint = InjectionPoint.AFTER_COLOR) : Source() {

    /** Set by EffectChain each frame with the FBO tex at the tap point. */
    var feedTexId: Int = -1

    var frameDelay: Int = 0   // future: ring-buffer for multi-frame delay

    override val texId: Int get() = feedTexId
    override fun update() {}
    override fun release() {}

    init { label = "Feedback" }
}
