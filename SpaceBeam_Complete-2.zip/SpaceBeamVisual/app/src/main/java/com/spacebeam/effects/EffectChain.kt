package com.spacebeam.effects

import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.Log
import android.view.Surface
import com.spacebeam.engine.Fbo
import com.spacebeam.engine.GlProgram
import com.spacebeam.engine.QuadRenderer
import com.spacebeam.modulation.ParamStore
import com.spacebeam.sources.*
import javax.microedition.khronos.egl.EGLConfig as LegacyEglConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.roundToInt

/**
 * GLSurfaceView.Renderer that runs the full effect chain:
 *   Sources → Mixer → CameraTransform → Color → EdgeDetect →
 *   Kaleidoscope → MasterTransform → Tunnel → Swirl →
 *   SpiritVisual → AtmosphereThreshold → MotionRipple → Screen
 *
 * All effects are GLSL passes on ping-pong FBOs at 1920×1080.
 */
class EffectChain(private val context: Context) : GLSurfaceView.Renderer {

    private val TAG = "EffectChain"

    // Render resolution
    val W = 1920; val H = 1080

    private lateinit var quad: QuadRenderer

    // Programs — one per shader
    private lateinit var progPassthrough:    GlProgram
    private lateinit var progCamTransform:   GlProgram
    private lateinit var progColor:          GlProgram
    private lateinit var progEdge:           GlProgram
    private lateinit var progKaleidoscope:   GlProgram
    private lateinit var progTunnel:         GlProgram
    private lateinit var progSwirl:          GlProgram
    private lateinit var progBlur:           GlProgram
    private lateinit var progRgbShift:       GlProgram
    private lateinit var progSpirit:         GlProgram
    private lateinit var progAtmosphere:     GlProgram
    private lateinit var progMotionRipple:   GlProgram
    private lateinit var progBlend:          GlProgram

    // Ping-pong FBOs
    private lateinit var fboA: Fbo
    private lateinit var fboB: Fbo
    private lateinit var fboBlur1: Fbo
    private lateinit var fboBlur2: Fbo
    private lateinit var fboSpirit: Fbo   // spirit trail accumulator
    private lateinit var fboPrev: Fbo     // previous frame for spirit diff
    private lateinit var fboMotion: Fbo   // motion mask

    // Sources (added externally before init)
    val sources = mutableListOf<Source>()

    // Feedback sources need the chain to set their texId
    private val feedbackSources get() = sources.filterIsInstance<FeedbackSource>()

    // Recording
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var trackIndex = -1
    @Volatile var isRecording = false
    private var recEglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var recEglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var recEglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    var recordPath: String = ""

    // FPS
    private var lastFrameTime = System.nanoTime()
    var onFpsUpdate: ((Float) -> Unit)? = null
    var onMotionEnergy: ((Float) -> Unit)? = null
    private var fpsFrames = 0
    private var fpsTime   = 0L

    // Motion energy (for focus driver)
    @Volatile var motionEnergy = 0f

    // Phase accumulators
    private var time = 0f

    private fun loadShader(asset: String): String =
        context.assets.open(asset).bufferedReader().readText()

    private val vertSrc get() = loadShader("shaders/quad.vert")

    override fun onSurfaceCreated(gl: GL10?, config: LegacyEglConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        quad = QuadRenderer()

        progPassthrough  = GlProgram(vertSrc, loadShader("shaders/effects/passthrough.frag"))
        progCamTransform = GlProgram(vertSrc, loadShader("shaders/effects/camera_transform.frag"))
        progColor        = GlProgram(vertSrc, loadShader("shaders/effects/color.frag"))
        progEdge         = GlProgram(vertSrc, loadShader("shaders/effects/edge_detect.frag"))
        progKaleidoscope = GlProgram(vertSrc, loadShader("shaders/effects/kaleidoscope.frag"))
        progTunnel       = GlProgram(vertSrc, loadShader("shaders/effects/tunnel.frag"))
        progSwirl        = GlProgram(vertSrc, loadShader("shaders/effects/swirl.frag"))
        progBlur         = GlProgram(vertSrc, loadShader("shaders/effects/blur.frag"))
        progRgbShift     = GlProgram(vertSrc, loadShader("shaders/effects/rgb_shift.frag"))
        progSpirit       = GlProgram(vertSrc, loadShader("shaders/effects/spirit.frag"))
        progAtmosphere   = GlProgram(vertSrc, loadShader("shaders/effects/atmosphere.frag"))
        progMotionRipple = GlProgram(vertSrc, loadShader("shaders/effects/motion_ripple.frag"))
        progBlend        = GlProgram(vertSrc, loadShader("shaders/effects/blend.frag"))

        fboA      = Fbo(W, H); fboB      = Fbo(W, H)
        fboBlur1  = Fbo(W, H); fboBlur2  = Fbo(W, H)
        fboSpirit = Fbo(W, H); fboPrev   = Fbo(W, H)
        fboMotion = Fbo(W, H)

        // Init camera sources
        sources.filterIsInstance<CameraSource>().forEach { it.initGl(W, H) }
        sources.filterIsInstance<RtspSource>().forEach   { it.initGl(W, H) }

        fpsTime = System.currentTimeMillis()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt  = ((now - lastFrameTime) / 1e9f).coerceIn(0.001f, 0.1f)
        lastFrameTime = now
        time += dt
        ParamStore.tick(dt)

        // Update all sources
        sources.forEach { it.update() }

        // Build motion mask (frame diff for focus driver)
        buildMotionMask()

        // Compute focus intensity
        val focusDrive  = ParamStore.norm("FOCUS_DRIVE")
        val focusManual = ParamStore.norm("FOCUS_MANUAL")
        val focusIntensity = (focusDrive * motionEnergy + (1f - focusDrive) * focusManual).coerceIn(0f, 1f)

        // ── MIXER: blend all sources injected at MIXER into fboA ──────────
        mixSources(InjectionPoint.MIXER)

        // Inject feedback sources at MIXER
        feedbackSources.filter { it.tapPoint == InjectionPoint.MIXER }
            .forEach { blendOver(fboA, it.texId, it.alpha, it.blendMode.glslId) }

        // ── CAMERA TRANSFORM ──────────────────────────────────────────────
        passCameraTransform(fboA, fboB)
        mixSourcesAt(InjectionPoint.AFTER_CAM_TRANSFORM, fboB)
        swap()

        // ── COLOR GRADING ─────────────────────────────────────────────────
        passColor(fboA, fboB)
        mixSourcesAt(InjectionPoint.AFTER_COLOR, fboB)
        swap()

        // ── EDGE DETECT ───────────────────────────────────────────────────
        passEdge(fboA, fboB); swap()
        mixSourcesAt(InjectionPoint.AFTER_EDGE, fboA)

        // ── KALEIDOSCOPE ──────────────────────────────────────────────────
        passKaleidoscope(fboA, fboB); swap()
        mixSourcesAt(InjectionPoint.AFTER_KALEIDOSCOPE, fboA)

        // ── MASTER TRANSFORM ──────────────────────────────────────────────
        passMasterTransform(fboA, fboB); swap()

        // ── 3D TUNNEL ─────────────────────────────────────────────────────
        if (ParamStore.norm("T_STRENGTH") > 0.01f || ParamStore.norm("FISHEYE") > 0.01f) {
            passTunnel(fboA, fboB); swap()
        }

        // ── SWIRL ─────────────────────────────────────────────────────────
        if (ParamStore.norm("S_STRENGTH") > 0.01f) { passSwirl(fboA, fboB); swap() }

        // Provide feedback tap points
        feedbackSources.forEach { src ->
            when (src.tapPoint) {
                InjectionPoint.AFTER_CAM_TRANSFORM -> src.feedTexId = fboA.texId
                InjectionPoint.AFTER_COLOR         -> src.feedTexId = fboA.texId
                InjectionPoint.AFTER_EDGE          -> src.feedTexId = fboA.texId
                InjectionPoint.AFTER_KALEIDOSCOPE  -> src.feedTexId = fboA.texId
                else -> {}
            }
        }

        // ── SPIRIT VISUAL ─────────────────────────────────────────────────
        if (ParamStore.norm("SPIRIT_STR") > 0.01f) {
            passSpirit(fboA, fboB, focusIntensity); swap()
        }

        // ── ATMOSPHERE THRESHOLD ──────────────────────────────────────────
        if (ParamStore.norm("ATM_STR") > 0.01f) {
            blurPass(fboA, fboBlur1, fboBlur2, ParamStore.norm("ATM_BLUR") * 12f)
            passAtmosphere(fboA, fboBlur1, fboB, focusIntensity); swap()
        }

        // ── MOTION ZONE RIPPLE ────────────────────────────────────────────
        if (ParamStore.norm("MZ_RIPPLE_STR") > 0.02f) {
            passMotionRipple(fboA, fboMotion, fboB, focusIntensity); swap()
        }

        // ── RGB SHIFT ─────────────────────────────────────────────────────
        if (ParamStore.norm("RGB_SHIFT") > 0.01f) { passRgbShift(fboA, fboB); swap() }

        // ── Screen injection ──────────────────────────────────────────────
        mixSourcesAt(InjectionPoint.SCREEN, fboA)

        // ── Blit to screen ────────────────────────────────────────────────
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, W, H)
        progPassthrough.use()
        bindTex(0, fboA.texId)
        progPassthrough.setInt("uTex", 0)
        quad.draw(progPassthrough)

        // ── Feed recorder ─────────────────────────────────────────────────
        if (isRecording) feedRecorder(fboA.texId)

        // ── Save previous frame for spirit diff ───────────────────────────
        blit(fboA, fboPrev)

        // ── FPS counter ───────────────────────────────────────────────────
        fpsFrames++
        val ms = System.currentTimeMillis()
        if (ms - fpsTime >= 1000) {
            onFpsUpdate?.invoke(fpsFrames * 1000f / (ms - fpsTime))
            onMotionEnergy?.invoke(motionEnergy)
            fpsFrames = 0; fpsTime = ms
        }
    }

    // ── Effect pass helpers ───────────────────────────────────────────────────

    private fun passCameraTransform(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progCamTransform.use()
        bindTex(0, src.texId); progCamTransform.setInt("uTex", 0)
        progCamTransform.setFloat("uAngle",  ParamStore.norm("CAM_ANGLE") * 6.2832f)
        progCamTransform.setFloat("uZoom",   0.1f + ParamStore.norm("CAM_ZOOM") * 3.9f)
        progCamTransform.setVec2 ("uMove",   ParamStore.norm("MOVE_X") * 2f - 1f, ParamStore.norm("MOVE_Y") * 2f - 1f)
        progCamTransform.setVec2 ("uTilt",   ParamStore.norm("TILT_X") * 2f - 1f, ParamStore.norm("TILT_Y") * 2f - 1f)
        progCamTransform.setFloat("uBend",   ParamStore.norm("BEND") * 2f - 1f)
        progCamTransform.setFloat("uWobble", ParamStore.norm("WOBBLE"))
        progCamTransform.setFloat("uTime",   time)
        quad.draw(progCamTransform); dst.unbind()
    }

    private fun passMasterTransform(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progCamTransform.use()
        bindTex(0, src.texId); progCamTransform.setInt("uTex", 0)
        progCamTransform.setFloat("uAngle",  ParamStore.norm("M_ANGLE") * 6.2832f)
        progCamTransform.setFloat("uZoom",   0.1f + ParamStore.norm("M_ZOOM") * 3.9f)
        progCamTransform.setVec2 ("uMove",   ParamStore.norm("M_MOVE_X") * 2f - 1f, ParamStore.norm("M_MOVE_Y") * 2f - 1f)
        progCamTransform.setVec2 ("uTilt",   0f, 0f)
        progCamTransform.setFloat("uBend",   0f)
        progCamTransform.setFloat("uWobble", 0f)
        progCamTransform.setFloat("uTime",   time)
        quad.draw(progCamTransform); dst.unbind()
    }

    private fun passColor(src: Fbo, dst: Fbo) {
        blurPass(src, fboBlur1, fboBlur2, ParamStore.norm("GLOW") * 15f)
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progColor.use()
        bindTex(0, src.texId);    progColor.setInt("uTex", 0)
        bindTex(1, fboBlur2.texId); progColor.setInt("uBlurTex", 1)
        progColor.setFloat("uBrightness", ParamStore.norm("BRIGHTNESS") * 2f - 1f)
        progColor.setFloat("uContrast",   ParamStore.norm("CONTRAST")   * 3f)
        progColor.setFloat("uSaturation", ParamStore.norm("SATURATION") * 3f)
        progColor.setFloat("uHueShift",   ParamStore.norm("HUE"))
        progColor.setFloat("uNegative",   ParamStore.norm("NEGATIVE"))
        progColor.setFloat("uGlow",       ParamStore.norm("GLOW"))
        quad.draw(progColor); dst.unbind()
    }

    private fun passEdge(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progEdge.use()
        bindTex(0, src.texId); progEdge.setInt("uTex", 0)
        progEdge.setFloat("uAmount",     ParamStore.norm("EDGE_AMOUNT"))
        progEdge.setFloat("uThreshold",  ParamStore.norm("EDGE_THRESH"))
        progEdge.setFloat("uHue",        ParamStore.norm("EDGE_HUE"))
        progEdge.setFloat("uSaturation", ParamStore.norm("EDGE_SAT"))
        progEdge.setVec2("uTexelSize",   1f / W, 1f / H)
        quad.draw(progEdge); dst.unbind()
    }

    private fun passKaleidoscope(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progKaleidoscope.use()
        bindTex(0, src.texId); progKaleidoscope.setInt("uTex", 0)
        progKaleidoscope.setFloat("uAxes",        ParamStore.actual("K_AXIS").coerceIn(1f, 25f))
        progKaleidoscope.setFloat("uAmount",       ParamStore.norm("K_AMOUNT"))
        progKaleidoscope.setFloat("uKZoom",        0.1f + ParamStore.norm("K_ZOOM") * 3.9f)
        progKaleidoscope.setFloat("uAngleOffset",  ParamStore.norm("K_ANGLE") * 6.2832f)
        quad.draw(progKaleidoscope); dst.unbind()
    }

    private fun passTunnel(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progTunnel.use()
        bindTex(0, src.texId); progTunnel.setInt("uTex", 0)
        progTunnel.setFloat("uStrength",   ParamStore.norm("T_STRENGTH"))
        progTunnel.setFloat("uShape",      ParamStore.norm("T_SHAPE"))
        progTunnel.setFloat("uFisheye",    ParamStore.norm("FISHEYE"))
        progTunnel.setFloat("uSpeed",      (ParamStore.norm("T_SPEED") * 2f - 1f) * 0.5f)
        progTunnel.setFloat("uTime",       time)
        progTunnel.setFloat("uFogDist",    ParamStore.norm("T_FOG_DIST"))
        progTunnel.setVec3 ("uFogColor",   ParamStore.norm("T_FOG_HUE"), ParamStore.norm("T_FOG_SAT"), ParamStore.norm("T_FOG_BRIT"))
        progTunnel.setFloat("uRainbowStr", ParamStore.norm("RAINBOW_STR"))
        progTunnel.setFloat("uWaveStr",    ParamStore.norm("WAVE_STR"))
        progTunnel.setFloat("uCurve",      ParamStore.norm("CURVE") * 2f - 1f)
        progTunnel.setFloat("uVortex",     ParamStore.norm("VORTEX"))
        quad.draw(progTunnel); dst.unbind()
    }

    private fun passSwirl(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progSwirl.use()
        bindTex(0, src.texId); progSwirl.setInt("uTex", 0)
        progSwirl.setFloat("uStrength", ParamStore.norm("S_STRENGTH"))
        progSwirl.setFloat("uWideness", ParamStore.norm("S_WIDENESS"))
        progSwirl.setFloat("uActivity", ParamStore.norm("S_ACTIVITY"))
        progSwirl.setFloat("uSpeed",    ParamStore.norm("S_SPEED") * 2f - 1f)
        progSwirl.setFloat("uTime",     time)
        progSwirl.setFloat("uFogDist",  ParamStore.norm("S_FOG_DIST"))
        progSwirl.setFloat("uFogSoft",  ParamStore.norm("S_FOG_SOFT"))
        progSwirl.setVec3 ("uFogColor", ParamStore.norm("S_FOG_HUE"), ParamStore.norm("S_FOG_SAT"), ParamStore.norm("S_FOG_BRIT"))
        quad.draw(progSwirl); dst.unbind()
    }

    private fun passSpirit(src: Fbo, dst: Fbo, focusIntensity: Float) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progSpirit.use()
        bindTex(0, src.texId);       progSpirit.setInt("uCurrent",  0)
        bindTex(1, fboPrev.texId);   progSpirit.setInt("uPrevious", 1)
        bindTex(2, fboSpirit.texId); progSpirit.setInt("uTrail",    2)
        progSpirit.setFloat("uSensitivity",    ParamStore.norm("SPIRIT_SENS"))
        progSpirit.setFloat("uTrailDecay",     ParamStore.norm("SPIRIT_TRAIL"))
        progSpirit.setFloat("uHue",            ParamStore.norm("SPIRIT_HUE"))
        progSpirit.setFloat("uStrength",       ParamStore.norm("SPIRIT_STR") * 2f)
        progSpirit.setFloat("uFocusIntensity", focusIntensity)
        quad.draw(progSpirit)
        dst.unbind()
        // Blit result into spirit trail FBO for next frame
        blit(dst, fboSpirit)
    }

    private fun passAtmosphere(src: Fbo, blur: Fbo, dst: Fbo, focusIntensity: Float) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progAtmosphere.use()
        bindTex(0, src.texId);  progAtmosphere.setInt("uTex",     0)
        bindTex(1, blur.texId); progAtmosphere.setInt("uBlurTex", 1)
        progAtmosphere.setFloat("uThreshold",      ParamStore.norm("ATM_THRESH"))
        progAtmosphere.setFloat("uStrength",       ParamStore.norm("ATM_STR"))
        progAtmosphere.setFloat("uHue",            ParamStore.norm("ATM_HUE"))
        progAtmosphere.setFloat("uBlur",           ParamStore.norm("ATM_BLUR"))
        progAtmosphere.setFloat("uFocusIntensity", focusIntensity)
        progAtmosphere.setFloat("uTime",           time)
        quad.draw(progAtmosphere); dst.unbind()
    }

    private fun passMotionRipple(src: Fbo, mask: Fbo, dst: Fbo, focusIntensity: Float) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progMotionRipple.use()
        bindTex(0, src.texId);  progMotionRipple.setInt("uTex",        0)
        bindTex(1, mask.texId); progMotionRipple.setInt("uMotionMask", 1)
        progMotionRipple.setFloat("uRippleStr",     ParamStore.norm("MZ_RIPPLE_STR"))
        progMotionRipple.setFloat("uRippleFreq",    ParamStore.norm("MZ_RIPPLE_FREQ"))
        progMotionRipple.setFloat("uTime",          time)
        progMotionRipple.setFloat("uFocusIntensity",focusIntensity)
        quad.draw(progMotionRipple); dst.unbind()
    }

    private fun passRgbShift(src: Fbo, dst: Fbo) {
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progRgbShift.use()
        bindTex(0, src.texId); progRgbShift.setInt("uTex", 0)
        progRgbShift.setFloat("uShift", ParamStore.norm("RGB_SHIFT") * 0.05f)
        quad.draw(progRgbShift); dst.unbind()
    }

    /** Two-pass Gaussian blur into blur FBOs. */
    private fun blurPass(src: Fbo, tmp: Fbo, out: Fbo, radius: Float) {
        if (radius < 0.5f) { blit(src, out); return }
        val px = 1f / W; val py = 1f / H
        // Horizontal
        tmp.bind(); GLES20.glViewport(0, 0, W, H)
        progBlur.use(); bindTex(0, src.texId); progBlur.setInt("uTex", 0)
        progBlur.setVec2("uDirection", px, 0f); progBlur.setFloat("uRadius", radius)
        quad.draw(progBlur); tmp.unbind()
        // Vertical
        out.bind(); GLES20.glViewport(0, 0, W, H)
        progBlur.use(); bindTex(0, tmp.texId); progBlur.setInt("uTex", 0)
        progBlur.setVec2("uDirection", 0f, py); progBlur.setFloat("uRadius", radius)
        quad.draw(progBlur); out.unbind()
    }

    /** Blend texId over dst FBO using blend mode. */
    private fun blendOver(dst: Fbo, srcTexId: Int, alpha: Float, blendMode: Int) {
        if (srcTexId < 0) return
        fboB.bind(); GLES20.glViewport(0, 0, W, H)
        progBlend.use()
        bindTex(0, dst.texId);  progBlend.setInt("uTexA", 0)
        bindTex(1, srcTexId);   progBlend.setInt("uTexB", 1)
        progBlend.setFloat("uAlpha", alpha)
        progBlend.setInt  ("uBlendMode", blendMode)
        quad.draw(progBlend); fboB.unbind()
        blit(fboB, dst)
    }

    private fun mixSources(point: InjectionPoint) {
        val srcs = sources.filter { it.injectionPoint == point && it.texId >= 0 }
        if (srcs.isEmpty()) { clearFbo(fboA); return }
        val first = srcs.first()
        blit(first.texId, fboA)
        srcs.drop(1).forEach { blendOver(fboA, it.texId, it.alpha, it.blendMode.glslId) }
    }

    private fun mixSourcesAt(point: InjectionPoint, target: Fbo) {
        val srcs = sources.filter { it.injectionPoint == point && it.texId >= 0 }
        srcs.forEach { blendOver(target, it.texId, it.alpha, it.blendMode.glslId) }
    }

    /** Build a greyscale motion mask from frame diff (current vs previous). */
    private fun buildMotionMask() {
        fboMotion.bind(); GLES20.glViewport(0, 0, W, H)
        // Simple diff pass using edge shader repurposed as motion mask
        progBlend.use()
        val curTexId = sources.filterIsInstance<CameraSource>().firstOrNull()?.texId ?: -1
        if (curTexId < 0 || fboPrev.texId < 0) { GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); fboMotion.unbind(); return }
        bindTex(0, curTexId);       progBlend.setInt("uTexA", 0)
        bindTex(1, fboPrev.texId);  progBlend.setInt("uTexB", 1)
        progBlend.setFloat("uAlpha", 1f)
        progBlend.setInt("uBlendMode", 4) // DIFFERENCE
        quad.draw(progBlend)
        fboMotion.unbind()
        // Estimate energy as average of motion mask (sampled via pixel reads — limited, but no compute shaders in ES 2.0)
        val pix = java.nio.ByteBuffer.allocateDirect(4).order(java.nio.ByteOrder.nativeOrder())
        fboMotion.bind()
        GLES20.glReadPixels(W/2, H/2, 1, 1, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, pix)
        fboMotion.unbind()
        val r = (pix.get(0).toInt() and 0xFF) / 255f
        val g = (pix.get(1).toInt() and 0xFF) / 255f
        val b = (pix.get(2).toInt() and 0xFF) / 255f
        motionEnergy = motionEnergy * 0.85f + (r * 0.299f + g * 0.587f + b * 0.114f) * 0.15f
    }

    // ── Utility helpers ───────────────────────────────────────────────────────

    private var _a = true
    private fun swap() { if (_a) { val t = fboA; fboA = fboB; fboB = t } }

    private fun blit(src: Fbo, dst: Fbo) { blit(src.texId, dst) }
    private fun blit(srcTexId: Int, dst: Fbo) {
        if (srcTexId < 0) return
        dst.bind(); GLES20.glViewport(0, 0, W, H)
        progPassthrough.use(); bindTex(0, srcTexId); progPassthrough.setInt("uTex", 0)
        quad.draw(progPassthrough); dst.unbind()
    }

    private fun clearFbo(fbo: Fbo) {
        fbo.bind(); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); fbo.unbind()
    }

    private fun bindTex(unit: Int, texId: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
    }

    // ── Recording via MediaCodec + MediaMuxer ─────────────────────────────────
    fun startRecording(outputPath: String) {
        if (isRecording) return
        recordPath = outputPath
        try {
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
                configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            }
            muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            codec!!.start()
            isRecording = true
            Log.i(TAG, "Recording started: $outputPath")
        } catch (e: Exception) {
            Log.e(TAG, "Recording start failed", e)
        }
    }

    private fun feedRecorder(texId: Int) {
        val c = codec ?: return
        // Drain encoder
        val bufInfo = MediaCodec.BufferInfo()
        var idx = c.dequeueOutputBuffer(bufInfo, 0)
        while (idx >= 0) {
            val buf = c.getOutputBuffer(idx) ?: run { c.releaseOutputBuffer(idx, false); idx = c.dequeueOutputBuffer(bufInfo, 0); continue }
            if ((bufInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                trackIndex = muxer!!.addTrack(c.outputFormat)
                muxer!!.start()
            } else if (trackIndex >= 0) {
                muxer!!.writeSampleData(trackIndex, buf, bufInfo)
            }
            c.releaseOutputBuffer(idx, false)
            idx = c.dequeueOutputBuffer(bufInfo, 0)
        }
    }

    fun stopRecording() {
        if (!isRecording) return
        isRecording = false
        try { codec?.signalEndOfInputStream() } catch (_: Exception) {}
        try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        try { if (trackIndex >= 0) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        codec = null; muxer = null; trackIndex = -1
        Log.i(TAG, "Recording stopped: $recordPath")
    }

    fun releaseAll() {
        stopRecording()
        sources.forEach { it.release() }
        if (::quad.isInitialized) quad.delete()
        // Programs
        if (::progPassthrough.isInitialized)  progPassthrough.delete()
        if (::progCamTransform.isInitialized) progCamTransform.delete()
        if (::progColor.isInitialized)        progColor.delete()
        if (::progEdge.isInitialized)         progEdge.delete()
        if (::progKaleidoscope.isInitialized) progKaleidoscope.delete()
        if (::progTunnel.isInitialized)       progTunnel.delete()
        if (::progSwirl.isInitialized)        progSwirl.delete()
        if (::progBlur.isInitialized)         progBlur.delete()
        if (::progRgbShift.isInitialized)     progRgbShift.delete()
        if (::progSpirit.isInitialized)       progSpirit.delete()
        if (::progAtmosphere.isInitialized)   progAtmosphere.delete()
        if (::progMotionRipple.isInitialized) progMotionRipple.delete()
        if (::progBlend.isInitialized)        progBlend.delete()
        // FBOs
        if (::fboA.isInitialized)      fboA.delete()
        if (::fboB.isInitialized)      fboB.delete()
        if (::fboBlur1.isInitialized)  fboBlur1.delete()
        if (::fboBlur2.isInitialized)  fboBlur2.delete()
        if (::fboSpirit.isInitialized) fboSpirit.delete()
        if (::fboPrev.isInitialized)   fboPrev.delete()
        if (::fboMotion.isInitialized) fboMotion.delete()
    }
}
