package com.spacebeam.engine

import android.opengl.GLES20
import android.util.Log

class GlProgram(vertSrc: String, fragSrc: String) {

    val id: Int

    init {
        val vert = compileShader(GLES20.GL_VERTEX_SHADER, vertSrc)
        val frag = compileShader(GLES20.GL_FRAGMENT_SHADER, fragSrc)
        id = GLES20.glCreateProgram().also { prog ->
            GLES20.glAttachShader(prog, vert)
            GLES20.glAttachShader(prog, frag)
            GLES20.glLinkProgram(prog)
            val status = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) {
                Log.e("GlProgram", "Link failed: ${GLES20.glGetProgramInfoLog(prog)}")
            }
        }
        GLES20.glDeleteShader(vert)
        GLES20.glDeleteShader(frag)
    }

    fun use() = GLES20.glUseProgram(id)

    fun setFloat(name: String, v: Float)  = GLES20.glUniform1f(loc(name), v)
    fun setInt  (name: String, v: Int)    = GLES20.glUniform1i(loc(name), v)
    fun setVec2 (name: String, x: Float, y: Float) = GLES20.glUniform2f(loc(name), x, y)
    fun setVec3 (name: String, x: Float, y: Float, z: Float) = GLES20.glUniform3f(loc(name), x, y, z)

    fun attrib(name: String) = GLES20.glGetAttribLocation(id, name)
    private fun loc(name: String) = GLES20.glGetUniformLocation(id, name)

    fun delete() = GLES20.glDeleteProgram(id)

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e("GlProgram", "Compile failed (type=$type): ${GLES20.glGetShaderInfoLog(shader)}")
        }
        return shader
    }
}
