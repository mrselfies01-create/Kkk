package com.spacebeam.midi

import android.content.Context
import android.media.midi.*
import android.util.Log
import com.spacebeam.modulation.ParamStore

/** Handles Bluetooth MIDI connection, CC receive, and param mapping. */
class MidiController(private val context: Context) {

    private val TAG = "MidiController"

    private var midiManager: MidiManager? = null
    private var openDevice: MidiDevice? = null
    private var receiver: MidiReceiver? = null

    /** CC number → param key */
    val mappings = mutableMapOf<Int, String>()

    /** When non-null, the next CC received will be mapped to this param key. */
    var learningParam: String? = null

    var onParamChanged: ((String, Float) -> Unit)? = null

    fun init() {
        midiManager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    }

    fun scanAndConnect(onDeviceFound: (List<MidiDeviceInfo>) -> Unit) {
        val mgr = midiManager ?: return
        val infos = mgr.devices?.toList() ?: emptyList()
        onDeviceFound(infos)
    }

    fun connect(info: MidiDeviceInfo) {
        val mgr = midiManager ?: return
        mgr.openDevice(info, { device ->
            openDevice = device
            val port = device?.info?.ports?.firstOrNull { it.type == MidiDeviceInfo.PortInfo.TYPE_INPUT }
            val outputPort = device?.openOutputPort(0)
            outputPort?.connect(object : MidiReceiver() {
                override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                    parseMidi(msg, offset, count)
                }
            })
            Log.i(TAG, "MIDI connected: ${info.properties.getString(MidiDeviceInfo.PROPERTY_NAME)}")
        }, null)
    }

    private fun parseMidi(msg: ByteArray, offset: Int, count: Int) {
        if (count < 3) return
        val status = msg[offset].toInt() and 0xFF
        val type   = status and 0xF0
        if (type != 0xB0) return   // only CC messages
        val cc    = msg[offset + 1].toInt() and 0x7F
        val value = msg[offset + 2].toInt() and 0x7F

        // Learn mode
        val learning = learningParam
        if (learning != null) {
            mappings[cc] = learning
            learningParam = null
            Log.i(TAG, "Mapped CC$cc → $learning")
            return
        }

        // Apply to param
        val key = mappings[cc] ?: return
        val normalised = value / 127f
        val param = ParamStore.all[key] ?: return
        param.rawValue = param.min + normalised * (param.max - param.min)
        onParamChanged?.invoke(key, param.rawValue)
    }

    fun disconnect() {
        openDevice?.close()
        openDevice = null
    }

    fun saveMappings(): String = mappings.entries.joinToString(",") { "${it.key}:${it.value}" }
    fun loadMappings(s: String) {
        mappings.clear()
        s.split(",").forEach { entry ->
            val parts = entry.split(":")
            if (parts.size == 2) mappings[parts[0].toIntOrNull() ?: return@forEach] = parts[1]
        }
    }
    fun clearMappings() = mappings.clear()
}
