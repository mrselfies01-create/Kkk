package com.example.visualtransferapp

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.media.*
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.core.Point
import org.opencv.imgproc.Imgproc
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private val TAG = "SpaceBeamVisual"

    // ── UI ────────────────────────────────────────────────────────────────────
    private lateinit var surfaceView: SurfaceView
    private lateinit var tvFps: TextView
    private lateinit var tvParams: TextView
    private lateinit var paramContainer: LinearLayout
    private lateinit var effectSpinner: Spinner
    private lateinit var btnTapBpm: Button
    private lateinit var btnSnapshot: Button
    private lateinit var btnRecord: Button
    private lateinit var seekTime: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var tvAtmosIntensity: TextView

    // ── Camera ────────────────────────────────────────────────────────────────
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var currentEffect = EFFECT_KALEIDOSCOPE
    private var useFrontCamera = false

    // ── Effect params (0–1000 range) ──────────────────────────────────────────
    private val params = mutableMapOf(
        // MIXER
        "CAMERA"         to 1000,
        // CAMERA TRANSFORM
        "CAM_ANGLE"      to 0,
        "CAM_ZOOM"       to 700,
        "MOVE_X"         to 500,
        "MOVE_Y"         to 500,
        "TILT_X"         to 500,
        "TILT_Y"         to 500,
        "BEND"           to 500,
        "WOBBLE"         to 0,
        "DISTORT"        to 0,
        "RGB_SHIFT"      to 0,
        // COLOR
        "BRIGHTNESS"     to 500,
        "HUE"            to 0,
        "NEGATIVE"       to 0,
        "GLOW"           to 0,
        "CONTRAST"       to 500,
        "SATURATION"     to 500,
        // EDGE DETECT
        "EDGE_AMOUNT"    to 0,
        "EDGE_THRESH"    to 300,
        "EDGE_HUE"       to 0,
        "EDGE_SAT"       to 1000,
        // KALEIDOSCOPE
        "K_AXIS"         to 2,
        "K_AMOUNT"       to 1000,
        "K_ZOOM"         to 0,
        // MASTER TRANSFORM
        "M_ANGLE"        to 0,
        "M_ZOOM"         to 700,
        "M_MOVE_X"       to 500,
        "M_MOVE_Y"       to 500,
        // 3D TUNNEL
        "T_STRENGTH"     to 0,
        "T_SHAPE"        to 0,
        "FISHEYE"        to 905,
        "T_SPEED"        to 500,
        "T_FOG_DIST"     to 0,
        // SWIRL
        "S_STRENGTH"     to 0,
        "S_WIDENESS"     to 500,
        "S_ACTIVITY"     to 200,
        "S_SPEED"        to 500,
        "S_FOG_DIST"     to 100,
        "S_FOG_SOFT"     to 150,
        "S_FOG_HUE"      to 0,
        "S_FOG_SAT"      to 0,
        "S_FOG_BRIT"     to 0,
        // FOG / RAINBOW
        "FOG_DIST"       to 0,
        "FOG_HUE"        to 905,
        "FOG_SAT"        to 0,
        "FOG_BRIT"       to 1000,
        "RAINBOW_STR"    to 0,
        "RAINBOW_POS"    to 0,
        "WAVE_STR"       to 0,
        "WAVE_POS"       to 0,
        "CURVE"          to 500,
        "VORTEX"         to 434,
        "FLUX"           to 0,
        // SHIELD / RIPPLE / NATURE / ATMOSPHERE
        "SHIELD_STR"     to 0,
        "SHIELD_RADIUS"  to 500,
        "RIPPLE_STR"     to 0,
        "RIPPLE_SPEED"   to 500,
        "RIPPLE_FREQ"    to 300,
        "NATURE_STR"     to 0,
        "NATURE_BLUR"    to 200,
        "ATMOS_HUE"      to 120,
        "ATMOS_SAT"      to 400,
        "ATMOS_GLOW"     to 0,
        "BPM"            to 120,
        // 2D PIXEL GRID
        "PIXEL_SIZE"     to 20,
        "PIXEL_GLOW"     to 500,
        // 2D LASER GRID
        "LASER_DENSITY"  to 500,
        "LASER_HUE"      to 0,
        "LASER_SPEED"    to 500,
        // 3D PARALLAX
        "PAR_LAYERS"     to 3,
        "PAR_DEPTH"      to 500,
        "PAR_SPEED"      to 500,
        // 3D CUBE WARP
        "CUBE_STR"       to 0,
        "CUBE_SPEED"     to 500,
        "CUBE_FACE"      to 0,
        // ATMOSPHERE THRESHOLD
        "ATM_THRESH"     to 300,
        "ATM_STR"        to 600,
        "ATM_HUE"        to 90,
        "ATM_BLUR"       to 400,
        // FOCUS / BRAIN INTENSITY
        "FOCUS_DRIVE"    to 600,
        "FOCUS_MANUAL"   to 500,
        // MOTION-ZONE RIPPLE
        "MZ_RIPPLE_STR"  to 500,
        "MZ_RIPPLE_FREQ" to 400,
        // MOTION-ZONE SMOOTH
        "MZ_SMOOTH_STR"  to 400,
        // GPU RENDER QUALITY
        "GPU_QUALITY"    to 500,
        "GPU_PASSES"     to 1,
        // SPIRIT VISUAL
        "SPIRIT_SENS"    to 300,
        "SPIRIT_TRAIL"   to 400,
        "SPIRIT_HUE"     to 270,
        "SPIRIT_STR"     to 500,
        // ── DSP AUDIO PASSTHROUGH ────────────────────────────────────────────
        // Master output gain of passthrough (0=mute, 1000=unity, >1000=boost)
        "DSP_GAIN"       to 800,
        // Low-pass cutoff 20..20000 Hz represented as 0..1000
        "DSP_LP_FREQ"    to 800,
        // High-pass cutoff 20..2000 Hz represented as 0..1000
        "DSP_HP_FREQ"    to 50,
        // Noise gate threshold: signals below this level (0..1000) are silenced
        "DSP_GATE_THRESH" to 100,
        // Atmosphere threshold guard: if measured audio energy (0..1000) exceeds
        // this, the passthrough output is attenuated to protect visual coherence
        "DSP_ATMOS_GUARD" to 700,
        // Enable/disable passthrough (0=off, 1=on)
        "DSP_ENABLE"     to 0
    )

    // ── UI section map ────────────────────────────────────────────────────────
    private val sections = linkedMapOf(
        "MIXER"              to listOf("CAMERA"),
        "CAMERA TRANSFORM"   to listOf("CAM_ANGLE","CAM_ZOOM","MOVE_X","MOVE_Y","TILT_X","TILT_Y","BEND","WOBBLE","DISTORT","RGB_SHIFT"),
        "COLOR"              to listOf("BRIGHTNESS","HUE","NEGATIVE","GLOW","CONTRAST","SATURATION"),
        "EDGE DETECT"        to listOf("EDGE_AMOUNT","EDGE_THRESH","EDGE_HUE","EDGE_SAT"),
        "KALEIDOSCOPE"       to listOf("K_AXIS","K_AMOUNT","K_ZOOM"),
        "MASTER TRANSFORM"   to listOf("M_ANGLE","M_ZOOM","M_MOVE_X","M_MOVE_Y"),
        "3D TUNNEL"          to listOf("T_STRENGTH","T_SHAPE","FISHEYE","T_SPEED","T_FOG_DIST"),
        "SWIRL"              to listOf("S_STRENGTH","S_WIDENESS","S_ACTIVITY","S_SPEED","S_FOG_DIST","S_FOG_SOFT","S_FOG_HUE","S_FOG_SAT","S_FOG_BRIT"),
        "ATMOSPHERE/NATURE"  to listOf("FOG_DIST","FOG_HUE","FOG_SAT","FOG_BRIT","RAINBOW_STR","RAINBOW_POS","WAVE_STR","WAVE_POS","CURVE","VORTEX","FLUX"),
        "SHIELD & RIPPLE"    to listOf("SHIELD_STR","SHIELD_RADIUS","RIPPLE_STR","RIPPLE_SPEED","RIPPLE_FREQ","NATURE_STR","NATURE_BLUR","ATMOS_HUE","ATMOS_SAT","ATMOS_GLOW","BPM"),
        "2D PIXEL GRID"      to listOf("PIXEL_SIZE","PIXEL_GLOW"),
        "2D LASER GRID"      to listOf("LASER_DENSITY","LASER_HUE","LASER_SPEED"),
        "3D PARALLAX"        to listOf("PAR_LAYERS","PAR_DEPTH","PAR_SPEED"),
        "3D CUBE WARP"       to listOf("CUBE_STR","CUBE_SPEED","CUBE_FACE"),
        "ATMOSPHERE THRESH"  to listOf("ATM_THRESH","ATM_STR","ATM_HUE","ATM_BLUR"),
        "FOCUS INTENSITY"    to listOf("FOCUS_DRIVE","FOCUS_MANUAL"),
        "MOTION ZONE RIPPLE" to listOf("MZ_RIPPLE_STR","MZ_RIPPLE_FREQ"),
        "MOTION ZONE SMOOTH" to listOf("MZ_SMOOTH_STR"),
        "GPU RENDER"         to listOf("GPU_QUALITY","GPU_PASSES"),
        "SPIRIT VISUAL"      to listOf("SPIRIT_SENS","SPIRIT_TRAIL","SPIRIT_HUE","SPIRIT_STR"),
        "DSP AUDIO"          to listOf("DSP_ENABLE","DSP_GAIN","DSP_LP_FREQ","DSP_HP_FREQ","DSP_GATE_THRESH","DSP_ATMOS_GUARD")
    )

    // ── BPM / phase state ─────────────────────────────────────────────────────
    private val bpmTaps    = mutableListOf<Long>()
    private var bpm        = 120.0
    private var tunnelPhase    = 0.0
    private var swirlPhase     = 0.0
    private var ripplePhase    = 0.0
    private var vortexPhase    = 0.0
    private var wavePhase      = 0.0
    private var cubePhase      = 0.0
    private var laserPhase     = 0.0
    private var parallaxPhase  = 0.0
    private var atmosPhase     = 0.0
    private var spiritPhase    = 0.0

    // ── Focus / motion state ──────────────────────────────────────────────────
    private var prevGray: Mat? = null
    @Volatile private var motionEnergy = 0.0
    private var spiritTrail: Mat? = null

    // ── DSP audio passthrough state ───────────────────────────────────────────
    /**
     * Single-pole IIR coefficients for low-pass and high-pass filters.
     * Recomputed whenever DSP_LP_FREQ / DSP_HP_FREQ params change.
     *
     * For a 1st-order IIR low-pass:   y[n] = a*x[n] + (1-a)*y[n-1]   a = 1/(1+Fc/Fs*TAU)
     * For a 1st-order IIR high-pass:  y[n] = b*(y[n-1] + x[n] - x[n-1])
     *
     * We use the simple α form common in embedded DSP.
     */
    private var dspLpAlpha  = 0.9f   // low-pass coefficient  (close to 1 = high cutoff)
    private var dspHpAlpha  = 0.1f   // high-pass coefficient (close to 0 = low cutoff)
    /** IIR filter state for LP and HP, per channel (stereo: [0]=L, [1]=R) */
    private val dspLpState  = FloatArray(2) { 0f }
    private val dspHpState  = FloatArray(2) { 0f }
    private val dspHpPrev   = FloatArray(2) { 0f }
    /** Running RMS energy of the microphone signal, used for atmosphere guard */
    @Volatile private var dspMicEnergy = 0.0
    /** AudioRecord / AudioTrack for passthrough */
    private var dspRecord: AudioRecord? = null
    private var dspTrack:  AudioTrack?  = null
    private var dspThread: Thread?      = null
    @Volatile private var dspRunning    = false

    private val DSP_SAMPLE_RATE   = 44100
    private val DSP_CHANNEL_IN    = AudioFormat.CHANNEL_IN_STEREO
    private val DSP_CHANNEL_OUT   = AudioFormat.CHANNEL_OUT_STEREO
    private val DSP_FORMAT        = AudioFormat.ENCODING_PCM_FLOAT

    // ── Preset slots ──────────────────────────────────────────────────────────
    private val presetSlots = Array<Map<String, Int>?>(10) { null }
    private var activeSlot  = 0

    // ── Recording state ───────────────────────────────────────────────────────
    private var isRecording  = false
    private var isPlaying    = true
    private var mediaRecorder: MediaRecorder? = null
    private var recorderSurface: android.view.Surface? = null
    private var recorderInputBitmap: Bitmap? = null
    private var frameW = 0; private var frameH = 0

    // ── FPS ───────────────────────────────────────────────────────────────────
    private var frameCount   = 0
    private var lastFpsTime  = System.currentTimeMillis()
    private var fps          = 0.0
    private val mainHandler  = Handler(Looper.getMainLooper())

    @Volatile private var snapshotPending = false

    companion object {
        const val EFFECT_KALEIDOSCOPE   = 0
        const val EFFECT_TUNNEL         = 1
        const val EFFECT_SWIRL          = 2
        const val EFFECT_NATURE         = 3
        const val EFFECT_SHIELD_RIPPLE  = 4
        const val EFFECT_EDGE           = 5
        const val EFFECT_COLOR          = 6
        const val EFFECT_PIXEL_GRID     = 7
        const val EFFECT_LASER_GRID     = 8
        const val EFFECT_PARALLAX       = 9
        const val EFFECT_CUBE_WARP      = 10
        const val EFFECT_SPIRIT         = 11
        val EFFECT_NAMES = arrayOf(
            "KALEIDOSCOPE","3D TUNNEL","SWIRL","NATURE/ATMOS","SHIELD & RIPPLE",
            "EDGE DETECT","COLOR","2D PIXEL GRID","2D LASER GRID",
            "3D PARALLAX","3D CUBE WARP","SPIRIT VISUAL"
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LIFECYCLE
    // ─────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!OpenCVLoader.initDebug()) Log.e(TAG, "OpenCV init failed")
        else                           Log.i(TAG, "OpenCV ready")

        surfaceView    = findViewById(R.id.surfaceView)
        tvFps          = findViewById(R.id.tvFps)
        tvParams       = findViewById(R.id.tvParams)
        paramContainer = findViewById(R.id.paramContainer)
        effectSpinner  = findViewById(R.id.effectSpinner)
        btnTapBpm      = findViewById(R.id.btnTapBpm)
        btnSnapshot    = findViewById(R.id.btnSnapshot)
        btnRecord      = findViewById(R.id.btnRecord)
        seekTime       = findViewById(R.id.seekTime)
        tvTime         = findViewById(R.id.tvTime)
        btnPlayPause   = findViewById(R.id.btnPlayPause)

        // Atmosphere intensity HUD overlay
        tvAtmosIntensity = TextView(this).apply {
            text = "⚡ 0%"
            setTextColor(Color.parseColor("#00FF88"))
            textSize = 13f
            setPadding(12, 4, 12, 4)
            setBackgroundColor(Color.parseColor("#88000000"))
            typeface = Typeface.MONOSPACE
        }

        setupEffectSpinner()
        buildParamUI()
        wireSlotButtons()

        btnTapBpm.setOnClickListener { tapBpm() }
        btnSnapshot.setOnClickListener { saveSnapshot() }
        btnRecord.setOnClickListener { toggleRecording() }
        btnPlayPause.setOnClickListener {
            isPlaying = !isPlaying
            btnPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause
                else           android.R.drawable.ic_media_play)
        }
        findViewById<ImageButton>(R.id.btnFlipCamera).setOnClickListener {
            useFrontCamera = !useFrontCamera
            startCamera()
        }

        checkCameraPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        stopRecording()
        stopDspPassthrough()
        prevGray?.release()
        spiritTrail?.release()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UI SETUP
    // ─────────────────────────────────────────────────────────────────────────

    private fun setupEffectSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, EFFECT_NAMES)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        effectSpinner.adapter = adapter
        effectSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentEffect = pos
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun buildParamUI() {
        paramContainer.removeAllViews()
        for ((sectionName, keys) in sections) {
            val header = TextView(this).apply {
                text = "▶  $sectionName"
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#222222"))
                setPadding(16, 10, 16, 10)
                textSize = 13f
            }
            val sectionBody = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility  = View.GONE
            }
            header.setOnClickListener {
                sectionBody.visibility = if (sectionBody.visibility == View.GONE) View.VISIBLE else View.GONE
                header.text = (if (sectionBody.visibility == View.VISIBLE) "▼  " else "▶  ") + sectionName
            }
            paramContainer.addView(header)
            paramContainer.addView(sectionBody)

            for (key in keys) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4,2,4,2) }
                val label = Button(this).apply {
                    text = key.replace("_"," ")
                    textSize = 10f; setTextColor(Color.WHITE)
                    setBackgroundColor(Color.parseColor("#333333"))
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
                    setPadding(4,4,4,4)
                }
                val maxVal = if (key == "K_AXIS") 8 else 1000
                val seek = SeekBar(this).apply {
                    max = maxVal; progress = params[key] ?: 500
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2.5f)
                }
                val tvVal = TextView(this).apply {
                    text = "${params[key] ?: 0}"; setTextColor(Color.WHITE); textSize = 11f
                    setPadding(6,0,6,0)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                }
                seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) {
                        params[key] = v; tvVal.text = "$v"
                        when (key) {
                            "BPM"         -> bpm = v.toDouble()
                            "DSP_ENABLE"  -> if (v > 0) startDspPassthrough() else stopDspPassthrough()
                            "DSP_LP_FREQ",
                            "DSP_HP_FREQ" -> recalcDspCoefficients()
                        }
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
                label.setOnLongClickListener {
                    params[key] = 500; seek.progress = 500; tvVal.text = "500"; true
                }
                row.addView(label); row.addView(seek); row.addView(tvVal)
                sectionBody.addView(row)
            }
        }
    }

    private fun wireSlotButtons() {
        val ids = listOf(
            R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5,
            R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )
        ids.forEachIndexed { idx, resId ->
            val btn = findViewById<Button>(resId)
            btn.setOnClickListener {
                val slot = presetSlots[idx + 1]
                if (slot != null) {
                    loadPreset(slot)
                    activeSlot = idx + 1
                    Toast.makeText(this, "Preset ${idx+1} loaded", Toast.LENGTH_SHORT).show()
                    highlightSlot(btn)
                } else {
                    Toast.makeText(this, "Slot ${idx+1} empty — long-press to save", Toast.LENGTH_SHORT).show()
                }
            }
            btn.setOnLongClickListener {
                presetSlots[idx + 1] = params.toMap()
                Toast.makeText(this, "✔ Preset ${idx+1} saved", Toast.LENGTH_SHORT).show()
                btn.setBackgroundColor(Color.parseColor("#226644"))
                true
            }
        }
    }

    private fun highlightSlot(active: Button) {
        listOf(R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5,
               R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9).forEach {
            findViewById<Button>(it).setBackgroundColor(Color.parseColor("#222222"))
        }
        active.setBackgroundColor(Color.parseColor("#444455"))
    }

    private fun loadPreset(slot: Map<String, Int>) {
        slot.forEach { (k, v) -> params[k] = v }
        bpm = (params["BPM"] ?: 120).toDouble()
        mainHandler.post { buildParamUI(); wireSlotButtons() }
    }

    private fun tapBpm() {
        val now = System.currentTimeMillis()
        bpmTaps.add(now)
        if (bpmTaps.size > 8) bpmTaps.removeAt(0)
        if (bpmTaps.size >= 2) {
            val intervals = (1 until bpmTaps.size).map { (bpmTaps[it] - bpmTaps[it-1]).toDouble() }
            bpm = 60000.0 / intervals.average()
            params["BPM"] = bpm.toInt().coerceIn(40, 300)
        }
        btnTapBpm.text = "TAP\n${bpm.toInt()} BPM"
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CAMERA
    // ─────────────────────────────────────────────────────────────────────────

    private fun checkCameraPermission() {
        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) { startCamera(); return }

        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            if (results[Manifest.permission.CAMERA] == true) startCamera()
            else Toast.makeText(this, "Camera permission required", Toast.LENGTH_LONG).show()
        }.launch(missing.toTypedArray())
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { proxy -> processFrame(proxy) }
            val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA
                           else                CameraSelector.DEFAULT_BACK_CAMERA
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, analysis)
            } catch (e: Exception) { Log.e(TAG, "Camera bind failed", e) }
        }, ContextCompat.getMainExecutor(this))
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DSP AUDIO PASSTHROUGH
    // Microphone → IIR low-pass + high-pass → noise gate → atmosphere guard
    // → output gain → speaker.  The atmosphere guard attenuates the output
    // when visual atmosphere energy is high, protecting the visual coherence.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Recompute IIR filter alpha coefficients from current param values.
     * Called on init and whenever DSP_LP_FREQ / DSP_HP_FREQ slider changes.
     *
     * LP α = dt / (RC + dt)  where RC = 1/(2π·fc) and dt = 1/Fs
     * HP α = RC / (RC + dt)
     * We map the 0..1000 param to 20..20000 Hz (log scale for LP)
     * and 20..2000 Hz (log scale for HP).
     */
    private fun recalcDspCoefficients() {
        val fs = DSP_SAMPLE_RATE.toFloat()
        val dt = 1f / fs

        // LP: param 0→20Hz, param 1000→20000Hz (log scale)
        val lpFreq = 20f * 10f.pow(params["DSP_LP_FREQ"]!! / 1000f * 3f)  // 20..20000
        val lpRc   = 1f / (2f * Math.PI.toFloat() * lpFreq)
        dspLpAlpha = dt / (lpRc + dt)

        // HP: param 0→20Hz, param 1000→2000Hz (log scale)
        val hpFreq = 20f * 10f.pow(params["DSP_HP_FREQ"]!! / 1000f * 2f)  // 20..2000
        val hpRc   = 1f / (2f * Math.PI.toFloat() * hpFreq)
        dspHpAlpha = hpRc / (hpRc + dt)

        Log.d(TAG, "DSP coeff: LP α=$dspLpAlpha (${lpFreq}Hz)  HP α=$dspHpAlpha (${hpFreq}Hz)")
    }

    /**
     * Start the DSP audio passthrough thread.
     * Opens AudioRecord (microphone) and AudioTrack (speaker) in STREAM mode,
     * reads PCM float frames, applies IIR LP/HP filter chain + gate + guard,
     * then writes to the AudioTrack output.
     */
    private fun startDspPassthrough() {
        if (dspRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission needed for DSP", Toast.LENGTH_SHORT).show()
            return
        }

        recalcDspCoefficients()

        val minBufIn  = AudioRecord.getMinBufferSize(DSP_SAMPLE_RATE, DSP_CHANNEL_IN, DSP_FORMAT)
        val minBufOut = AudioTrack.getMinBufferSize(DSP_SAMPLE_RATE, DSP_CHANNEL_OUT, DSP_FORMAT)
        // Use at least 4× min buffer for stability
        val bufSize   = maxOf(minBufIn, minBufOut) * 4

        try {
            dspRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                DSP_SAMPLE_RATE, DSP_CHANNEL_IN, DSP_FORMAT, bufSize
            )
            dspTrack = AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(DSP_SAMPLE_RATE)
                    .setEncoding(DSP_FORMAT)
                    .setChannelMask(DSP_CHANNEL_OUT)
                    .build(),
                bufSize,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
        } catch (e: Exception) {
            Log.e(TAG, "DSP init failed", e)
            Toast.makeText(this, "DSP init failed: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // Reset filter state
        dspLpState.fill(0f); dspHpState.fill(0f); dspHpPrev.fill(0f)

        dspRunning = true
        dspRecord!!.startRecording()
        dspTrack!!.play()

        dspThread = Thread({
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
            // Stereo: interleaved [L, R, L, R ...]  — bufSize / 4 floats per read
            val floatsPerRead = bufSize / 4 / 2   // /4 bytes per float, /2 stereo
            val buf = FloatArray(floatsPerRead * 2) // *2 stereo channels
            val outBuf = FloatArray(buf.size)

            while (dspRunning) {
                val read = dspRecord!!.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (read <= 0) continue

                // ── Param snapshot (avoid volatile reads in inner loop) ────────
                val gainLinear     = params["DSP_GAIN"]!!       / 1000f
                val gateThresh     = params["DSP_GATE_THRESH"]!! / 1000f * 0.05f   // 0..0.05 amplitude
                val atmosGuardVal  = params["DSP_ATMOS_GUARD"]!! / 1000f            // 0..1
                val lpA            = dspLpAlpha
                val hpA            = dspHpAlpha

                // ── Atmosphere guard: attenuate output when visual/audio is hot
                // dspMicEnergy is 0..1 measured from the mic.
                // When it exceeds the user's ATM_GUARD threshold, pull back gain
                // so the audio doesn't overwhelm the visual atmosphere rendering.
                val guardAttenuation = if (dspMicEnergy > atmosGuardVal) {
                    // Soft knee: ramp from 1.0 down to 0.2 as energy overshoots guard
                    val overshoot = ((dspMicEnergy - atmosGuardVal) / (1.0 - atmosGuardVal + 1e-6)).coerceIn(0.0, 1.0)
                    (1.0 - overshoot * 0.8).toFloat()
                } else 1f

                val effectiveGain  = gainLinear * guardAttenuation

                // ── Running RMS accumulator for this block ────────────────────
                var sumSq = 0.0

                for (i in 0 until read step 2) {
                    val iCh = i / 2   // sample index within channel pair
                    // Process left (i) and right (i+1)
                    for (ch in 0..1) {
                        val sampleIdx = i + ch
                        if (sampleIdx >= read) { outBuf[sampleIdx] = 0f; continue }
                        var s = buf[sampleIdx]

                        // ── 1st-order IIR low-pass ─────────────────────────
                        // y[n] = α·x[n] + (1−α)·y[n−1]
                        dspLpState[ch] = lpA * s + (1f - lpA) * dspLpState[ch]
                        s = dspLpState[ch]

                        // ── 1st-order IIR high-pass ────────────────────────
                        // y[n] = α·(y[n−1] + x[n] − x[n−1])
                        val hpOut = hpA * (dspHpState[ch] + s - dspHpPrev[ch])
                        dspHpPrev[ch]  = s
                        dspHpState[ch] = hpOut
                        s = hpOut

                        // ── Noise gate ─────────────────────────────────────
                        // Hard gate: zero-out samples below threshold
                        if (abs(s) < gateThresh) s = 0f

                        // ── Output gain + atmosphere guard attenuation ─────
                        s *= effectiveGain

                        // ── Clamp to [-1, 1] to avoid DAC distortion ───────
                        s = s.coerceIn(-1f, 1f)

                        outBuf[sampleIdx] = s
                        sumSq += s * s
                    }
                }

                // Update mic energy (smooth RMS, 0..1)
                val rms = sqrt(sumSq / read)
                dspMicEnergy = dspMicEnergy * 0.9 + rms * 0.1   // leaky integrator

                dspTrack!!.write(outBuf, 0, read, AudioTrack.WRITE_BLOCKING)
            }

            dspRecord?.stop()
            dspTrack?.stop()
        }, "DSP-Passthrough")
        dspThread!!.isDaemon = true
        dspThread!!.start()

        Toast.makeText(this, "DSP passthrough ON", Toast.LENGTH_SHORT).show()
    }

    private fun stopDspPassthrough() {
        dspRunning = false
        dspThread?.join(300)
        dspThread = null
        try { dspRecord?.release() } catch (_: Exception) {}
        try { dspTrack?.release()  } catch (_: Exception) {}
        dspRecord = null
        dspTrack  = null
        dspMicEnergy = 0.0
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FRAME PROCESSING — main pipeline
    // ─────────────────────────────────────────────────────────────────────────

    private fun processFrame(proxy: ImageProxy) {
        if (!isPlaying) { proxy.close(); return }

        val bitmap = imageProxyToBitmap(proxy) ?: run { proxy.close(); return }
        proxy.close()

        if (frameW == 0) { frameW = bitmap.width; frameH = bitmap.height }

        // ── BPM phase advance ────────────────────────────────────────────────
        val bpmDelta = bpm / 60.0 / 30.0
        tunnelPhase   = (tunnelPhase   + bpmDelta * (params["T_SPEED"]!!      / 500.0)) % (2*Math.PI)
        swirlPhase    = (swirlPhase    + bpmDelta * (params["S_SPEED"]!!      / 500.0)) % (2*Math.PI)
        ripplePhase   = (ripplePhase   + bpmDelta * (params["RIPPLE_SPEED"]!! / 500.0)) % (2*Math.PI)
        vortexPhase   = (vortexPhase   + bpmDelta * (params["VORTEX"]!!       / 500.0)) % (2*Math.PI)
        wavePhase     = (wavePhase     + bpmDelta * 0.5)                                % (2*Math.PI)
        cubePhase     = (cubePhase     + bpmDelta * (params["CUBE_SPEED"]!!   / 500.0)) % (2*Math.PI)
        laserPhase    = (laserPhase    + bpmDelta * (params["LASER_SPEED"]!!  / 500.0)) % (2*Math.PI)
        parallaxPhase = (parallaxPhase + bpmDelta * (params["PAR_SPEED"]!!    / 500.0)) % (2*Math.PI)
        atmosPhase    = (atmosPhase    + bpmDelta * 0.3)                                % (2*Math.PI)
        spiritPhase   = (spiritPhase   + bpmDelta * 0.4)                                % (2*Math.PI)

        val src = Mat()
        Utils.bitmapToMat(bitmap, src)
        Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2BGR)

        // ── Compute focus/motion energy ───────────────────────────────────────
        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
        val energy = computeMotionEnergy(gray)
        motionEnergy = energy
        gray.release()

        val focusDrive     = params["FOCUS_DRIVE"]!!  / 1000.0
        val focusManual    = params["FOCUS_MANUAL"]!! / 1000.0
        val focusIntensity = (focusDrive * motionEnergy + (1.0 - focusDrive) * focusManual).coerceIn(0.0, 1.0)

        // ── Camera transform ──────────────────────────────────────────────────
        val transformed = applyCameraTransform(src)

        val qualityParam = params["GPU_QUALITY"]!!
        val interpMode = when {
            qualityParam < 340 -> Imgproc.INTER_NEAREST
            qualityParam < 670 -> Imgproc.INTER_LINEAR
            else               -> Imgproc.INTER_CUBIC
        }

        // ── Main effect ───────────────────────────────────────────────────────
        var result = when (currentEffect) {
            EFFECT_KALEIDOSCOPE  -> applyKaleidoscope(transformed, interpMode)
            EFFECT_TUNNEL        -> applyTunnel(transformed, interpMode)
            EFFECT_SWIRL         -> applySwirl(transformed, interpMode)
            EFFECT_NATURE        -> applyNatureAtmos(transformed, focusIntensity)
            EFFECT_SHIELD_RIPPLE -> applyShieldRipple(transformed)
            EFFECT_EDGE          -> applyEdgeDetect(transformed)
            EFFECT_COLOR         -> applyColorEffect(transformed)
            EFFECT_PIXEL_GRID    -> applyPixelGrid(transformed)
            EFFECT_LASER_GRID    -> applyLaserGrid(transformed)
            EFFECT_PARALLAX      -> applyParallaxDepth(transformed)
            EFFECT_CUBE_WARP     -> applyCubeWarp(transformed, interpMode)
            EFFECT_SPIRIT        -> applySpiritVisual(transformed, focusIntensity)
            else                 -> transformed.clone()
        }

        // ── Atmosphere threshold overlay ──────────────────────────────────────
        if (params["ATM_STR"]!! > 10) {
            val atmOverlay = applyAtmosphereThreshold(result, focusIntensity)
            Core.addWeighted(result, 1.0, atmOverlay, params["ATM_STR"]!! / 1000.0, 0.0, result)
            atmOverlay.release()
        }

        // ── Motion-zone ripple ────────────────────────────────────────────────
        if (params["MZ_RIPPLE_STR"]!! > 20 && motionEnergy > 0.05) {
            result = applyMotionZoneRipple(result, focusIntensity)
        }

        // ── Motion-zone smooth ────────────────────────────────────────────────
        if (params["MZ_SMOOTH_STR"]!! > 20) {
            result = applyMotionZoneSmooth(result)
        }

        // ── Spirit trail overlay ──────────────────────────────────────────────
        if (params["SPIRIT_STR"]!! > 10) {
            result = blendSpiritTrail(result, focusIntensity)
        }

        // ── Multi-pass GPU blend ──────────────────────────────────────────────
        val passes = (params["GPU_PASSES"]!! / 250 + 1).coerceIn(1, 4)
        if (passes > 1) {
            for (p in 1 until passes) {
                val pass = result.clone()
                Core.addWeighted(result, 0.7, pass, 0.3, 0.0, result)
                pass.release()
            }
        }

        // ── Color grading ─────────────────────────────────────────────────────
        val colored = applyColorGrading(result)

        // ── RGB shift ─────────────────────────────────────────────────────────
        val final = if (params["RGB_SHIFT"]!! > 0) applyRgbShift(colored) else colored

        // ── Draw to screen ────────────────────────────────────────────────────
        drawToSurface(final)

        // ── Feed to recorder ──────────────────────────────────────────────────
        if (isRecording) feedRecorder(final)

        // ── HUD update ────────────────────────────────────────────────────────
        frameCount++
        val now = System.currentTimeMillis()
        if (now - lastFpsTime >= 1000) {
            fps = frameCount * 1000.0 / (now - lastFpsTime)
            frameCount = 0; lastFpsTime = now
            val pct = (motionEnergy * 100).toInt()
            val dspPct = (dspMicEnergy * 100).toInt()
            mainHandler.post {
                tvFps.text = "FPS: ${fps.toInt()}  BPM: ${bpm.toInt()}  FOCUS: ${pct}%  DSP: ${dspPct}%"
            }
        }

        transformed.release(); result.release(); colored.release(); src.release()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MOTION / FOCUS ENERGY
    // ─────────────────────────────────────────────────────────────────────────
    private fun computeMotionEnergy(grayFrame: Mat): Double {
        val prev = prevGray
        if (prev == null || prev.size() != grayFrame.size()) {
            prevGray = grayFrame.clone()
            return 0.0
        }
        val diff = Mat()
        Core.absdiff(grayFrame, prev, diff)
        val sensThresh = params["SPIRIT_SENS"]!! / 1000.0 * 60.0
        Imgproc.threshold(diff, diff, sensThresh, 255.0, Imgproc.THRESH_TOZERO)
        val mean = Core.mean(diff).`val`[0]
        diff.release()
        prevGray?.release()
        prevGray = grayFrame.clone()
        return (mean / 30.0).coerceIn(0.0, 1.0)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ATMOSPHERE THRESHOLD EFFECT
    // ─────────────────────────────────────────────────────────────────────────
    private fun applyAtmosphereThreshold(src: Mat, focusIntensity: Double): Mat {
        val thresh  = params["ATM_THRESH"]!! / 1000.0 * 255.0
        val hue     = params["ATM_HUE"]!!   / 1000.0 * 180.0
        val blurR   = (params["ATM_BLUR"]!! / 1000.0 * 49.0).toInt() * 2 + 1

        val hsv = Mat(); Imgproc.cvtColor(src, hsv, Imgproc.COLOR_BGR2HSV)
        val channels = mutableListOf<Mat>(); Core.split(hsv, channels)
        val mask = Mat()
        val effectiveThresh = (thresh - focusIntensity * thresh * 0.5).coerceIn(10.0, 250.0)
        Imgproc.threshold(channels[2], mask, effectiveThresh, 255.0, Imgproc.THRESH_BINARY)

        val aura = Mat.zeros(src.size(), src.type())
        aura.setTo(Scalar(hue, 220.0, 255.0))
        Imgproc.cvtColor(aura, aura, Imgproc.COLOR_HSV2BGR)

        val masked = Mat.zeros(src.size(), src.type())
        aura.copyTo(masked, mask)

        val pulseAlpha = 0.5 + 0.5 * sin(atmosPhase)
        val blurred = Mat()
        Imgproc.GaussianBlur(masked, blurred, Size(blurR.toDouble(), blurR.toDouble()), 0.0)
        Core.addWeighted(masked, 1.0, blurred, pulseAlpha, 0.0, masked)

        channels.forEach { it.release() }; hsv.release(); mask.release()
        aura.release(); blurred.release()
        return masked
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MOTION-ZONE RIPPLE
    // ─────────────────────────────────────────────────────────────────────────
    private fun applyMotionZoneRipple(src: Mat, focusIntensity: Double): Mat {
        val rippleStr  = params["MZ_RIPPLE_STR"]!! / 1000.0 * 20.0 * (0.5 + focusIntensity * 0.5)
        val rippleFreq = params["MZ_RIPPLE_FREQ"]!! / 1000.0 * 60.0 + 5.0

        val w = src.cols(); val h = src.rows()
        val dst = Mat.zeros(src.size(), src.type())
        val mapX = Mat(h, w, CvType.CV_32FC1)
        val mapY = Mat(h, w, CvType.CV_32FC1)

        val prev = prevGray
        val motionMask: Mat? = if (prev != null && prev.cols() == w && prev.rows() == h) {
            val curGray = Mat(); Imgproc.cvtColor(src, curGray, Imgproc.COLOR_BGR2GRAY)
            val d = Mat(); Core.absdiff(curGray, prev, d)
            val thr = Mat(); Imgproc.threshold(d, thr, 15.0, 1.0, Imgproc.THRESH_BINARY)
            thr.convertTo(thr, CvType.CV_32FC1)
            curGray.release(); d.release(); thr
        } else null

        for (y in 0 until h) {
            for (x in 0 until w) {
                val motionW = motionMask?.get(y, x)?.get(0) ?: 1.0f
                val r = sqrt(((x - w/2.0).pow(2) + (y - h/2.0).pow(2)))
                val nx = x + rippleStr * motionW * sin(r / rippleFreq + ripplePhase * 2 * Math.PI)
                val ny = y + rippleStr * motionW * cos(r / rippleFreq + ripplePhase * 2 * Math.PI * 0.7)
                mapX.put(y, x, floatArrayOf(nx.toFloat()))
                mapY.put(y, x, floatArrayOf(ny.toFloat()))
            }
        }
        Imgproc.remap(src, dst, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        motionMask?.release(); mapX.release(); mapY.release()
        return dst
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MOTION-ZONE SMOOTH
    // ─────────────────────────────────────────────────────────────────────────
    private fun applyMotionZoneSmooth(src: Mat): Mat {
        val smoothStr = params["MZ_SMOOTH_STR"]!! / 1000.0
        if (smoothStr < 0.02) return src.clone()

        val blurK = (smoothStr * 19).toInt() * 2 + 1
        val blurred = Mat()
        Imgproc.GaussianBlur(src, blurred, Size(blurK.toDouble(), blurK.toDouble()), 0.0)

        val prev = prevGray
        val result = src.clone()
        if (prev != null && prev.cols() == src.cols() && prev.rows() == src.rows()) {
            val curGray = Mat(); Imgproc.cvtColor(src, curGray, Imgproc.COLOR_BGR2GRAY)
            val diff = Mat(); Core.absdiff(curGray, prev, diff)
            val diffF = Mat(); diff.convertTo(diffF, CvType.CV_32FC1, 1.0/255.0)
            val alpha = Mat(); Core.merge(listOf(diffF, diffF, diffF), alpha)
            // Work in float
            val srcF = Mat(); src.convertTo(srcF, CvType.CV_32FC3, 1.0/255.0)
            val blurF = Mat(); blurred.convertTo(blurF, CvType.CV_32FC3, 1.0/255.0)
            val sharpPart = Mat(); val smoothPart = Mat()
            Core.multiply(srcF, alpha, sharpPart)
            val oneMinusAlpha = Mat()
            Core.subtract(Mat.ones(alpha.size(), alpha.type()), alpha, oneMinusAlpha)
            Core.multiply(blurF, oneMinusAlpha, smoothPart)
            val blendF = Mat()
            Core.add(sharpPart, smoothPart, blendF)
            blendF.convertTo(result, CvType.CV_8UC3, 255.0)

            curGray.release(); diff.release(); diffF.release(); alpha.release()
            srcF.release(); blurF.release(); sharpPart.release()
            smoothPart.release(); oneMinusAlpha.release(); blendF.release()
        }
        blurred.release()
        return result
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SPIRIT VISUAL (standalone mode)
    // ─────────────────────────────────────────────────────────────────────────
    private fun applySpiritVisual(src: Mat, focusIntensity: Double): Mat {
        val hue  = params["SPIRIT_HUE"]!! / 1000.0 * 180.0
        val sens = params["SPIRIT_SENS"]!! / 1000.0 * 60.0
        val str  = params["SPIRIT_STR"]!!  / 1000.0

        val prev = prevGray ?: return src.clone()
        if (prev.cols() != src.cols() || prev.rows() != src.rows()) return src.clone()

        val curGray = Mat(); Imgproc.cvtColor(src, curGray, Imgproc.COLOR_BGR2GRAY)
        val diff = Mat(); Core.absdiff(curGray, prev, diff)
        val effectiveSens = (sens - focusIntensity * sens * 0.6).coerceIn(2.0, 60.0)
        Imgproc.threshold(diff, diff, effectiveSens, 255.0, Imgproc.THRESH_TOZERO)

        diff.convertTo(diff, -1, 3.0 + focusIntensity * 2.0, 0.0)
        val diffBgr = Mat(); Imgproc.cvtColor(diff, diffBgr, Imgproc.COLOR_GRAY2BGR)

        val hsvEnergy = Mat(); Imgproc.cvtColor(diffBgr, hsvEnergy, Imgproc.COLOR_BGR2HSV)
        val ch = mutableListOf<Mat>(); Core.split(hsvEnergy, ch)
        ch[0].setTo(Scalar(hue))
        ch[1].setTo(Scalar(220.0))
        Core.merge(ch, hsvEnergy)
        val spirit = Mat(); Imgproc.cvtColor(hsvEnergy, spirit, Imgproc.COLOR_HSV2BGR)

        val glow = Mat(); Imgproc.GaussianBlur(spirit, glow, Size(15.0, 15.0), 0.0)
        Core.addWeighted(spirit, 1.0, glow, 0.8, 0.0, spirit)

        val darkSrc = Mat()
        Core.addWeighted(src, 0.3, Mat.zeros(src.size(), src.type()), 0.7, 0.0, darkSrc)
        val out = Mat(); Core.addWeighted(darkSrc, 1.0, spirit, str * (1.0 + focusIntensity), 0.0, out)

        curGray.release(); diff.release(); diffBgr.release(); hsvEnergy.release()
        ch.forEach { it.release() }; spirit.release(); glow.release(); darkSrc.release()
        return out
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SPIRIT TRAIL BLEND
    // ─────────────────────────────────────────────────────────────────────────
    private fun blendSpiritTrail(src: Mat, focusIntensity: Double): Mat {
        val trail  = params["SPIRIT_TRAIL"]!! / 1000.0
        val str    = params["SPIRIT_STR"]!!   / 1000.0
        val sens   = params["SPIRIT_SENS"]!!  / 1000.0 * 60.0
        val hue    = params["SPIRIT_HUE"]!!   / 1000.0 * 180.0

        val prev = prevGray
        val w = src.cols(); val h = src.rows()

        if (spiritTrail == null || spiritTrail!!.cols() != w || spiritTrail!!.rows() != h) {
            spiritTrail?.release()
            spiritTrail = Mat.zeros(h, w, CvType.CV_32FC3)
        }
        val trailMat = spiritTrail!!

        if (prev != null && prev.cols() == w && prev.rows() == h) {
            val curGray = Mat(); Imgproc.cvtColor(src, curGray, Imgproc.COLOR_BGR2GRAY)
            val diff = Mat(); Core.absdiff(curGray, prev, diff)
            val effSens = (sens - focusIntensity * sens * 0.5).coerceIn(2.0, 60.0)
            Imgproc.threshold(diff, diff, effSens, 255.0, Imgproc.THRESH_TOZERO)
            diff.convertTo(diff, -1, 2.5, 0.0)

            val diffBgr = Mat(); Imgproc.cvtColor(diff, diffBgr, Imgproc.COLOR_GRAY2BGR)
            val hsvE = Mat(); Imgproc.cvtColor(diffBgr, hsvE, Imgproc.COLOR_BGR2HSV)
            val ch = mutableListOf<Mat>(); Core.split(hsvE, ch)
            ch[0].setTo(Scalar(hue)); ch[1].setTo(Scalar(200.0))
            Core.merge(ch, hsvE)
            val newEnergy = Mat(); Imgproc.cvtColor(hsvE, newEnergy, Imgproc.COLOR_HSV2BGR)
            val newF = Mat(); newEnergy.convertTo(newF, CvType.CV_32FC3, 1.0/255.0)

            Core.addWeighted(trailMat, trail, newF, (1.0 - trail) * (1.0 + focusIntensity), 0.0, trailMat)

            curGray.release(); diff.release(); diffBgr.release(); hsvE.release()
            ch.forEach { it.release() }; newEnergy.release(); newF.release()
        }

        val trail8 = Mat(); trailMat.convertTo(trail8, CvType.CV_8UC3, 255.0)
        val glow = Mat(); Imgproc.GaussianBlur(trail8, glow, Size(11.0, 11.0), 0.0)
        Core.addWeighted(trail8, 1.0, glow, 0.5, 0.0, trail8)

        val result = Mat()
        Core.addWeighted(src, 1.0, trail8, str * (1.0 + focusIntensity * 0.5), 0.0, result)
        trail8.release(); glow.release()
        return result
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EFFECTS
    // ─────────────────────────────────────────────────────────────────────────

    private fun applyCameraTransform(src: Mat): Mat {
        val w = src.cols().toDouble(); val h = src.rows().toDouble()
        val zoom  = params["CAM_ZOOM"]!! / 1000.0 * 2.0
        val angle = params["CAM_ANGLE"]!! / 1000.0 * 360.0
        val cx    = w / 2.0 + (params["MOVE_X"]!! - 500) / 500.0 * w * 0.2
        val cy    = h / 2.0 + (params["MOVE_Y"]!! - 500) / 500.0 * h * 0.2
        val M     = Imgproc.getRotationMatrix2D(Point(cx, cy), angle, zoom)
        val dst   = Mat()
        Imgproc.warpAffine(src, dst, M, src.size(), Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        val wobble = params["WOBBLE"]!! / 1000.0
        if (wobble > 0) {
            val wobbleMat = Mat()
            val mapX = Mat(src.rows(), src.cols(), CvType.CV_32FC1)
            val mapY = Mat(src.rows(), src.cols(), CvType.CV_32FC1)
            for (y in 0 until src.rows()) for (x in 0 until src.cols()) {
                mapX.put(y, x, floatArrayOf((x + wobble * 20.0 * sin(y / 30.0 + swirlPhase)).toFloat()))
                mapY.put(y, x, floatArrayOf((y + wobble * 20.0 * sin(x / 30.0 + swirlPhase)).toFloat()))
            }
            Imgproc.remap(dst, wobbleMat, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
            mapX.release(); mapY.release(); dst.release(); M.release()
            return wobbleMat
        }
        M.release(); return dst
    }

    private fun applyKaleidoscope(src: Mat, interp: Int = Imgproc.INTER_LINEAR): Mat {
        val axes   = params["K_AXIS"]!!.coerceIn(1, 8)
        val amount = params["K_AMOUNT"]!! / 1000.0
        val kZoom  = 1.0 + params["K_ZOOM"]!! / 500.0
        val w = src.cols(); val h = src.rows()
        val cx = w / 2.0;  val cy = h / 2.0
        val dst = Mat.zeros(src.size(), src.type())
        val angleStep = Math.PI / axes
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            var dx = (x - cx) / kZoom; var dy = (y - cy) / kZoom
            var angle = atan2(dy, dx); val radius = sqrt(dx*dx + dy*dy)
            angle = angle % (2*angleStep); if (angle < 0) angle += 2*angleStep
            if (angle > angleStep) angle = 2*angleStep - angle
            val ka = angle * amount + atan2(dy, dx) * (1 - amount)
            mapX.put(y, x, floatArrayOf((cx + radius * cos(ka) * kZoom).toFloat()))
            mapY.put(y, x, floatArrayOf((cy + radius * sin(ka) * kZoom).toFloat()))
        }
        Imgproc.remap(src, dst, mapX, mapY, interp, Core.BORDER_REFLECT)
        mapX.release(); mapY.release(); return dst
    }

    private fun applyTunnel(src: Mat, interp: Int = Imgproc.INTER_LINEAR): Mat {
        val strength = params["T_STRENGTH"]!! / 1000.0
        val fisheye  = params["FISHEYE"]!!    / 1000.0
        val shape    = params["T_SHAPE"]!!    / 1000.0
        if (strength < 0.01 && fisheye < 0.01) return src.clone()
        val w = src.cols(); val h = src.rows()
        val cx = w / 2.0; val cy = h / 2.0
        val dst = Mat.zeros(src.size(), src.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            val dx = (x - cx) / cx; val dy = (y - cy) / cy
            val r  = sqrt(dx*dx + dy*dy); val angle = atan2(dy, dx)
            val fishR  = if (fisheye > 0) { val k = fisheye*2.0; r*(1.0+k*r*r)/(1.0+k) } else r
            val tunnelR = if (strength > 0) { val t = 1.0/(fishR+0.001+strength)+tunnelPhase*strength; t%1.0 } else fishR
            val squareR = max(abs(dx), abs(dy))
            val blendR  = tunnelR*(1-shape) + squareR*shape
            mapX.put(y, x, floatArrayOf((cx + blendR*cos(angle)*cx).toFloat()))
            mapY.put(y, x, floatArrayOf((cy + blendR*sin(angle)*cy).toFloat()))
        }
        Imgproc.remap(src, dst, mapX, mapY, interp, Core.BORDER_REFLECT)
        mapX.release(); mapY.release(); return dst
    }

    private fun applySwirl(src: Mat, interp: Int = Imgproc.INTER_LINEAR): Mat {
        val strength = params["S_STRENGTH"]!! / 1000.0 * 6.0
        val wideness = params["S_WIDENESS"]!! / 1000.0
        val activity = params["S_ACTIVITY"]!! / 1000.0
        if (strength < 0.01) return src.clone()
        val w = src.cols(); val h = src.rows()
        val cx = w / 2.0; val cy = h / 2.0
        val dst = Mat.zeros(src.size(), src.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            val dx = x - cx; val dy = y - cy
            val r  = sqrt(dx*dx + dy*dy)
            val maxR  = sqrt(cx*cx + cy*cy) * wideness
            val twist = strength * exp(-r/(maxR+1.0)) * (1.0 + activity * sin(swirlPhase))
            val angle = atan2(dy, dx) + twist
            mapX.put(y, x, floatArrayOf((cx + r*cos(angle)).toFloat()))
            mapY.put(y, x, floatArrayOf((cy + r*sin(angle)).toFloat()))
        }
        Imgproc.remap(src, dst, mapX, mapY, interp, Core.BORDER_REFLECT)
        mapX.release(); mapY.release()
        val fogDist = params["S_FOG_DIST"]!! / 1000.0
        if (fogDist > 0.02) {
            val fogBrit = params["S_FOG_BRIT"]!! / 1000.0
            val fogSoft = params["S_FOG_SOFT"]!! / 1000.0
            val fog = Mat.zeros(dst.size(), dst.type())
            fog.setTo(Scalar(0.0, 0.0, fogBrit * 255.0))
            Core.addWeighted(dst, 1.0 - fogDist*fogSoft, fog, fogDist*fogSoft, 0.0, dst)
            fog.release()
        }
        return dst
    }

    private fun applyNatureAtmos(src: Mat, focusIntensity: Double = 0.5): Mat {
        val natureStr = params["NATURE_STR"]!! / 1000.0
        val atmosHue  = params["ATMOS_HUE"]!!  / 1000.0 * 180.0
        val atmosSat  = params["ATMOS_SAT"]!!  / 1000.0
        val atmosGlow = params["ATMOS_GLOW"]!! / 1000.0
        val dynSat    = (atmosSat  + focusIntensity * 0.3).coerceIn(0.0, 1.0)
        val dynGlow   = (atmosGlow + focusIntensity * 0.4).coerceIn(0.0, 1.0)

        val result = src.clone()
        if (natureStr > 0.02) {
            val blurK = (params["NATURE_BLUR"]!! / 1000.0 * 20).toInt() * 2 + 1
            Imgproc.GaussianBlur(result, result, Size(blurK.toDouble(), blurK.toDouble()), 0.0)
        }
        if (dynSat > 0.05 || dynGlow > 0.05) {
            val hsv = Mat(); Imgproc.cvtColor(result, hsv, Imgproc.COLOR_BGR2HSV)
            val channels = mutableListOf<Mat>(); Core.split(hsv, channels)
            val hueTarget = Mat(channels[0].size(), channels[0].type())
            hueTarget.setTo(Scalar(atmosHue))
            Core.addWeighted(channels[0], 1.0-dynSat, hueTarget, dynSat, 0.0, channels[0])
            hueTarget.release()
            Core.merge(channels, hsv)
            Imgproc.cvtColor(hsv, result, Imgproc.COLOR_HSV2BGR)
            hsv.release(); channels.forEach { it.release() }
        }
        if (dynGlow > 0.02) {
            val glow = Mat(); Imgproc.GaussianBlur(result, glow, Size(21.0, 21.0), 0.0)
            Core.addWeighted(result, 1.0+dynGlow, glow, -dynGlow*0.5, 0.0, result)
            glow.release()
        }
        val rainbowStr = params["RAINBOW_STR"]!! / 1000.0
        if (rainbowStr > 0.02) applyRainbow(result, rainbowStr, params["RAINBOW_POS"]!! / 1000.0)
        val vortex = params["VORTEX"]!! / 1000.0
        if (vortex > 0.02) applyVortexEffect(result, vortex)
        val waveStr = params["WAVE_STR"]!! / 1000.0
        if (waveStr > 0.02) applyWaveEffect(result, waveStr)
        return result
    }

    private fun applyShieldRipple(src: Mat): Mat {
        val shieldStr    = params["SHIELD_STR"]!!    / 1000.0
        val shieldRadius = params["SHIELD_RADIUS"]!! / 1000.0
        val rippleStr    = params["RIPPLE_STR"]!!    / 1000.0
        val rippleFreq   = params["RIPPLE_FREQ"]!!   / 1000.0 * 40.0
        val w = src.cols(); val h = src.rows()
        val cx = w / 2.0; val cy = h / 2.0
        val dst = Mat.zeros(src.size(), src.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            val dx = (x - cx) / cx; val dy = (y - cy) / cy
            val r  = sqrt(dx*dx + dy*dy); val angle = atan2(dy, dx)
            val ripple = rippleStr * sin(r*rippleFreq - ripplePhase*2*Math.PI) * exp(-r*2.0)
            val shield = if (shieldStr > 0 && r < shieldRadius) {
                val edge = (shieldRadius - r) / shieldRadius; shieldStr*edge*edge*0.3
            } else 0.0
            val nr = r + ripple + shield
            mapX.put(y, x, floatArrayOf((cx + nr*cos(angle)*cx).toFloat()))
            mapY.put(y, x, floatArrayOf((cy + nr*sin(angle)*cy).toFloat()))
        }
        Imgproc.remap(src, dst, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        mapX.release(); mapY.release()
        if (shieldStr > 0.05) {
            val sr = (shieldRadius * min(w, h) / 2.0).toInt()
            Imgproc.circle(dst, Point(cx, cy), sr, Scalar(0.0, 180.0*shieldStr, 255.0*shieldStr), (2+shieldStr*4).toInt())
        }
        return dst
    }

    private fun applyEdgeDetect(src: Mat): Mat {
        val amount = params["EDGE_AMOUNT"]!! / 1000.0
        if (amount < 0.01) return src.clone()
        val gray = Mat(); val edges = Mat(); val result = src.clone()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
        val thresh = params["EDGE_THRESH"]!! / 1000.0 * 300.0
        Imgproc.Canny(gray, edges, thresh, thresh*2)
        val edgeHue = params["EDGE_HUE"]!! / 1000.0 * 180.0
        val edgeSat = params["EDGE_SAT"]!! / 1000.0
        val edgeBgr = Mat(); Imgproc.cvtColor(edges, edgeBgr, Imgproc.COLOR_GRAY2BGR)
        val hsv = Mat(); Imgproc.cvtColor(edgeBgr, hsv, Imgproc.COLOR_BGR2HSV)
        val ch = mutableListOf<Mat>(); Core.split(hsv, ch)
        ch[0].setTo(Scalar(edgeHue)); ch[1].setTo(Scalar(edgeSat*255))
        Core.merge(ch, hsv)
        val edgeColor = Mat(); Imgproc.cvtColor(hsv, edgeColor, Imgproc.COLOR_HSV2BGR)
        Core.addWeighted(result, 1.0-amount, edgeColor, amount, 0.0, result)
        gray.release(); edges.release(); edgeBgr.release(); hsv.release()
        ch.forEach { it.release() }; edgeColor.release()
        return result
    }

    private fun applyColorEffect(src: Mat): Mat = applyColorGrading(src)

    private fun applyColorGrading(src: Mat): Mat {
        val brightness  = (params["BRIGHTNESS"]!! - 500) / 500.0 * 100.0
        val contrast    = params["CONTRAST"]!!   / 500.0
        val saturation  = params["SATURATION"]!! / 500.0
        val hueShift    = params["HUE"]!!        / 1000.0 * 180.0
        val negative    = params["NEGATIVE"]!!   / 1000.0
        val glow        = params["GLOW"]!!       / 1000.0
        var result = src.clone()
        result.convertTo(result, -1, contrast, brightness)
        if (saturation != 1.0 || hueShift != 0.0) {
            val hsv = Mat(); Imgproc.cvtColor(result, hsv, Imgproc.COLOR_BGR2HSV)
            val channels = mutableListOf<Mat>(); Core.split(hsv, channels)
            if (hueShift != 0.0) {
                Core.add(channels[0], Scalar(hueShift/2.0), channels[0])
                Core.normalize(channels[0], channels[0], 0.0, 180.0, Core.NORM_MINMAX)
            }
            channels[1].convertTo(channels[1], -1, saturation, 0.0)
            Core.merge(channels, hsv); Imgproc.cvtColor(hsv, result, Imgproc.COLOR_HSV2BGR)
            hsv.release(); channels.forEach { it.release() }
        }
        if (negative > 0.01) {
            val inv = Mat(); Core.bitwise_not(result, inv)
            Core.addWeighted(result, 1.0-negative, inv, negative, 0.0, result); inv.release()
        }
        if (glow > 0.01) {
            val glowMat = Mat(); Imgproc.GaussianBlur(result, glowMat, Size(21.0,21.0), 0.0)
            Core.addWeighted(result, 1.0, glowMat, glow*0.5, 0.0, result); glowMat.release()
        }
        return result
    }

    private fun applyRgbShift(src: Mat): Mat {
        val shift = (params["RGB_SHIFT"]!! / 1000.0 * 20).toInt()
        if (shift == 0) return src.clone()
        val channels = mutableListOf<Mat>(); Core.split(src, channels)
        val Mr = Mat.zeros(2, 3, CvType.CV_32F).apply { put(0,0,1.0,0.0,shift.toDouble()); put(1,0,0.0,1.0,0.0) }
        val Ml = Mat.zeros(2, 3, CvType.CV_32F).apply { put(0,0,1.0,0.0,-shift.toDouble()); put(1,0,0.0,1.0,0.0) }
        val rS = Mat(); val bS = Mat()
        Imgproc.warpAffine(channels[2], rS, Mr, src.size())
        Imgproc.warpAffine(channels[0], bS, Ml, src.size())
        val merged = Mat(); Core.merge(listOf(bS, channels[1], rS), merged)
        channels.forEach { it.release() }; rS.release(); bS.release(); Mr.release(); Ml.release()
        return merged
    }

    private fun applyRainbow(mat: Mat, strength: Double, pos: Double) {
        val w = mat.cols(); val h = mat.rows()
        val rainbowMat = Mat.zeros(mat.size(), CvType.CV_8UC3)
        for (y in 0 until h) {
            val hue = ((y.toDouble()/h + pos + wavePhase*0.1) % 1.0) * 180.0
            for (x in 0 until w) rainbowMat.put(y, x, hue, 255.0, 200.0)
        }
        val rainbowBgr = Mat(); Imgproc.cvtColor(rainbowMat, rainbowBgr, Imgproc.COLOR_HSV2BGR)
        Core.addWeighted(mat, 1.0-strength*0.5, rainbowBgr, strength*0.5, 0.0, mat)
        rainbowMat.release(); rainbowBgr.release()
    }

    private fun applyVortexEffect(mat: Mat, strength: Double) {
        val w = mat.cols(); val h = mat.rows(); val cx = w/2.0; val cy = h/2.0
        val dst = Mat.zeros(mat.size(), mat.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            val dx = x-cx; val dy = y-cy; val r = sqrt(dx*dx+dy*dy)
            val a = atan2(dy,dx) + strength*3.0*exp(-r/(cx*0.5))*cos(vortexPhase)
            mapX.put(y, x, floatArrayOf((cx+r*cos(a)).toFloat()))
            mapY.put(y, x, floatArrayOf((cy+r*sin(a)).toFloat()))
        }
        Imgproc.remap(mat, dst, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        dst.copyTo(mat); dst.release(); mapX.release(); mapY.release()
    }

    private fun applyWaveEffect(mat: Mat, strength: Double) {
        val w = mat.cols(); val h = mat.rows()
        val wavePos = params["WAVE_POS"]!! / 1000.0
        val dst = Mat.zeros(mat.size(), mat.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        for (y in 0 until h) for (x in 0 until w) {
            mapX.put(y, x, floatArrayOf((x + strength*30.0*sin(y/30.0+wavePhase+wavePos*Math.PI*2)).toFloat()))
            mapY.put(y, x, floatArrayOf((y + strength*15.0*sin(x/40.0+wavePhase)).toFloat()))
        }
        Imgproc.remap(mat, dst, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        dst.copyTo(mat); dst.release(); mapX.release(); mapY.release()
    }

    private fun applyPixelGrid(src: Mat): Mat {
        val blockSize = (params["PIXEL_SIZE"]!! / 1000.0 * 38 + 2).toInt().coerceAtLeast(2)
        val glowStr   = params["PIXEL_GLOW"]!! / 1000.0
        val w = src.cols(); val h = src.rows(); val dst = src.clone()
        val smallW = (w/blockSize).coerceAtLeast(1); val smallH = (h/blockSize).coerceAtLeast(1)
        val small = Mat()
        Imgproc.resize(src, small, Size(smallW.toDouble(), smallH.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
        Imgproc.resize(small, dst, Size(w.toDouble(), h.toDouble()), 0.0, 0.0, Imgproc.INTER_NEAREST)
        small.release()
        if (glowStr > 0.02) {
            val gc = Scalar(50.0*glowStr, 220.0*glowStr*(0.5+0.5*sin(laserPhase)), 255.0*glowStr)
            var x = 0; while (x < w) { Imgproc.line(dst, Point(x.toDouble(),0.0), Point(x.toDouble(),h.toDouble()), gc, 1); x+=blockSize }
            var y = 0; while (y < h) { Imgproc.line(dst, Point(0.0,y.toDouble()), Point(w.toDouble(),y.toDouble()), gc, 1); y+=blockSize }
        }
        return dst
    }

    private fun applyLaserGrid(src: Mat): Mat {
        val density = (params["LASER_DENSITY"]!! / 1000.0 * 76 + 4).toInt()
        val hue     = params["LASER_HUE"]!!      / 1000.0 * 180.0
        val w = src.cols(); val h = src.rows(); val dst = src.clone()
        val overlay = Mat.zeros(src.size(), src.type())
        val scrollY = (laserPhase / (2*Math.PI) * density).toInt() % density
        val scrollX = (laserPhase / (2*Math.PI) * density * 0.7).toInt() % density
        val pulse   = 0.6 + 0.4 * sin(laserPhase * 2)
        val hsvC = Mat(1,1, CvType.CV_8UC3).apply { put(0,0, hue, 230.0, (255*pulse).coerceIn(0.0,255.0)) }
        val bgrM = Mat(); Imgproc.cvtColor(hsvC, bgrM, Imgproc.COLOR_HSV2BGR)
        val ba = bgrM.get(0,0); val lc = Scalar(ba[0],ba[1],ba[2]); hsvC.release(); bgrM.release()
        var y = scrollY; while (y < h) { Imgproc.line(overlay, Point(0.0,y.toDouble()), Point(w.toDouble(),y.toDouble()), lc, 1); y+=density }
        var x = scrollX; while (x < w) { Imgproc.line(overlay, Point(x.toDouble(),0.0), Point(x.toDouble(),h.toDouble()), lc, 1); x+=density }
        val glow = Mat(); Imgproc.GaussianBlur(overlay, glow, Size(7.0,7.0), 0.0)
        Core.addWeighted(dst, 1.0, glow, 0.8, 0.0, dst)
        Core.addWeighted(dst, 1.0, overlay, 0.6, 0.0, dst)
        overlay.release(); glow.release(); return dst
    }

    private fun applyParallaxDepth(src: Mat): Mat {
        val numLayers = (params["PAR_LAYERS"]!! / 1000.0 * 5 + 1).toInt().coerceIn(1,6)
        val depthPx   = params["PAR_DEPTH"]!!   / 1000.0 * 60.0
        val w = src.cols().toDouble(); val h = src.rows().toDouble()
        val dst = Mat.zeros(src.size(), src.type())
        for (i in numLayers downTo 0) {
            val t = i.toDouble() / numLayers.toDouble()
            val M = Imgproc.getRotationMatrix2D(Point(w/2, h/2), 0.0, 1.0+t*0.35)
            M.put(0, 2, M.get(0,2)[0] + depthPx*t*sin(parallaxPhase+i*0.9))
            M.put(1, 2, M.get(1,2)[0] + depthPx*t*cos(parallaxPhase*0.7+i*1.1))
            val layer = Mat()
            Imgproc.warpAffine(src, layer, M, src.size(), Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
            Core.addWeighted(dst, 1.0, layer, (1.0-t*0.65)*(1.0/(numLayers+1)), 0.0, dst)
            layer.release(); M.release()
        }
        return dst
    }

    private fun applyCubeWarp(src: Mat, interp: Int = Imgproc.INTER_LINEAR): Mat {
        val strength = params["CUBE_STR"]!! / 1000.0
        if (strength < 0.01) return src.clone()
        val w = src.cols(); val h = src.rows(); val cx = w/2.0; val cy = h/2.0
        val rotX = cubePhase; val rotY = cubePhase*0.7
        val cosX = cos(rotX); val sinX = sin(rotX); val cosY = cos(rotY); val sinY = sin(rotY)
        val dst  = Mat.zeros(src.size(), src.type())
        val mapX = Mat(h, w, CvType.CV_32FC1); val mapY = Mat(h, w, CvType.CV_32FC1)
        val fL   = cx * 1.5
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x-cx)/cx; val ny = (y-cy)/cy
            val zD = fL/(fL+strength*100.0)
            val rx = nx*cosY - zD*sinY
            val ry = ny*cosX + (nx*sinY+zD*cosY)*sinX
            val rz = -ny*sinX + (nx*sinY+zD*cosY)*cosX + 0.001
            mapX.put(y, x, floatArrayOf(((rx/rz)*cx + cx).toFloat()))
            mapY.put(y, x, floatArrayOf(((ry/rz)*cy + cy).toFloat()))
        }
        Imgproc.remap(src, dst, mapX, mapY, interp, Core.BORDER_REFLECT)
        mapX.release(); mapY.release()
        val blended = Mat(); Core.addWeighted(src, 1.0-strength, dst, strength, 0.0, blended)
        dst.release(); return blended
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DRAW / BITMAP HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Convert ImageProxy (RGBA_8888) to Bitmap.
     * Uses the plane buffer directly — no MediaImage dependency.
     */
    private fun imageProxyToBitmap(proxy: ImageProxy): Bitmap? {
        return try {
            val plane  = proxy.planes[0]
            val buffer: ByteBuffer = plane.buffer
            val bytes  = ByteArray(buffer.remaining())
            buffer.get(bytes)
            val bmp = Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
            bmp
        } catch (e: Exception) { Log.e(TAG, "Bitmap convert failed", e); null }
    }

    private fun drawToSurface(mat: Mat) {
        val holder: SurfaceHolder = surfaceView.holder
        // lockCanvas() is correct here — lockHardwareCanvas() is only available
        // on SurfaceHolder when hardware acceleration is confirmed, and is NOT
        // available via SurfaceHolder.  Use lockCanvas + hardware-accelerated
        // window flag (set in AndroidManifest: hardwareAccelerated=true).
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            val bmp = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
            val display = mat.clone()
            Imgproc.cvtColor(display, display, Imgproc.COLOR_BGR2RGBA)
            Utils.matToBitmap(display, bmp); display.release()
            val paint = Paint().apply { isFilterBitmap = true }
            canvas.drawBitmap(bmp, null, RectF(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat()), paint)
            drawMotionHud(canvas)
            bmp.recycle()
        } finally { holder.unlockCanvasAndPost(canvas) }
    }

    private fun drawMotionHud(canvas: Canvas) {
        val barW = 80f; val barH = 8f
        val x = canvas.width - barW - 8f; val y = canvas.height - 30f
        val bgPaint = Paint().apply { color = Color.argb(120, 0, 0, 0) }
        canvas.drawRect(x, y, x + barW, y + barH, bgPaint)
        val fillPaint = Paint().apply {
            color = when {
                motionEnergy > 0.7 -> Color.RED
                motionEnergy > 0.3 -> Color.YELLOW
                else               -> Color.parseColor("#00FF88")
            }
        }
        canvas.drawRect(x, y, x + (barW * motionEnergy).toFloat(), y + barH, fillPaint)
        val txtPaint = Paint().apply { color = Color.WHITE; textSize = 18f; typeface = Typeface.MONOSPACE }
        canvas.drawText("⚡${(motionEnergy*100).toInt()}%", x, y - 4f, txtPaint)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SNAPSHOT
    // ─────────────────────────────────────────────────────────────────────────
    private fun saveSnapshot() {
        snapshotPending = true
        Toast.makeText(this, "Snapshot saved to Gallery", Toast.LENGTH_SHORT).show()
    }

    private fun doSaveSnapshot(mat: Mat) {
        try {
            val bmp = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
            val display = mat.clone()
            Imgproc.cvtColor(display, display, Imgproc.COLOR_BGR2RGBA)
            Utils.matToBitmap(display, bmp); display.release()
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "SpaceBeam_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SpaceBeam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            uri?.let { contentResolver.openOutputStream(it)?.use { os -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, os) } }
            bmp.recycle()
        } catch (e: Exception) { Log.e(TAG, "Snapshot failed", e) }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VIDEO RECORDING
    // Uses MediaRecorder(context) constructor — correct for API 31+.
    // Falls back via @Suppress for older APIs where the no-arg ctor is used.
    // ─────────────────────────────────────────────────────────────────────────
    private fun toggleRecording() {
        if (isRecording) {
            stopRecording()
            btnRecord.text = "● REC"
        } else {
            if (startRecording()) {
                isRecording = true
                btnRecord.text = "■ STOP"
            }
        }
    }

    private fun startRecording(): Boolean {
        if (frameW == 0 || frameH == 0) {
            Toast.makeText(this, "Wait for camera to start", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "SpaceBeam_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpaceBeam")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw Exception("Cannot create video URI")
            val fd = contentResolver.openFileDescriptor(uri, "w")?.fileDescriptor
                ?: throw Exception("Cannot open FD")

            // MediaRecorder(context) constructor requires API 31.
            // On API 23-30 use no-arg constructor.
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setVideoSize(frameW, frameH)
            mr.setVideoFrameRate(30)
            mr.setVideoEncodingBitRate(4_000_000)
            mr.setOutputFile(fd)
            mr.prepare()
            mr.start()
            mediaRecorder = mr
            recorderSurface = mr.surface
            Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Recording start failed", e)
            Toast.makeText(this, "Recording failed: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun stopRecording() {
        isRecording = false
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (_: Exception) {}
        mediaRecorder = null
        recorderSurface = null
        recorderInputBitmap?.recycle(); recorderInputBitmap = null
        if (frameW > 0)
            Toast.makeText(this, "Recording saved to Movies/SpaceBeam", Toast.LENGTH_SHORT).show()
    }

    /**
     * Feed the current processed Mat to the MediaRecorder Surface.
     *
     * Surface.lockCanvas(null) is the correct API here.
     * Surface.lockHardwareCanvas() does NOT exist on android.view.Surface —
     * it only exists on android.view.SurfaceHolder.  Using lockCanvas(null)
     * is safe: the Surface backing MediaRecorder accepts software canvas draws.
     */
    private fun feedRecorder(mat: Mat) {
        val surface = recorderSurface ?: return
        try {
            val bmp = recorderInputBitmap
                ?: Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
                    .also { recorderInputBitmap = it }
            val display = mat.clone()
            Imgproc.cvtColor(display, display, Imgproc.COLOR_BGR2RGBA)
            Utils.matToBitmap(display, bmp); display.release()
            // FIX: Surface does NOT have lockHardwareCanvas() — use lockCanvas(null)
            val c: Canvas = surface.lockCanvas(null) ?: return
            c.drawBitmap(bmp, null, RectF(0f, 0f, c.width.toFloat(), c.height.toFloat()), null)
            surface.unlockCanvasAndPost(c)
        } catch (e: Exception) {
            Log.e(TAG, "Recorder feed failed", e)
            stopRecording()
        }
        if (snapshotPending) { snapshotPending = false; doSaveSnapshot(mat) }
    }
}
