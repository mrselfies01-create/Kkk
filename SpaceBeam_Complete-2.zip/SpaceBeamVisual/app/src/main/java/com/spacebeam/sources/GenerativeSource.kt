package com.spacebeam.sources

import android.content.Context
import android.opengl.GLES20
import com.spacebeam.engine.Fbo
import com.spacebeam.engine.GlProgram
import com.spacebeam.engine.QuadRenderer

enum class GenerativeType(val fragAsset: String, val displayName: String) {
    PLASMA("shaders/generative/plasma.frag", "Plasma"),
    STARFIELD("shaders/generative/starfield.frag", "Starfield")
}

class GenerativeSource(
    private val context: Context,
    var type: GenerativeType = GenerativeType.PLASMA,
    private val width: Int,
    private val height: Int
) : Source() {

    private val VERT = """
        attribute vec2 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord;
        void main(){gl_Position=vec4(aPosition,0.,1.);vTexCoord=aTexCoord;}
    """.trimIndent()

    private var fbo: Fbo? = null
    private var program: GlProgram? = null
    private var quad: QuadRenderer? = null
    private var elapsed = 0f

    override val texId: Int get() = fbo?.texId ?: -1

    init { initGl() }

    private fun initGl() {
        fbo?.delete(); program?.delete(); quad?.delete()
        val fragSrc = context.assets.open(type.fragAsset).bufferedReader().readText()
        val vertSrc = context.assets.open("shaders/quad.vert").bufferedReader().readText()
        fbo     = Fbo(width, height)
        program = GlProgram(vertSrc, fragSrc)
        quad    = QuadRenderer()
        label   = type.displayName
    }

    override fun update() {
        val fbo = fbo ?: return
        val prog = program ?: return
        val q = quad ?: return
        elapsed += 1f / 60f
        fbo.bind()
        GLES20.glViewport(0, 0, width, height)
        prog.use()
        prog.setFloat("uTime", elapsed)
        prog.setVec2("uResolution", width.toFloat(), height.toFloat())
        q.draw(prog)
        fbo.unbind()
    }

    override fun release() { fbo?.delete(); program?.delete(); quad?.delete() }
}
