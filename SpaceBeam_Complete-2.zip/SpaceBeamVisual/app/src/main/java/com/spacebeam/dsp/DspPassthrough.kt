package com.spacebeam.dsp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.*
import android.util.Log
import androidx.core.content.ContextCompat
import com.spacebeam.modulation.ParamStore
import kotlin.math.*

/**
 * Real-time DSP audio passthrough:
 *   Mic → 1st-order IIR LP + HP → noise gate → atmosphere guard → gain → speaker
 *
 * Atmosphere guard: when measured mic RMS energy exceeds DSP_GUARD threshold,
 * attenuates output so audio doesn't overwhelm the visual atmosphere rendering.
 */
class DspPassthrough(private val context: Context) {

    private val TAG = "DspPassthrough"

    val SAMPLE_RATE = 44100
    val CH_IN  = AudioFormat.CHANNEL_IN_STEREO
    val CH_OUT = AudioFormat.CHANNEL_OUT_STEREO
    val ENC    = AudioFormat.ENCODING_PCM_FLOAT

    private var record: AudioRecord? = null
    private var track:  AudioTrack?  = null
    private var thread: Thread?      = null

    @Volatile var running = false
    @Volatile var micEnergy = 0.0   // 0..1 RMS, read by EffectChain for atmosphere guard

    // IIR filter state [L, R]
    private val lpState = FloatArray(2)
    private val hpState = FloatArray(2)
    private val hpPrev  = FloatArray(2)
    private var lpAlpha = 0.9f
    private var hpAlpha = 0.1f

    fun start() {
        if (running) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "No RECORD_AUDIO permission"); return
        }
        recalcCoeffs()
        val minBuf = maxOf(
            AudioRecord.getMinBufferSize(SAMPLE_RATE, CH_IN, ENC),
            AudioTrack.getMinBufferSize(SAMPLE_RATE, CH_OUT, ENC)
        ) * 4

        try {
            record = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CH_IN, ENC, minBuf)
            track  = AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(ENC)
                    .setChannelMask(CH_OUT)
                    .build(),
                minBuf, AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
        } catch (e: Exception) { Log.e(TAG, "Init failed", e); return }

        lpState.fill(0f); hpState.fill(0f); hpPrev.fill(0f)
        running = true
        record!!.startRecording(); track!!.play()

        thread = Thread({
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
            val floatsPerRead = minBuf / 4 / 2   // /4=bytes per float /2=stereo
            val buf    = FloatArray(floatsPerRead * 2)
            val outBuf = FloatArray(buf.size)

            while (running) {
                val read = record!!.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (read <= 0) continue
                recalcCoeffs()

                val gain      = ParamStore.norm("DSP_GAIN") * 2f         // 0..2
                val gate      = ParamStore.norm("DSP_GATE") * 0.05f      // 0..0.05
                val guard     = ParamStore.norm("DSP_GUARD")             // 0..1
                val lp        = lpAlpha; val hp = hpAlpha

                // Atmosphere guard attenuation
                val guardAtt = if (micEnergy > guard) {
                    val ov = ((micEnergy - guard) / (1.0 - guard + 1e-6)).coerceIn(0.0, 1.0)
                    (1.0 - ov * 0.8).toFloat()
                } else 1f

                val effGain = gain * guardAtt
                var sumSq = 0.0

                for (i in 0 until read step 2) {
                    for (ch in 0..1) {
                        val idx = i + ch
                        if (idx >= read) { if (idx < outBuf.size) outBuf[idx] = 0f; continue }
                        var s = buf[idx]
                        // LP
                        lpState[ch] = lp * s + (1f - lp) * lpState[ch]; s = lpState[ch]
                        // HP
                        val hpOut = hp * (hpState[ch] + s - hpPrev[ch])
                        hpPrev[ch] = s; hpState[ch] = hpOut; s = hpOut
                        // Gate
                        if (abs(s) < gate) s = 0f
                        // Gain + guard
                        s = (s * effGain).coerceIn(-1f, 1f)
                        if (idx < outBuf.size) outBuf[idx] = s
                        sumSq += s.toDouble().pow(2)
                    }
                }
                micEnergy = micEnergy * 0.9 + sqrt(sumSq / read) * 0.1
                track!!.write(outBuf, 0, read, AudioTrack.WRITE_BLOCKING)
            }
            record?.stop(); track?.stop()
        }, "DSP-Thread").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.join(400); thread = null
        try { record?.release() } catch (_: Exception) {}
        try { track?.release()  } catch (_: Exception) {}
        record = null; track = null; micEnergy = 0.0
    }

    private fun recalcCoeffs() {
        val fs = SAMPLE_RATE.toFloat(); val dt = 1f / fs
        val lpFreq = 20f * 10f.pow(ParamStore.norm("DSP_LP_FREQ") * 3f)
        val hpFreq = 20f * 10f.pow(ParamStore.norm("DSP_HP_FREQ") * 2f)
        val lpRc = 1f / (2f * Math.PI.toFloat() * lpFreq)
        val hpRc = 1f / (2f * Math.PI.toFloat() * hpFreq)
        lpAlpha = dt / (lpRc + dt)
        hpAlpha = hpRc / (hpRc + dt)
    }
}
