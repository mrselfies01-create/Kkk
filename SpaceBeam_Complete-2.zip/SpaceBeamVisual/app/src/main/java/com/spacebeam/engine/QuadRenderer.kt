package com.spacebeam.engine

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Draws a full-screen quad.  Used for every effect pass.
 * Bind program → set uniforms → call draw().
 */
class QuadRenderer {

    private val vbo: Int
    private val quadData = floatArrayOf(
        // x,    y,    u,    v
        -1f,  -1f,  0f,   1f,
         1f,  -1f,  1f,   1f,
        -1f,   1f,  0f,   0f,
         1f,   1f,  1f,   0f,
    )

    init {
        val buf: FloatBuffer = ByteBuffer.allocateDirect(quadData.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(quadData); position(0) }
        val ids = IntArray(1); GLES20.glGenBuffers(1, ids, 0); vbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quadData.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Draw with the currently bound program, using aPosition and aTexCoord attributes. */
    fun draw(program: GlProgram) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        val posLoc = program.attrib("aPosition")
        val texLoc = program.attrib("aTexCoord")
        if (posLoc >= 0) {
            GLES20.glEnableVertexAttribArray(posLoc)
            GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, 0)
        }
        if (texLoc >= 0) {
            GLES20.glEnableVertexAttribArray(texLoc)
            GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, 8)
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        if (posLoc >= 0) GLES20.glDisableVertexAttribArray(posLoc)
        if (texLoc >= 0) GLES20.glDisableVertexAttribArray(texLoc)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    fun delete() = GLES20.glDeleteBuffers(1, intArrayOf(vbo), 0)
}
