package com.spacebeam.modulation

import kotlin.math.*

enum class LfoShape { SINE, TRIANGLE, RAMP, WOBBLE_SINE, RANDOM_SMOOTH, RANDOM_STEP }

/** A single animatable float parameter.
 *  raw value is set by the slider (0..1000 int, stored as 0..1 float internally).
 *  actual = smoothed(raw + lfo + sensor)  clamped to [min, max]. */
data class Param(
    val key: String,
    val label: String,
    val min: Float = 0f,
    val max: Float = 1000f,
    val default: Float = 500f,
    val locked: Boolean = false
) {
    // Slider raw value (0..max)
    var rawValue: Float = default
        set(v) { field = v.coerceIn(min, max) }

    // Smoothed actual value
    var actualValue: Float = default
        private set

    var smooth: Float = 0f   // 0=instant, 1=very slow

    // LFO
    var lfoEnabled: Boolean = false
    var lfoShape: LfoShape = LfoShape.SINE
    var lfoSpeed: Float = 1f    // Hz (or BPM divisor when synced)
    var lfoDepth: Float = 0f    // 0..1 of (max-min)
    var lfoBpmSync: Boolean = false
    var lfoPhase: Double = 0.0  // internal phase accumulator

    // Sensor
    var sensorAxis: SensorAxis = SensorAxis.NONE
    var sensorDepth: Float = 0f  // 0..1

    // Actual value is locked by presets
    var isLocked: Boolean = locked

    /** Call once per frame.
     *  @param dt         seconds since last frame
     *  @param bpm        current BPM for LFO sync
     *  @param sensorVal  current normalised sensor value for the mapped axis (-1..1)
     */
    fun tick(dt: Float, bpm: Float, sensorVal: Float) {
        // LFO phase advance
        val freqHz = if (lfoBpmSync && bpm > 0f) (bpm / 60f * lfoSpeed) else lfoSpeed
        lfoPhase = (lfoPhase + freqHz * dt) % 1.0

        val lfoOut: Float = if (lfoEnabled && lfoDepth > 0f) {
            val shaped = when (lfoShape) {
                LfoShape.SINE          -> sin(lfoPhase * 2 * Math.PI).toFloat()
                LfoShape.TRIANGLE      -> (2f * abs((lfoPhase * 2 - floor(lfoPhase * 2 + 0.5)).toFloat()) - 1f)
                LfoShape.RAMP          -> (lfoPhase * 2 - 1).toFloat()
                LfoShape.WOBBLE_SINE   -> sin(lfoPhase * 2 * Math.PI + sin(lfoPhase * 6 * Math.PI) * 0.5).toFloat()
                LfoShape.RANDOM_SMOOTH -> smoothRandom(lfoPhase)
                LfoShape.RANDOM_STEP   -> if (lfoPhase < 0.5) -1f else 1f
            }
            shaped * lfoDepth * (max - min) * 0.5f
        } else 0f

        val sensorOut = if (sensorAxis != SensorAxis.NONE) sensorVal * sensorDepth * (max - min) * 0.5f
        else 0f

        val target = (rawValue + lfoOut + sensorOut).coerceIn(min, max)
        // Smooth approach
        actualValue = if (smooth < 0.001f) target
        else actualValue + (target - actualValue) * (1f - smooth.coerceIn(0f, 0.999f)).pow(dt * 60f)
    }

    /** Normalised actual value 0..1 */
    val norm: Float get() = (actualValue - min) / (max - min).coerceAtLeast(0.001f)

    private var rndA = 0f; private var rndB = 0f; private var rndPhase0 = 0.0
    private fun smoothRandom(ph: Double): Float {
        if (ph < rndPhase0) { rndA = rndB; rndB = (Math.random().toFloat() * 2f - 1f) }
        rndPhase0 = ph
        return rndA + (rndB - rndA) * ph.toFloat()
    }
}

enum class SensorAxis { NONE, PITCH, ROLL, YAW, ACCEL_X, ACCEL_Y, ACCEL_Z }
