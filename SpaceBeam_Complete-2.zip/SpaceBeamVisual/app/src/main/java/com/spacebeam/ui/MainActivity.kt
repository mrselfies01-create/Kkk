package com.spacebeam.ui

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.SensorManager
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.spacebeam.dsp.DspPassthrough
import com.spacebeam.effects.EffectChain
import com.spacebeam.midi.MidiController
import com.spacebeam.modulation.*
import com.spacebeam.sources.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private lateinit var glView:         android.opengl.GLSurfaceView
    private lateinit var tvFps:          TextView
    private lateinit var tvMotion:       TextView
    private lateinit var paramScroll:    ScrollView
    private lateinit var paramContainer: LinearLayout
    private lateinit var btnRecord:      Button
    private lateinit var btnSnapshot:    Button
    private lateinit var btnSettings:    ImageButton
    private lateinit var btnAddSource:   Button
    private lateinit var presetBar:      LinearLayout
    private lateinit var seekTransition: SeekBar
    private lateinit var btnAutoPlay:    ImageButton

    private lateinit var chain:  EffectChain
    private lateinit var dsp:    DspPassthrough
    private lateinit var midi:   MidiController

    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoPlayRunning = false
    private var currentPresetSlot = -1
    private var transitionMs = 1000L

    // BPM tap
    private val bpmTaps = mutableListOf<Long>()

    // Gesture state
    private var gesturePointer0 = PointF(); private var gesturePointer1 = PointF()
    private var gestureStartDist = 0f;      private var gestureStartAngle = 0f
    private var gestureStartZoom = 0f;      private var gestureStartRot = 0f
    private var gestureStartX = 0f;         private var gestureStartY = 0f

    // ── Permissions ───────────────────────────────────────────────────────────
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.CAMERA] == true) initApp()
        else Toast.makeText(this, "Camera permission required", Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        setContentView(buildLayout())

        val needed = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) initApp() else permLauncher.launch(missing.toTypedArray())
    }

    override fun onResume()  { super.onResume(); if (::glView.isInitialized) glView.onResume() }
    override fun onPause()   { super.onPause();  if (::glView.isInitialized) glView.onPause() }
    override fun onDestroy() {
        super.onDestroy()
        if (::chain.isInitialized) chain.releaseAll()
        if (::dsp.isInitialized)   dsp.stop()
        if (::midi.isInitialized)  midi.disconnect()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        ParamStore.unregisterSensors(sm)
    }

    // ── App init (after permissions) ──────────────────────────────────────────
    private fun initApp() {
        chain = EffectChain(this)
        dsp   = DspPassthrough(this)
        midi  = MidiController(this).also { it.init() }

        // Add default camera source
        val cam = CameraSource(this, this)
        chain.sources.add(cam)

        // GL surface view
        glView = android.opengl.GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(chain)
            renderMode = android.opengl.GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        (findViewById<FrameLayout>(R.id.glContainer)).addView(
            glView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        // GL init for camera happens on GL thread
        glView.queueEvent { cam.initGl(chain.W, chain.H) }

        chain.onFpsUpdate    = { fps -> mainHandler.post { tvFps.text    = "FPS: ${fps.toInt()}" } }
        chain.onMotionEnergy = { e   -> mainHandler.post { tvMotion.text = "⚡${(e*100).toInt()}%" } }

        midi.onParamChanged = { key, _ -> mainHandler.post { refreshParamUI(key) } }

        // Sensors
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        ParamStore.registerSensors(sm)

        // Build UI
        buildParamUI()
        buildPresetBar()
        wireGestures()

        // Load preset 0 as default (simple 2×2 kaleidoscope)
        ParamStore["K_AXIS"].rawValue   = 2f
        ParamStore["K_AMOUNT"].rawValue = 1000f
    }

    // ── Layout builder ────────────────────────────────────────────────────────
    private fun buildLayout(): android.view.View {
        val root = android.widget.FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            id = android.view.View.generateViewId()
        }

        // GL container (full screen behind everything)
        val glContainer = FrameLayout(this).apply { id = R.id.glContainer }
        root.addView(glContainer, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)

        // Right-side control panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#CC111111"))
            setPadding(8, 8, 8, 8)
        }
        val panelLp = FrameLayout.LayoutParams(360, FrameLayout.LayoutParams.MATCH_PARENT).apply {
            gravity = android.view.Gravity.END
        }

        // Top row: FPS + motion + record + snapshot
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvFps    = TextView(this).apply { text = "FPS: --"; setTextColor(android.graphics.Color.WHITE); textSize = 11f }
        tvMotion = TextView(this).apply { text = "⚡0%"; setTextColor(android.graphics.Color.parseColor("#00FF88")); textSize = 11f; setPadding(8,0,8,0) }
        btnRecord   = Button(this).apply { text = "● REC"; textSize = 10f; setBackgroundColor(android.graphics.Color.parseColor("#661111")) }
        btnSnapshot = Button(this).apply { text = "📷"; textSize = 14f; setBackgroundColor(android.graphics.Color.parseColor("#222222")) }
        btnSettings = ImageButton(this).apply { setBackgroundColor(android.graphics.Color.parseColor("#222222")) }
        btnSettings.setImageResource(android.R.drawable.ic_menu_manage)
        topRow.addView(tvFps);    topRow.addView(tvMotion)
        topRow.addView(btnRecord); topRow.addView(btnSnapshot); topRow.addView(btnSettings)
        panel.addView(topRow)

        // Effect section + source add
        btnAddSource = Button(this).apply {
            text = "+ SOURCE"; textSize = 10f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.parseColor("#113311"))
        }
        panel.addView(btnAddSource)

        // Param scroll area
        paramScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        paramContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        paramScroll.addView(paramContainer)
        panel.addView(paramScroll)

        // Preset bar
        presetBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val transRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        seekTransition = SeekBar(this).apply {
            max = 4000; progress = 1000
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        seekTransition.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { transitionMs = v.toLong() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        btnAutoPlay = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_play)
            setBackgroundColor(android.graphics.Color.parseColor("#222222"))
        }
        transRow.addView(TextView(this).apply { text = "⏱"; setTextColor(android.graphics.Color.WHITE); textSize = 14f })
        transRow.addView(seekTransition)
        transRow.addView(btnAutoPlay)
        presetBar.addView(transRow)
        panel.addView(presetBar)

        root.addView(panel, panelLp)

        // Wire buttons
        btnRecord.setOnClickListener  { toggleRecording() }
        btnSnapshot.setOnClickListener { takeSnapshot() }
        btnSettings.setOnClickListener { showSettings() }
        btnAddSource.setOnClickListener { showAddSourceDialog() }
        btnAutoPlay.setOnClickListener  { toggleAutoPlay() }

        return root
    }

    // ── Param UI ──────────────────────────────────────────────────────────────
    private val sections = linkedMapOf(
        "MIXER"              to listOf("CAMERA"),
        "CAMERA TRANSFORM"   to listOf("CAM_ANGLE","CAM_ZOOM","MOVE_X","MOVE_Y","TILT_X","TILT_Y","BEND","WOBBLE","DISTORT","RGB_SHIFT"),
        "COLOR"              to listOf("BRIGHTNESS","HUE","NEGATIVE","GLOW","CONTRAST","SATURATION"),
        "EDGE DETECT"        to listOf("EDGE_AMOUNT","EDGE_THRESH","EDGE_HUE","EDGE_SAT"),
        "KALEIDOSCOPE"       to listOf("K_AXIS","K_AMOUNT","K_ZOOM","K_ANGLE"),
        "MASTER TRANSFORM"   to listOf("M_ANGLE","M_ZOOM","M_MOVE_X","M_MOVE_Y"),
        "3D TUNNEL"          to listOf("T_STRENGTH","T_SHAPE","FISHEYE","T_SPEED","T_FOG_DIST","T_FOG_HUE","T_FOG_SAT","T_FOG_BRIT","RAINBOW_STR","WAVE_STR","CURVE","VORTEX","FLUX"),
        "SWIRL"              to listOf("S_STRENGTH","S_WIDENESS","S_ACTIVITY","S_SPEED","S_FOG_DIST","S_FOG_SOFT","S_FOG_HUE","S_FOG_SAT","S_FOG_BRIT"),
        "SHIELD & RIPPLE"    to listOf("SHIELD_STR","SHIELD_RADIUS","RIPPLE_STR","RIPPLE_SPEED","RIPPLE_FREQ","NATURE_STR","NATURE_BLUR","ATMOS_HUE","ATMOS_SAT","ATMOS_GLOW","BPM"),
        "SPIRIT VISUAL"      to listOf("SPIRIT_SENS","SPIRIT_TRAIL","SPIRIT_HUE","SPIRIT_STR"),
        "ATMOSPHERE THRESH"  to listOf("ATM_THRESH","ATM_STR","ATM_HUE","ATM_BLUR"),
        "FOCUS INTENSITY"    to listOf("FOCUS_DRIVE","FOCUS_MANUAL"),
        "MOTION ZONE"        to listOf("MZ_RIPPLE_STR","MZ_RIPPLE_FREQ","MZ_SMOOTH_STR"),
        "DSP AUDIO"          to listOf("DSP_ENABLE","DSP_GAIN","DSP_LP_FREQ","DSP_HP_FREQ","DSP_GATE","DSP_GUARD"),
        "GPU"                to listOf("GPU_QUALITY")
    )

    private val sectionBodies = mutableMapOf<String, LinearLayout>()
    private val paramSeekBars = mutableMapOf<String, SeekBar>()
    private val paramValueTvs = mutableMapOf<String, TextView>()

    private fun buildParamUI() {
        paramContainer.removeAllViews()
        sectionBodies.clear(); paramSeekBars.clear(); paramValueTvs.clear()

        for ((sectionName, keys) in sections) {
            val header = TextView(this).apply {
                text = "▶  $sectionName"
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.parseColor("#1A1A2E"))
                setPadding(12, 10, 12, 10)
                textSize = 12f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility  = View.GONE
            }
            sectionBodies[sectionName] = body
            header.setOnClickListener {
                val open = body.visibility == View.VISIBLE
                body.visibility = if (open) View.GONE else View.VISIBLE
                header.text = (if (!open) "▼  " else "▶  ") + sectionName
            }
            paramContainer.addView(header)
            paramContainer.addView(body)

            for (key in keys) {
                val param = ParamStore.all[key] ?: continue
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(4, 2, 4, 2)
                }
                val labelBtn = Button(this).apply {
                    text = param.label
                    textSize = 9f
                    setTextColor(if (param.isLocked) android.graphics.Color.YELLOW else android.graphics.Color.WHITE)
                    setBackgroundColor(android.graphics.Color.parseColor("#222233"))
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f)
                    setPadding(4, 2, 4, 2)
                }
                val seek = SeekBar(this).apply {
                    max      = param.max.toInt()
                    progress = param.rawValue.toInt()
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2.5f)
                }
                val tvVal = TextView(this).apply {
                    text = param.rawValue.toInt().toString()
                    setTextColor(android.graphics.Color.parseColor("#AAFFAA"))
                    textSize = 10f
                    setPadding(4, 0, 4, 0)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
                }
                paramSeekBars[key] = seek
                paramValueTvs[key] = tvVal

                seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, v: Int, user: Boolean) {
                        if (!user) return
                        param.rawValue = v.toFloat()
                        tvVal.text = v.toString()
                        onParamChanged(key, v.toFloat())
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {
                        midi.learningParam?.let { } // cancel learn on touch
                    }
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })

                // Long-press label → open param detail / MIDI learn / lock
                labelBtn.setOnLongClickListener { showParamDetail(key); true }
                // Double-tap label → reset to default
                labelBtn.setOnClickListener {
                    if (midi.learningParam == null) {
                        midi.learningParam = key
                        Toast.makeText(this, "Move a MIDI CC to map to ${param.label}", Toast.LENGTH_SHORT).show()
                    }
                }
                row.addView(labelBtn); row.addView(seek); row.addView(tvVal)
                body.addView(row)
            }
        }
    }

    private fun refreshParamUI(key: String) {
        val param = ParamStore.all[key] ?: return
        paramSeekBars[key]?.progress = param.rawValue.toInt()
        paramValueTvs[key]?.text     = param.rawValue.toInt().toString()
    }

    private fun onParamChanged(key: String, value: Float) {
        when (key) {
            "DSP_ENABLE" -> if (value > 0) dsp.start() else dsp.stop()
        }
    }

    private fun showParamDetail(key: String) {
        val param = ParamStore.all[key] ?: return
        val dialog = AlertDialog.Builder(this)
        val v = layoutInflater.inflate(android.R.layout.simple_list_item_2, null)
        dialog.setTitle("${param.label}  (${param.rawValue.toInt()})")
        dialog.setItems(arrayOf(
            if (param.isLocked) "🔓 Unlock (currently locked)" else "🔒 Lock",
            "LFO: ${if (param.lfoEnabled) "ON ✓" else "off"}",
            "LFO Speed: ${param.lfoSpeed}",
            "LFO Depth: ${param.lfoDepth}",
            "LFO Shape: ${param.lfoShape.name}",
            "LFO BPM Sync: ${param.lfoBpmSync}",
            "Sensor: ${param.sensorAxis.name}",
            "Smooth: ${param.smooth}",
            "Reset to default"
        )) { _, which ->
            when (which) {
                0 -> { param.isLocked = !param.isLocked; buildParamUI() }
                1 -> { param.lfoEnabled = !param.lfoEnabled }
                2 -> showFloatInput("LFO Speed", param.lfoSpeed) { param.lfoSpeed = it }
                3 -> showFloatInput("LFO Depth", param.lfoDepth) { param.lfoDepth = it }
                4 -> showEnumPicker("LFO Shape", LfoShape.values().map { it.name }) { param.lfoShape = LfoShape.values()[it] }
                5 -> { param.lfoBpmSync = !param.lfoBpmSync }
                6 -> showEnumPicker("Sensor", SensorAxis.values().map { it.name }) { param.sensorAxis = SensorAxis.values()[it] }
                7 -> showFloatInput("Smooth (0–1)", param.smooth) { param.smooth = it.coerceIn(0f, 0.999f) }
                8 -> { param.rawValue = param.default; refreshParamUI(key) }
            }
        }
        dialog.show()
    }

    private fun showFloatInput(label: String, current: Float, onSet: (Float) -> Unit) {
        val et = EditText(this).apply { setText(current.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle(label).setView(et)
            .setPositiveButton("Set") { _, _ -> et.text.toString().toFloatOrNull()?.let { onSet(it) } }
            .show()
    }

    private fun showEnumPicker(label: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(label)
            .setItems(items.toTypedArray()) { _, which -> onPick(which) }.show()
    }

    // ── Preset bar ────────────────────────────────────────────────────────────
    private fun buildPresetBar() {
        // Remove old preset buttons if any
        val existingRow = presetBar.findViewWithTag<LinearLayout>("presetRow")
        if (existingRow != null) presetBar.removeView(existingRow)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; tag = "presetRow" }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        for (i in 1..9) {
            val btn = Button(this).apply {
                text = "$i"
                textSize = 12f
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(
                    if (i == currentPresetSlot + 1) android.graphics.Color.parseColor("#334466")
                    else android.graphics.Color.parseColor("#222222")
                )
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(2, 2, 2, 2)
                }
                tag = "preset_$i"
            }
            btn.setOnClickListener {
                ParamStore.loadPreset(i - 1)
                currentPresetSlot = i - 1
                // Smooth transition via param smoothing
                ParamStore.all.values.forEach { p -> if (p.smooth < 0.01f) p.smooth = 0.02f }
                mainHandler.postDelayed({
                    ParamStore.all.values.forEach { p -> if (p.smooth < 0.05f) p.smooth = 0f }
                }, transitionMs + 200)
                buildParamUI()
                Toast.makeText(this, "Preset $i", Toast.LENGTH_SHORT).show()
            }
            btn.setOnLongClickListener {
                ParamStore.savePreset(i - 1)
                btn.setBackgroundColor(android.graphics.Color.parseColor("#226644"))
                Toast.makeText(this, "Preset $i saved", Toast.LENGTH_SHORT).show()
                true
            }
            if (i <= 5) row1.addView(btn) else row2.addView(btn)
        }
        // TAP BPM button
        val tapBtn = Button(this).apply {
            text = "TAP BPM"
            textSize = 9f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.parseColor("#332222"))
        }
        tapBtn.setOnClickListener { tapBpm() }
        row2.addView(tapBtn)

        presetBar.addView(row1, 0)
        presetBar.addView(row2, 1)
    }

    private fun tapBpm() {
        val now = System.currentTimeMillis()
        bpmTaps.add(now)
        if (bpmTaps.size > 8) bpmTaps.removeAt(0)
        if (bpmTaps.size >= 2) {
            val avg = (1 until bpmTaps.size).map { (bpmTaps[it] - bpmTaps[it-1]).toDouble() }.average()
            val bpm = (60000.0 / avg).coerceIn(40.0, 300.0).toFloat()
            ParamStore["BPM"].rawValue = bpm
            refreshParamUI("BPM")
            Toast.makeText(this, "BPM: ${bpm.toInt()}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Auto-play ─────────────────────────────────────────────────────────────
    private var autoPlayIndex = 0
    private val autoPlayRunnable = object : Runnable {
        override fun run() {
            if (!autoPlayRunning) return
            val slot = autoPlayIndex % 9
            ParamStore.loadPreset(slot)
            currentPresetSlot = slot
            autoPlayIndex++
            mainHandler.postDelayed(this, maxOf(transitionMs * 3, 3000))
        }
    }

    private fun toggleAutoPlay() {
        autoPlayRunning = !autoPlayRunning
        btnAutoPlay.setImageResource(
            if (autoPlayRunning) android.R.drawable.ic_media_pause
            else                 android.R.drawable.ic_media_play)
        if (autoPlayRunning) mainHandler.post(autoPlayRunnable)
        else mainHandler.removeCallbacks(autoPlayRunnable)
    }

    // ── Two-finger gestures → Master Transform ────────────────────────────────
    private fun wireGestures() {
        glView.setOnTouchListener { _, ev ->
            when {
                ev.pointerCount >= 2 -> handleTwoFingerGesture(ev)
                else -> false
            }
        }
    }

    private fun handleTwoFingerGesture(ev: MotionEvent): Boolean {
        val x0 = ev.getX(0); val y0 = ev.getY(0)
        val x1 = ev.getX(1); val y1 = ev.getY(1)
        val dx = x1 - x0; val dy = y1 - y0
        val dist  = sqrt(dx*dx + dy*dy)
        val angle = atan2(dy, dx)
        val cx    = (x0 + x1) / 2f; val cy = (y0 + y1) / 2f

        when (ev.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> {
                gesturePointer0.set(x0, y0); gesturePointer1.set(x1, y1)
                gestureStartDist  = dist;    gestureStartAngle = angle
                gestureStartZoom  = ParamStore.norm("M_ZOOM") * 1000f
                gestureStartRot   = ParamStore.norm("M_ANGLE") * 1000f
                gestureStartX     = ParamStore.norm("M_MOVE_X") * 1000f
                gestureStartY     = ParamStore.norm("M_MOVE_Y") * 1000f
            }
            MotionEvent.ACTION_MOVE -> {
                if (gestureStartDist > 10f) {
                    val zoomDelta = (dist / gestureStartDist - 1f) * 300f
                    ParamStore["M_ZOOM"].rawValue    = (gestureStartZoom + zoomDelta).coerceIn(0f, 1000f)
                    val angleDelta = (angle - gestureStartAngle) / (2 * Math.PI.toFloat()) * 1000f
                    ParamStore["M_ANGLE"].rawValue   = ((gestureStartRot + angleDelta) % 1000f + 1000f) % 1000f
                    val moveFactor = 200f / maxOf(glView.width.toFloat(), 1f)
                    ParamStore["M_MOVE_X"].rawValue  = (gestureStartX + (cx - gesturePointer0.x) * moveFactor).coerceIn(0f, 1000f)
                    ParamStore["M_MOVE_Y"].rawValue  = (gestureStartY + (cy - gesturePointer0.y) * moveFactor).coerceIn(0f, 1000f)
                    refreshParamUI("M_ZOOM"); refreshParamUI("M_ANGLE")
                    refreshParamUI("M_MOVE_X"); refreshParamUI("M_MOVE_Y")
                }
            }
        }
        return true
    }

    // ── Add Source dialog ─────────────────────────────────────────────────────
    private fun showAddSourceDialog() {
        AlertDialog.Builder(this)
            .setTitle("Add Source")
            .setItems(arrayOf("📷 Camera (flip)", "📡 RTSP Stream", "🌀 Generative Shader", "🔁 Feedback Loop")) { _, which ->
                when (which) {
                    0 -> { // Flip existing camera
                        chain.sources.filterIsInstance<CameraSource>().firstOrNull()?.flip()
                        Toast.makeText(this, "Camera flipped", Toast.LENGTH_SHORT).show()
                    }
                    1 -> showRtspDialog()
                    2 -> {
                        val gen = GenerativeSource(this, GenerativeType.PLASMA, chain.W, chain.H)
                        glView.queueEvent { chain.sources.add(gen) }
                        Toast.makeText(this, "Plasma generator added", Toast.LENGTH_SHORT).show()
                    }
                    3 -> {
                        val fb = FeedbackSource(InjectionPoint.AFTER_COLOR)
                        chain.sources.add(fb)
                        Toast.makeText(this, "Feedback loop added", Toast.LENGTH_SHORT).show()
                    }
                }
            }.show()
    }

    private fun showRtspDialog() {
        val et = EditText(this).apply {
            hint = "rtsp://192.168.x.x:8080/h264_ulaw.sdp"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this).setTitle("RTSP URL").setView(et)
            .setPositiveButton("Add") { _, _ ->
                val url = et.text.toString().trim()
                if (url.startsWith("rtsp://")) {
                    val src = RtspSource(this, url)
                    glView.queueEvent { src.initGl(chain.W, chain.H); chain.sources.add(src) }
                    Toast.makeText(this, "RTSP source adding…", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Invalid RTSP URL", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    // ── Recording ─────────────────────────────────────────────────────────────
    private fun toggleRecording() {
        if (chain.isRecording) {
            chain.stopRecording()
            btnRecord.text = "● REC"
            btnRecord.setBackgroundColor(android.graphics.Color.parseColor("#661111"))
            Toast.makeText(this, "Saved to Movies/SpaceBeam", Toast.LENGTH_SHORT).show()
        } else {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "SpaceBeam_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpaceBeam")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
            val fd  = uri?.let { contentResolver.openFileDescriptor(it, "w")?.fileDescriptor }
            if (fd != null) {
                // Write to a temp file; MediaCodec needs a path
                val tmpFile = java.io.File(cacheDir, "rec_${System.currentTimeMillis()}.mp4")
                chain.startRecording(tmpFile.absolutePath)
                btnRecord.text = "■ STOP"
                btnRecord.setBackgroundColor(android.graphics.Color.RED)
            } else {
                Toast.makeText(this, "Cannot create video file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── Snapshot ──────────────────────────────────────────────────────────────
    private fun takeSnapshot() {
        // Read pixels from GL thread
        glView.queueEvent {
            val w = chain.W; val h = chain.H
            val buf = java.nio.ByteBuffer.allocateDirect(w * h * 4).order(java.nio.ByteOrder.nativeOrder())
            android.opengl.GLES20.glReadPixels(0, 0, w, h, android.opengl.GLES20.GL_RGBA, android.opengl.GLES20.GL_UNSIGNED_BYTE, buf)
            buf.rewind()
            val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            // GL reads bottom-up — flip
            val matrix = android.graphics.Matrix().apply { postScale(1f, -1f, w/2f, h/2f) }
            val flipped = android.graphics.Bitmap.createBitmap(bmp, 0, 0, w, h, matrix, true)
            bmp.recycle()
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "SpaceBeam_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SpaceBeam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            uri?.let { contentResolver.openOutputStream(it)?.use { os -> flipped.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, os) } }
            flipped.recycle()
            mainHandler.post { Toast.makeText(this, "Snapshot saved", Toast.LENGTH_SHORT).show() }
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────
    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("⚙ Settings")
            .setItems(arrayOf(
                "Reset all presets",
                "Connect Bluetooth MIDI",
                "MIDI: clear all mappings",
                "DSP: ${if (::dsp.isInitialized && dsp.running) "ON — tap to stop" else "OFF — tap to start"}",
                "Force screen on",
                "About"
            )) { _, which ->
                when (which) {
                    0 -> { AlertDialog.Builder(this).setTitle("Reset presets?")
                        .setPositiveButton("Reset") { _, _ ->
                            for (i in 0..8) ParamStore.presets[i] = null
                            Toast.makeText(this, "Presets reset", Toast.LENGTH_SHORT).show()
                        }.setNegativeButton("Cancel", null).show() }
                    1 -> showMidiScan()
                    2 -> { midi.clearMappings(); Toast.makeText(this,"MIDI cleared",Toast.LENGTH_SHORT).show() }
                    3 -> { if (::dsp.isInitialized) { if (dsp.running) dsp.stop() else dsp.start(); showSettings() } }
                    4 -> window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    5 -> AlertDialog.Builder(this).setTitle("SpaceBeam").setMessage(
                        "Full visual synthesizer\nOpenGL ES 2.0 · CameraX · ExoPlayer RTSP\n" +
                        "Spirit-1 DSP · MIDI · LFO · Sensor modulation\n\nBuilt with ❤"
                    ).setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun showMidiScan() {
        midi.scanAndConnect { devices ->
            if (devices.isEmpty()) {
                Toast.makeText(this, "No MIDI devices found", Toast.LENGTH_SHORT).show()
                return@scanAndConnect
            }
            val names = devices.map { it.properties.getString(android.media.midi.MidiDeviceInfo.PROPERTY_NAME) ?: "Device" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Select MIDI device")
                .setItems(names) { _, which -> midi.connect(devices[which]) }
                .show()
        }
    }

    // ── R stubs (since we're building layout programmatically) ────────────────
    object R {
        object id {
            val glContainer = android.view.View.generateViewId()
        }
    }
}
