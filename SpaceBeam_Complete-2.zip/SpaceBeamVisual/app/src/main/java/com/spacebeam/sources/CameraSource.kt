package com.spacebeam.sources

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner

/**
 * CameraSource: feeds CameraX preview into an OpenGL ES OES texture.
 * The OES texture is updated via SurfaceTexture each frame.
 */
class CameraSource(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    var useFront: Boolean = false
) : Source() {

    private val TAG = "CameraSource"

    private var surfaceTexture: SurfaceTexture? = null
    private var oesTexId: Int = -1
    private var frameAvailable = false

    // External OES program for sampling OES texture to a regular FBO
    private var oesFbo: com.spacebeam.engine.Fbo? = null
    private var oesProgram: com.spacebeam.engine.GlProgram? = null
    private var quad: com.spacebeam.engine.QuadRenderer? = null
    private var fboW = 0; private var fboH = 0

    override val texId: Int get() = oesFbo?.texId ?: -1

    /** Call once from GL thread after EGL context exists. */
    fun initGl(width: Int, height: Int) {
        fboW = width; fboH = height
        // Create OES texture
        val texIds = IntArray(1)
        GLES20.glGenTextures(1, texIds, 0)
        oesTexId = texIds[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)

        surfaceTexture = SurfaceTexture(oesTexId).apply {
            setOnFrameAvailableListener { frameAvailable = true }
        }

        // FBO for converting OES → regular RGBA
        oesFbo = com.spacebeam.engine.Fbo(width, height)
        quad   = com.spacebeam.engine.QuadRenderer()
        oesProgram = com.spacebeam.engine.GlProgram(OES_VERT, OES_FRAG)

        startCamera()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().apply {
                setSurfaceProvider { req ->
                    val surface = android.view.Surface(surfaceTexture)
                    req.provideSurface(surface, ContextCompat.getMainExecutor(context)) {}
                }
            }
            val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                           else          CameraSelector.DEFAULT_BACK_CAMERA
            try {
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, preview)
                Log.i(TAG, "Camera bound")
            } catch (e: Exception) { Log.e(TAG, "Camera bind failed", e) }
        }, ContextCompat.getMainExecutor(context))
    }

    fun flip() {
        useFront = !useFront
        startCamera()
    }

    override fun update() {
        if (!frameAvailable) return
        frameAvailable = false
        surfaceTexture?.updateTexImage()

        // Blit OES → FBO using external OES shader
        val fbo  = oesFbo  ?: return
        val prog = oesProgram ?: return
        val q    = quad ?: return

        fbo.bind()
        GLES20.glViewport(0, 0, fboW, fboH)
        prog.use()
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        prog.setInt("uTex", 0)
        // Pass the SurfaceTexture transform matrix
        val stMatrix = FloatArray(16)
        surfaceTexture?.getTransformMatrix(stMatrix)
        GLES20.glUniformMatrix4fv(
            GLES20.glGetUniformLocation(prog.id, "uSTMatrix"), 1, false, stMatrix, 0)
        q.draw(prog)
        fbo.unbind()
    }

    override fun release() {
        surfaceTexture?.release()
        oesFbo?.delete()
        oesProgram?.delete()
        quad?.delete()
        if (oesTexId >= 0) GLES20.glDeleteTextures(1, intArrayOf(oesTexId), 0)
    }

    companion object {
        private val OES_VERT = """
            attribute vec2 aPosition;
            attribute vec2 aTexCoord;
            uniform mat4 uSTMatrix;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
                vTexCoord = (uSTMatrix * vec4(aTexCoord, 0.0, 1.0)).xy;
            }
        """.trimIndent()

        private val OES_FRAG = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES uTex;
            varying vec2 vTexCoord;
            void main() { gl_FragColor = texture2D(uTex, vTexCoord); }
        """.trimIndent()
    }
}
