package com.spacebeam.sources

import android.opengl.GLES20

enum class BlendMode(val label: String, val glslId: Int) {
    MIX("Mix",0), ADD("Add",1), SCREEN("Screen",2), MULTIPLY("Multiply",3),
    DIFFERENCE("Diff",4), OVERLAY("Overlay",5), MAX("Max",6), MIN("Min",7), SUBTRACT("Sub",8)
}

enum class InjectionPoint { MIXER, AFTER_CAM_TRANSFORM, AFTER_COLOR, AFTER_EDGE, AFTER_KALEIDOSCOPE, SCREEN }

/** Base class for all visual sources. */
abstract class Source {
    var alpha: Float = 1f
    var blendMode: BlendMode = BlendMode.MIX
    var injectionPoint: InjectionPoint = InjectionPoint.MIXER
    var label: String = "Source"

    // Transform
    var zoom: Float = 1f
    var angle: Float = 0f
    var moveX: Float = 0f
    var moveY: Float = 0f
    var flipH: Boolean = false
    var flipV: Boolean = false

    /** GL texture ID produced by this source, or -1 if not ready. */
    abstract val texId: Int

    /** Called each frame before rendering; update internal texture. */
    abstract fun update()

    /** Release all GL resources. */
    abstract fun release()
}
