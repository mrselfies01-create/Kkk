package com.spacebeam.sources

import android.content.Context
import android.graphics.SurfaceTexture
import android.net.Uri
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.spacebeam.engine.Fbo
import com.spacebeam.engine.GlProgram
import com.spacebeam.engine.QuadRenderer

/** Streams RTSP video via ExoPlayer and exposes it as a GL texture. */
class RtspSource(private val context: Context, var url: String) : Source() {

    private val TAG = "RtspSource"

    private var player: ExoPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var oesTexId = -1
    private var oesFbo: Fbo? = null
    private var oesProgram: GlProgram? = null
    private var quad: QuadRenderer? = null
    private var frameAvailable = false
    private var fboW = 0; private var fboH = 0

    override val texId: Int get() = oesFbo?.texId ?: -1

    fun initGl(width: Int, height: Int) {
        fboW = width; fboH = height
        val ids = IntArray(1); GLES20.glGenTextures(1, ids, 0); oesTexId = ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        surfaceTexture = SurfaceTexture(oesTexId).apply {
            setOnFrameAvailableListener { frameAvailable = true }
        }
        oesFbo = Fbo(width, height)
        quad   = QuadRenderer()
        oesProgram = GlProgram(OES_VERT, OES_FRAG)
        startPlayer()
    }

    private fun startPlayer() {
        player = ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            repeatMode = Player.REPEAT_MODE_ALL
            val surface = surfaceTexture?.let { android.view.Surface(it) }
            if (surface != null) setVideoSurface(surface)
            addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Log.e(TAG, "RTSP error: ${error.message}")
                }
            })
            prepare()
            play()
        }
    }

    override fun update() {
        if (!frameAvailable) return
        frameAvailable = false
        surfaceTexture?.updateTexImage()
        val fbo  = oesFbo ?: return
        val prog = oesProgram ?: return
        val q    = quad ?: return
        fbo.bind()
        GLES20.glViewport(0, 0, fboW, fboH)
        prog.use()
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        prog.setInt("uTex", 0)
        val stm = FloatArray(16); surfaceTexture?.getTransformMatrix(stm)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog.id, "uSTMatrix"), 1, false, stm, 0)
        q.draw(prog)
        fbo.unbind()
    }

    override fun release() {
        player?.release(); player = null
        surfaceTexture?.release()
        oesFbo?.delete(); oesProgram?.delete(); quad?.delete()
        if (oesTexId >= 0) GLES20.glDeleteTextures(1, intArrayOf(oesTexId), 0)
    }

    companion object {
        val OES_VERT = """
            attribute vec2 aPosition; attribute vec2 aTexCoord;
            uniform mat4 uSTMatrix; varying vec2 vTexCoord;
            void main(){gl_Position=vec4(aPosition,0.,1.);vTexCoord=(uSTMatrix*vec4(aTexCoord,0.,1.)).xy;}
        """.trimIndent()
        val OES_FRAG = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES uTex; varying vec2 vTexCoord;
            void main(){gl_FragColor=texture2D(uTex,vTexCoord);}
        """.trimIndent()
    }
}
